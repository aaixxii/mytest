package com.nec.biomatcher.spec.services.exception;

import java.rmi.RemoteException;

import com.google.common.base.Throwables;

public class BioSearchJobControllerServiceException extends RemoteException {
	private static final long serialVersionUID = 1L;

	public BioSearchJobControllerServiceException() {
	}

	public BioSearchJobControllerServiceException(String message) {
		super(message);
	}

	public BioSearchJobControllerServiceException(String message, Throwable cause) {
		super(message + " : " + Throwables.getStackTraceAsString(cause));
	}

}
