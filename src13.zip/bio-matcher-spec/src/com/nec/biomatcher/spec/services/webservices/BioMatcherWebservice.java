package com.nec.biomatcher.spec.services.webservices;

import java.util.List;

import javax.jws.WebService;

import com.nec.biomatcher.spec.services.exception.BioMatcherWebserviceException;
import com.nec.biomatcher.spec.transfer.commands.BioCommandRequest;
import com.nec.biomatcher.spec.transfer.commands.BioCommandResult;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatusInfoDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

/**
 * The Interface BioMatcherWebservice.
 */
@WebService(name = "bioMatcherWebServiceInterface", targetNamespace = "http://webservices.biomatcher.nec.com/")
public interface BioMatcherWebservice {

	/**
	 * Echo.
	 *
	 * @param message
	 *            the message
	 * @return the string
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public String echo(String message) throws BioMatcherWebserviceException;

	/**
	 * Verify.
	 *
	 * @param verifyRequest
	 *            the verify request
	 * @return the verify job result dto
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public VerifyJobResultDto verify(VerifyJobRequestDto verifyRequest) throws BioMatcherWebserviceException;

	/**
	 * Submit verification job.
	 *
	 * @param verifyRequest
	 *            the verify request
	 * @return the string
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public String submitVerificationJob(VerifyJobRequestDto verifyRequest) throws BioMatcherWebserviceException;

	/**
	 * Gets the verification job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the verification job status
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public BioJobStatus getVerificationJobStatus(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Gets the verification job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the verification job result
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public VerifyJobResultDto getVerificationJobResult(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Delete verification job.
	 *
	 * @param jobId
	 *            the job id
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public void deleteVerificationJob(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Submit extraction job.
	 *
	 * @param jobRequestDto
	 *            the job request dto
	 * @return the string
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public String submitExtractionJob(ExtractJobRequestDto jobRequestDto) throws BioMatcherWebserviceException;

	/**
	 * Gets the extraction job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extraction job status
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public BioJobStatus getExtractionJobStatus(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Gets the extraction job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extraction job result
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public ExtractJobResultDto getExtractionJobResult(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Delete extraction job.
	 *
	 * @param jobId
	 *            the job id
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public void deleteExtractionJob(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Gets the biometric event status info.
	 *
	 * @param biometricId
	 *            the biometric id
	 * @return the biometric event status info
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public BiometricEventStatusInfoDto getBiometricEventStatusInfo(Long biometricId)
			throws BioMatcherWebserviceException;

	/**
	 * Gets the biometric event status info list.
	 *
	 * @param externalId
	 *            the external id
	 * @param eventId
	 *            the event id
	 * @param binId
	 *            the bin id
	 * @return the biometric event status info list
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public List<BiometricEventStatusInfoDto> getBiometricEventStatusInfoList(String externalId, String eventId,
			Integer binId) throws BioMatcherWebserviceException;

	/**
	 * Submit search job.
	 *
	 * @param jobRequestDto
	 *            the job request dto
	 * @return the string
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public String submitSearchJob(SearchJobRequestDto jobRequestDto) throws BioMatcherWebserviceException;

	/**
	 * Gets the search job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the search job status
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public BioJobStatus getSearchJobStatus(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Gets the search job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the search job result
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public SearchJobResultDto getSearchJobResult(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Delete search job.
	 *
	 * @param jobId
	 *            the job id
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public void deleteSearchJob(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Submit sync job.
	 *
	 * @param syncJobRequestDto
	 *            the sync job request dto
	 * @return the string
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public String submitSyncJob(SyncJobRequestDto syncJobRequestDto) throws BioMatcherWebserviceException;

	/**
	 * Gets the sync job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the sync job status
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public BioJobStatus getSyncJobStatus(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Gets the sync job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the sync job result
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public SyncJobResultDto getSyncJobResult(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Delete sync job.
	 *
	 * @param jobId
	 *            the job id
	 * @throws BioMatcherWebserviceException
	 *             the bio matcher webservice exception
	 */
	public void deleteSyncJob(String jobId) throws BioMatcherWebserviceException;

	/**
	 * Performs the bio command action using BioCommandRequest
	 * 
	 * @param bioCommandRequest
	 * @return BioCommandResult
	 * @throws BioMatcherWebserviceException
	 */
	public BioCommandResult performBioCommandAction(BioCommandRequest bioCommandRequest)
			throws BioMatcherWebserviceException;
}
