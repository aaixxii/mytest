package com.nec.biomatcher.spec.services.exception;

import java.rmi.RemoteException;

/**
 * The Class BioVerificationJobServiceException.
 */
public class BioVerificationJobServiceException extends RemoteException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio verification job service exception.
	 */
	public BioVerificationJobServiceException() {
		super("BioVerificationControllerException encountered.");
	}

	/**
	 * Instantiates a new bio verification job service exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioVerificationJobServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio verification job service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioVerificationJobServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
