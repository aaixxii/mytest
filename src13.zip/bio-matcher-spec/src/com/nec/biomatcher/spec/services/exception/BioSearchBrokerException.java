package com.nec.biomatcher.spec.services.exception;

import java.rmi.RemoteException;

/**
 * The Class BioSearchBrokerException.
 */
public class BioSearchBrokerException extends RemoteException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio match broker exception.
	 */
	public BioSearchBrokerException() {
		super("BioSearchBrokerException encountered.");
	}

	/**
	 * Instantiates a new bio match broker exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioSearchBrokerException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio match broker exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioSearchBrokerException(String message, Throwable cause) {
		super(message, cause);
	}
}
