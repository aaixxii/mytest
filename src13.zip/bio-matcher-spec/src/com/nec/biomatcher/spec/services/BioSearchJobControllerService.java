package com.nec.biomatcher.spec.services;

import java.util.List;

import com.nec.biomatcher.spec.services.exception.BioSearchJobControllerServiceException;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatusInfoDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

public interface BioSearchJobControllerService {

	public String submitSyncJob(SyncJobRequestDto syncJobRequestDto) throws BioSearchJobControllerServiceException;

	public BiometricEventStatusInfoDto getBiometricEventStatusInfo(Long biometricId)
			throws BioSearchJobControllerServiceException;

	public List<BiometricEventStatusInfoDto> getBiometricEventStatusInfoList(String externalId, String eventId,
			Integer binId) throws BioSearchJobControllerServiceException;

	public String submitSearchJob(SearchJobRequestDto jobRequestDto) throws BioSearchJobControllerServiceException;

	public void notifySearchJobExtractionCompleted(String searchJobId, ExtractJobResultDto extractionResult)
			throws BioSearchJobControllerServiceException;

	public BioJobStatus getSearchJobStatus(String searchJobId) throws BioSearchJobControllerServiceException;

	public SearchJobRequestDto getSearchJobRequest(String searchJobId) throws BioSearchJobControllerServiceException;

	public SearchJobResultDto getSearchJobResult(String searchJobId) throws BioSearchJobControllerServiceException;

	public void deleteSearchJob(String searchJobId) throws BioSearchJobControllerServiceException;

	public BioJobStatus getSyncJobStatus(String syncJobId) throws BioSearchJobControllerServiceException;

	public SyncJobResultDto getSyncJobResult(String syncJobId) throws BioSearchJobControllerServiceException;

	public void deleteSyncJob(String syncJobId) throws BioSearchJobControllerServiceException;

	public void notifySyncJobExtractionCompleted(String syncJobId, ExtractJobResultDto extractionResult)
			throws BioSearchJobControllerServiceException;

	public void syncRemoteBiometricEvents(String sourceSiteId, String targetSiteId,
			List<BiometricEventSyncTypeDto> biometricEventSyncList) throws BioSearchJobControllerServiceException;

}
