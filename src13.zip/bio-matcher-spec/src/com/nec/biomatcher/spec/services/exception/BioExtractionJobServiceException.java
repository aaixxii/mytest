package com.nec.biomatcher.spec.services.exception;

import java.rmi.RemoteException;

/**
 * The Class BioExtractionJobServiceException.
 */
public class BioExtractionJobServiceException extends RemoteException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio extraction job service exception.
	 */
	public BioExtractionJobServiceException() {
		super("BioExtractionJobServiceException encountered.");
	}

	/**
	 * Instantiates a new bio extraction job service exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioExtractionJobServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio extraction job service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioExtractionJobServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
