package com.nec.biomatcher.spec.services;

import com.nec.biomatcher.spec.services.exception.BioExtractionJobServiceException;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

/**
 * The Interface BioExtractionJobService.
 */
public interface BioExtractionJobService {

	/**
	 * Submit extraction job.
	 *
	 * @param jobRequestDto
	 *            the job request dto
	 * @return the string
	 * @throws BioExtractionJobServiceException
	 *             the bio extraction job service exception
	 */
	public String submitExtractionJob(ExtractJobRequestDto jobRequestDto) throws BioExtractionJobServiceException;

	/**
	 * Gets the extraction job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extraction job status
	 * @throws BioExtractionJobServiceException
	 *             the bio extraction job service exception
	 */
	public BioJobStatus getExtractionJobStatus(String jobId) throws BioExtractionJobServiceException;

	/**
	 * Gets the extraction job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extraction job result
	 * @throws BioExtractionJobServiceException
	 *             the bio extraction job service exception
	 */
	public ExtractJobResultDto getExtractionJobResult(String jobId) throws BioExtractionJobServiceException;

	/**
	 * Delete extraction job.
	 *
	 * @param jobId
	 *            the job id
	 * @throws BioExtractionJobServiceException
	 *             the bio extraction job service exception
	 */
	public void deleteExtractionJob(String jobId) throws BioExtractionJobServiceException;
}
