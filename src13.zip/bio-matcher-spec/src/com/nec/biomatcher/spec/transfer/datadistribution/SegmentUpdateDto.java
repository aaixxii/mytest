package com.nec.biomatcher.spec.transfer.datadistribution;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class SegmentUpdateDto implements Dto {
	private static final long serialVersionUID = 1L;

	private Integer segmentId;
	private SegmentStatus segmentStatus;
	private String templateType;
	private Integer totalRecords = 0;
	private Long startBiometricId;
	private Long endBiometricId;
	private Long startSegmentVersion;
	private Long endSegmentVersion;
	private List<String> segmentDownloadUrlList;
	private byte[] segmentChangeSetData;
	private byte maxEventCount;

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public Long getStartBiometricId() {
		return startBiometricId;
	}

	public void setStartBiometricId(Long startBiometricId) {
		this.startBiometricId = startBiometricId;
	}

	public Long getEndBiometricId() {
		return endBiometricId;
	}

	public void setEndBiometricId(Long endBiometricId) {
		this.endBiometricId = endBiometricId;
	}

	public Long getStartSegmentVersion() {
		return startSegmentVersion;
	}

	public void setStartSegmentVersion(Long startSegmentVersion) {
		this.startSegmentVersion = startSegmentVersion;
	}

	public Long getEndSegmentVersion() {
		return endSegmentVersion;
	}

	public void setEndSegmentVersion(Long endSegmentVersion) {
		this.endSegmentVersion = endSegmentVersion;
	}

	public byte[] getSegmentChangeSetData() {
		return segmentChangeSetData;
	}

	public void setSegmentChangeSetData(byte[] segmentChangeSetData) {
		this.segmentChangeSetData = segmentChangeSetData;
	}

	public boolean hadSegmentDownloadUrlList() {
		return segmentDownloadUrlList != null && segmentDownloadUrlList.size() > 0;
	}

	public List<String> getSegmentDownloadUrlList() {
		if (segmentDownloadUrlList == null) {
			segmentDownloadUrlList = new ArrayList<String>();
		}
		return segmentDownloadUrlList;
	}

	public void setSegmentDownloadUrlList(List<String> segmentDownloadUrlList) {
		this.segmentDownloadUrlList = segmentDownloadUrlList;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	public SegmentStatus getSegmentStatus() {
		return segmentStatus;
	}

	public void setSegmentStatus(SegmentStatus segmentStatus) {
		this.segmentStatus = segmentStatus;
	}

	public byte getMaxEventCount() {
		return maxEventCount;
	}

	public void setMaxEventCount(byte maxEventCount) {
		this.maxEventCount = maxEventCount;
	}

}
