package com.nec.biomatcher.spec.transfer.datadistribution;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class SegmentSyncResponseDto implements Dto {
	private static final long serialVersionUID = 1L;

	private String instanceId;
	private SegmentSyncRequestType requestType;
	private List<SegmentReportDto> segmentReportDtoList;

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public List<SegmentReportDto> getSegmentReportDtoList() {
		if (segmentReportDtoList == null) {
			segmentReportDtoList = new ArrayList<SegmentReportDto>();
		}
		return segmentReportDtoList;
	}

	public void setSegmentReportDtoList(List<SegmentReportDto> segmentReportDtoList) {
		this.segmentReportDtoList = segmentReportDtoList;
	}

	public SegmentSyncRequestType getRequestType() {
		return requestType;
	}

	public void setRequestType(SegmentSyncRequestType requestType) {
		this.requestType = requestType;
	}

}
