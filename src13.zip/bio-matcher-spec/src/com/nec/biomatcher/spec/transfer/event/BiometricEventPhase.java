package com.nec.biomatcher.spec.transfer.event;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum BiometricEventPhase {

	@XmlEnumValue("PENDING_SYNC")
	PENDING_SYNC("PS"),

	@XmlEnumValue("SYNC_COMPLETED")
	SYNC_COMPLETED("SC"),

	@XmlEnumValue("SYNC_ERROR")
	SYNC_ERROR("SE"),

	@XmlEnumValue("DATA_ERROR")
	DATA_ERROR("DE");

	/** The Constant valueMap. */
	private static final Map<String, BiometricEventPhase> valueMap = Arrays.stream(values())
			.collect(Collectors.toMap(BiometricEventPhase::getValue, (p) -> p));

	private final String value;

	BiometricEventPhase(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	/**
	 * Enum of.
	 *
	 * @param value
	 *            the value
	 * @return the biometric event phase
	 */
	public static BiometricEventPhase enumOf(String value) {
		return (BiometricEventPhase) valueMap.get(value);
	}
}
