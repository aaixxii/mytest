package com.nec.biomatcher.spec.transfer.commands;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobRequest;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SubmitJobActionRequest extends BioCommandRequest {
	private static final long serialVersionUID = 1L;

	private BioMatcherJobRequest jobRequest;

	public BioMatcherJobRequest getJobRequest() {
		return jobRequest;
	}

	public void setJobRequest(BioMatcherJobRequest jobRequest) {
		this.jobRequest = jobRequest;
	}

}
