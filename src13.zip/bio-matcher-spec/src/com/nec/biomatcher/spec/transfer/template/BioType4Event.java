package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType4Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer quality;
	private byte faceNFG2FeatureData[];

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public byte[] getFaceNFG2FeatureData() {
		return faceNFG2FeatureData;
	}

	public void setFaceNFG2FeatureData(byte[] faceNFG2FeatureData) {
		this.faceNFG2FeatureData = faceNFG2FeatureData;
	}
}
