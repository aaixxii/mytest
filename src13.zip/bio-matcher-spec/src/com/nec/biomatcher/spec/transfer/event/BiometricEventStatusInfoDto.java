package com.nec.biomatcher.spec.transfer.event;

import java.util.Date;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class BiometricEventStatusInfoDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private Long biometricId;

	/** The external id. */
	private String externalId;

	private String eventId;

	/** The bin id. */
	private Integer binId;

	private BiometricEventStatus status;

	private BiometricEventPhase phase;

	private String errorLogId;

	private Date errorDateTime;

	public Long getBiometricId() {
		return biometricId;
	}

	public void setBiometricId(Long biometricId) {
		this.biometricId = biometricId;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public BiometricEventStatus getStatus() {
		return status;
	}

	public void setStatus(BiometricEventStatus status) {
		this.status = status;
	}

	public BiometricEventPhase getPhase() {
		return phase;
	}

	public void setPhase(BiometricEventPhase phase) {
		this.phase = phase;
	}

	public String getErrorLogId() {
		return errorLogId;
	}

	public void setErrorLogId(String errorLogId) {
		this.errorLogId = errorLogId;
	}

	public Date getErrorDateTime() {
		return errorDateTime;
	}

	public void setErrorDateTime(Date errorDateTime) {
		this.errorDateTime = errorDateTime;
	}
}
