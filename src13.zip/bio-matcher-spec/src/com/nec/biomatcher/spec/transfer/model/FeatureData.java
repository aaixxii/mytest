package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class FeatureData.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FeatureData implements Dto {
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;
    
    /** The position. */
    @XmlAttribute(required = true)
    protected ImagePosition position;
    
    /** The algorithm type. */
    @XmlAttribute(required = true)
    protected AlgorithmType algorithmType;
    
    @XmlAttribute
    protected String feType;
    
    @XmlAttribute
    protected String primaryPattern;
    
    @XmlAttribute
    protected String secondaryPattern;
    
    @XmlAttribute
    protected String subType;
    
    @XmlAttribute(required = false)
    protected Integer iqlQuality ;
    
    @XmlElement(required = false, nillable = false)
    protected List<MinutiaData> minutiaDataList;
    
    @XmlElement(required = false, nillable = false)
    protected List<LfmlData> lfmlDataList;
    
    @XmlElement(required = false)
    protected FisData fisData;
    
    @XmlElement(required = false)
    protected PaextData paextData;
    
    /** The data. */
    protected byte[] data;
    
    private List<BioParameterGroupDto> keyValueGroupList;
    
    public FeatureData() {
        
    }
    
    public FeatureData(ImagePosition position, AlgorithmType algorithmType, byte[] data) {
        this.position = position;
        this.algorithmType = algorithmType;
        this.data = data;
    }
    
    public ImagePosition getPosition() {
        return position;
    }
    
    public void setPosition(ImagePosition position) {
        this.position = position;
    }
    
    public AlgorithmType getAlgorithmType() {
        return algorithmType;
    }
    
    public void setAlgorithmType(AlgorithmType algorithmType) {
        this.algorithmType = algorithmType;
    }
    
    public byte[] getData() {
        return data;
    }    
    
    public void setData(byte[] data) {
        this.data = data;
    }
    
    public boolean hasKeyValueGroupList() {
        return keyValueGroupList != null && keyValueGroupList.size() > 0;
    }
    
    public List<BioParameterGroupDto> getKeyValueGroupList() {
        if (keyValueGroupList == null) {
            keyValueGroupList = new ArrayList<>();
        }
        return keyValueGroupList;
    }
    
    public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
        this.keyValueGroupList = keyValueGroupList;
    }
    
    public String getFeType() {
        return feType;
    }
    
    public void setFeType(String feType) {
        this.feType = feType;
    }
    
    public String getSubType() {
        return subType;
    }
    
    public void setSubType(String subType) {
        this.subType = subType;
    }
    
    public List<MinutiaData> getMinutiaDataList() {
        if (this.minutiaDataList == null) {
            this.minutiaDataList = new ArrayList<>();
        }
        return this.minutiaDataList;
    }
    
    public void setMinutiaDataList(List<MinutiaData> minutiaDataList) {
        this.minutiaDataList = minutiaDataList;
    }
    
    public List<LfmlData> getLfmlDataList() {
        if (this.lfmlDataList == null) {
            this.lfmlDataList = new ArrayList<>();
        }
        return lfmlDataList;
    }
    
    public void setLfmlDataList(List<LfmlData> lfmlDataList) {
        this.lfmlDataList = lfmlDataList;
    }
    
    public String getPrimaryPattern() {
        return primaryPattern;
    }
    
    public void setPrimaryPattern(String primaryPattern) {
        this.primaryPattern = primaryPattern;
    }
    
    public String getSecondaryPattern() {
        return secondaryPattern;
    }
    
    public void setSecondaryPattern(String secondaryPattern) {
        this.secondaryPattern = secondaryPattern;
    }

    public FisData getFisData() {
        return fisData;
    }

    public void setFisData(FisData fisData) {
        this.fisData = fisData;
    }

    public PaextData getPaextData() {
        return paextData;
    }

    public void setPaextData(PaextData paextData) {
        this.paextData = paextData;
    }

    public Integer getIqlQuality() {
        return iqlQuality;
    }

    public void setIqlQuality(Integer iqlQuality) {
        this.iqlQuality = iqlQuality;
    }     
}
