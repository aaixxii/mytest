package com.nec.biomatcher.spec.transfer.commands;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SubmitJobActionResult extends BioCommandResult {
	private static final long serialVersionUID = 1L;

	private String jobId;

	public SubmitJobActionResult() {
	}

	public SubmitJobActionResult(String jobId) {
		this.jobId = jobId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

}
