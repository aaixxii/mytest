package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * The Enum BioJobStatus.
 */
@XmlEnum
public enum BioJobStatus {

	/** The pending. */
	@XmlEnumValue("PENDING")
	PENDING,

	/** The completed. */
	@XmlEnumValue("COMPLETED")
	COMPLETED,

	/** The not found. */
	@XmlEnumValue("NOT_FOUND")
	NOT_FOUND,

	@XmlEnumValue("FAILED")
	FAILED;
}
