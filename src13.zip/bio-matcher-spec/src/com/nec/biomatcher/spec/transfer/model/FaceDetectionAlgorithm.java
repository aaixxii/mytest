package com.nec.biomatcher.spec.transfer.model;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * The Enum FaceDetectionAlgorithm.
 */
@XmlEnum
public enum FaceDetectionAlgorithm {

	/** The S14_ slow. */
	@XmlEnumValue("S14_SLOW")
	S14_SLOW(4, "S14 slow and accurate"),

	/** The S14_ fast. */
	@XmlEnumValue("S14_FAST")
	S14_FAST(6, "S14 fast but inaccurate"),

	/** The S17_ slow. */
	@XmlEnumValue("S17_SLOW")
	S17_SLOW(8, "S17 slow and accurate"),

	/** The S17_ fast. */
	@XmlEnumValue("S17_FAST")
	S17_FAST(9, "S17 fast but inaccurate"),

	/** The D10. */
	@XmlEnumValue("D10")
	D10(10, "D10 frontal pose"),

	/** The D11. */
	@XmlEnumValue("D11")
	D11(11, "D11 side pose");

	/** The Constant valueMap. */
	private static final Map<Integer, FaceDetectionAlgorithm> valueMap = Arrays.stream(values())
			.collect(Collectors.toMap(FaceDetectionAlgorithm::getValue, (p) -> p));

	/** The value. */
	private final int value;

	/** The description. */
	private final String description;

	/**
	 * Instantiates a new face detection algorithm.
	 *
	 * @param value
	 *            the value
	 * @param description
	 *            the description
	 */
	FaceDetectionAlgorithm(int value, String description) {
		this.value = value;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public int getValue() {
		return value;
	}

	/**
	 * Enum of.
	 *
	 * @param value
	 *            the value
	 * @return the face detection algorithm
	 */
	public static FaceDetectionAlgorithm enumOf(Integer value) {
		return (FaceDetectionAlgorithm) valueMap.get(value);
	}
}
