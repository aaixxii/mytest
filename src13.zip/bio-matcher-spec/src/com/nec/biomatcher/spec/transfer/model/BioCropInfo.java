package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class BioCropInfo implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlElement
	protected PointDto center;

	@XmlAttribute
	protected Integer angle;

	protected BioRectangle rectangle;

	@XmlAttribute
	protected Boolean amputation;

	@XmlAttribute
	protected ImagePosition position;

	public Integer getAngle() {
		return angle;
	}

	public void setAngle(Integer angle) {
		this.angle = angle;
	}

	public PointDto getCenter() {
		return center;
	}

	public void setCenter(PointDto center) {
		this.center = center;
	}

	public BioRectangle getRectangle() {
		return rectangle;
	}

	public void setRectangle(BioRectangle rectangle) {
		this.rectangle = rectangle;
	}

	public Boolean getAmputation() {
		return amputation;
	}

	public void setAmputation(Boolean amputation) {
		this.amputation = amputation;
	}

	public ImagePosition getPosition() {
		return position;
	}

	public void setPosition(ImagePosition position) {
		this.position = position;
	}

}
