package com.nec.biomatcher.spec.transfer.job.payload;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class AbstractBioMatcherJobPayload.
 */
public abstract class AbstractBioMatcherJobPayload implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

}
