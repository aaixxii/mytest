package com.nec.biomatcher.spec.transfer.job.extract;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.BioParameterGroupDto;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.Image;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;

/**
 * The Class ExtractJobResultDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtractJobResultDto extends BioMatcherJobResult {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private String jobId;

	/** The template info list. */
	private List<TemplateInfo> templateInfoList;

	/** The error list. */
	private List<ErrorMessageDto> errorList;

	/** The status. */
	private BioJobStatus status;

	private String jobMode;

	private List<BioParameterGroupDto> keyValueGroupList;

	private List<Image> extractOutputImageList;

	/**
	 * Instantiates a new extract job result dto.
	 */
	public ExtractJobResultDto() {

	}

	/**
	 * Instantiates a new extract job result dto.
	 *
	 * @param status
	 *            the status
	 */
	public ExtractJobResultDto(BioJobStatus status) {
		this.status = status;
	}

	public List<TemplateInfo> getTemplateInfoList() {
		if (templateInfoList == null) {
			templateInfoList = new ArrayList<TemplateInfo>();
		}
		return templateInfoList;
	}

	public void setTemplateInfoList(List<TemplateInfo> templateInfoList) {
		this.templateInfoList = templateInfoList;
	}

	public boolean hasErrorList() {
		return errorList != null && errorList.size() > 0;
	}

	public List<ErrorMessageDto> getErrorList() {
		if (errorList == null) {
			errorList = new ArrayList<ErrorMessageDto>();
		}
		return errorList;
	}

	public void setErrorList(List<ErrorMessageDto> errorList) {
		this.errorList = errorList;
	}

	public BioJobStatus getStatus() {
		return status;
	}

	public void setStatus(BioJobStatus status) {
		this.status = status;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

	public List<BioParameterGroupDto> getKeyValueGroupList() {
		if (keyValueGroupList == null) {
			keyValueGroupList = new ArrayList<>();
		}
		return keyValueGroupList;
	}

	public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
		this.keyValueGroupList = keyValueGroupList;
	}

	public List<Image> getExtractOutputImageList() {
		return extractOutputImageList;
	}

	public void setExtractOutputImageList(List<Image> extractOutputImageList) {
		this.extractOutputImageList = extractOutputImageList;
	}

}
