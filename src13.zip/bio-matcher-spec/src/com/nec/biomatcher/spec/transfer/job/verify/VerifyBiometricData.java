package com.nec.biomatcher.spec.transfer.job.verify;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.FeatureData;
import com.nec.biomatcher.spec.transfer.model.FeatureExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;

/**
 * The Class VerifyBiometricData.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class VerifyBiometricData implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The candidate id. */
	@XmlAttribute(required = true)
	private String candidateId;

	/** The container id. */
	private Integer containerId;

	/** The feature data list. */
	private List<FeatureData> featureDataList;

	private List<TemplateInfo> templateInfoList;

	/** The image list. */
	// This is list because client might choose to send multiple modality images
	private List<FeatureExtractInputImage> imageList;

	public String getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public boolean hasFeatureDataList() {
		return featureDataList != null && featureDataList.size() > 0;
	}

	public List<FeatureData> getFeatureDataList() {
		if (featureDataList == null) {
			featureDataList = new ArrayList<>();
		}
		return featureDataList;
	}

	public void setFeatureDataList(List<FeatureData> featureDataList) {
		this.featureDataList = featureDataList;
	}

	public boolean hasImageList() {
		return imageList != null && imageList.size() > 0;
	}

	public List<FeatureExtractInputImage> getImageList() {
		if (imageList == null) {
			imageList = new ArrayList<>();
		}
		return imageList;
	}

	public void setImageList(List<FeatureExtractInputImage> imageList) {
		this.imageList = imageList;
	}

	public boolean hasTemplateInfoList() {
		return templateInfoList != null && templateInfoList.size() > 0;
	}

	public List<TemplateInfo> getTemplateInfoList() {
		if (templateInfoList == null) {
			templateInfoList = new ArrayList<>();
		}
		return templateInfoList;
	}

	public void setTemplateInfoList(List<TemplateInfo> templateInfoList) {
		this.templateInfoList = templateInfoList;
	}

}
