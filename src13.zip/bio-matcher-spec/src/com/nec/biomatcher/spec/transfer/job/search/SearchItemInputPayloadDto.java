package com.nec.biomatcher.spec.transfer.job.search;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.template.BioTemplatePayload;

/**
 * The Class SearchItemInputPayloadDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchItemInputPayloadDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The function id. */
	private String functionId;

	/** The template type. */
	protected String templateType;

	/** The template data. */
	private byte[] templateData;

	private BioTemplatePayload templatePayload;

	/** The max hit count. */
	private Integer maxHitCount;

	/** The min score threshold. */
	private Integer minScoreThreshold;

	/** The search options. */
	private SearchOptionsDto searchOptions;

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public byte[] getTemplateData() {
		return templateData;
	}

	public void setTemplateData(byte[] templateData) {
		this.templateData = templateData;
	}

	public Integer getMaxHitCount() {
		return maxHitCount;
	}

	public void setMaxHitCount(Integer maxHitCount) {
		this.maxHitCount = maxHitCount;
	}

	public Integer getMinScoreThreshold() {
		return minScoreThreshold;
	}

	public void setMinScoreThreshold(Integer minScoreThreshold) {
		this.minScoreThreshold = minScoreThreshold;
	}

	public SearchOptionsDto getSearchOptions() {
		return searchOptions;
	}

	public void setSearchOptions(SearchOptionsDto searchOptions) {
		this.searchOptions = searchOptions;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public BioTemplatePayload getTemplatePayload() {
		return templatePayload;
	}

	public void setTemplatePayload(BioTemplatePayload templatePayload) {
		this.templatePayload = templatePayload;
	}

}
