package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum BioImageEnhanceType {
	@XmlEnumValue("1")
	ENH_AGC("1"), @XmlEnumValue("6")
	ENH_DOG("6"), @XmlEnumValue("5")
	ENH_ENHANCE("5"), @XmlEnumValue("2")
	ENH_HISTOGRAM("2"), @XmlEnumValue("8")
	ENH_IAC_AUTO_LATENT_FINGER("8"), @XmlEnumValue("9")
	ENH_IAC_AUTO_LATENT_PALM("9"), @XmlEnumValue("10")
	ENH_NBRE("10"), @XmlEnumValue("0")
	ENH_SMOOTH("0"), @XmlEnumValue("7")
	ENH_STRETCH("7"), @XmlEnumValue("4")
	ENH_VRP_LAT("4"), @XmlEnumValue("3")
	ENH_VRP_TEN("3");
	private final String value;

	BioImageEnhanceType(String v) {
		value = v;
	}

	public String value() {
		return value;
	}

	public static BioImageEnhanceType fromValue(String v) {
		for (BioImageEnhanceType c : BioImageEnhanceType.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v.toString());
	}

}
