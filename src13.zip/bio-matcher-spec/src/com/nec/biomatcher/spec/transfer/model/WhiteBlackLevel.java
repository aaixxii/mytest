package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * The Enum WhiteBlackLevel.
 */
@XmlEnum
public enum WhiteBlackLevel {

	/** The blacklevel. */
	@XmlEnumValue("BLACKLEVEL")
	BLACKLEVEL("1"),

	/** The whitelevel. */
	@XmlEnumValue("WHITELEVEL")
	WHITELEVEL("0");

	/** The value. */
	private final String value;

	/**
	 * Instantiates a new white black level.
	 *
	 * @param v
	 *            the v
	 */
	WhiteBlackLevel(String v) {
		value = v;
	}

	/**
	 * Value.
	 *
	 * @return the string
	 */
	public String value() {
		return value;
	}

	/**
	 * From value.
	 *
	 * @param v
	 *            the v
	 * @return the white black level
	 */
	public static WhiteBlackLevel fromValue(String v) {
		for (WhiteBlackLevel c : WhiteBlackLevel.values()) {
			if (c.value.equals(v)) {
				return c;
			}
		}
		throw new IllegalArgumentException(v.toString());
	}

}
