package com.nec.biomatcher.spec.transfer.datadistribution;

public enum SegmentStatus {
	PREPARING, ACTIVE, DELETE, ERROR;
}
