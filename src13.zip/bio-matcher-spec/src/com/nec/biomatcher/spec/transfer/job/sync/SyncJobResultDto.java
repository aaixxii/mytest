package com.nec.biomatcher.spec.transfer.job.sync;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SyncJobResultDto extends BioMatcherJobResult {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	protected String jobId;

	/** The error list. */
	protected List<ErrorMessageDto> errorList;

	/** The status. */
	protected BioJobStatus status;

	protected List<BiometricEventSyncTypeDto> successfulEventSyncTypeDtoList;

	public SyncJobResultDto() {

	}

	public SyncJobResultDto(String jobId, BioJobStatus status) {
		this.jobId = jobId;
		this.status = status;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public boolean hasErrorList() {
		return errorList != null && errorList.size() > 0;
	}

	public List<ErrorMessageDto> getErrorList() {
		if (errorList == null) {
			errorList = new ArrayList<ErrorMessageDto>();
		}

		return errorList;
	}

	public void setErrorList(List<ErrorMessageDto> errorList) {
		this.errorList = errorList;
	}

	public BioJobStatus getStatus() {
		return status;
	}

	public void setStatus(BioJobStatus status) {
		this.status = status;
	}

	public List<BiometricEventSyncTypeDto> getSuccessfulEventSyncTypeDtoList() {
		if (successfulEventSyncTypeDtoList == null) {
			successfulEventSyncTypeDtoList = new ArrayList<>();
		}
		return successfulEventSyncTypeDtoList;
	}

	public void setSuccessfulEventSyncTypeDtoList(List<BiometricEventSyncTypeDto> successfulEventSyncTypeDtoList) {
		this.successfulEventSyncTypeDtoList = successfulEventSyncTypeDtoList;
	}

}
