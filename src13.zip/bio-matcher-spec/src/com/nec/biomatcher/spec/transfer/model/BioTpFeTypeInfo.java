package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class BioTpFeTypeInfo implements Dto {
	private static final long serialVersionUID = 1L;

	protected BioFeType rolledPc2FeType;
	protected BioFeType slapPc2FeType;
	protected BioFeType rolledFmp5FeType;
	protected BioFeType slapFmp5FeType;

	public BioTpFeTypeInfo() {
	}

	public BioTpFeTypeInfo(BioFeType rolledPc2FeType, BioFeType slapPc2FeType, BioFeType rolledFmp5FeType,
			BioFeType slapFmp5FeType) {
		this.rolledPc2FeType = rolledPc2FeType;
		this.slapPc2FeType = slapPc2FeType;
		this.rolledFmp5FeType = rolledFmp5FeType;
		this.slapFmp5FeType = slapFmp5FeType;
	}

	public BioFeType getRolledPc2FeType() {
		return rolledPc2FeType;
	}

	public void setRolledPc2FeType(BioFeType rolledPc2FeType) {
		this.rolledPc2FeType = rolledPc2FeType;
	}

	public BioFeType getSlapPc2FeType() {
		return slapPc2FeType;
	}

	public void setSlapPc2FeType(BioFeType slapPc2FeType) {
		this.slapPc2FeType = slapPc2FeType;
	}

	public BioFeType getRolledFmp5FeType() {
		return rolledFmp5FeType;
	}

	public void setRolledFmp5FeType(BioFeType rolledFmp5FeType) {
		this.rolledFmp5FeType = rolledFmp5FeType;
	}

	public BioFeType getSlapFmp5FeType() {
		return slapFmp5FeType;
	}

	public void setSlapFmp5FeType(BioFeType slapFmp5FeType) {
		this.slapFmp5FeType = slapFmp5FeType;
	}

}
