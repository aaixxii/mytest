package com.nec.biomatcher.spec.transfer.biometrics;

import javax.xml.bind.annotation.XmlSeeAlso;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class BiometricEventSyncTypeDto.
 */
@XmlSeeAlso({ InsertBiometricEventDto.class, DeleteBiometricEventDto.class, UpdateBiometricEventUserFlagDto.class })
public class BiometricEventSyncTypeDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The external id. */
	private String externalId;

	private String eventId;

	public BiometricEventSyncTypeDto() {

	}

	public BiometricEventSyncTypeDto(String externalId, String eventId) {
		this.externalId = externalId;
		this.eventId = eventId;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

}
