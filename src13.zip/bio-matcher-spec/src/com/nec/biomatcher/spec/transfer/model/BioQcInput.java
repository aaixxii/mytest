package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class BioQcInput implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlAttribute
	protected Integer duplicateCheckThreshold;
	@XmlAttribute
	protected BioQcMode qcMode;
	@XmlAttribute
	protected Integer rolledQualityThreshold;
	@XmlAttribute
	protected Integer sequenceCheckThreshold;
	@XmlAttribute
	protected Integer sequenceCheckThresholdLittle;
	@XmlAttribute
	protected Integer slapConfidenceThreshold;
	@XmlAttribute
	protected Integer slapHandConfidenceThreshold;
	@XmlAttribute
	protected Integer palmQualityThreshold;

	public Integer getPalmQualityThreshold() {
		return palmQualityThreshold;
	}

	public void setPalmQualityThreshold(Integer palmQualityThreshold) {
		this.palmQualityThreshold = palmQualityThreshold;
	}

	public Integer getDuplicateCheckThreshold() {
		return duplicateCheckThreshold;
	}

	public void setDuplicateCheckThreshold(Integer duplicateCheckThreshold) {
		this.duplicateCheckThreshold = duplicateCheckThreshold;
	}

	public BioQcMode getQcMode() {
		return qcMode;
	}

	public void setQcMode(BioQcMode qcMode) {
		this.qcMode = qcMode;
	}

	public Integer getRolledQualityThreshold() {
		return rolledQualityThreshold;
	}

	public void setRolledQualityThreshold(Integer rolledQualityThreshold) {
		this.rolledQualityThreshold = rolledQualityThreshold;
	}

	public Integer getSequenceCheckThreshold() {
		return sequenceCheckThreshold;
	}

	public void setSequenceCheckThreshold(Integer sequenceCheckThreshold) {
		this.sequenceCheckThreshold = sequenceCheckThreshold;
	}

	public Integer getSequenceCheckThresholdLittle() {
		return sequenceCheckThresholdLittle;
	}

	public void setSequenceCheckThresholdLittle(Integer sequenceCheckThresholdLittle) {
		this.sequenceCheckThresholdLittle = sequenceCheckThresholdLittle;
	}

	public Integer getSlapConfidenceThreshold() {
		return slapConfidenceThreshold;
	}

	public void setSlapConfidenceThreshold(Integer slapConfidenceThreshold) {
		this.slapConfidenceThreshold = slapConfidenceThreshold;
	}

	public Integer getSlapHandConfidenceThreshold() {
		return slapHandConfidenceThreshold;
	}

	public void setSlapHandConfidenceThreshold(Integer slapHandConfidenceThreshold) {
		this.slapHandConfidenceThreshold = slapHandConfidenceThreshold;
	}

}
