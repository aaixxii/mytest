package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum BioQcMode {
	@XmlEnumValue("2")
	QC_MODE_ADVANCED(2), @XmlEnumValue("1")
	QC_MODE_NORMAL(1), @XmlEnumValue("0")
	QC_MODE_OFF(0);
	private final int value;

	BioQcMode(int v) {
		value = v;
	}

	public int value() {
		return value;
	}
}
