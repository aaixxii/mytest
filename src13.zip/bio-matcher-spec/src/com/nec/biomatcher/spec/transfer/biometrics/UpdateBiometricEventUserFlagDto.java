package com.nec.biomatcher.spec.transfer.biometrics;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.UpdateUserFlagMode;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class UpdateBiometricEventUserFlagDto extends BiometricEventSyncTypeDto {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private UpdateUserFlagMode updateUserFlagMode;

	private List<Integer> binIdList;

	private String userFlags;

	public UpdateUserFlagMode getUpdateUserFlagMode() {
		return updateUserFlagMode;
	}

	public void setUpdateUserFlagMode(UpdateUserFlagMode updateUserFlagMode) {
		this.updateUserFlagMode = updateUserFlagMode;
	}

	public String getUserFlags() {
		return userFlags;
	}

	public void setUserFlags(String userFlags) {
		this.userFlags = userFlags;
	}

	public List<Integer> getBinIdList() {
		return binIdList;
	}

	public void setBinIdList(List<Integer> binIdList) {
		this.binIdList = binIdList;
	}

}
