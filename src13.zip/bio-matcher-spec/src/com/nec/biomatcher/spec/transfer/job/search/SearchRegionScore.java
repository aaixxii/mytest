package com.nec.biomatcher.spec.transfer.job.search;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class SearchRegionScore implements Dto {
	private static final long serialVersionUID = 1L;
	private int x;
	private int y;
	private int score;

	public SearchRegionScore() {

	}

	public SearchRegionScore(int x, int y, int score) {
		this.x = x;
		this.y = y;
		this.score = score;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

}
