package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtractManualData implements Dto {
	private static final long serialVersionUID = 1L;

	private byte[] editedMinutia;
	private byte[] markup;

	public byte[] getEditedMinutia() {
		return editedMinutia;
	}

	public void setEditedMinutia(byte[] editedMinutia) {
		this.editedMinutia = editedMinutia;
	}

	public byte[] getMarkup() {
		return markup;
	}

	public void setMarkup(byte[] markup) {
		this.markup = markup;
	}

}
