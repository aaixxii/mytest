package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;

public class SearchRawScoreDto implements Dto {
	private static final long serialVersionUID = 1L;

	private AlgorithmType algorithmType;
	private ImagePosition imagePosition;
	private String feType;
	private Integer score = 0;
	private Integer quality = 0;
	private String axis;
	private List<SearchRegionScore> regionScoreList;

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public ImagePosition getImagePosition() {
		return imagePosition;
	}

	public void setImagePosition(ImagePosition imagePosition) {
		this.imagePosition = imagePosition;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public String getAxis() {
		return axis;
	}

	public void setAxis(String axis) {
		this.axis = axis;
	}

	public String getFeType() {
		return feType;
	}

	public void setFeType(String feType) {
		this.feType = feType;
	}

	public boolean hasRegionScoreList() {
		return regionScoreList != null && regionScoreList.size() > 0;
	}

	public List<SearchRegionScore> getRegionScoreList() {
		if (regionScoreList == null) {
			regionScoreList = new ArrayList<SearchRegionScore>();
		}
		return regionScoreList;
	}

	public void setRegionScoreList(List<SearchRegionScore> regionScoreList) {
		this.regionScoreList = regionScoreList;
	}

}
