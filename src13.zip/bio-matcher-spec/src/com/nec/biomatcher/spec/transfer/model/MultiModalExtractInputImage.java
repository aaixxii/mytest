package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class MultiModalExtractInputImage.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MultiModalExtractInputImage extends ExtractInputImage {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The face extract input image. */
	private FaceExtractInputImage faceExtractInputImage;

	/** The iris extract input image. */
	private IrisExtractInputImage irisExtractInputImage;

	private FingerExtractInputImage fingerExtractInputImage;

	private PalmExtractInputImage palmExtractInputImage;

	public FaceExtractInputImage getFaceExtractInputImage() {
		return faceExtractInputImage;
	}

	public void setFaceExtractInputImage(FaceExtractInputImage faceExtractInputImage) {
		this.faceExtractInputImage = faceExtractInputImage;
	}

	public IrisExtractInputImage getIrisExtractInputImage() {
		return irisExtractInputImage;
	}

	public void setIrisExtractInputImage(IrisExtractInputImage irisExtractInputImage) {
		this.irisExtractInputImage = irisExtractInputImage;
	}

	public FingerExtractInputImage getFingerExtractInputImage() {
		return fingerExtractInputImage;
	}

	public void setFingerExtractInputImage(FingerExtractInputImage fingerExtractInputImage) {
		this.fingerExtractInputImage = fingerExtractInputImage;
	}

	public PalmExtractInputImage getPalmExtractInputImage() {
		return palmExtractInputImage;
	}

	public void setPalmExtractInputImage(PalmExtractInputImage palmExtractInputImage) {
		this.palmExtractInputImage = palmExtractInputImage;
	}
}
