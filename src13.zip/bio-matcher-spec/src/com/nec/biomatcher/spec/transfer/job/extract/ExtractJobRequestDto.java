package com.nec.biomatcher.spec.transfer.job.extract;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobRequest;

/**
 * The Class ExtractJobRequestDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtractJobRequestDto extends BioMatcherJobRequest {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The extract input payload. */
	protected ExtractInputPayloadDto extractInputPayload;

	/** The callback url. */
	protected String callbackUrl;

	/** The job timeout mill. */
	protected Long jobTimeoutMill;

	protected String jobMode;

	@XmlElement(required = false, nillable = true)
	protected Integer priority;

	public ExtractJobRequestDto() {

	}

	public ExtractJobRequestDto(ExtractInputPayloadDto extractInputPayload, String callbackUrl, Long jobTimeoutMill,
			String jobMode) {
		this.extractInputPayload = extractInputPayload;
		this.callbackUrl = callbackUrl;
		this.jobTimeoutMill = jobTimeoutMill;
		this.jobMode = jobMode;
	}

	public ExtractInputPayloadDto getExtractInputPayload() {
		return extractInputPayload;
	}

	public void setExtractInputPayload(ExtractInputPayloadDto extractInputPayload) {
		this.extractInputPayload = extractInputPayload;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public Long getJobTimeoutMill() {
		return jobTimeoutMill;
	}

	public void setJobTimeoutMill(Long jobTimeoutMill) {
		this.jobTimeoutMill = jobTimeoutMill;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

}
