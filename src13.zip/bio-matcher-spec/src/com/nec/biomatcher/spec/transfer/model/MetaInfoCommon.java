package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class MetaInfoCommon.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class MetaInfoCommon implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The gender. */
	@XmlAttribute
	protected GenderEnum gender;

	/** The race. */
	@XmlAttribute
	protected String race;

	/** The region. */
	@XmlElement(required = false, nillable = true)
	protected Long regionFlags;

	@XmlElement(required = false, nillable = true)
	protected String userFlags;

	/** The yob. */
	@XmlElement(required = false, nillable = true)
	protected Integer yob;

	/** The yob range. */
	@XmlElement(required = false, nillable = true)
	protected Integer yobRange;

	@XmlElement(required = false, nillable = true)
	protected Integer targetQualityThreshold;

	protected List<BioParameterDto> parameters;

	public GenderEnum getGender() {
		return gender;
	}

	public void setGender(GenderEnum gender) {
		this.gender = gender;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public Integer getYob() {
		return yob;
	}

	public void setYob(Integer yob) {
		this.yob = yob;
	}

	public Integer getYobRange() {
		return yobRange;
	}

	public void setYobRange(Integer yobRange) {
		this.yobRange = yobRange;
	}

	public Long getRegionFlags() {
		return regionFlags;
	}

	public void setRegionFlags(Long regionFlags) {
		this.regionFlags = regionFlags;
	}

	public String getUserFlags() {
		return userFlags;
	}

	public void setUserFlags(String userFlags) {
		this.userFlags = userFlags;
	}

	public boolean hasParameters() {
		return parameters != null && parameters.size() > 0;
	}

	public List<BioParameterDto> getParameters() {
		if (parameters == null) {
			parameters = new ArrayList<>();
		}
		return parameters;
	}

	public void setParameters(List<BioParameterDto> parameters) {
		this.parameters = parameters;
	}

	public Integer getTargetQualityThreshold() {
		return targetQualityThreshold;
	}

	public void setTargetQualityThreshold(Integer targetQualityThreshold) {
		this.targetQualityThreshold = targetQualityThreshold;
	}
}
