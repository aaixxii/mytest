package com.nec.biomatcher.spec.transfer.commands;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.nec.biomatcher.spec.transfer.model.BioMatcherFaultDetail;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({ DeleteJobActionResult.class, GetJobResultActionResult.class, GetJobStatusActionResult.class,
		SubmitJobActionResult.class })
public class BioCommandResult implements Serializable {
	private static final long serialVersionUID = 1L;

	private BioMatcherFaultDetail fault;

	public BioMatcherFaultDetail getFault() {
		return fault;
	}

	public void setFault(BioMatcherFaultDetail fault) {
		this.fault = fault;
	}
}
