package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class FaceInputDetection.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class FaceInputDetection implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The algorithm type. */
	@XmlAttribute(required = true)
	protected AlgorithmType algorithmType;

	/** The eye roll. */
	@XmlElement(required = false, nillable = true)
	protected Integer eyeRoll;

	/** The max eye distance. */
	@XmlElement(required = false, nillable = true)
	protected Integer maxEyeDistance;

	/** The min eye distance. */
	@XmlElement(required = false, nillable = true)
	protected Integer minEyeDistance;

	/** The reliability. */
	@XmlElement(required = false, nillable = true)
	protected Float reliability;

	/** The detection algorithm. */
	@XmlAttribute(required = false)
	protected FaceDetectionAlgorithm detectionAlgorithm;

	/** The face2 points. */
	@XmlElement(required = false)
	protected Face2Points face2Points;

	@XmlElement(required = false, nillable = true)
	protected Integer shrinkFactor;

	@XmlElement(required = false, nillable = true)
	protected List<BioParameterDto> parameters;

	public Integer getEyeRoll() {
		return eyeRoll;
	}

	public void setEyeRoll(Integer eyeRoll) {
		this.eyeRoll = eyeRoll;
	}

	public Integer getMaxEyeDistance() {
		return maxEyeDistance;
	}

	public void setMaxEyeDistance(Integer maxEyeDistance) {
		this.maxEyeDistance = maxEyeDistance;
	}

	public Integer getMinEyeDistance() {
		return minEyeDistance;
	}

	public void setMinEyeDistance(Integer minEyeDistance) {
		this.minEyeDistance = minEyeDistance;
	}

	public Float getReliability() {
		return reliability;
	}

	public void setReliability(Float reliability) {
		this.reliability = reliability;
	}

	public Face2Points getFace2Points() {
		return face2Points;
	}

	public void setFace2Points(Face2Points face2Points) {
		this.face2Points = face2Points;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public FaceDetectionAlgorithm getDetectionAlgorithm() {
		return detectionAlgorithm;
	}

	public void setDetectionAlgorithm(FaceDetectionAlgorithm detectionAlgorithm) {
		this.detectionAlgorithm = detectionAlgorithm;
	}

	public Integer getShrinkFactor() {
		return shrinkFactor;
	}

	public void setShrinkFactor(Integer shrinkFactor) {
		this.shrinkFactor = shrinkFactor;
	}

	public boolean hasParameters() {
		return parameters != null && parameters.size() > 0;
	}

	public List<BioParameterDto> getParameters() {
		if (parameters == null) {
			parameters = new ArrayList<>();
		}
		return parameters;
	}

	public void setParameters(List<BioParameterDto> parameters) {
		this.parameters = parameters;
	}

}
