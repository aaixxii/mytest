package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType38Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private BioPalmFeatureInfo lowerRight;
	private BioPalmFeatureInfo upperRight;
	private BioPalmFeatureInfo lowerLeft;
	private BioPalmFeatureInfo upperLeft;
	private BioPalmFeatureInfo writerRight;
	private BioPalmFeatureInfo writerLeft;

	public BioPalmFeatureInfo getLowerRight() {
		return lowerRight;
	}

	public void setLowerRight(BioPalmFeatureInfo lowerRight) {
		this.lowerRight = lowerRight;
	}

	public BioPalmFeatureInfo getUpperRight() {
		return upperRight;
	}

	public void setUpperRight(BioPalmFeatureInfo upperRight) {
		this.upperRight = upperRight;
	}

	public BioPalmFeatureInfo getLowerLeft() {
		return lowerLeft;
	}

	public void setLowerLeft(BioPalmFeatureInfo lowerLeft) {
		this.lowerLeft = lowerLeft;
	}

	public BioPalmFeatureInfo getUpperLeft() {
		return upperLeft;
	}

	public void setUpperLeft(BioPalmFeatureInfo upperLeft) {
		this.upperLeft = upperLeft;
	}

	public BioPalmFeatureInfo getWriterRight() {
		return writerRight;
	}

	public void setWriterRight(BioPalmFeatureInfo writerRight) {
		this.writerRight = writerRight;
	}

	public BioPalmFeatureInfo getWriterLeft() {
		return writerLeft;
	}

	public void setWriterLeft(BioPalmFeatureInfo writerLeft) {
		this.writerLeft = writerLeft;
	}

}
