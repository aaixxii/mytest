package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MinutiaData implements Dto {	

	private static final long serialVersionUID = 7672512977515473788L;

	@XmlAttribute(required = true)
	protected Integer index;

	@XmlElement
	protected Minutia minutia;
	
	
	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public Minutia getMinutia() {
		return minutia;
	}

	public void setMinutia(Minutia minutia) {
		this.minutia = minutia;
	}
}
