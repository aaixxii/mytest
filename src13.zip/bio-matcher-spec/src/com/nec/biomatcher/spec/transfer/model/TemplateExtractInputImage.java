package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class TemplateExtractInputImage.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class TemplateExtractInputImage implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The extract input image. */
	@XmlElement(nillable = false, required = true)
	protected ExtractInputImage extractInputImage;

	/** The template types. */
	@XmlElement(nillable = false, required = true)
	protected List<String> templateTypes;

	public ExtractInputImage getExtractInputImage() {
		return extractInputImage;
	}

	public void setExtractInputImage(ExtractInputImage extractInputImage) {
		this.extractInputImage = extractInputImage;
	}

	public List<String> getTemplateTypes() {
		if (templateTypes == null) {
			templateTypes = new ArrayList<String>();
		}
		return templateTypes;
	}

	public void setTemplateTypes(List<String> templateTypes) {
		this.templateTypes = templateTypes;
	}
}
