package com.nec.biomatcher.spec.transfer.model;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;

/**
 * The Enum AlgorithmType.
 */
@XmlEnum
public enum AlgorithmType {

	FACE_NEC_S17(1),

	FACE_NEC_S18(2),

	FACE_NEC_NFV2(3),

	FACE_NEC_NFG2(4),

	IRIS_NEC(11),

	IRIS_DELTA_ID(12),

	FINGER_CMLAF(21),

	FINGER_PC2(22),

	FINGER_FMP5(23),

	FINGER_PC3R(24),

	FINGER_LFML(25),

	FINGER_ELFT(26),

	FINGER_CML(27),
	
	FINGER_BT5(28),	
	
	FINGER_FIS(29),

	PALM_PC3R(31),

	PALM_LFML(32);

	/** The Constant valueMap. */
	private static final Map<Integer, AlgorithmType> valueMap = Arrays.stream(values())
			.collect(Collectors.toMap(AlgorithmType::getValue, (p) -> p));

	/** The value. */
	private final int value;

	/**
	 * Instantiates a new algorithm type.
	 *
	 * @param v
	 *            the v
	 */
	AlgorithmType(int v) {
		value = v;
	}

	public Integer getValue() {
		return value;
	}

	/**
	 * Enum of.
	 *
	 * @param value
	 *            the value
	 * @return the algorithm type
	 */
	public static AlgorithmType enumOf(Integer value) {
		return (AlgorithmType) valueMap.get(value);
	}
}
