package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class TemplateInfo.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class TemplateInfo implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The template type. */
	@XmlElement(required = true, nillable = false)
	protected String templateType;

	protected SubModality subModality;

	/** The template data. */
	protected byte[] templateData;

	@XmlElement(required = false, nillable = true)
	protected List<FeatureData> featureDataList;

	public TemplateInfo() {

	}

	public TemplateInfo(String templateType, byte[] templateData) {
		this.templateType = templateType;
		this.templateData = templateData;
	}

	public byte[] getTemplateData() {
		return templateData;
	}

	public void setTemplateData(byte[] templateData) {
		this.templateData = templateData;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public boolean hasFeatureDataList() {
		return featureDataList != null && featureDataList.size() > 0;
	}

	public List<FeatureData> getFeatureDataList() {
		if (featureDataList == null) {
			featureDataList = new ArrayList<FeatureData>();
		}
		return featureDataList;
	}

	public void setFeatureDataList(List<FeatureData> featureDataList) {
		this.featureDataList = featureDataList;
	}

	public SubModality getSubModality() {
		return subModality;
	}

	public void setSubModality(SubModality subModality) {
		this.subModality = subModality;
	}
}
