package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.template.BioTemplatePayload;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertTemplateInfo implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlElement(required = true, nillable = false)
	private Integer binId;

	/** The template type. */
	protected String templateType;

	/** The template data. */
	protected byte[] templateData;

	protected BioTemplatePayload templatePayload;

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public byte[] getTemplateData() {
		return templateData;
	}

	public void setTemplateData(byte[] templateData) {
		this.templateData = templateData;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public BioTemplatePayload getTemplatePayload() {
		return templatePayload;
	}

	public void setTemplatePayload(BioTemplatePayload templatePayload) {
		this.templatePayload = templatePayload;
	}
}
