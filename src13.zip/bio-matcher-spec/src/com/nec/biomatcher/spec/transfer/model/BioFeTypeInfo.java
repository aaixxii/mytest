package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class BioFeTypeInfo implements Dto {
	private static final long serialVersionUID = 1L;

	protected List<BioTpFeTypeInfo> xdblTpFeTypeInfoList;

	protected List<BioTpFeTypeInfo> rdblTpFeTypeInfoList;

	protected BioTpFeTypeInfo tlixTpFeTypeInfo;

	protected BioLpFeTypeInfo lixLpFeTypeInfo;

	protected BioLpFeTypeInfo llixLpFeTypeInfo;

	protected BioLpFeTypeInfo ldbxLpFeTypeInfo;

	public List<BioTpFeTypeInfo> getXdblTpFeTypeInfoList() {
		if (xdblTpFeTypeInfoList == null) {
			xdblTpFeTypeInfoList = new ArrayList<BioTpFeTypeInfo>();
		}
		return xdblTpFeTypeInfoList;
	}

	public void setXdblTpFeTypeInfoList(List<BioTpFeTypeInfo> xdblTpFeTypeInfoList) {
		this.xdblTpFeTypeInfoList = xdblTpFeTypeInfoList;
	}

	public BioLpFeTypeInfo getLixLpFeTypeInfo() {
		return lixLpFeTypeInfo;
	}

	public void setLixLpFeTypeInfo(BioLpFeTypeInfo lixLpFeTypeInfo) {
		this.lixLpFeTypeInfo = lixLpFeTypeInfo;
	}

	public BioLpFeTypeInfo getLlixLpFeTypeInfo() {
		return llixLpFeTypeInfo;
	}

	public void setLlixLpFeTypeInfo(BioLpFeTypeInfo llixLpFeTypeInfo) {
		this.llixLpFeTypeInfo = llixLpFeTypeInfo;
	}

	public BioLpFeTypeInfo getLdbxLpFeTypeInfo() {
		return ldbxLpFeTypeInfo;
	}

	public void setLdbxLpFeTypeInfo(BioLpFeTypeInfo ldbxLpFeTypeInfo) {
		this.ldbxLpFeTypeInfo = ldbxLpFeTypeInfo;
	}

	public BioTpFeTypeInfo getTlixTpFeTypeInfo() {
		return tlixTpFeTypeInfo;
	}

	public void setTlixTpFeTypeInfo(BioTpFeTypeInfo tlixTpFeTypeInfo) {
		this.tlixTpFeTypeInfo = tlixTpFeTypeInfo;
	}

	public List<BioTpFeTypeInfo> getRdblTpFeTypeInfoList() {
		if (rdblTpFeTypeInfoList == null) {
			rdblTpFeTypeInfoList = new ArrayList<BioTpFeTypeInfo>();
		}
		return rdblTpFeTypeInfoList;
	}

	public void setRdblTpFeTypeInfoList(List<BioTpFeTypeInfo> rdblTpFeTypeInfoList) {
		this.rdblTpFeTypeInfoList = rdblTpFeTypeInfoList;
	}
}