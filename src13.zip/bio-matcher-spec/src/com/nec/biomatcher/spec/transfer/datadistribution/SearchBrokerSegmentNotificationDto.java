package com.nec.biomatcher.spec.transfer.datadistribution;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.RangeDto;

public class SearchBrokerSegmentNotificationDto implements Dto {
	private static final long serialVersionUID = 1L;
	private Integer segmentId;
	private List<Long> corruptedDataVersionIdList;
	private List<RangeDto> syncCompletedVersionIdRangeList;

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public boolean hasCorruptedDataVersionIdList() {
		return corruptedDataVersionIdList != null;
	}

	public List<Long> getCorruptedDataVersionIdList() {
		if (corruptedDataVersionIdList == null) {
			corruptedDataVersionIdList = new ArrayList<>();
		}
		return corruptedDataVersionIdList;
	}

	public void setCorruptedDataVersionIdList(List<Long> corruptedDataVersionIdList) {
		this.corruptedDataVersionIdList = corruptedDataVersionIdList;
	}

	public boolean hasSyncCompletedVersionIdRangeList() {
		return syncCompletedVersionIdRangeList != null;
	}

	public List<RangeDto> getSyncCompletedVersionIdRangeList() {
		if (syncCompletedVersionIdRangeList == null) {
			syncCompletedVersionIdRangeList = new ArrayList<>();
		}
		return syncCompletedVersionIdRangeList;
	}

	public void setSyncCompletedVersionIdRangeList(List<RangeDto> syncCompletedVersionIdRangeList) {
		this.syncCompletedVersionIdRangeList = syncCompletedVersionIdRangeList;
	}
}
