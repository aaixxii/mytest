package com.nec.biomatcher.spec.transfer.job;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * The Enum BioMatcherJobType.
 */
@XmlType
@XmlEnum(String.class)
public enum BioMatcherJobType {

	@XmlEnumValue("ENROLL")
	ENROLL("ENROLL"),

	/** The extract. */
	@XmlEnumValue("EXTRACT")
	EXTRACT("EXTRACT"),

	/** The search. */
	@XmlEnumValue("SEARCH")
	SEARCH("SEARCH"),

	/** The verify. */
	@XmlEnumValue("VERIFY")
	VERIFY("VERIFY"),

	/** The extract verify. */
	@XmlEnumValue("EXTRACT_VERIFY")
	EXTRACT_VERIFY("EXTRACT_VERIFY"),

	/** The extract search. */
	@XmlEnumValue("EXTRACT_SEARCH")
	EXTRACT_SEARCH("EXTRACT_SEARCH");

	/** The description. */
	private String description;

	/**
	 * Instantiates a new bio matcher job type.
	 *
	 * @param description
	 *            the description
	 */
	private BioMatcherJobType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
