package com.nec.biomatcher.spec.transfer.datadistribution;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class SegmentSyncRequestDto implements Dto {
	private static final long serialVersionUID = 1L;

	private String instanceId;
	private SegmentSyncRequestType requestType;
	private List<SegmentUpdateDto> segmentUpdateDtoList;

	public String getInstanceId() {
		return instanceId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public boolean hasSegmentUpdates() {
		return segmentUpdateDtoList != null && segmentUpdateDtoList.size() > 0;
	}

	public List<SegmentUpdateDto> getSegmentUpdateDtoList() {
		if (segmentUpdateDtoList == null) {
			segmentUpdateDtoList = new ArrayList<SegmentUpdateDto>();
		}
		return segmentUpdateDtoList;
	}

	public void setSegmentUpdateDtoList(List<SegmentUpdateDto> segmentUpdateDtoList) {
		this.segmentUpdateDtoList = segmentUpdateDtoList;
	}

	public SegmentSyncRequestType getRequestType() {
		return requestType;
	}

	public void setRequestType(SegmentSyncRequestType requestType) {
		this.requestType = requestType;
	}

}
