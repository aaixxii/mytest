package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class FeatureExtractInputImage.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FeatureExtractInputImage implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The extract input image. */
	@XmlElement(nillable = false, required = true)
	protected ExtractInputImage extractInputImage;

	/** The algorithm types. */
	protected List<AlgorithmType> algorithmTypes;

	/**
	 * Instantiates a new feature extract input image.
	 */
	public FeatureExtractInputImage() {

	}

	/**
	 * Instantiates a new feature extract input image.
	 *
	 * @param extractInputImage
	 *            the extract input image
	 * @param algorithmTypes
	 *            the algorithm types
	 */
	public FeatureExtractInputImage(ExtractInputImage extractInputImage, AlgorithmType... algorithmTypes) {
		this.extractInputImage = extractInputImage;
		if (algorithmTypes != null && algorithmTypes.length > 0) {
			Collections.addAll(getAlgorithmTypes(), algorithmTypes);
		}
	}

	public List<AlgorithmType> getAlgorithmTypes() {
		if (algorithmTypes == null) {
			algorithmTypes = new ArrayList<AlgorithmType>();
		}
		return algorithmTypes;
	}

	public void setAlgorithmTypes(List<AlgorithmType> algorithmTypes) {
		this.algorithmTypes = algorithmTypes;
	}

	public ExtractInputImage getExtractInputImage() {
		return extractInputImage;
	}

	public void setExtractInputImage(ExtractInputImage extractInputImage) {
		this.extractInputImage = extractInputImage;
	}
}
