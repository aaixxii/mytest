package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class IrisExtractInputImage.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class IrisExtractInputImage extends ExtractInputImage {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The left eye image. */
	protected Image leftEyeImage;

	/** The right eye image. */
	protected Image rightEyeImage;

	/** The iris extraction parameters. */
	protected List<ExtractInputParameter> extractionParameters;

	/**
	 * Instantiates a new iris extract input image.
	 */
	public IrisExtractInputImage() {

	}

	/**
	 * Instantiates a new iris extract input image.
	 *
	 * @param leftEyeImage
	 *            the left eye image
	 * @param rightEyeImage
	 *            the right eye image
	 * @param irisExtractInputParameters
	 *            the iris extract input parameters
	 */
	public IrisExtractInputImage(Image leftEyeImage, Image rightEyeImage,
			ExtractInputParameter... extractInputParameters) {
		this.leftEyeImage = leftEyeImage;
		this.rightEyeImage = rightEyeImage;
		if (extractInputParameters != null && extractInputParameters.length > 0) {
			Collections.addAll(getExtractionParameters(), extractInputParameters);
		}
	}

	public Image getLeftEyeImage() {
		return leftEyeImage;
	}

	public void setLeftEyeImage(Image leftEyeImage) {
		this.leftEyeImage = leftEyeImage;
	}

	public Image getRightEyeImage() {
		return rightEyeImage;
	}

	public void setRightEyeImage(Image rightEyeImage) {
		this.rightEyeImage = rightEyeImage;
	}

	public boolean hasExtractionParameters() {
		return extractionParameters != null && extractionParameters.size() > 0;
	}

	public List<ExtractInputParameter> getExtractionParameters() {
		if (extractionParameters == null) {
			extractionParameters = new ArrayList<ExtractInputParameter>();
		}
		return extractionParameters;
	}

	public void setExtractionParameters(List<ExtractInputParameter> extractionParameters) {
		this.extractionParameters = extractionParameters;
	}
}
