package com.nec.biomatcher.spec.transfer.job.verify;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.Modality;

/**
 * The Class VerifyModalScore.
 */
public class VerifyModalScore implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The modal. */
	private Modality modal;

	/** The composite score. */
	private Double compositeScore;

	/** The individual score list. */
	private List<VerifyRawScoreDto> rawScoreList;

	public Modality getModal() {
		return modal;
	}

	public void setModal(Modality modal) {
		this.modal = modal;
	}

	public List<VerifyRawScoreDto> getRawScoreList() {
		if (rawScoreList == null) {
			rawScoreList = new ArrayList<VerifyRawScoreDto>();
		}
		return rawScoreList;
	}

	public void setRawScoreList(List<VerifyRawScoreDto> rawScoreList) {
		this.rawScoreList = rawScoreList;
	}

	public Double getCompositeScore() {
		return compositeScore;
	}

	public void setCompositeScore(Double compositeScore) {
		this.compositeScore = compositeScore;
	}
}
