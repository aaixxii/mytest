package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;

@XmlEnum
public enum SubModality {
	SUB_MODAL_FINGER_ROLL, SUB_MODAL_FINGER_SLAP;

	public String value() {
		return name();
	}

	public static SubModality fromValue(String v) {
		return valueOf(v);
	}
}
