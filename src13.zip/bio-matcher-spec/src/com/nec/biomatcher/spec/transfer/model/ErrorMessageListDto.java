package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ErrorMessageListDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private List<ErrorMessageDto> errors;

	public ErrorMessageListDto() {

	}

	public ErrorMessageListDto(ErrorMessageDto... errors) {
		if (errors != null) {
			this.errors = Arrays.asList(errors);
		}
	}

	public ErrorMessageListDto(List<ErrorMessageDto> errors) {
		this.errors = errors;
	}

	public List<ErrorMessageDto> getErrors() {
		if (errors == null) {
			errors = new ArrayList<ErrorMessageDto>();
		}
		return errors;
	}

	public void setErrors(List<ErrorMessageDto> errors) {
		this.errors = errors;
	}

}
