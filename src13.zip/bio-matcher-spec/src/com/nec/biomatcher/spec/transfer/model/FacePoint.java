package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class FacePoint.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class FacePoint implements Dto {
	private static final long serialVersionUID = 1L;

	/** The x. */
	@XmlAttribute
	protected Integer x;

	/** The y. */
	@XmlAttribute
	protected Integer y;

	public FacePoint() {

	}

	public FacePoint(Integer x, Integer y) {
		this.x = x;
		this.y = y;
	}

	public Integer getX() {
		return x;
	}

	public void setX(Integer x) {
		this.x = x;
	}

	public Integer getY() {
		return y;
	}

	public void setY(Integer y) {
		this.y = y;
	}

}
