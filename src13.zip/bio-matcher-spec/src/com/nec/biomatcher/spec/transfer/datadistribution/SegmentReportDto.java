package com.nec.biomatcher.spec.transfer.datadistribution;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class SegmentReportDto implements Dto {
	private static final long serialVersionUID = 1L;

	private String searchNodeId;
	private Integer segmentId;
	private Long segmentVersion;
	private Long startSegmentVersion;
	private Long endSegmentVersion;
	private SegmentStatus status;
	private Date reportDateTime;

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public SegmentStatus getStatus() {
		return status;
	}

	public void setStatus(SegmentStatus status) {
		this.status = status;
	}

	public Long getStartSegmentVersion() {
		return startSegmentVersion;
	}

	public void setStartSegmentVersion(Long startSegmentVersion) {
		this.startSegmentVersion = startSegmentVersion;
	}

	public Long getEndSegmentVersion() {
		return endSegmentVersion;
	}

	public void setEndSegmentVersion(Long endSegmentVersion) {
		this.endSegmentVersion = endSegmentVersion;
	}

	public Date getReportDateTime() {
		return reportDateTime;
	}

	public void setReportDateTime(Date reportDateTime) {
		this.reportDateTime = reportDateTime;
	}

	public Long getSegmentVersion() {
		return segmentVersion;
	}

	public void setSegmentVersion(Long segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public String getSearchNodeId() {
		return searchNodeId;
	}

	public void setSearchNodeId(String searchNodeId) {
		this.searchNodeId = searchNodeId;
	}

}
