package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class IrisExtractInputParameter.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class IrisExtractInputParameter extends ExtractInputParameter {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The face input detection. */
	@XmlElement(required = true, nillable = false)
	protected IrisInputDetection irisInputDetection;

	public IrisInputDetection getIrisInputDetection() {
		return irisInputDetection;
	}

	public void setIrisInputDetection(IrisInputDetection irisInputDetection) {
		this.irisInputDetection = irisInputDetection;
	}
}
