package com.nec.biomatcher.spec.transfer.model;

public enum BioParameterKeyEnum {
	EyeRoll, MaxEyeDistance, MinEyeDistance, Reliability, Algorithm, ShrinkFactor, Rotation, Speed, MATCH_THRESHOLD, USER_FLAG, REGION_FLAG, YOB, YOB_RANGE, GENDER, RACE, TARGET_QUALITY_THRESHOLD;
}
