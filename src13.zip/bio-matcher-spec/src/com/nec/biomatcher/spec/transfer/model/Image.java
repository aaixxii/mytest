package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class Image.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Image implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The data. */
	@XmlElement(required = true)
	protected byte[] data;

	/** The lob uri. */
	protected String lobUri;

	/** The dpi. */
	@XmlElement(required = false, nillable = true)
	protected Integer dpi;

	/** The width. */
	@XmlElement(required = false, nillable = true)
	protected Integer width;

	/** The height. */
	@XmlElement(required = false, nillable = true)
	protected Integer height;

	/** The type. */
	@XmlAttribute(required = true)
	protected ImageFormat type;

	@XmlAttribute(required = false)
	protected Boolean isBlackOnWhite;

	/** The position. */
	@XmlAttribute(required = false)
	protected ImagePosition position;

	@XmlElement(required = false, nillable = true)
	protected List<BioCropInfo> cropInfo;

	@XmlElement(required = false, nillable = true)
	protected Modality modality;

	@XmlElement(required = false, nillable = true)
	protected ExtractManualData manualData;

	@XmlElement(required = false, nillable = true)
	protected List<BioParameterGroupDto> keyValueGroupList;

	/**
	 * Instantiates a new image.
	 */
	public Image() {

	}

	/**
	 * Instantiates a new image.
	 *
	 * @param data
	 *            the data
	 */
	public Image(byte[] data) {
		this.data = data;
	}

	/**
	 * Instantiates a new image.
	 *
	 * @param data
	 *            the data
	 * @param type
	 *            the type
	 */
	public Image(byte[] data, ImageFormat type) {
		this.data = data;
		this.type = type;
	}

	/**
	 * Instantiates a new image.
	 *
	 * @param data
	 *            the data
	 * @param type
	 *            the type
	 * @param position
	 *            the position
	 */
	public Image(byte[] data, ImageFormat type, ImagePosition position) {
		this.data = data;
		this.type = type;
		this.position = position;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public Integer getDpi() {
		return dpi;
	}

	public void setDpi(Integer dpi) {
		this.dpi = dpi;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getHeight() {
		return height;
	}

	public void setHeight(Integer height) {
		this.height = height;
	}

	public ImageFormat getType() {
		return type;
	}

	public void setType(ImageFormat type) {
		this.type = type;
	}

	public String getLobUri() {
		return lobUri;
	}

	public void setLobUri(String lobUri) {
		this.lobUri = lobUri;
	}

	public ImagePosition getPosition() {
		return position;
	}

	public void setPosition(ImagePosition position) {
		this.position = position;
	}

	public Modality getModality() {
		return modality;
	}

	public void setModality(Modality modality) {
		this.modality = modality;
	}

	public ExtractManualData getManualData() {
		return manualData;
	}

	public void setManualData(ExtractManualData manualData) {
		this.manualData = manualData;
	}

	public boolean hasKeyValueGroupList() {
		return keyValueGroupList != null && !keyValueGroupList.isEmpty();
	}

	public List<BioParameterGroupDto> getKeyValueGroupList() {
		if (keyValueGroupList == null) {
			keyValueGroupList = new ArrayList<>();
		}
		return keyValueGroupList;
	}

	public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
		this.keyValueGroupList = keyValueGroupList;
	}

	public Boolean isBlackOnWhite() {
		return isBlackOnWhite;
	}

	public void setIsBlackOnWhite(Boolean isBlackOnWhite) {
		this.isBlackOnWhite = isBlackOnWhite;
	}

	public List<BioCropInfo> getCropInfo() {	
		if (cropInfo == null) {
			cropInfo = new ArrayList<>();
		}
		return cropInfo;
	}

	public void setCropInfo(List<BioCropInfo> cropInfo) {
		this.cropInfo = cropInfo;
	}
}
