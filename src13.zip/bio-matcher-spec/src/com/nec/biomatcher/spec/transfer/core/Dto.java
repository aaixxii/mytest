package com.nec.biomatcher.spec.transfer.core;

import java.io.Serializable;

/**
 * The Interface Dto.
 */
public interface Dto extends Serializable {

}
