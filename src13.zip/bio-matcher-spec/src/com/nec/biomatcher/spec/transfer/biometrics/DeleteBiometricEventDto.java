package com.nec.biomatcher.spec.transfer.biometrics;

import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class DeleteBiometricEventDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DeleteBiometricEventDto extends BiometricEventSyncTypeDto {
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private Set<Integer> binIdSet;

	public Set<Integer> getBinIdSet() {
		if (binIdSet == null) {
			binIdSet = new HashSet<>();
		}
		return binIdSet;
	}

	public void setBinIdSet(Set<Integer> binIdSet) {
		this.binIdSet = binIdSet;
	}
}
