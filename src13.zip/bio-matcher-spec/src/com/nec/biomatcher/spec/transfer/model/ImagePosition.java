package com.nec.biomatcher.spec.transfer.model;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

/**
 * The Enum ImagePosition.
 */
@XmlType
@XmlEnum(String.class)
public enum ImagePosition {

	UNKNOWN(0),

	ROLL_RTHUMB(1),

	ROLL_RINDEX(2),

	ROLL_RMIDDLE(3),

	ROLL_RRING(4),

	ROLL_RLITTLE(5),

	ROLL_LTHUMB(6),

	ROLL_LINDEX(7),

	ROLL_LMIDDLE(8),

	ROLL_LRING(9),

	ROLL_LLITTLE(10),

	SLAP_RTHUMB(11),

	SLAP_LTHUMB(12),

	SLAP_RFOUR(13),

	SLAP_LFOUR(14),

	SLAP_THUMBS(15),

	SLAP_RINDEX(40),

	SLAP_RMIDDLE(41),

	SLAP_RRING(42),

	SLAP_RLITTLE(43),

	SLAP_LINDEX(44),

	SLAP_LMIDDLE(45),

	SLAP_LRING(46),

	SLAP_LLITTLE(47),

	PALM_UNKNOWN(20),

	PALM_RFULL(21),

	PALM_RWRITER(22),

	PALM_LFULL(23),

	PALM_LWRITER(24),

	PALM_RLOWER(25),

	PALM_RUPPER(26),

	PALM_LLOWER(27),

	PALM_LUPPER(28),

	PALM_ROTHER(29),

	PALM_LOTHER(30),

	PALM_RINTERDIGITAL(31),

	PALM_RTHENAR(32),

	PALM_RHYPOTHENAR(33),

	PALM_LINTERDIGITAL(34),

	PALM_LTHENAR(35),

	PALM_LHYPOTHENAR(36),

	FRONTAL_FACE(51),

	RIGHT_IRIS(52),

	LEFT_IRIS(53),

	PLANTAR_UNKNOWN(60), PLANTAR_RSOLE(61), PLANTAR_LSOLE(62), PLANTAR_UNKNOWN_TOE(63), PLANTAR_RBIG_TOE(
			64), PLANTAR_R2ND_TOE(65), PLANTAR_RMIDDLE_TOE(66), PLANTAR_R4TH_TOE(67), PLANTAR_RLITTLE_TOE(
					68), PLANTAR_LBIG_TOE(69), PLANTAR_L2ND_TOE(70), PLANTAR_LMIDDLE_TOE(71), PLANTAR_L4TH_TOE(
							72), PLANTAR_LLITTLE_TOE(73), PLANTAR_RFRONT(74), PLANTAR_RBACK(75), PLANTAR_LFRONT(
									76), PLANTAR_LBACK(77), PLANTAR_RMIDDLE(78), PLANTAR_LMIDDLE(79);

	private static final Map<Integer, ImagePosition> valueMap = Arrays.stream(values())
			.collect(Collectors.toMap(ImagePosition::getPosition, (p) -> p));

	private final int position;

	ImagePosition(int position) {
		this.position = position;
	}

	public int getPosition() {
		return position;
	}

	public static ImagePosition enumOf(Integer position) {
		return (ImagePosition) valueMap.get(position);
	}

}
