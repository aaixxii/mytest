package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class ExtractInputImage.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({ FaceExtractInputImage.class, IrisExtractInputImage.class, FingerExtractInputImage.class,
		PalmExtractInputImage.class, MultiModalExtractInputImage.class })
public class ExtractInputImage implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	@XmlElement(required = false, nillable = true)
	protected List<BioParameterGroupDto> keyValueGroupList;

	public boolean hasKeyValueGroupList() {
		return keyValueGroupList != null && !keyValueGroupList.isEmpty();
	}

	public List<BioParameterGroupDto> getKeyValueGroupList() {
		if (keyValueGroupList == null) {
			keyValueGroupList = new ArrayList<>();
		}
		return keyValueGroupList;
	}

	public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
		this.keyValueGroupList = keyValueGroupList;
	}

}
