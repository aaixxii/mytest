package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType2Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer quality;
	private byte faceS18FeatureData[];

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public byte[] getFaceS18FeatureData() {
		return faceS18FeatureData;
	}

	public void setFaceS18FeatureData(byte[] faceS18FeatureData) {
		this.faceS18FeatureData = faceS18FeatureData;
	}

}
