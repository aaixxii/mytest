package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class IrisInputDetection implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlAttribute(required = true)
	protected AlgorithmType algorithmType;

	@XmlElement(required = false, nillable = true)
	protected Integer speedLevel;

	@XmlElement(required = false, nillable = true)
	protected List<BioParameterDto> parameters;

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public Integer getSpeedLevel() {
		return speedLevel;
	}

	public void setSpeedLevel(Integer speedLevel) {
		this.speedLevel = speedLevel;
	}

	public boolean hasParameters() {
		return parameters != null && parameters.size() > 0;
	}

	public List<BioParameterDto> getParameters() {
		if (parameters == null) {
			parameters = new ArrayList<>();
		}
		return parameters;
	}

	public void setParameters(List<BioParameterDto> parameters) {
		this.parameters = parameters;
	}

}
