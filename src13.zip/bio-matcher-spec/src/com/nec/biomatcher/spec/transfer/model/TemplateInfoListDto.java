package com.nec.biomatcher.spec.transfer.model;

import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class TemplateInfoListDto.
 */
public class TemplateInfoListDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The template info list. */
	protected List<TemplateInfo> templateInfoList;

	public List<TemplateInfo> getTemplateInfoList() {
		return templateInfoList;
	}

	public void setTemplateInfoList(List<TemplateInfo> templateInfoList) {
		this.templateInfoList = templateInfoList;
	}
}
