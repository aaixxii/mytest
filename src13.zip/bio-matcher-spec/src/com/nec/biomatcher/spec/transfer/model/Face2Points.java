package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class Face2Points.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class Face2Points implements Dto {
	private static final long serialVersionUID = 1L;

	/** The right eye center. */
	@XmlElement(required = true)
	protected FacePoint rightEyeCenter;

	/** The left eye center. */
	@XmlElement(required = true)
	protected FacePoint leftEyeCenter;

	public Face2Points() {

	}

	public Face2Points(FacePoint leftEyeCenter, FacePoint rightEyeCenter) {
		this.leftEyeCenter = leftEyeCenter;
		this.rightEyeCenter = rightEyeCenter;
	}

	public FacePoint getRightEyeCenter() {
		return rightEyeCenter;
	}

	public void setRightEyeCenter(FacePoint rightEyeCenter) {
		this.rightEyeCenter = rightEyeCenter;
	}

	public FacePoint getLeftEyeCenter() {
		return leftEyeCenter;
	}

	public void setLeftEyeCenter(FacePoint leftEyeCenter) {
		this.leftEyeCenter = leftEyeCenter;
	}

}
