package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioPalmFeatureInfo implements Dto {
	private static final long serialVersionUID = 1L;

	private Integer quality;
	private byte[] featureData;

	public BioPalmFeatureInfo() {

	}

	public BioPalmFeatureInfo(Integer quality, byte[] featureData) {
		this.featureData = featureData;
		this.quality = quality;
	}

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public byte[] getFeatureData() {
		return featureData;
	}

	public void setFeatureData(byte[] featureData) {
		this.featureData = featureData;
	}

}
