package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class FaceExtractInputParameter.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FaceExtractInputParameter extends ExtractInputParameter {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The face input detection. */
	@XmlElement(required = true, nillable = false)
	protected FaceInputDetection faceInputDetection;

	/**
	 * Instantiates a new face extract input parameter.
	 */
	public FaceExtractInputParameter() {

	}

	/**
	 * Instantiates a new face extract input parameter.
	 *
	 * @param faceInputDetection
	 *            the face input detection
	 */
	public FaceExtractInputParameter(FaceInputDetection faceInputDetection) {
		this.faceInputDetection = faceInputDetection;
	}

	public FaceInputDetection getFaceInputDetection() {
		return faceInputDetection;
	}

	public void setFaceInputDetection(FaceInputDetection faceInputDetection) {
		this.faceInputDetection = faceInputDetection;
	}

}
