package com.nec.biomatcher.spec.transfer.model;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class RangeDto implements Dto {
	private static final long serialVersionUID = 1L;

	private Long lowerBound;
	private Long upperBound;

	public RangeDto(Long lowerBound, Long upperBound) {
		this.lowerBound = lowerBound;
		this.upperBound = upperBound;
	}

	public Long getLowerBound() {
		return lowerBound;
	}

	public void setLowerBound(Long lowerBound) {
		this.lowerBound = lowerBound;
	}

	public Long getUpperBound() {
		return upperBound;
	}

	public void setUpperBound(Long upperBound) {
		this.upperBound = upperBound;
	}

}
