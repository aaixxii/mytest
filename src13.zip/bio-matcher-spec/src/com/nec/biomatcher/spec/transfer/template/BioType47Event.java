package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType47Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private BioPalmFeatureInfo interDigitalRight;
	private BioPalmFeatureInfo thenarRight;
	private BioPalmFeatureInfo hypothenarRight;
	private BioPalmFeatureInfo interDigitalLeft;
	private BioPalmFeatureInfo thenarLeft;
	private BioPalmFeatureInfo hypothenarLeft;
	private BioPalmFeatureInfo writerRight;
	private BioPalmFeatureInfo writerLeft;

	public BioPalmFeatureInfo getInterDigitalRight() {
		return interDigitalRight;
	}

	public void setInterDigitalRight(BioPalmFeatureInfo interDigitalRight) {
		this.interDigitalRight = interDigitalRight;
	}

	public BioPalmFeatureInfo getThenarRight() {
		return thenarRight;
	}

	public void setThenarRight(BioPalmFeatureInfo thenarRight) {
		this.thenarRight = thenarRight;
	}

	public BioPalmFeatureInfo getHypothenarRight() {
		return hypothenarRight;
	}

	public void setHypothenarRight(BioPalmFeatureInfo hypothenarRight) {
		this.hypothenarRight = hypothenarRight;
	}

	public BioPalmFeatureInfo getInterDigitalLeft() {
		return interDigitalLeft;
	}

	public void setInterDigitalLeft(BioPalmFeatureInfo interDigitalLeft) {
		this.interDigitalLeft = interDigitalLeft;
	}

	public BioPalmFeatureInfo getThenarLeft() {
		return thenarLeft;
	}

	public void setThenarLeft(BioPalmFeatureInfo thenarLeft) {
		this.thenarLeft = thenarLeft;
	}

	public BioPalmFeatureInfo getHypothenarLeft() {
		return hypothenarLeft;
	}

	public void setHypothenarLeft(BioPalmFeatureInfo hypothenarLeft) {
		this.hypothenarLeft = hypothenarLeft;
	}

	public BioPalmFeatureInfo getWriterRight() {
		return writerRight;
	}

	public void setWriterRight(BioPalmFeatureInfo writerRight) {
		this.writerRight = writerRight;
	}

	public BioPalmFeatureInfo getWriterLeft() {
		return writerLeft;
	}

	public void setWriterLeft(BioPalmFeatureInfo writerLeft) {
		this.writerLeft = writerLeft;
	}
}
