package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class SearchHitCandidate implements Dto {
	private static final long serialVersionUID = 1L;

	private String externalId;

	private Integer binId;
	private Integer score = 0;
	private String requestItemKey;
	private String searchNodeId;
	private List<SearchFusedScoreDto> fusedScoreList;

	private List<SearchHitEvent> hitEventList;

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public String getSearchNodeId() {
		return searchNodeId;
	}

	public void setSearchNodeId(String searchNodeId) {
		this.searchNodeId = searchNodeId;
	}

	public boolean hasHitEventList() {
		return hitEventList != null && hitEventList.size() > 0;
	}

	public int getHitEventCount() {
		return hitEventList == null ? 0 : hitEventList.size();
	}

	public List<SearchHitEvent> getHitEventList() {
		if (hitEventList == null) {
			hitEventList = new ArrayList<>();
		}
		return hitEventList;
	}

	public void setHitEventList(List<SearchHitEvent> hitEventList) {
		this.hitEventList = hitEventList;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Integer getBinId() {
		return binId;
	}

	public String getRequestItemKey() {
		return requestItemKey;
	}

	public void setRequestItemKey(String requestItemKey) {
		this.requestItemKey = requestItemKey;
	}

	public boolean hasFusedScoreList() {
		return fusedScoreList != null && fusedScoreList.size() > 0;
	}

	public List<SearchFusedScoreDto> getFusedScoreList() {
		if (fusedScoreList == null) {
			fusedScoreList = new ArrayList<>();
		}
		return fusedScoreList;
	}

	public void setFusedScoreList(List<SearchFusedScoreDto> fusedScoreList) {
		this.fusedScoreList = fusedScoreList;
	}
}
