package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class TenprintFingerInputImage extends ExtractInputImage {
	private static final long serialVersionUID = 1L;

	protected List<Image> images;

	protected List<ExtractInputParameter> extractionParameters;

	public List<Image> getImages() {
		if (images == null) {
			images = new ArrayList<>();
		}
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public boolean hasExtractionParameters() {
		return extractionParameters != null && extractionParameters.size() > 0;
	}

	public List<ExtractInputParameter> getExtractionParameters() {
		return extractionParameters;
	}

	public void setExtractionParameters(List<ExtractInputParameter> extractionParameters) {
		this.extractionParameters = extractionParameters;
	}

	/*
	 * public List<BioImageEnhanceType> getEnhancements() { return enhancements;
	 * }
	 * 
	 * public void setEnhancements(List<BioImageEnhanceType> enhancements) {
	 * this.enhancements = enhancements; }
	 * 
	 * public BioFeTypeInfo getFeTypeInfo() { return feTypeInfo; }
	 * 
	 * public void setFeTypeInfo(BioFeTypeInfo feTypeInfo) { this.feTypeInfo =
	 * feTypeInfo; }
	 * 
	 * public BioQcInput getQcInput() { return qcInput; }
	 * 
	 * public void setQcInput(BioQcInput qcInput) { this.qcInput = qcInput; }
	 * 
	 */

}
