package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;

/**
 * The Enum Modality.
 */
@XmlEnum
public enum Modality {

	/** The face. */
	FACE,
	/** The iris. */
	IRIS,
	/** The finger. */
	FINGER,
	/** The palm. */
	PALM,
	/** The multi modal. */
	MULTI_MODAL;

	/**
	 * Value.
	 *
	 * @return the string
	 */
	public String value() {
		return name();
	}

	/**
	 * From value.
	 *
	 * @param v
	 *            the v
	 * @return the modality
	 */
	public static Modality fromValue(String v) {
		return valueOf(v);
	}
}
