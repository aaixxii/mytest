package com.nec.biomatcher.spec.transfer.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;

@XmlEnum
public enum TemplateType {

	   TEMPLATE_TYPE_1(1, "FACE S17 Template"), TEMPLATE_TYPE_2(2, "FACE S18 Template"), TEMPLATE_TYPE_3(3, "FACE NFV2 Template"), TEMPLATE_TYPE_4(4, "FACE NFG2 Template"), TEMPLATE_TYPE_11(11, "IRIS NEC Template"), TEMPLATE_TYPE_12(12, "IRIS DELTA_ID Template"), TEMPLATE_TYPE_22(22, "IRIS DELTA_ID Deserialized Template"), TEMPLATE_TYPE_31(31,
	            "RDBTM or SDBTM CMLAF Template"), TEMPLATE_TYPE_32(32, "XDBTM CMLAF Template"), TEMPLATE_TYPE_33(33, "XDBL Template"), TEMPLATE_TYPE_34(34, "LDBX Template"), TEMPLATE_TYPE_35(35, "RDBTM or SDBTM CML Template"), TEMPLATE_TYPE_36(36, "RDBTM and SDBTM CML Template"), TEMPLATE_TYPE_37(37, "Full Palm PC3R Template"), TEMPLATE_TYPE_38(38,
	                    "Split Palm PC3R Template"), TEMPLATE_TYPE_39(39, "3 Part Palm PC3R Template"), TEMPLATE_TYPE_40(40, "Latent Palm PC3R Template"), TEMPLATE_TYPE_41(41,
	                            "RDBL or SDBL Template"), TEMPLATE_TYPE_42(42, "Rolled or Slap LFML Template"), TEMPLATE_TYPE_43(43, "Rolled and Slap LFML Template"), TEMPLATE_TYPE_44(44, "Latent Finger LFML Template"), TEMPLATE_TYPE_45(45, "Palm LFML Template"), TEMPLATE_TYPE_46(46, "Latent Palm LFML Template"), TEMPLATE_TYPE_47(47, "3 Part Palm LFML Template"), TEMPLATE_TYPE_48(48, "Latent Palm LFML Template"),TEMPLATE_TYPE_49(49, "ELFT Template");

	/** The Constant valueMap. */
	public static final Map<Integer, TemplateType> valueMap = Collections.unmodifiableMap(
			Arrays.stream(values()).collect(Collectors.toMap(TemplateType::getTemplateTypeCode, (p) -> p)));

	public static final Map<String, TemplateType> nameMap = Collections
			.unmodifiableMap(Arrays.stream(values()).collect(Collectors.toMap(TemplateType::name, (p) -> p)));

	/** The value. */
	private final int templateTypeCode;

	private final String description;

	/**
	 * Instantiates a new algorithm type.
	 *
	 * @param v
	 *            the v
	 */
	TemplateType(int templateTypeCode, String description) {
		this.templateTypeCode = templateTypeCode;
		this.description = description;
	}

	public int getTemplateTypeCode() {
		return templateTypeCode;
	}

	public String getDescription() {
		return description;
	}

	/**
	 * Enum of.
	 *
	 * @param value
	 *            the value
	 * @return the algorithm type
	 */
	public static TemplateType enumOf(Integer value) {
		return (TemplateType) valueMap.get(value);
	}

	public static final TemplateType getByName(String name) {
		return (TemplateType) nameMap.get(name);
	}

	public static final Integer getTemplateTypeCodeByName(String name) {
		TemplateType templateType = nameMap.get(name);
		return templateType == null ? null : templateType.getTemplateTypeCode();
	}
}
