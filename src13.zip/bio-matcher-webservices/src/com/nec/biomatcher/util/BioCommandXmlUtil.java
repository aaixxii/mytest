package com.nec.biomatcher.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.SchemaOutputResolver;
import javax.xml.transform.Result;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;

import com.nec.biomatcher.spec.transfer.commands.DeleteJobActionRequest;
import com.nec.biomatcher.spec.transfer.commands.DeleteJobActionResult;
import com.nec.biomatcher.spec.transfer.commands.GetJobResultActionRequest;
import com.nec.biomatcher.spec.transfer.commands.GetJobResultActionResult;
import com.nec.biomatcher.spec.transfer.commands.GetJobStatusActionRequest;
import com.nec.biomatcher.spec.transfer.commands.GetJobStatusActionResult;
import com.nec.biomatcher.spec.transfer.commands.SubmitJobActionRequest;
import com.nec.biomatcher.spec.transfer.commands.SubmitJobActionResult;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;

public class BioCommandXmlUtil {
	private static final Logger logger = Logger.getLogger(BioCommandXmlUtil.class);

	private static JAXBContext jaxbContext;
	private static String schema;

	public static byte[] serialize(BioMatcherJobResult bioMatcherJobResult) throws Throwable {
		try {
			if (jaxbContext == null) {
				initializeJAXBContext();
			}

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			jaxbContext.createMarshaller().marshal(bioMatcherJobResult, baos);

			return baos.toByteArray();
		} catch (Throwable th) {
			logger.error("Error in serialize: " + th.getMessage(), th);
			throw th;
		}
	}

	public static String getSchema() throws Throwable {
		logger.info("In BioCommandXmlUtil.getSchema: " + new Date());
		try {
			if (schema == null) {
				initializeSchema();
			}

			return schema;
		} catch (Throwable th) {
			logger.error("Error in getSchema: " + th.getMessage(), th);
			throw th;
		}
	}

	private static synchronized void initializeSchema() throws Throwable {
		if (schema == null) {
			if (jaxbContext == null) {
				initializeJAXBContext();
			}

			StringWriter schemaWriter = new StringWriter();
			SchemaOutputResolver schemaOutputResolver = new SchemaOutputResolver() {
				public Result createOutput(String namespaceUri, String suggestedFileName) throws IOException {
					StreamResult result = new StreamResult(schemaWriter);
					result.setSystemId(suggestedFileName);
					return result;
				}
			};

			jaxbContext.generateSchema(schemaOutputResolver);

			schema = schemaWriter.toString();
		}
	}

	private static synchronized void initializeJAXBContext() throws Exception {
		if (jaxbContext == null) {
			jaxbContext = JAXBContext.newInstance(VerifyJobRequestDto.class, VerifyJobResultDto.class,
					ExtractJobRequestDto.class, ExtractJobResultDto.class, SearchJobRequestDto.class,
					SearchJobResultDto.class, SyncJobRequestDto.class, SyncJobResultDto.class,
					DeleteJobActionRequest.class, DeleteJobActionResult.class, GetJobResultActionRequest.class,
					GetJobResultActionResult.class, GetJobStatusActionRequest.class, GetJobStatusActionResult.class,
					SubmitJobActionRequest.class, SubmitJobActionResult.class);
		}
	}
}
