package com.nec.biomatcher.web.controller.home;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/secured/home")
public class HomeController {

	private Logger logger = Logger.getLogger(this.getClass().getName());

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView index() {
		logger.info("In HomeController");
		return new ModelAndView("home");
	}
}
