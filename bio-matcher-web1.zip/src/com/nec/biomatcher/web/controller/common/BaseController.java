package com.nec.biomatcher.web.controller.common;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.base.MoreObjects;

public abstract class BaseController {
	// protected final Logger logger = Logger.getLogger(getClass().getName());

	@Autowired
	private MessageSource messageSource;

	protected String getMessage(String code, Object[] args, HttpServletRequest request) {
		String msg = messageSource.getMessage(code, args, request.getLocale());
		return msg;
	}

	@RequestMapping(value = "/mainIndex", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request) {
		String tileName = MoreObjects.firstNonNull(request.getParameter("tileName"), "home");
		return new ModelAndView(tileName);
	}
}
