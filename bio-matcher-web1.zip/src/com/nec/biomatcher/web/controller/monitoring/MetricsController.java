package com.nec.biomatcher.web.controller.monitoring;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Supplier;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.hazelcast.core.ISet;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.metrics.MetricsFileStorage;
import com.nec.biomatcher.core.framework.cache.CacheExpiryParam;
import com.nec.biomatcher.core.framework.cache.FunctionalCacheService;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CheckedSupplier;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

@Controller
@RequestMapping(value = "/admin/metrics")
public class MetricsController {
	private static final Logger logger = Logger.getLogger(MetricsController.class);

	private BioParameterService bioParameterService = (BioParameterService) SpringServiceManager
			.getBean("bioParameterService");
	private BioMatcherConfigService bioMatcherConfigService = (BioMatcherConfigService) SpringServiceManager
			.getBean("bioMatcherConfigService");
	private BioMatchManagerService bioMatchManagerService = (BioMatchManagerService) SpringServiceManager
			.getBean("bioMatchManagerService");
	private MetricsFileStorage metricsFileStorage = (MetricsFileStorage) SpringServiceManager
			.getBean("metricsFileStorage");
	private FunctionalCacheService functionalCacheService = SpringServiceManager.getBean("functionalCacheService");

	private static final Supplier<Integer> fileStorageReporterDelaySeconds = BioParameterService
			.getIntSupplier("METRICS_FILE_STORAGE_REPORTER_DELAY_SECONDS", "DEFAULT", 20);
	private static final CacheExpiryParam serverMetricsWindowDataCacheParam = CacheExpiryParam.ttl(60,
			"SERVER_METRICS_WINDOW_DATA_CACHE_TTL_SECONDS");
	private static final CacheExpiryParam serverMetricsLatestDataCacheParam = CacheExpiryParam.ttl(20,
			"SERVER_METRICS_WINDOW_DATA_CACHE_TTL_SECONDS");
	private static final CacheExpiryParam eventMetricsCacheParam = CacheExpiryParam.ttl(120,
			"EVENT_METRICS_CHART_DATA_CACHE_TTL_SECONDS");
	private static final CacheExpiryParam scLoadMetricsCacheParam = CacheExpiryParam.ttl(60,
			"SC_LOAD_METRICS_CHART_DATA_CACHE_TTL_SECONDS");
	private static CheckedSupplier<List<String>> GET_METRICS_DATA_UPDATES_SUPPLIER;
	private static CheckedSupplier<List<String>> GET_FULL_METRICS_DATA_SUPPLIER;
	private static CheckedSupplier<String> GET_BIOMETRIC_EVENT_STATS_DATA_SUPPLIER;
	private static CheckedSupplier<String> GET_SEARCH_CONTROLLER_STATS_DATA_SUPPLIER;

	@RequestMapping(value = "/getMetricsServerList", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getMetricsServerList(HttpServletRequest request) {
		logger.trace("In MetricsController.getMetricsServerList: " + new Date());
		try {
			Set<String> serverHostSet = bioMatcherConfigService.getServerHostnameSet(BioServerType.MANAGER);

			JsonArray jsonServerHostArray = new JsonArray();

			serverHostSet.forEach((serverHost) -> jsonServerHostArray.add(new JsonPrimitive(serverHost)));

			JsonObject jsonResponse = new JsonObject();
			jsonResponse.add("data", jsonServerHostArray);
			return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
		} catch (Throwable th) {
			logger.error("Error in getMetricsServerList: " + th.getMessage(), th);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/getServerMetricsData", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getMetricsData(HttpServletRequest request) {
		logger.trace("In MetricsController.getServerMetricsData: updatesFlag: " + request.getParameter("updatesFlag"));
		try {
			boolean updatesFlag = Boolean.valueOf(request.getParameter("updatesFlag"));

			List<String> metricDataList = null;

			if (updatesFlag) {

				if (GET_METRICS_DATA_UPDATES_SUPPLIER == null) {
					GET_METRICS_DATA_UPDATES_SUPPLIER = () -> {
						List<String> tempMetricLatestDataList = new ArrayList<>();
						Set<String> serverIdList = bioMatcherConfigService.getServerHostnameSet(BioServerType.MANAGER);
						for (String serverHost : serverIdList) {
							String metricData = metricsFileStorage.getLatestMetricData(serverHost);
							if (metricData != null) {
								tempMetricLatestDataList.add(metricData);
							}
						}
						return tempMetricLatestDataList;
					};
				}

				serverMetricsLatestDataCacheParam.timeToLiveSeconds = fileStorageReporterDelaySeconds.get();
				metricDataList = functionalCacheService.getCachedValue(GET_METRICS_DATA_UPDATES_SUPPLIER,
						serverMetricsLatestDataCacheParam);
			} else {
				if (GET_FULL_METRICS_DATA_SUPPLIER == null) {
					GET_FULL_METRICS_DATA_SUPPLIER = () -> {
						int defaultChartWindowMinutes = bioParameterService
								.getParameterValue("DEFAULT_CHART_WINDOW_MINUTES", "ADMIN", 30);
						Set<String> serverIdList = bioMatcherConfigService.getServerHostnameSet(BioServerType.MANAGER);
						List<String> tempMetricWindowDataList = new ArrayList<>();
						Calendar calendar = Calendar.getInstance();
						calendar.add(Calendar.MINUTE, -1 * defaultChartWindowMinutes);
						for (String serverHost : serverIdList) {
							tempMetricWindowDataList
									.addAll(metricsFileStorage.getMetricDataAfterMarker(serverHost, calendar));
						}
						return tempMetricWindowDataList;
					};
				}
				metricDataList = functionalCacheService.getCachedValue(GET_FULL_METRICS_DATA_SUPPLIER,
						serverMetricsWindowDataCacheParam);
			}

			JsonParser jsonParser = new JsonParser();
			JsonArray jsonArray = new JsonArray();
			if (metricDataList != null) {
				for (String metricData : metricDataList) {
					try {
						jsonArray.add(jsonParser.parse(metricData));
					} catch (Throwable th) {
						logger.error("Error in getServerMetricsData while parsing metricData: ->{" + metricData
								+ "}<- : " + th.getMessage(), th);
					}
				}
			}

			JsonObject jsonObject = new JsonObject();
			jsonObject.add("data", jsonArray);

			return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
		} catch (Throwable th) {
			logger.error("Error in getServerMetricsData: " + th.getMessage(), th);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/getBiometricEventStatsData", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getBiometricEventStatsData(HttpServletRequest request) {
		logger.trace("In MetricsController.getBiometricEventCountData: " + new Date());
		try {
			if (GET_BIOMETRIC_EVENT_STATS_DATA_SUPPLIER == null) {
				GET_BIOMETRIC_EVENT_STATS_DATA_SUPPLIER = () -> {

					Map<BiKey<Integer, Integer>, Long> eventCountByBinSegmentMap = bioMatchManagerService
							.getEventCountByBinIdSegmentId();

					Map<Integer, Long> eventStatsByBinMap = new HashMap<>();

					JsonArray segmentStatsJsonArray = new JsonArray();
					eventCountByBinSegmentMap.forEach((binIdSegmentIdKey, eventCount) -> {
						JsonObject jsonObject = new JsonObject();
						jsonObject.addProperty("binId", binIdSegmentIdKey.getA());
						jsonObject.addProperty("segmentId", binIdSegmentIdKey.getB());
						jsonObject.addProperty("count", eventCount);
						segmentStatsJsonArray.add(jsonObject);

						eventStatsByBinMap.compute(binIdSegmentIdKey.getA(), (binId, oldEventCount) -> {
							return oldEventCount == null ? eventCount : (oldEventCount + eventCount);
						});
					});

					JsonArray binStatsJsonArray = new JsonArray();
					eventStatsByBinMap.forEach((binId, eventCount) -> {
						JsonObject jsonObject = new JsonObject();
						jsonObject.addProperty("binId", binId);
						jsonObject.addProperty("count", eventCount);
						binStatsJsonArray.add(jsonObject);
					});

					JsonObject jsonStats = new JsonObject();
					jsonStats.add("eventCountByBin", binStatsJsonArray);
					jsonStats.add("eventCountBySegment", segmentStatsJsonArray);

					JsonObject jsonResponse = new JsonObject();
					jsonResponse.add("data", jsonStats);

					return jsonResponse.toString();
				};
			}

			String eventStatData = functionalCacheService.getCachedValue(GET_BIOMETRIC_EVENT_STATS_DATA_SUPPLIER,
					eventMetricsCacheParam);

			return new ResponseEntity<>(eventStatData, HttpStatus.OK);
		} catch (Throwable th) {
			logger.error("Error in getBiometricEventCountData: " + th.getMessage(), th);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping(value = "/getScLoadMetricsData", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getScLoadMetricsData(HttpServletRequest request) {
		logger.trace("In MetricsController.getScLoadMetricsData: " + new Date());
		try {
			if (GET_SEARCH_CONTROLLER_STATS_DATA_SUPPLIER == null) {
				GET_SEARCH_CONTROLLER_STATS_DATA_SUPPLIER = () -> {
					ClusterInstance clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SC);
					if (clusterInstance == null) {
						clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SB);
					}

					Map<String, JsonObject> searchNodeJsonMap = new TreeMap<>();
					Set<String> capacityGroups = new TreeSet<>();

					if (clusterInstance != null) {
						ISet<String> snCapacityGroupKeySet = clusterInstance.getSet("SN_CAPACITY_GROUP_KEY_SET");
						for (String snCapacityGroupKey : snCapacityGroupKeySet) {
							String splitParts[] = snCapacityGroupKey.split("\\|");
							String searchNodeId = splitParts[0];
							String capacityGroupId = splitParts[1];

							capacityGroups.add(capacityGroupId);

							JsonObject searchNodeJsonObject = searchNodeJsonMap.get(searchNodeId);
							if (searchNodeJsonObject == null) {
								searchNodeJsonObject = new JsonObject();
								searchNodeJsonObject.addProperty("serverId", searchNodeId);
								searchNodeJsonObject.addProperty("onlineFlag", clusterInstance
										.getAtomicLong("SEARCH_NODE_ONLINE_FLAG_" + searchNodeId).get() == 1);
								searchNodeJsonObject.addProperty("currentLoad", 0);
								searchNodeJsonMap.put(searchNodeId, searchNodeJsonObject);
							}

							int capacityGroupLoad = (int) clusterInstance
									.getAtomicLong("SN_LOAD_" + searchNodeId + "_" + capacityGroupId).get();
							searchNodeJsonObject.addProperty("currentLoad",
									searchNodeJsonObject.remove("currentLoad").getAsInt() + capacityGroupLoad);

							searchNodeJsonObject.addProperty("cpgId_" + capacityGroupId, capacityGroupLoad);
						}
					}

					JsonArray snStatsJsonArray = new JsonArray();
					searchNodeJsonMap.values().forEach(searchNodeJsonObject -> {
						snStatsJsonArray.add(searchNodeJsonObject);
					});

					JsonArray capacityGroupsJsonArray = new JsonArray();
					capacityGroups.forEach(capacityGroupId -> {
						JsonPrimitive jsonPrimitive = new JsonPrimitive(capacityGroupId);
						capacityGroupsJsonArray.add(jsonPrimitive);
					});

					JsonArray functionLoadJsonArray = new JsonArray();

					if (clusterInstance != null) {
						ISet<String> functionIdSet = clusterInstance.getSet("FUNCTION_ID_SET");
						for (String functionId : functionIdSet) {
							JsonObject functionLoadJsonObject = new JsonObject();
							functionLoadJsonObject.addProperty("functionId", functionId);
							functionLoadJsonObject.addProperty("currentLoad",
									(int) clusterInstance.getAtomicLong("FUNC_LOAD_" + functionId).get());
							functionLoadJsonArray.add(functionLoadJsonObject);
						}
					}

					JsonObject jsonStats = new JsonObject();
					jsonStats.add("snStatsJsonArray", snStatsJsonArray);
					jsonStats.add("capacityGroups", capacityGroupsJsonArray);
					jsonStats.add("functionLoadJsonArray", functionLoadJsonArray);

					JsonObject jsonResponse = new JsonObject();
					jsonResponse.add("data", jsonStats);

					return jsonResponse.toString();
				};
			}

			String statData = functionalCacheService.getCachedValue(GET_SEARCH_CONTROLLER_STATS_DATA_SUPPLIER,
					scLoadMetricsCacheParam);

			return new ResponseEntity<>(statData, HttpStatus.OK);
		} catch (Throwable th) {
			logger.error("Error in getScLoadMetricsData: " + th.getMessage(), th);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}