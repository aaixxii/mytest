package com.nec.biomatcher.web.controller.monitoring;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.core.framework.cache.FunctionalCacheService;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

@Controller
@RequestMapping(value = "/admin/monitoring")
public class MonitoringController {
	private static final Logger logger = Logger.getLogger(MetricsController.class);

	private BioParameterService bioParameterService = (BioParameterService) SpringServiceManager
			.getBean("bioParameterService");
	private BioMatcherConfigService bioMatcherConfigService = (BioMatcherConfigService) SpringServiceManager
			.getBean("bioMatcherConfigService");
	private BioMatchManagerService bioMatchManagerService = (BioMatchManagerService) SpringServiceManager
			.getBean("bioMatchManagerService");
	private FunctionalCacheService functionalCacheService = SpringServiceManager.getBean("functionalCacheService");

	@RequestMapping(value = "/monitoringIndex", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request) {
		logger.debug("In MetricsController.index");

		String monitoringPageId = "statmonitor.init";
		if (StringUtils.isNotBlank(request.getParameter("monitoringPageId"))) {
			monitoringPageId = request.getParameter("monitoringPageId");
		}

		return new ModelAndView(monitoringPageId);
	}

	@RequestMapping(value = "/latestStatistics", method = RequestMethod.GET)
	public ModelAndView latestStatistics(HttpServletRequest request) {
		logger.debug("In MetricsController.latestStatistics");
		return new ModelAndView("statmonitor.latest_statistics");
	}

	@RequestMapping(value = "/windowStatistics", method = RequestMethod.GET)
	public ModelAndView windowStatistics(HttpServletRequest request) {
		logger.debug("In MetricsController.windowStatistics");
		return new ModelAndView("statmonitor.window_statistics");
	}

	@RequestMapping(value = "/searchControllerStatistics", method = RequestMethod.GET)
	public ModelAndView searchControllerStatistics(HttpServletRequest request) {
		logger.debug("In MetricsController.searchControllerStatistics");
		return new ModelAndView("statmonitor.search_controller_statistics");
	}
}
