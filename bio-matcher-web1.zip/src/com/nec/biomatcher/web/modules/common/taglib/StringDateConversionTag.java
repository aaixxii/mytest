package com.nec.biomatcher.web.modules.common.taglib;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.DateUtil;

public class StringDateConversionTag extends TagSupport {
	private static final long serialVersionUID = 1L;

	private static final Logger _logger = Logger.getLogger(StringDateConversionTag.class);

	private String format;

	private String strDate;

	public StringDateConversionTag() {
		format = null;
		strDate = null;

	}

	public void release() {
		super.release();
		format = null;
		strDate = null;

	}

	public int doStartTag() throws JspException {
		try {
			pageContext.getOut().print(convertStrToDate());
		} catch (Exception e) {
			_logger.error("Error occured while converting the date:" + strDate + ", error:" + e.getMessage(), e);
			// throw new JspException("Error:" + e.getMessage());
		}
		return SKIP_BODY;
	}

	public String convertStrToDate() {
		try {
			if (StringUtils.isNotBlank(strDate)) {
				String convertedDate = DateUtil.formatForCalendarDisplay(strDate.trim()); // converts
																							// the
																							// date
																							// to
																							// DD/MM/YYYY
				Date newDate = DateUtil.toDate(convertedDate);
				Date dobDate = DateUtil.removeTime(newDate);
				return parseOnlyDate(dobDate, pageContext.getRequest().getLocale());
			}
		} catch (Exception e) {
			_logger.error("Error occured while converting the date:" + strDate + ", error:" + e.getMessage(), e);
		}
		if (strDate == null) {
			return "";
		}
		return strDate;

	}

	/**
	 * Description: This method parsed java.util.Date type to java.lang.String
	 * by specified string format
	 *
	 * @param date
	 *            the date
	 * @param format
	 *            the format
	 * @return the string
	 */
	public static String parseOnlyDate(java.util.Date date, Locale locale) {

		String s = null;
		if (date != null) {
			s = DateFormat.getDateInstance(DateFormat.MEDIUM, locale).format(date);
		}

		return s;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getStrDate() {
		return strDate;
	}

	public void setStrDate(String strDate) {
		this.strDate = strDate;
	}

}
