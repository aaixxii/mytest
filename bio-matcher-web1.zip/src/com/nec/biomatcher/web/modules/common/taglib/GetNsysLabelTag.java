package com.nec.biomatcher.web.modules.common.taglib;

import java.util.Map;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.admin.BioAdminService;
import com.nec.biomatcher.comp.admin.exception.BioAdminServiceException;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class GetNsysLabelTag extends TagSupport {
	private static final long serialVersionUID = 1L;

	private static final Logger _logger = Logger.getLogger(GetNsysLabelTag.class);

	private BioAdminService bioAdminService = (BioAdminService) SpringServiceManager.getBean("bioAdminService");

	private String labelFor;

	private String groupName;

	private String isTitleType;

	public GetNsysLabelTag() {
		labelFor = null;
	}

	public void release() {
		super.release();
		labelFor = null;
	}

	public int doStartTag() throws JspException {
		try {
			String displayValue = fetchLabel(labelFor);

			if (StringUtils.isNotBlank(isTitleType) && Boolean.TRUE == Boolean.valueOf(isTitleType)) {
				if (displayValue.length() >= 1) {
					String titleTypeDisplayValue = String.valueOf(displayValue.charAt(0)).toUpperCase()
							+ displayValue.substring(1).toLowerCase();
					displayValue = titleTypeDisplayValue;
				}
			}

			pageContext.getOut().print(displayValue);
		} catch (Exception e) {
			_logger.error("Error occured while fetching the label from database, error:" + e.getMessage(), e);
			throw new JspException("Error:" + e.getMessage());
		}
		return SKIP_BODY;
	}

	public String fetchLabel(String labelFor) throws BioAdminServiceException {
		if (StringUtils.isNotBlank(labelFor)) {
			Map<String, String> displayLabelMap = bioAdminService
					.getDisplayLabelMap(StringUtils.isBlank(groupName) ? "REVEAL_CLIENT_LABELS" : groupName);
			return displayLabelMap.get(labelFor);
		}
		_logger.warn("No label could be found in database for :" + labelFor);
		return "";
	}

	public String getLabelFor() {
		return labelFor;
	}

	public void setLabelFor(String labelFor) {
		this.labelFor = labelFor;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getIsTitleType() {
		return isTitleType;
	}

	public void setIsTitleType(String isTitleType) {
		this.isTitleType = isTitleType;
	}

}
