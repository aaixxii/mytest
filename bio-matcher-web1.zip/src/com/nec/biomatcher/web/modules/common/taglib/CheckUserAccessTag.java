/* Copyright 2006 NEC Singapore Pte Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of NEC Singapore Pte Ltd.
 * The use is subject to license terms from NEC Singapore Pte Ltd.
 *
 */
package com.nec.biomatcher.web.modules.common.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import com.nec.biomatcher.core.framework.web.session.UserSession;

/**
 * Check if user has functional access to page
 *
 * @version $Revision: 1.3 $
 * @author $Author: EST $
 */
public final class CheckUserAccessTag extends TagSupport {
	private static final long serialVersionUID = 1L;

	/**
	 * Defer our checking until the end of this tag is encountered.
	 *
	 * @throws JspException
	 *             if a JSP exception has occurred
	 * @return int
	 */
	public int doStartTag() throws JspException {
		return SKIP_BODY;
	}

	/**
	 * Check UserSession to determine if user has access to current page
	 *
	 * @throws JspException
	 *             if a JSP exception has occurred
	 * @return int
	 */
	public int doEndTag() throws JspException {
		UserSession userSession = (UserSession) pageContext.getSession().getAttribute(UserSession.attributeName);

		if (userSession == null) {
			try {
				pageContext.forward("/error.jsp");
			} catch (Exception e) {
				throw new JspException(e.toString());
			}

			return SKIP_PAGE;
		} else {
			return EVAL_PAGE;
		}
	}

}
