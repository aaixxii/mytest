package com.nec.biomatcher.web.modules.login;

import java.util.List;

import com.nec.biomatcher.web.modules.common.BaseForm;

public class LoginForm extends BaseForm {

	private static final long serialVersionUID = 1L;

	private String userId;
	private String password;

	private String loggedInUserName;

	private boolean redirectFlag;
	private String workStation;

	private String changePassword;
	private String newPassword;

	private List<SecurityQuestionParameter> questionsList;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the redirectFlag
	 */
	public boolean isRedirectFlag() {
		return redirectFlag;
	}

	/**
	 * @param redirectFlag
	 *            the redirectFlag to set
	 */
	public void setRedirectFlag(boolean redirectFlag) {
		this.redirectFlag = redirectFlag;
	}

	/**
	 * @return the workStation
	 */
	public String getWorkStation() {
		return workStation;
	}

	/**
	 * @param workStation
	 *            the workStation to set
	 */
	public void setWorkStation(String workStation) {
		this.workStation = workStation;
	}

	public void setChangePassword(String changePassword) {
		this.changePassword = changePassword;
	}

	public String getChangePassword() {
		return changePassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public List<SecurityQuestionParameter> getQuestionsList() {
		return questionsList;
	}

	public void setQuestionsList(List<SecurityQuestionParameter> questionsList) {
		this.questionsList = questionsList;
	}

	public String getLoggedInUserName() {
		return loggedInUserName;
	}

	public void setLoggedInUserName(String loggedInUserName) {
		this.loggedInUserName = loggedInUserName;
	}
}
