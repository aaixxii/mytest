package com.nec.biomatcher.template.validator;

import java.util.List;

import com.nec.biomatcher.template.validator.exception.InvalidTemplateException;
import com.nec.biomatcher.template.validator.exception.TemplateValidatorException;

public interface TemplateValidatorService {
	public String getTemplateValidatorControllerId();

	public boolean validateTemplates(List<byte[]> templateList, long timeOutMilli)
			throws TemplateValidatorException, InvalidTemplateException;
}
