package com.nec.biomatcher.template.validator.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class TemplateValidatorException extends CoreException {
	private static final long serialVersionUID = 1L;

	public TemplateValidatorException(String message, Throwable cause) {
		super(message, cause);
	}

	public TemplateValidatorException(String message) {
		super(message);
	}

	public TemplateValidatorException(Throwable cause) {
		super(cause);
	}

}
