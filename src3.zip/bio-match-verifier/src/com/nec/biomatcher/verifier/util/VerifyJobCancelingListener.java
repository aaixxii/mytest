package com.nec.biomatcher.verifier.util;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.verifier.queueing.VerificationJobQueueHelper;

import io.netty.util.internal.StringUtil;

public class VerifyJobCancelingListener implements MessageListener<String> {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(VerifyJobCancelingListener.class);
	
	private VerificationJobQueueHelper verificationJobQueueHelper;
	
	public VerifyJobCancelingListener() {
		logger.info("In VerifyJobCancelingListener()");
	}

	@Override
	public void onMessage(final Message<String> meg) {		
		String msg = meg.getMessageObject();
		if (StringUtil.isNullOrEmpty(msg)) {
			logger.info("Recevied empty string, return");
			return;
		}		
		logger.info("Got message from notifyVerifyJobCancelingTopic. Recevied messge:" + msg);
		if (this.verificationJobQueueHelper == null) {
			getVerifyJobQueueHelper();
		}
		String myVerifyControllerId = verificationJobQueueHelper.getVerificationControllerId();
		if (StringUtil.isNullOrEmpty(myVerifyControllerId )) {
			logger.info("myVerifyControllerId  is null or empty , return");
			return;
		}		
		logger.info("My verifyCotrol Id:" + myVerifyControllerId);
		String receivedVcIds = msg.split(":")[0];
		if (!receivedVcIds.contains(myVerifyControllerId )) {
			logger.info("Received VCIDS is not contain my Id, return");
			return;
		}
		String verifyJobId =  msg.split(":")[1];
		if (StringUtils.isBlank(verifyJobId)) {
			logger.info("rceived empty extraction job id. skip process.");
			return;
		}		
		try {
			ConcurrentHashMap<String, VerifyJobInfo> verifyJobReqMap = verificationJobQueueHelper.getVerifyJobRequestMap();
			VerifyJobInfo verifyJobInfo = verifyJobReqMap.get(verifyJobId);
			if (verifyJobInfo == null) {
				logger.warn("VerifyJob is not in my memory, jobId=" + verifyJobId + " VC="+ myVerifyControllerId + ". It may be finished or keeped in other VC.");				
			}

			verificationJobQueueHelper.deleteMyVerifyJob(verifyJobId);					
			logger.info("Success to delete verifyJob. verifyJobId: " + verifyJobId + " by VC:" + myVerifyControllerId);
		} catch (Throwable th) {
			logger.error("Error in deleting verifyJobId: " + verifyJobId + " : " + th.getMessage(), th);
		}	
	}
	
	public void setVerifyJobQueueHelper(VerificationJobQueueHelper verificationJobQueueHelper) {
		this.verificationJobQueueHelper = verificationJobQueueHelper;
	}	
	
	private void getVerifyJobQueueHelper() {
		if (this.verificationJobQueueHelper == null) {
			this.verificationJobQueueHelper = SpringServiceManager.getBean("verificationJobQueueHelper");
		}
	}
}
