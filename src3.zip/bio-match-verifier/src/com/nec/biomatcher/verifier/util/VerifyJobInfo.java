package com.nec.biomatcher.verifier.util;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobType;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;

public class VerifyJobInfo {
	private String verifyJobId;
	private long jobTimeoutMill = -1;
	private long createTimestampMilli;
	private long assignmentTimestampMilli = -1;
	private long submitTimestampMilli = -1;
	private long jobCompletedTimestampMilli = -1;
	private String callbackUrl;
	private String assignedVerifyNodeId;
	private VerifyJobRequestDto jobRequestDto;
	private VerifyJobResultDto jobResultDto;
	private volatile boolean jobCompletedFlag = false;
	private Semaphore waitSemaphore = new Semaphore(0);
	private boolean functionSlotAcquiredFlag;

	public VerifyJobInfo(String verifyJobId, String callbackUrl, long jobTimeoutMill) {
		this.verifyJobId = verifyJobId;
		this.callbackUrl = callbackUrl;
		this.jobTimeoutMill = jobTimeoutMill;
		this.createTimestampMilli = System.currentTimeMillis();
	}

	public VerifyJobInfo(String verifyJobId, VerifyJobRequestDto jobRequestDto) {
		this.verifyJobId = verifyJobId;
		this.jobRequestDto = jobRequestDto;
		this.callbackUrl = jobRequestDto.getCallbackUrl();
		this.createTimestampMilli = System.currentTimeMillis();
	}

	public void assignVerifyNodeId(String verifyNodeId) {
		assignedVerifyNodeId = verifyNodeId;
		assignmentTimestampMilli = System.currentTimeMillis();
	}

	public synchronized void notifyJobCompleted(JobSlotClusterService verifyClusterService,
			VerifyJobResultDto verifyJobResultDto) {
		if (!jobCompletedFlag) {
			jobCompletedFlag = true;
			jobCompletedTimestampMilli = System.currentTimeMillis();

			if (verifyJobResultDto != null) {
				jobResultDto = verifyJobResultDto;
			}

			waitSemaphore.release();

			if (assignedVerifyNodeId != null) {
				verifyClusterService.releaseJobSlot(assignedVerifyNodeId);
				MetricsUtil.time(BioComponentType.VN, assignedVerifyNodeId, "VN_JOB_TIME_TAKEN",
						getVerifyNodeTimeTakenMilli(), TimeUnit.MILLISECONDS);
			}
		}
	}

	public String getVerifyJobId() {
		return verifyJobId;
	}

	public void setVerifyJobId(String verifyJobId) {
		this.verifyJobId = verifyJobId;
	}

	public long getSubmitTimestampMilli() {
		return submitTimestampMilli;
	}

	public void setSubmitTimestampMilli(long submitTimestampMilli) {
		this.submitTimestampMilli = submitTimestampMilli;
	}

	public long getJobCompletedTimestampMilli() {
		return jobCompletedTimestampMilli;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public VerifyJobRequestDto getJobRequestDto() {
		return jobRequestDto;
	}

	public void setJobRequestDto(VerifyJobRequestDto jobRequestDto) {
		this.jobRequestDto = jobRequestDto;
	}

	public long getCreateTimestampMilli() {
		return createTimestampMilli;
	}

	public void setCreateTimestampMilli(long createTimestampMilli) {
		this.createTimestampMilli = createTimestampMilli;
	}

	public long getDelayFromCreateDateTime() {
		return System.currentTimeMillis() - createTimestampMilli;
	}

	public long getAssignmentDelayMilli() {
		if (assignmentTimestampMilli == -1L) {
			return 0;
		} else {
			return assignmentTimestampMilli - createTimestampMilli;
		}
	}

	public long getSubmitTimeTakenMilli() {
		if (assignmentTimestampMilli == -1L || submitTimestampMilli == -1L) {
			return 0;
		} else {
			return submitTimestampMilli - assignmentTimestampMilli;
		}
	}

	public long getVerifyNodeTimeTakenMilli() {
		if (submitTimestampMilli == -1L || jobCompletedTimestampMilli == -1L) {
			return 0;
		} else {
			return jobCompletedTimestampMilli - submitTimestampMilli;
		}
	}

	public long getAssignmentTimestampMilli() {
		return assignmentTimestampMilli;
	}

	public boolean getJobCompletedFlag() {
		return jobCompletedFlag;
	}

	public String getAssignedVerifyNodeId() {
		return assignedVerifyNodeId;
	}

	public Semaphore getWaitSemaphore() {
		return waitSemaphore;
	}

	public long getJobTimeoutMill() {
		return jobTimeoutMill;
	}

	public void setJobTimeoutMill(long jobTimeoutMill) {
		this.jobTimeoutMill = jobTimeoutMill;
	}

	public VerifyJobResultDto getJobResultDto() {
		return jobResultDto;
	}

	public void setJobResultDto(VerifyJobResultDto jobResultDto) {
		this.jobResultDto = jobResultDto;
	}

	public boolean isFunctionSlotAcquiredFlag() {
		return functionSlotAcquiredFlag;
	}

	public void markFunctionSlotAcquired() {
		this.functionSlotAcquiredFlag = true;
	}

	public synchronized void releaseFunctionSlot(MatcherFunctionControlUtil matcherFunctionControlUtil) {
		if (functionSlotAcquiredFlag) {
			matcherFunctionControlUtil.releaseFunctionSlot(BioMatcherJobType.VERIFY.name());
			functionSlotAcquiredFlag = false;
		}
	}

}
