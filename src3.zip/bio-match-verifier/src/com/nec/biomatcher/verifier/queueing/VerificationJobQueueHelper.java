package com.nec.biomatcher.verifier.queueing;

import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.MoreObjects;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.callback.CallbackService;
import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.inmemory.BioTaskType;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.comp.inmemory.callback.CallbackListener;
import com.nec.biomatcher.comp.inmemory.tasktimeout.TaskTimeoutListener;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.comp.zmq.ZmqPullMessageListener;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.GuavaCacheCleaner;
import com.nec.biomatcher.core.framework.common.HessianSerializer;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentProducerConsumer;
import com.nec.biomatcher.core.framework.common.exception.SerializationException;
import com.nec.biomatcher.core.framework.license.exception.InvalidLicenseException;
import com.nec.biomatcher.core.framework.license.impl.LicenseManager;
import com.nec.biomatcher.spec.services.exception.BioVerificationJobServiceException;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobType;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyBiometricData;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.FeatureData;
import com.nec.biomatcher.spec.transfer.model.FeatureExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;
import com.nec.biomatcher.verifier.service.BioVerificationService;
import com.nec.biomatcher.verifier.service.exception.BioVerificationException;
import com.nec.biomatcher.verifier.service.exception.BioVerificationTimeoutException;
import com.nec.biomatcher.verifier.util.VerificationJaxbXmlConvertor;
import com.nec.biomatcher.verifier.util.VerifyConstants;
import com.nec.biomatcher.verifier.util.VerifyJobInfo;
import com.nec.biomatcher.verifier.util.VerifyProtobufUtil;
import com.nec.megha.proto.verify.VerifyResponseProto.VerifyResponse;

public class VerificationJobQueueHelper implements InitializingBean, DisposableBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(VerificationJobQueueHelper.class);

	private static final Logger VERIFY_JOB_NODE_RESPONSE_LOGGER = Logger.getLogger(
		"VERIFY_JOB_NODE_RESPONSE");
	private static final Logger MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER = Logger.getLogger(
		"MATCHER_NODE_DUMP_ERROR_PAYLOAD");

	/** The bio parameter service. */
	protected BioParameterService bioParameterService;

	protected BioMatcherConfigService bioMatcherConfigService;

	private BioVerificationService bioVerificationService;

	/** The lob image service. */
	private LobImageService lobImageService;

	private CallbackService httpCallbackService;
	private CallbackService zmqCallbackService;

	/** The pending job queue. */
	private PriorityBlockingQueue<JobEntry> pendingJobQueue = new PriorityBlockingQueue<>();

	private DelayQueue<DelayedItem<String>> verifyJobQueueHousekeepingQueue = new DelayQueue<>();

	/** The verification job executor. */
	protected ConcurrentProducerConsumer<String> verificationJobExecutor;

	private String verifyControllerId;

	/** The notify callabck in worker thread flag. */
	private boolean notifyCallabckInWorkerThreadFlag = false;

	/** The verification jaxb xml convertor. */
	private final VerificationJaxbXmlConvertor verificationJaxbXmlConvertor =
		new VerificationJaxbXmlConvertor();

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	private ConcurrentHashMap<String, VerifyJobInfo> verifyJobRequestMap =
		new ConcurrentHashMap<>();

	private static LoadingCache<String, BiKey<VerifyJobRequestDto, Throwable>> bioVerifyJobRequestDtoCache;

	private JobSlotClusterService verifyClusterService;

	private MatcherFunctionControlUtil matcherFunctionControlUtil;

	private LicenseManager licenseManager;

	@SuppressWarnings("serial")
	private final ConcurrentHashMap<AlgorithmType, String> algorithmMap =
		new ConcurrentHashMap<AlgorithmType, String>() {
			{
				put(AlgorithmType.FACE_NEC_S17, "TEMPLATE_TYPE_1");
				put(AlgorithmType.FACE_NEC_S18, "TEMPLATE_TYPE_2");
				put(AlgorithmType.FACE_NEC_NFV2, "TEMPLATE_TYPE_3");
				put(AlgorithmType.FACE_NEC_NFG2, "TEMPLATE_TYPE_4");
				put(AlgorithmType.IRIS_NEC, "TEMPLATE_TYPE_11");
				put(AlgorithmType.FINGER_CMLAF, "TEMPLATE_TYPE_31");
				put(AlgorithmType.FINGER_CML, "TEMPLATE_TYPE_36");
				put(AlgorithmType.FINGER_LFML, "TEMPLATE_TYPE_44");
				put(AlgorithmType.FINGER_ELFT, "TEMPLATE_TYPE_49");
				put(AlgorithmType.FINGER_PC2, "TEMPLATE_TYPE_49");
				put(AlgorithmType.FINGER_BT5, "TEMPLATE_TYPE_49");
				put(AlgorithmType.FINGER_FMP5, "TEMPLATE_TYPE_49");
				put(AlgorithmType.PALM_LFML, "TEMPLATE_TYPE_48");				
				put(AlgorithmType.FINGER_FIS, "TEMPLATE_TYPE_33");
				put(AlgorithmType.FINGER_FIS, "TEMPLATE_TYPE_34");
				put(AlgorithmType.FINGER_FIS, "TEMPLATE_TYPE_41");
			}
		};

	public void setLicenseManager(LicenseManager licenseManager) {
		this.licenseManager = licenseManager;
	}

	public String getVerificationControllerId() {
		return verifyControllerId;
	}

	/**
	 * Submit verification job.
	 *
	 * @param jobId
	 *            the job id
	 * @param jobRequestDto
	 *            the job request dto
	 * @return the string
	 * @throws BioVerificationJobServiceException
	 *             the bio verification job service exception
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public VerifyJobInfo submitVerificationJob(String jobId, VerifyJobRequestDto jobRequestDto)
		throws BioVerificationJobServiceException, LobImageServiceException,
		SerializationException {
		logger.info("In submitVerificationJob : Received verification job with verifyJobId: "
			+ jobId + ", jobTimeoutMill: " + jobRequestDto.getJobTimeoutMill() + ", callbackUrl: "
			+ jobRequestDto.getCallbackUrl());

		if (verifyControllerId == null) {
			throw new BioVerificationJobServiceException(
				"Verification Controller is not configured on " + HostnameUtil.getIpAddress() + ", "
					+ HostnameUtil.getHostname());
		}

		MetricsUtil.meter(BioComponentType.VC, verifyControllerId, "VERIFY_JOB_SUBMITTED");

		assert jobRequestDto.getProbeBiomericData() != null : "Invalid Probe BiomericData";

		assert CollectionUtils.isNotEmpty(jobRequestDto
			.getGalleryBiomericDataList()) : "Invalid Gallery BiomericData List";

		long maxVerifyJobTimeoutMilli = bioParameterService.getParameterValue(
			"MAX_VERIFY_JOB_TIMEOUT_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(2));
		Long jobTimeoutMill = Math.min(maxVerifyJobTimeoutMilli, MoreObjects.firstNonNull(
			jobRequestDto.getJobTimeoutMill(), maxVerifyJobTimeoutMilli));

		jobRequestDto.setJobTimeoutMill(jobTimeoutMill);

		VerifyJobInfo verifyJobInfo = new VerifyJobInfo(jobId, jobRequestDto.getCallbackUrl(),
			jobTimeoutMill);

		try {
			checkLicense(jobRequestDto.getProbeBiomericData());

			if (matcherFunctionControlUtil.tryAcquireFunctionSlot(BioMatcherJobType.VERIFY
				.name())) {
				verifyJobInfo.markFunctionSlotAcquired();
			} else {
				throw new BioVerificationJobServiceException(
					"Unable to acquire verify function job slot");
			}

			bioVerifyJobRequestDtoCache.put(jobId, new BiKey<>(jobRequestDto, null));

			boolean saveVerifyRequestPayload = bioParameterService.getParameterValue(
				"SAVE_VERIFY_REQUEST_PAYLOAD_FLAG", "DEFAULT", false);
			BioMatcherJobRequestPayload bioMatcherJobRequestPayload =
				new BioMatcherJobRequestPayload();
			bioMatcherJobRequestPayload.setVerifyJobRequest(jobRequestDto);
			if (!saveVerifyRequestPayload) {
				// replace with dummy job request without job payload
				bioMatcherJobRequestPayload.setVerifyJobRequest(new VerifyJobRequestDto(null, null,
					null, jobRequestDto.getCallbackUrl(), jobRequestDto.getJobTimeoutMill(),
					jobRequestDto.getJobMode()));
			}

			lobImageService.createLob(jobId, HessianSerializer.marshal(bioMatcherJobRequestPayload),
				"req");

			long verifyJobRetentionPeriodMilli = bioParameterService.getParameterValue(
				"VERIFY_JOB_RETENTION_PERIOD_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(30));
			verifyJobQueueHousekeepingQueue.add(new DelayedItem<String>(jobId, jobTimeoutMill
				+ verifyJobRetentionPeriodMilli));

			verifyJobRequestMap.put(jobId, verifyJobInfo);

			InMemoryManager.registerVerifyForTimeout(jobId, jobTimeoutMill);

			pendingJobQueue.add(new JobEntry(jobId, jobRequestDto.getPriority()));

			return verifyJobInfo;
		} catch (InvalidLicenseException ex) {
			verifyJobRequestMap.remove(jobId);
			releaseFunctionSlot(verifyJobInfo);
			throw new BioVerificationJobServiceException("Licence is not available : " + ex
				.getMessage(), ex);
		} catch (BioVerificationJobServiceException | LobImageServiceException
			| SerializationException ex) {
			verifyJobRequestMap.remove(jobId);
			releaseFunctionSlot(verifyJobInfo);
			throw ex;
		} catch (Throwable th) {
			verifyJobRequestMap.remove(jobId);
			releaseFunctionSlot(verifyJobInfo);
			throw new BioVerificationJobServiceException(
				"Error in submitVerificationJob for jobId: " + jobId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Submit verification job.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extract job result dto
	 */
	private void submitVerificationJob(String jobId) {
		NDC.clear();
		NDC.push("VI_JOBID#" + jobId);

		VerifyJobInfo verifyJobInfo = verifyJobRequestMap.get(jobId);
		if (verifyJobInfo == null) {
			logger.warn("In submitVerificationJob: Cannot find VerifyJobInfo with jobId: " + jobId);
			return;
		}

		VerifyJobResultDto errorResult = null;
		try {
			if (verifyJobInfo.getJobRequestDto() == null) {
				BiKey<VerifyJobRequestDto, Throwable> bioVerifyJobRequestKey =
					bioVerifyJobRequestDtoCache.get(jobId);
				if (bioVerifyJobRequestKey.getB() != null) {
					throw bioVerifyJobRequestKey.getB();
				}
				verifyJobInfo.setJobRequestDto(bioVerifyJobRequestKey.getA());
			}

			bioVerificationService.submitVerificationJob(jobId, verifyJobInfo);
		} catch (BioVerificationTimeoutException | BioMatcherNodeSendException ex) {
			logger.error(ex.getClass().getSimpleName() + " Error in submitVerificationJob: " + ex
				.getMessage(), ex);
			MetricsUtil.meter(BioComponentType.VC, verifyControllerId, "VERIFY_TIMEOUT_ERROR");
			errorResult = new VerifyJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(VerifyConstants.ERROR_CODE_TIMEOUT,
				ex.getMessage(), null, new Date()));
		} catch (BioMatcherNodeConnectionException ex) {
			logger.error(ex.getClass().getSimpleName() + " Error in submitVerificationJob: " + ex
				.getMessage(), ex);
			MetricsUtil.meter(BioComponentType.VC, verifyControllerId, "VERIFY_CONNECTION_ERROR");
			errorResult = new VerifyJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(VerifyConstants.ERROR_CODE_TIMEOUT,
				ex.getMessage(), null, new Date()));
		} catch (LobImageServiceException | LobImageNotFoundException | SerializationException ex) {
			logger.error(ex.getClass().getSimpleName() + " Error in submitVerificationJob: " + ex
				.getMessage(), ex);
			MetricsUtil.meter(BioComponentType.VC, verifyControllerId, "VERIFY_OTHER_ERROR");
			errorResult = new VerifyJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(
				VerifyConstants.ERROR_CODE_LOBSTREAM_ACCESS, ex.getMessage(), null, new Date()));
		} catch (Throwable th) {
			logger.error(th.getClass().getSimpleName() + " Error in submitVerificationJob: " + th
				.getMessage(), th);
			MetricsUtil.meter(BioComponentType.VC, verifyControllerId, "VERIFY_OTHER_ERROR");
			errorResult = new VerifyJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(VerifyConstants.ERROR_CODE_GENERAL,
				th.getMessage(), null, new Date()));
		} finally {
			verifyJobInfo.setJobRequestDto(null);
		}

		if (errorResult != null) {
			saveVerificationResult(jobId, errorResult);
		}
	}

	private final void releaseFunctionSlot(VerifyJobInfo verifyJobInfo) {
		if (verifyJobInfo != null && verifyJobInfo.isFunctionSlotAcquiredFlag()) {
			verifyJobInfo.releaseFunctionSlot(matcherFunctionControlUtil);
		}
	}

	private void saveVerificationResult(String verifyJobId, VerifyJobResultDto verifyJobResultDto) {
		logger.debug("In saveVerificationResult: verifyJobId: " + verifyJobId);

		InMemoryManager.removeFromTimeoutQueue(verifyJobId);

		pendingJobQueue.remove(new JobEntry(verifyJobId));

		VerifyJobInfo verifyJobInfo = verifyJobRequestMap.remove(verifyJobId);
		if (verifyJobInfo == null) {
			logger.warn("In saveVerificationResult: Cannot find VerifyJobInfo with jobId: "
				+ verifyJobId);
			return;
		}

		releaseFunctionSlot(verifyJobInfo);

		if (!verifyJobInfo.getJobCompletedFlag()) {
			verifyJobInfo.notifyJobCompleted(verifyClusterService, verifyJobResultDto);
			MetricsUtil.time(BioComponentType.VC, verifyControllerId, "VERIFY_JOB_TIME_TAKEN",
				verifyJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);
		}

		logger.info("Verify job completed for verifyJobId: " + verifyJobId + ", status: "
			+ verifyJobResultDto.getStatus() + ", assignedVerifyNodeId: " + verifyJobInfo
				.getAssignedVerifyNodeId() + ", assignmentDelayMilli: " + verifyJobInfo
					.getAssignmentDelayMilli() + ", submitToVerifyNodeTimeTakenMilli: "
			+ verifyJobInfo.getSubmitTimeTakenMilli() + ", verifyNodeTimeTakenMilli: "
			+ verifyJobInfo.getVerifyNodeTimeTakenMilli() + ", TotalTimeTakenMilli: "
			+ verifyJobInfo.getDelayFromCreateDateTime());

		MetricsUtil.time("FUNCTION.VERIFY.JOB_TIME_TAKEN", verifyJobInfo
			.getVerifyNodeTimeTakenMilli(), TimeUnit.MILLISECONDS);

		try {
			BioMatcherJobResultPayload bioMatcherJobResultPayload =
				new BioMatcherJobResultPayload();
			bioMatcherJobResultPayload.setBioMatcherJobResult(verifyJobResultDto);
			bioMatcherJobResultPayload.setCallbackUrl(verifyJobInfo.getCallbackUrl());

			byte lobData[] = HessianSerializer.marshal(bioMatcherJobResultPayload);

			try {
				lobImageService.createLob(verifyJobId, lobData, "res");
			} catch (Throwable th) {
				th = new BioVerificationException(
					"Error saving verification request for verifyJobId: " + verifyJobId + " : " + th
						.getMessage(), th);
				createErrorResult(verifyJobId, verifyJobInfo.getCallbackUrl(), "res",
					VerifyConstants.ERROR_CODE_LOBSTREAM_ACCESS, th);
			}
		} catch (Throwable th) {
			th = new BioVerificationException("Error saving verification request for verifyJobId: "
				+ verifyJobId + " : " + th.getMessage(), th);
			createErrorResult(verifyJobId, verifyJobInfo.getCallbackUrl(), "res",
				VerifyConstants.ERROR_CODE_SERIALIZATION, th);
		}

		if (StringUtils.isNotBlank(verifyJobInfo.getCallbackUrl())) {
			if (notifyCallabckInWorkerThreadFlag) {
				notifyJobCompletedToSubmitter(verifyJobId, verifyJobInfo.getCallbackUrl(),
					verifyJobResultDto);
			} else {
				InMemoryManager.submitForVerifyCallback(verifyJobId, verifyJobInfo
					.getCallbackUrl());
			}
		}

		try {
			lobImageService.deleteLob(verifyJobId, "req");
		} catch (Throwable th) {
			th = new BioVerificationException(
				"Error deleting verification request for verifyJobId: " + verifyJobId + " : " + th
					.getMessage(), th);
			createErrorLob(verifyJobId, "derror", th);
		}
	}

	/**
	 * Notify job completed.
	 *
	 * @param jobId
	 *            the job id
	 */
	private void notifyJobCompletedToSubmitter(String jobId, String callbackUrl) {
		try {
			if (CallbackService.isBatchCallbackUrl(callbackUrl)) {
				notifyJobCompletedToSubmitter(jobId, callbackUrl, null);
			} else {
				byte[] lobData = lobImageService.getLobData(jobId, "res");

				BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(
					lobData);

				notifyJobCompletedToSubmitter(jobId, bioMatcherJobResultPayload.getCallbackUrl(),
					(VerifyJobResultDto)bioMatcherJobResultPayload.getBioMatcherJobResult());
			}
		} catch (Throwable th) {
			logger.error("Error during notifyJobCompletedToSubmitter for jobId: " + jobId + " : "
				+ th.getMessage(), th);
		}
	}

	/**
	 * Notify job completed.
	 *
	 * @param jobId
	 *            the job id
	 * @param callbackUrl
	 *            the callback url
	 * @param jobResultDto
	 *            the job result dto
	 */
	private void notifyJobCompletedToSubmitter(
		String jobId,
		String callbackUrl,
		VerifyJobResultDto jobResultDto) {
		VerifyJobInfo verifyJobInfo = verifyJobRequestMap.remove(jobId);
		if (verifyJobInfo != null && !verifyJobInfo.getJobCompletedFlag()) {
			logger.warn("In notifyJobCompletedToSubmitter: Marking incomplete job with jobId: "
				+ jobId);
			verifyJobInfo.notifyJobCompleted(verifyClusterService, jobResultDto);
			MetricsUtil.time(BioComponentType.VC, verifyControllerId, "VERIFY_JOB_TIME_TAKEN",
				verifyJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);
		}

		releaseFunctionSlot(verifyJobInfo);

		if (StringUtils.isBlank(callbackUrl)) {
			return;
		}
		try {
			if (callbackUrl.startsWith("http")) {
				httpCallbackService.postCallback(callbackUrl, jobResultDto == null ? null
					: verificationJaxbXmlConvertor.marshal(jobResultDto));
			} else {
				zmqCallbackService.postCallback(callbackUrl, jobResultDto == null ? null
					: verificationJaxbXmlConvertor.marshal(jobResultDto));
			}

		} catch (Throwable th) {
			th = new BioVerificationException(
				"Error in notifyJobCompletedToSubmitter during callback for jobId: " + jobId
					+ ", callbackUrl: " + callbackUrl + " : " + th.getMessage(), th);
			createErrorLob(jobId, "cerror", th);
		}
	}

	/**
	 * Notify job timeout.
	 *
	 * @param jobId
	 *            the job id
	 */
	private void notifyJobTimeout(String jobId) {

		pendingJobQueue.remove(new JobEntry(jobId));

		VerifyJobInfo verifyJobInfo = verifyJobRequestMap.get(jobId);
		if (verifyJobInfo == null) {
			logger.warn("In notifyJobTimeout: Cannot find VerifyJobInfo with jobId: " + jobId);
			return;
		}

		releaseFunctionSlot(verifyJobInfo);

		if (!verifyJobInfo.getJobCompletedFlag()) {
			BioVerificationException ex = new BioVerificationException(
				"Error verification timeout for jobId: " + jobId);

			VerifyJobResultDto result = new VerifyJobResultDto();
			result.setJobId(jobId);
			result.setStatus(BioJobStatus.COMPLETED);
			result.getErrorList().add(new ErrorMessageDto(VerifyConstants.ERROR_CODE_TIMEOUT, ex
				.getMessage(), null, new Date()));

			saveVerificationResult(jobId, result);
		}

	}

	private final String getVerifyResultCallbackUrl()
		throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(verifyControllerId,
			BioComponentType.VC, BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
				"Error in getVerifyResultCallbackUrl: callback url is not configured for verifyControllerId: "
					+ verifyControllerId + ", connectionType: " + BioConnectionType.WORKER_CALLBACK
					+ ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	/**
	 * Creates the error result.
	 *
	 * @param jobId
	 *            the job id
	 * @param callbackUrl
	 *            the callback url
	 * @param lobType
	 *            the lob type
	 * @param errorCode
	 *            the error code
	 * @param th
	 *            the th
	 * @return the verify job result dto
	 */
	private final VerifyJobResultDto createErrorResult(
		String jobId,
		String callbackUrl,
		String lobType,
		String errorCode,
		Throwable th) {
		VerifyJobResultDto result = new VerifyJobResultDto();

		result.setJobId(jobId);
		result.setStatus(BioJobStatus.COMPLETED);
		result.getErrorList().add(new ErrorMessageDto(errorCode, th.getMessage(), null,
			new Date()));

		BioMatcherJobResultPayload bioMatcherJobResultPayload = new BioMatcherJobResultPayload();
		bioMatcherJobResultPayload.setBioMatcherJobResult(result);
		bioMatcherJobResultPayload.setCallbackUrl(callbackUrl);

		try {
			lobImageService.createLob(jobId, HessianSerializer.marshal(bioMatcherJobResultPayload),
				lobType);
		} catch (Throwable error) {
			logger.error("Error in createErrorResult while for jobId: " + jobId + " : " + error
				.getMessage(), error);
		}

		return result;
	}

	/**
	 * Creates the error lob.
	 *
	 * @param jobId
	 *            the job id
	 * @param lobType
	 *            the lob type
	 * @param th
	 *            the th
	 */
	private final void createErrorLob(String jobId, String lobType, Throwable th) {
		try {
			lobImageService.createLob(jobId, HessianSerializer.marshal(th), lobType);
		} catch (Throwable error) {
			logger.error("Error in createErrorLob while for jobId: " + jobId + " : " + error
				.getMessage(), error);
		}
	}

	/**
	 * Gets the verification job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the verification job status
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public BioJobStatus getVerificationJobStatus(String jobId)
		throws LobImageServiceException {
		if (lobImageService.checkLobExists(jobId, "res")) {
			return BioJobStatus.COMPLETED;
		} else if (lobImageService.checkLobExists(jobId, "req")) {
			return BioJobStatus.PENDING;
		} else {
			return BioJobStatus.NOT_FOUND;
		}
	}

	/**
	 * Gets the verification job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the verification job result
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 * @throws LobImageNotFoundException
	 *             the lob image not found exception
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public VerifyJobResultDto getVerificationJobResult(String jobId)
		throws LobImageServiceException, LobImageNotFoundException, SerializationException {
		byte lobData[] = lobImageService.getLobData(jobId, "res");

		if (lobData != null) {
			BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(
				lobData);
			return (VerifyJobResultDto)bioMatcherJobResultPayload.getBioMatcherJobResult();
		}

		if (lobImageService.checkLobExists(jobId, "req")) {
			return new VerifyJobResultDto(BioJobStatus.PENDING);
		} else {
			return new VerifyJobResultDto(BioJobStatus.NOT_FOUND);
		}
	}

	public VerifyJobRequestDto getVerifyJobRequest(String jobId)
		throws LobImageServiceException, LobImageNotFoundException, SerializationException {
		byte lobData[] = lobImageService.getLobData(jobId, "req");
		BioMatcherJobRequestPayload bioMatcherJobRequestPayload = HessianSerializer.unmarshal(
			lobData);
		return (VerifyJobRequestDto)bioMatcherJobRequestPayload.getVerifyJobRequest();
	}
	
	public void deleteVerificationJob(String verifyJobId) throws BioMatcherConfigServiceException {
		logger.info("In deleteVerificationJob. verifyJobId: " + verifyJobId);
		List<BioServerInfo> bioServerInfoList = bioMatcherConfigService.getServerInfoListByComponentType(BioComponentType.VC);
		if (bioServerInfoList.size() < 1) {
			logger.info("No active VC. return");
		}
		
		StringBuilder sb = new StringBuilder();
		for (BioServerInfo info : bioServerInfoList) {			
			sb.append(info.getServerId());
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1);	
		String notifyMsg = sb.toString() + ":" + verifyJobId; 
		logger.info("Notify message:" + " to VC:" + notifyMsg);
		bioVerificationService.notifyVerifyJobCanceling(notifyMsg);
	
	}

	/**
	 * Delete verification job.
	 *
	 * @param jobId
	 *            the job id
	 */
	public void deleteMyVerifyJob(String jobId) {
		try {
			VerifyJobInfo verifyJobInfo = verifyJobRequestMap.remove(jobId);
			if (verifyJobInfo != null && !verifyJobInfo.getJobCompletedFlag()) {
				logger.warn("In deleteVerificationJob: Deleting incomplete job with jobId: "
					+ jobId);
				verifyJobInfo.notifyJobCompleted(verifyClusterService, null);
				MetricsUtil.time(BioComponentType.VC, verifyControllerId, "VERIFY_JOB_TIME_TAKEN",
					verifyJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);
			}
			releaseFunctionSlot(verifyJobInfo);
			pendingJobQueue.remove(new JobEntry(jobId));
			lobImageService.deleteLobsByLobId(jobId);
			verifyJobQueueHousekeepingQueue.remove(new DelayedItem<String>(jobId, 0L));
			InMemoryManager.removeFromTimeoutQueue(jobId);
		} catch (Throwable th) {
			logger.error("Error deleting lob for lobId: " + jobId + " : " + th.getMessage(), th);
		}
	}

	private void processVerifyResponseDataBuf(byte[] verifyResponseDataBuf) {
		String verifyJobId = null;
		try {
			VerifyResponse verifyProtoResponse = null;
			try {
				verifyProtoResponse = VerifyResponse.parseFrom(verifyResponseDataBuf);
			} catch (Throwable th) {
				logger.error("Error parsing VerifyResponse in processVerifyResponseDataBuf: " + th
					.getMessage(), th);
				if (MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER.isTraceEnabled()) {
					MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER.error(
						"Error parsing VerifyResponse in processVerifyResponseDataBuf: " + th
							.getMessage() + ", responsePayload: [" + Base64.getEncoder()
								.encodeToString(verifyResponseDataBuf) + "]", th);
				}
				return;
			}

			verifyJobId = verifyProtoResponse.getMsgId();
			if (VERIFY_JOB_NODE_RESPONSE_LOGGER.isTraceEnabled()) {
				VERIFY_JOB_NODE_RESPONSE_LOGGER.trace(
					"In processVerifyResponseDataBuf: verifyJobId: " + verifyJobId
						+ ", verifyProtoResponse: " + verifyProtoResponse.toString());
			}
			
			VerifyJobInfo verifyJobInfo = verifyJobRequestMap.get(verifyJobId);			
			if (verifyJobInfo == null) {
				logger.info("In processVerifyResponseDataBuf: Cannot find verifyJobInfo for verifyJobId:" + verifyJobId + ". do nothing.");
				return;
			}

			VerifyJobResultDto verifyJobResultDto = VerifyProtobufUtil.getVerifyJobResult(
				verifyProtoResponse);
			verifyJobResultDto.setJobId(verifyJobId);

			saveVerificationResult(verifyJobId, verifyJobResultDto);
		} catch (Throwable th) {
			logger.error("Error in processVerifyResponseDataBuf: verifyJobId: " + verifyJobId
				+ " : " + th.getMessage(), th);
		}
	}

	private void startVerifyCallbackListener()
		throws Exception {
		logger.info("In startVerifyCallbackListener");
		String verifyResultCallbackUrl = null;
		try {
			verifyResultCallbackUrl = getVerifyResultCallbackUrl();

			Supplier<Integer> zmqIoThreadCountSupplier = BioParameterService.getIntSupplier(
				"VERIFY_RESULT_LISTENER_ZMQ_IO_THREAD_COUNT", "DEFAULT", 10);
			Supplier<Integer> messageExecutorConcurrencySupplier = BioParameterService
				.getIntSupplier("VC_VERIFY_RESULT_LISTENER_CONCURRENCY_COUNT", "DEFAULT", 50);

			ZmqPullMessageListener zmqVerifyResultListener = new ZmqPullMessageListener(
				"VC_VERIFY_RESULT_LISTENER", verifyResultCallbackUrl, zmqIoThreadCountSupplier,
				messageExecutorConcurrencySupplier, (
					verifyResponseDataBuf) -> processVerifyResponseDataBuf(verifyResponseDataBuf));

			zmqVerifyResultListener.startZmqPullListener();
		} catch (Throwable th) {
			Exception ex = new Exception(
				"Error in startVerifyCallbackListener during binding of the ZmqPullMessageListener on verifyResultCallbackUrl: "
					+ verifyResultCallbackUrl + " : " + th.getMessage(), th);
			logger.error(ex.getMessage(), ex);

			CommonLogger.STATUS_LOG.error(ex.getMessage());

			throw ex;
		}
	}

	private final synchronized void initializeVerifyJobRequestDtoCache() {
		if (bioVerifyJobRequestDtoCache == null) {

			logger.info("In initializeVerifyJobRequestDtoCache");

			int maxVerifyJobRequestDtoCacheCount = BioParameterService.getIntSupplier(
				"MAX_VERIFY_JOB_REQUEST_PAYLOAD_CACHE_COUNT", "DEFAULT", 100).get();
			long verifyJobRequestDtoCacheExpiryMilli = BioParameterService.getLongSupplier(
				"VERIFY_JOB_REQUEST_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS
					.toMillis(2)).get();

			bioVerifyJobRequestDtoCache = CacheBuilder.newBuilder().maximumSize(
				maxVerifyJobRequestDtoCacheCount)
				// .softValues()
				.concurrencyLevel(200).expireAfterWrite(verifyJobRequestDtoCacheExpiryMilli,
					TimeUnit.MILLISECONDS).build(
						new CacheLoader<String, BiKey<VerifyJobRequestDto, Throwable>>() {
							public BiKey<VerifyJobRequestDto, Throwable> load(String verifyJobId) {
								try {
									return new BiKey<>(getVerifyJobRequest(verifyJobId), null);
								} catch (Throwable th) {
									return new BiKey<>(null, th);
								}

							}
						});

			boolean registerGuavaCacheCleanerFlag = BioParameterService.getBooleanSupplier(
				"REGISTER_GUAVA_CACHE_CLEANER_FLAG", "DEFAULT", false).get();
			if (registerGuavaCacheCleanerFlag) {
				GuavaCacheCleaner.registerCache("VERIFY_JOB_REQUEST_PAYLOAD_CACHE",
					bioVerifyJobRequestDtoCache);
			}
		}
	}

	public void setBioVerificationService(BioVerificationService bioVerificationService) {
		this.bioVerificationService = bioVerificationService;
	}

	public void setLobImageService(LobImageService lobImageService) {
		this.lobImageService = lobImageService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setHttpCallbackService(CallbackService httpCallbackService) {
		this.httpCallbackService = httpCallbackService;
	}

	public void setZmqCallbackService(CallbackService zmqCallbackService) {
		this.zmqCallbackService = zmqCallbackService;
	}

	@Override
	public void destroy()
		throws Exception {
		logger.error("Destroy called for VerificationJobQueueHelper bean");
	}

	@Override
	public void afterPropertiesSet()
		throws Exception {
		logger.info("In afterPropertiesSet: " + initializationCount.get());

		synchronized (VerificationJobQueueHelper.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			verifyClusterService = bioVerificationService.getVerifyClusterService();

			verifyControllerId = bioVerificationService.getVerificationControllerId();

			if (verifyControllerId == null) {
				return;
			}

			matcherFunctionControlUtil = verifyClusterService.getMatcherFunctionControlUtil();

			initializeVerifyJobRequestDtoCache();

			CommonTaskScheduler.scheduleWithFixedDelay(new VerifyJobHouseKeepingTask(
				verifyJobQueueHousekeepingQueue, this, bioParameterService), 100, 100,
				TimeUnit.MILLISECONDS);

			Supplier<Integer> workerConcurrencyCountSupplier = BioParameterService.getIntSupplier(
				"VERIFICATION_WORKER_THREAD_CONCURRENCY", "DEFAULT", 50);

			verificationJobExecutor = new ConcurrentProducerConsumer<>("VERIFY_JOB_WORKER",
				() -> Uninterruptibles.takeUninterruptibly(pendingJobQueue).getJobId(), (
					exJobId) -> submitVerificationJob(exJobId), workerConcurrencyCountSupplier);

			startVerifyCallbackListener();

			InMemoryManager.callbackListenerMap.put(BioTaskType.VERIFY, new CallbackListener() {
				@Override
				public void notifyCallback(String taskKey, String callbackUrl) {
					notifyJobCompletedToSubmitter(taskKey, callbackUrl);
				}
			});

			InMemoryManager.timeoutListenerMap.put(BioTaskType.VERIFY, new TaskTimeoutListener() {

				@Override
				public void notifyTaskTimeout(String jobId) {
					notifyJobTimeout(jobId);
				}
			});

			notifyCallabckInWorkerThreadFlag = bioParameterService.getParameterValue(
				"NOTIFY_VERIFICATION_CALLBACK_IN_WORKER_THREAD_FLAG", "DEFAULT", false);

			InMemoryManager.startCallbackExecutor();

			MetricsUtil.registerGauge(BioComponentType.VC, verifyControllerId,
				"PENDING_VERIFY_JOB_COUNT", () -> {
					return pendingJobQueue.size();
				});
		}
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	private void checkLicense(VerifyBiometricData biomericData)
		throws InvalidLicenseException, BioMatcherConfigServiceException, BioVerificationException {
		if (biomericData.hasTemplateInfoList()) {
			for (TemplateInfo templateInfo : biomericData.getTemplateInfoList()) {
				String templateType = templateInfo.getTemplateType();
				licenseManager.checkVerificationLicense(templateType);
			}
		} else if (biomericData.hasFeatureDataList()) {
			for (FeatureData featureData : biomericData.getFeatureDataList()) {
				String templateType = algorithmMap.get(featureData.getAlgorithmType());
				licenseManager.checkVerificationLicense(templateType);
			}
		} else if (biomericData.hasImageList()) {
			for (FeatureExtractInputImage image : biomericData.getImageList()) {
				for (AlgorithmType algorithmType : image.getAlgorithmTypes()) {
					String templateType = algorithmMap.get(algorithmType);
					licenseManager.checkVerificationLicense(templateType);
				}
			}
		} else if (biomericData.getContainerId() != null) {
			BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigService.getMatcherBinInfo(
				biomericData.getContainerId());
			if (bioMatcherBinInfo == null) {
				throw new BioVerificationException("Matcher Bin does not exit for binId: "
					+ biomericData.getContainerId());
			}
			licenseManager.checkVerificationLicense(bioMatcherBinInfo.getTemplateType());
		}
	}

	public ConcurrentHashMap<String, VerifyJobInfo> getVerifyJobRequestMap() {
		return verifyJobRequestMap;
	}	
}
