package com.nec.biomatcher.verifier.queueing;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class VerifyJobHouseKeepingTask implements Runnable {
	private static final Logger logger = Logger.getLogger(VerifyJobHouseKeepingTask.class);

	private VerificationJobQueueHelper verificationJobQueueHelper;
	private BioParameterService bioParameterService;

	private DelayQueue<DelayedItem<String>> verifyJobQueueHousekeepingQueue;

	private boolean isInitialized = false;

	/**
	 * Instantiates a new verify job house keeping task.
	 *
	 * @param verifyJobQueueHousekeepingQueue
	 *            the verify job queue housekeeping queue
	 */
	public VerifyJobHouseKeepingTask(DelayQueue<DelayedItem<String>> verifyJobQueueHousekeepingQueue,
			VerificationJobQueueHelper verificationJobQueueHelper, BioParameterService bioParameterService) {
		this.verifyJobQueueHousekeepingQueue = verifyJobQueueHousekeepingQueue;
		this.verificationJobQueueHelper = verificationJobQueueHelper;
		this.bioParameterService = bioParameterService;
	}

	@Override
	public void run() {
		Thread.currentThread().setName("VERIFY_JOB_HOUSEKEEPING_TASK_" + Thread.currentThread().getId());

		logger.info("In VerifyJobHouseKeepingTask.run");

		while (!ShutdownHook.isShutdownFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				DelayedItem<String> delayedItem = null;
				while ((delayedItem = verifyJobQueueHousekeepingQueue.poll()) != null) {
					String verifyJobId = delayedItem.getItem();
					try {
						verificationJobQueueHelper.deleteVerificationJob(verifyJobId);
					} catch (Throwable th) {
						logger.error("Error in VerifyJobHouseKeepingTask for verifyJobId: " + verifyJobId + " : "
								+ th.getMessage(), th);
					}
				}

				long verifyJobRetentionPeriodMilli = bioParameterService.getParameterValue(
						"VERIFY_JOB_RETENTION_PERIOD_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(30));
				Uninterruptibles.sleepUninterruptibly(verifyJobRetentionPeriodMilli, TimeUnit.MILLISECONDS);

			} catch (Throwable th) {
				logger.error("Error in VerifyJobHouseKeepingTask: " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			}
		}
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		verificationJobQueueHelper = SpringServiceManager.getBean("verificationJobQueueHelper");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");

		isInitialized = true;
	}

}
