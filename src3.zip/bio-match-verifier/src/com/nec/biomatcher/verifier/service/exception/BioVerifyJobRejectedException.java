package com.nec.biomatcher.verifier.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class BioVerifyJobRejectedException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public BioVerifyJobRejectedException(String message, Throwable cause) {
		super(message, cause);
	}

	public BioVerifyJobRejectedException(String message) {
		super(message);
	}

	public BioVerifyJobRejectedException(Throwable cause) {
		super(cause);
	}

}
