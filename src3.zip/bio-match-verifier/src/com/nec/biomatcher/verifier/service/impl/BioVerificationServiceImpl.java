package com.nec.biomatcher.verifier.service.impl;

import java.io.Closeable;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Stopwatch;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeClientHelper;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeStatusCheckHelper;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.zmq.ZmqPushConnection;
import com.nec.biomatcher.comp.zmq.ZmqSendException;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyBiometricData;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;
import com.nec.biomatcher.verifier.service.BioVerificationService;
import com.nec.biomatcher.verifier.service.exception.BioVerificationException;
import com.nec.biomatcher.verifier.service.exception.BioVerificationTimeoutException;
import com.nec.biomatcher.verifier.util.VerifyJobCancelingListener;
import com.nec.biomatcher.verifier.util.VerifyJobInfo;
import com.nec.biomatcher.verifier.util.VerifyProtobufUtil;
import com.nec.megha.proto.verify.VerifyRequestProto.VerifyRequest;

/**
 * The Class BioVerificationServiceImpl.
 */
public class BioVerificationServiceImpl implements BioVerificationService, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioVerificationServiceImpl.class);

	private static final Logger VERIFY_JOB_NODE_REQUEST_LOGGER = Logger.getLogger("VERIFY_JOB_NODE_REQUEST");

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The bio matcher config service. */
	protected BioMatcherConfigService bioMatcherConfigService;

	/** The biometric event service. */
	private BiometricEventService biometricEventService;

	private TemplateDataService templateDataService;

	/** The verify controller id. */
	private String verifyControllerId;

	private MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper;

	private JobSlotClusterService verifyClusterService;
	
	private ITopic<String> notifyVerifyJobCancelingTopic;
	
	private String notifyVerifyJobCancelingTopicListenerId;

	private MatcherNodeClientHelper matcherNodeClientHelper = new MatcherNodeClientHelper();

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	public String getVerificationControllerId() {
		return verifyControllerId;
	}

	public JobSlotClusterService getVerifyClusterService() {
		return verifyClusterService;
	}

	public void submitVerificationJob(String verifyJobId, VerifyJobInfo verifyJobInfo)
			throws BioMatcherNodeClientException, BioMatcherNodeConnectionException, BioMatcherNodeSendException,
			BioMatcherNodeReceiveException, BioVerificationTimeoutException {
		if (logger.isTraceEnabled())
			logger.trace("In submitVerificationJob: verifyJobId: " + verifyJobId);
		try {
			VerifyJobRequestDto request = verifyJobInfo.getJobRequestDto();

			validateVerifyJobRequest(request);

			loadTemplateData(request.getProbeBiomericData(), request.getGalleryBiomericDataList());

			long minVerifyJobTimeoutMilli = bioParameterService.getParameterValue("MIN_VERIFY_JOB_TIMEOUT_MILLI",
					"DEFAULT", 500L);

			long timeoutMilli = verifyJobInfo.getJobTimeoutMill();

			timeoutMilli = timeoutMilli - (System.currentTimeMillis() - verifyJobInfo.getCreateTimestampMilli());

			if (timeoutMilli < minVerifyJobTimeoutMilli) {
				throw new BioVerificationTimeoutException(
						"In submitVerificationJob: Not enough time left to execute verify job. timeoutMilli: "
								+ timeoutMilli + ", minVerifyJobTimeoutMilli: " + minVerifyJobTimeoutMilli);
			}

			long queuePollStartTimeMilli = System.currentTimeMillis();
			String verifyNodeId = null;
			try {
				verifyNodeId = verifyClusterService.acquireJobSlot(timeoutMilli);
			} catch (Throwable th) {
				logger.error("Error during verifyClusterService.acquireJobSlot: " + th.getMessage(), th);
				throw new BioMatcherNodeClientException(
						"Error during verifyClusterService.acquireJobSlot: " + th.getMessage(), th);
			} finally {
				MetricsUtil.checkAndTime("FUNCTION.VERIFY.ASSIGN_TIME_TAKEN",
						(System.currentTimeMillis() - queuePollStartTimeMilli), TimeUnit.MILLISECONDS);
			}

			if (verifyNodeId == null) {
				throw new BioVerificationTimeoutException(
						"In submitVerificationJob: Verify job slot not available, waited for timeoutMilli: "
								+ timeoutMilli);
			}

			verifyJobInfo.assignVerifyNodeId(verifyNodeId);

			long queuePollTimeTakenMilli = System.currentTimeMillis() - queuePollStartTimeMilli;
			timeoutMilli = timeoutMilli - queuePollTimeTakenMilli;
			if (timeoutMilli < minVerifyJobTimeoutMilli) {
				throw new BioVerificationTimeoutException(
						"In submitVerificationJob: Not enough time left to execute verify job. timeoutMilli: "
								+ timeoutMilli + ", queuePollTimeTakenMilli: " + queuePollTimeTakenMilli
								+ ", minVerifyJobTimeoutMilli: " + minVerifyJobTimeoutMilli);
			}

			submitVerificationJobInternal(verifyJobId, verifyNodeId, request, timeoutMilli);				

			verifyJobInfo.setSubmitTimestampMilli(System.currentTimeMillis());
		} catch (BioMatcherNodeConnectionException | BioMatcherNodeSendException | BioMatcherNodeClientException
				| BioVerificationTimeoutException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioMatcherNodeClientException("Error in submitVerificationJob: " + th.getMessage(), th);
		}
	}

	private void submitVerificationJobInternal(String verifyJobId, String verifyNodeId, VerifyJobRequestDto request,
			long timeoutMilli) throws BioMatcherNodeClientException, BioMatcherNodeConnectionException,
			BioMatcherNodeSendException, BioMatcherNodeReceiveException, BioVerificationTimeoutException {
		if (logger.isTraceEnabled())
			logger.trace("In submitVerificationJobInternal: verifyJobId: " + verifyJobId + ", timeoutMilli: "
					+ timeoutMilli);

		Stopwatch stopWatch = Stopwatch.createStarted();

		try (Closeable timer = MetricsUtil.time(BioComponentType.VN, verifyNodeId, "VN_JOB_SEND_TIME_TAKEN")) {
			String verifyCallbackUrl = getVerifyResultCallbackUrl();

			VerifyRequest requestPayload = VerifyProtobufUtil.toProtobuf(verifyJobId, request, verifyCallbackUrl,
					bioParameterService);

			if (VERIFY_JOB_NODE_REQUEST_LOGGER.isTraceEnabled()) {
				VERIFY_JOB_NODE_REQUEST_LOGGER.trace("verifyNodeId: " + verifyNodeId + ", verifyJobId: " + verifyJobId
						+ ", requestPayload: " + requestPayload.toString());
			}

			String enConnectionUrl = getVerifyNodeConnectionUrl(verifyNodeId, BioConnectionType.WORKER);

			ZmqPushConnection.sendMessage(enConnectionUrl, verifyNodeId + "_" + verifyJobId,
					requestPayload.toByteArray());
		} catch (ZmqSendException ex) {
			logger.error("ZmqSendException in submitVerificationJobInternal: " + ex.getMessage(), ex);

			verifyClusterService.notifyOffline(verifyNodeId);

			BioMatcherNodeSendException sendEx = new BioMatcherNodeSendException(
					"ZmqSendException in submitVerificationJobInternal: " + ex.getMessage(), ex);

			matcherNodeClientHelper.handleSendReceiveError(verifyNodeId, BioComponentType.VN, sendEx);

			throw sendEx;
		} catch (Throwable th) {
			logger.error(th.getClass().getSimpleName() + " Error in submitVerificationJobInternal: " + th.getMessage(),
					th);

			// verifyClusterService.releaseJobSlot(verifyNodeId);

			if (!(th instanceof BioMatcherNodeClientException)) {
				th = new BioMatcherNodeClientException(
						th.getClass().getName() + " in submitVerificationJobInternal: " + th.getMessage(), th);
			}

			matcherNodeClientHelper.handleSendReceiveError(verifyNodeId, BioComponentType.VN, th);

			throw new BioMatcherNodeClientException("Error in submitVerificationJobInternal: " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = stopWatch.elapsed(TimeUnit.MILLISECONDS);
			if (timeTakenMilli > 5 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In submitVerificationJobInternal: TimeTakenMilli: " + timeTakenMilli
						+ ", verifyNodeId: " + verifyNodeId);
			}
		}
	}

	private final String getVerifyResultCallbackUrl() throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(verifyControllerId, BioComponentType.VC,
				BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
					"Error in getVerifyResultCallbackUrl: callback url is not configured for verifyControllerId: "
							+ verifyControllerId + ", connectionType: " + BioConnectionType.WORKER_CALLBACK
							+ ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	private final String getVerifyNodeConnectionUrl(String verifyNodeId, BioConnectionType bioConnectionType)
			throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(verifyNodeId, BioComponentType.VN,
				bioConnectionType, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException("Verify node connection url is not configured for verifyNodeId: "
					+ verifyNodeId + ", BioComponentType: " + BioComponentType.VN + ", connectionType: "
					+ bioConnectionType + ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	private void validateVerifyJobRequest(VerifyJobRequestDto verifyJobRequestDto) throws BioVerificationException {
		if (verifyJobRequestDto.getProbeBiomericData() == null) {
			throw new IllegalArgumentException("ProbeBiomericData is not set");
		}

		boolean probeDataFound = false;

		if (verifyJobRequestDto.getProbeBiomericData().hasFeatureDataList()) {
			probeDataFound = true;
		}

		if (verifyJobRequestDto.getProbeBiomericData().hasImageList()) {
			probeDataFound = true;
		}

		if (verifyJobRequestDto.getProbeBiomericData().hasTemplateInfoList()) {
			probeDataFound = true;
		}

		if (verifyJobRequestDto.getProbeBiomericData().getContainerId() != null) {
			probeDataFound = true;
		}

		if (!probeDataFound) {
			throw new IllegalArgumentException("Probe biometric data is incomplete");
		}

		for (VerifyBiometricData galleryBiometricData : verifyJobRequestDto.getGalleryBiomericDataList()) {
			boolean galleryDataFound = false;

			if (galleryBiometricData.hasFeatureDataList()) {
				galleryDataFound = true;
			} else if (galleryBiometricData.hasImageList()) {
				galleryDataFound = true;
			} else if (galleryBiometricData.hasTemplateInfoList()) {
				galleryDataFound = true;
			} else if (galleryBiometricData.getContainerId() != null) {
				galleryDataFound = true;
			}

			if (!galleryDataFound) {
				throw new IllegalArgumentException("Gallery data is incomplete");
			}
		}
	}

	private void loadTemplateData(VerifyBiometricData probeVerifyBiometricData,
			List<VerifyBiometricData> galleryVerifyBiometricDataList) throws BioVerificationException {
		loadTemplates(probeVerifyBiometricData);

		for (VerifyBiometricData verifyBiometricData : galleryVerifyBiometricDataList) {
			loadTemplates(verifyBiometricData);
		}
	}

	private void loadTemplates(VerifyBiometricData verifyBiometricData) throws BioVerificationException {
		if (CollectionUtils.isNotEmpty(verifyBiometricData.getImageList())) {
			return;
		}

		if (CollectionUtils.isNotEmpty(verifyBiometricData.getFeatureDataList())) {
			return;
		}

		if (CollectionUtils.isNotEmpty(verifyBiometricData.getTemplateInfoList())) {
			return;
		}

		try {
			if (verifyBiometricData.getContainerId() == null) {
				throw new BioVerificationException(
						"ContainerId is not set for externalId: " + verifyBiometricData.getCandidateId());
			}

			BiometricEventInfo biometricEventInfo = biometricEventService.getLatestBiometricEventInfoByExternalId(
					verifyBiometricData.getCandidateId(), verifyBiometricData.getContainerId());
			if (biometricEventInfo == null) {
				throw new BioVerificationException("BiometricEventInfo does not exists with externalId: "
						+ verifyBiometricData.getCandidateId() + ", binId: " + verifyBiometricData.getContainerId());
			}

			if (!BiometricEventStatus.ACTIVE.equals(biometricEventInfo.getStatus())) {
				throw new BioVerificationException("BiometricEventInfo is deleted for externalId: "
						+ verifyBiometricData.getCandidateId() + ", binId: " + verifyBiometricData.getContainerId()
						+ ", biometricId: " + biometricEventInfo.getBiometricId());
			}

			if (StringUtils.isBlank(biometricEventInfo.getTemplateDataKey())) {
				throw new BioVerificationException("TemplateDataKey is null for BiometricEventInfo wiht externalId: "
						+ verifyBiometricData.getCandidateId() + ", binId: " + verifyBiometricData.getContainerId());
			}

			byte templateBytes[] = templateDataService.getTemplateData(biometricEventInfo.getTemplateDataKey());

			BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigService
					.getMatcherBinInfo(verifyBiometricData.getContainerId());
			if (bioMatcherBinInfo == null) {
				throw new BioVerificationException(
						"BioMatcherBinInfo does not exists with binId: " + verifyBiometricData.getContainerId());
			}

			verifyBiometricData.getTemplateInfoList()
					.add(new TemplateInfo(bioMatcherBinInfo.getTemplateType(), templateBytes));
		} catch (BioVerificationException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioVerificationException(th.getMessage(), th);
		}
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBiometricEventService(BiometricEventService biometricEventService) {
		this.biometricEventService = biometricEventService;
	}

	public void setTemplateDataService(TemplateDataService templateDataService) {
		this.templateDataService = templateDataService;
	}

	public void setMatcherNodeStatusCheckHelper(MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper) {
		this.matcherNodeStatusCheckHelper = matcherNodeStatusCheckHelper;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		try {
			synchronized (BioVerificationServiceImpl.class) {
				if (initializationCount.get() > 0) {
					CommonLogger.STATUS_LOG
							.warn("BioVerificationServiceImpl.afterPropertiesSet is called multiple times: initializationCount: "
									+ initializationCount.get());
					return;
				}

				initializationCount.incrementAndGet();

				verifyClusterService = new JobSlotClusterService(BioComponentType.VC, BioComponentType.VN,
						(verifyNodeId -> matcherNodeStatusCheckHelper.sendServerCapacity(verifyNodeId)),
						bioMatcherConfigService, bioParameterService);
				verifyControllerId = verifyClusterService.getControllerId();
				HazelcastInstance verifyHazelcastInstance = verifyClusterService.getHazelcastInstance();
				this.notifyVerifyJobCancelingTopic = verifyHazelcastInstance.getTopic("NotifyVerifyJobCanceling");				
				notifyVerifyJobCancelingTopicListenerId = this.notifyVerifyJobCancelingTopic.addMessageListener(new VerifyJobCancelingListener());
			}
		} catch (Throwable th) {
			CommonLogger.STATUS_LOG.error("Error in BioVerificationServiceImpl.afterPropertiesSet: " + th.getMessage(),
					th);
			throw new BioVerificationException("Error in afterPropertiesSet: " + th.getMessage(), th);
		}
	}

	@Override
	public void notifyVerifyJobCanceling(String msg) {
		notifyVerifyJobCancelingTopic.publish(msg);		
	}
}
