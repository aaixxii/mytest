package com.nec.biomatcher.verifier.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.megha.proto.common.CommonProto.AlgorithmType;
import com.nec.megha.proto.common.CommonProto.CapsuleType;
import com.nec.megha.proto.common.CommonProto.FeatureData;
import com.nec.megha.proto.common.CommonProto.KeyValueGroupHolder;
import com.nec.megha.proto.common.CommonProto.Minutia;
import com.nec.megha.proto.common.CommonProto.MinutiaData;
import com.nec.megha.proto.common.CommonProto.Status;
import com.nec.megha.proto.common.CommonProto.SubType;
import com.nec.megha.proto.verify.VerifyResponseProto.MinutiaPair;
import com.nec.megha.proto.verify.VerifyResponseProto.RawScore;
import com.nec.megha.proto.verify.VerifyResponseProto.VerifyResponse;
import com.nec.megha.proto.verify.VerifyResponseProto.VerifyResponse.Candidate;

public class VerifyProtobufUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetVerifyJobResult() throws InvalidProtocolBufferException {
		VerifyResponse verifyResponse = buildVerifyResponse("verifyjob1", true);
		VerifyJobResultDto resultDto = VerifyProtobufUtil.getVerifyJobResult(verifyResponse);
		Assert.assertNotNull(resultDto);	
		Assert.assertEquals(5, resultDto.getCandidateResultList().size());		
		Assert.assertEquals(3, resultDto.getFeatureData().getMinutiaDataList().size());
		Assert.assertEquals(27, resultDto.getFeatureData().getMinutiaDataList().get(0).getMinutia().getAlgorithmType().getValue().intValue());
		Assert.assertEquals("MinutiaDataForTest", new String(resultDto.getFeatureData().getMinutiaDataList().get(0).getMinutia().getData()));	
		Assert.assertNotNull(resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getTargetMatchedAreaCenter());	
		Assert.assertNotNull(resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getProbeMatchedAreaCenter());	
		Assert.assertEquals(3, resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getMinutiaPairList().size());
		Assert.assertNotNull(resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getProbeMinutiaDataIndex());
		Assert.assertNotNull(resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getTargetMinutiaDataIndex());
		
		ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
		try {
			String jsonInString = mapper.writeValueAsString(resultDto);
			System.out.println(jsonInString);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}		
	}
	
	@Test
	public void testGetVerifyJobResult_no_featureData() throws InvalidProtocolBufferException {
		VerifyResponse verifyResponse = buildVerifyResponse("verifyjob1", false);
		VerifyJobResultDto resultDto = VerifyProtobufUtil.getVerifyJobResult(verifyResponse);
		Assert.assertNotNull(resultDto);	
		Assert.assertEquals(5, resultDto.getCandidateResultList().size());	
		Assert.assertNull(resultDto.getFeatureData());
		Assert.assertNotNull(resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getTargetMatchedAreaCenter());	
		Assert.assertEquals(3, resultDto.getCandidateResultList().get(0).getModalScoreList().get(0).getRawScoreList().get(0).getMinutiaPairList().size());
		
		ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
		try {
			String jsonInString = mapper.writeValueAsString(resultDto);
			System.out.println(jsonInString);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}		
	}

	public static VerifyResponse buildVerifyResponse(String jobId, boolean haveFeatureData) {
		VerifyResponse.Builder verifyReponseBuilder = VerifyResponse.newBuilder();

		verifyReponseBuilder.setMsgId(jobId);
		verifyReponseBuilder.setKvGroupHolder(KeyValueGroupHolder.newBuilder().build());
		verifyReponseBuilder.setStatus(Status.newBuilder().setSuccess(true).build());

		long timestamp = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			Candidate.Builder candidateBuilder = Candidate.newBuilder();
			candidateBuilder.setCandidateId("CandidateId" + (i + timestamp));
			candidateBuilder.addAllRawScore(buildRawScore(3));
			verifyReponseBuilder.addCandidate(candidateBuilder.build());
		}
		if (haveFeatureData) {
			verifyReponseBuilder.setFeature(buildFeatureData(CapsuleType.CAPSULE_TYPE_35));
		}		
		return verifyReponseBuilder.build();
	}
	
	private static List<RawScore> buildRawScore(int count) {
		final List<RawScore> rawScoreList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			RawScore.Builder rawScoreBuilder = RawScore.newBuilder();
			rawScoreBuilder.setProbeMinutiaDataIndex(i);
			rawScoreBuilder.setTargetMinutiaDataIndex(i);
			rawScoreBuilder.setAlgType(AlgorithmType.AlgFingerLFML);
			rawScoreBuilder.setProbeSubType(SubType.SUB_TYPE_ROLL_LINDEX);
			rawScoreBuilder.setTargetSubType(SubType.SUB_TYPE_SLAP_LINDEX);
			rawScoreBuilder.setQuality(10);			
			rawScoreBuilder.setScore(999);
			rawScoreBuilder.setTargetSubType(SubType.SUB_TYPE_ROLL_LINDEX);
			com.nec.megha.proto.verify.VerifyResponseProto.MatchedAreaCenter.Builder probePoint = 
					com.nec.megha.proto.verify.VerifyResponseProto.MatchedAreaCenter.newBuilder();
			probePoint.setX(100);
			probePoint.setY(100);
			rawScoreBuilder.setProbeMatchedAreaCenter(probePoint.build());
			com.nec.megha.proto.verify.VerifyResponseProto.MatchedAreaCenter.Builder targetPoint = 
					com.nec.megha.proto.verify.VerifyResponseProto.MatchedAreaCenter.newBuilder();
			targetPoint.setX(200);
			targetPoint.setY(200);
			rawScoreBuilder.setTargetMatchedAreaCenter(targetPoint);
			rawScoreBuilder.addAllMinutiaPair(buildMinutiaPair(3));	
			rawScoreList.add(rawScoreBuilder.build());
		}		
		return rawScoreList;		
	}

	private static List<MinutiaPair> buildMinutiaPair(int count) {
		final List<MinutiaPair> minutiaPairList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			MinutiaPair.Builder builder = MinutiaPair.newBuilder();
			builder.setSimilitude(1);
			builder.setProbeDirection(2);
			builder.setProbeMinutiaNumber(2);
			builder.setProbeX(100);
			builder.setProbeY(100);
			builder.setTargetDirection(2);
			builder.setTargetX(200);
			builder.setTargetY(200);			
			builder.setProbeMinutiaNumber(150);			
			builder.setTargetMinutiaNumber(250);
			minutiaPairList.add(builder.build());
		}
		return minutiaPairList;
	}
	private static FeatureData buildFeatureData(CapsuleType capsuleType) {		
		final FeatureData.Builder build = FeatureData.newBuilder();
		build.setAlgType(AlgorithmType.AlgFingerLFML);
		build.setSubType(SubType.SUB_TYPE_FACE);
		build.setData(ByteString.copyFrom("FeatureDataForTest".getBytes()));
		build.addAllMinutiaData(buildMinutiaDataList(3));	
		
		return build.build();	
		
	}
	
	private static List<MinutiaData> buildMinutiaDataList(int count) {
		final List<MinutiaData> minutiaDataList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			MinutiaData.Builder md = MinutiaData.newBuilder();
			Minutia.Builder mt = Minutia.newBuilder();
			mt.setAlgType(AlgorithmType.AlgFingerCML);
			mt.setData(ByteString.copyFrom("MinutiaDataForTest".getBytes()));
			md.setIndex(i);
			md.setMinutia(mt.build());			
			minutiaDataList.add(md.build());
		}
		return minutiaDataList;	
	}
}
