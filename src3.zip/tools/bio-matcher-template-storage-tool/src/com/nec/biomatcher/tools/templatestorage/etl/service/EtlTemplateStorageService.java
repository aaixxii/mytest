package com.nec.biomatcher.tools.templatestorage.etl.service;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateDataInfo;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.tools.templatestorage.etl.service.exceptions.EtlTemplateStorageServiceException;

public interface EtlTemplateStorageService {

	public Map<Integer, String> getTemplateStorageInfoMap() throws EtlTemplateStorageServiceException;

	public void saveTemplateDataInfoList(
			Collection<BiKey<BiometricEventInfo, BioTemplateDataInfo>> templateDataInfoList)
			throws EtlTemplateStorageServiceException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Long afterBiometricId, int maxRecords) throws EtlTemplateStorageServiceException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Date catchupFromDate, Long afterBiometricId, int maxRecords) throws EtlTemplateStorageServiceException;

	public List<BiometricIdInfo> getActiveBiometricIdInfoList() throws EtlTemplateStorageServiceException;
}
