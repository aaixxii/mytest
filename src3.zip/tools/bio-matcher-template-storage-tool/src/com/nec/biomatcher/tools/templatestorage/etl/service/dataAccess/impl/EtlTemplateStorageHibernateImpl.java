package com.nec.biomatcher.tools.templatestorage.etl.service.dataAccess.impl;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.google.common.collect.Lists;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDaoException;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;
import com.nec.biomatcher.tools.templatestorage.etl.EtlLogger;
import com.nec.biomatcher.tools.templatestorage.etl.service.dataAccess.EtlTemplateStorageDao;

public class EtlTemplateStorageHibernateImpl extends AbstractHibernateDao implements EtlTemplateStorageDao {
	private static final Logger logger = Logger.getLogger(EtlTemplateStorageHibernateImpl.class);

	public void updateBiometricEventTemplateDataKey(List<Long> biometricIdList) throws DaoException {
		try {
			String hql = "update BiometricEventInfo set templateDataKey=biometricId where biometricId in (:biometricId)";

			final Session session = this.currentSession();

			for (List<Long> subBiometricIdList : Lists.partition(biometricIdList, 1000)) {
				long startTimestampMilli = System.currentTimeMillis();
				int updateCount = session.createQuery(hql).setParameterList("biometricId", subBiometricIdList)
						.executeUpdate();

				long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
				if (logger.isDebugEnabled() || timeTakenMilli > 300) {
					EtlLogger.PREF.info(
							"In updateBiometricEventTemplateDataKey: subBiometricIdList: " + subBiometricIdList.size()
									+ ", updateCount: " + updateCount + ", timeTakenMilli: " + timeTakenMilli);
				}
			}
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	public void markBiometricEventsAsCorrupted(List<Long> corruptedBiometricIdList) throws DaoException {
		try {
			final Session session = this.currentSession();

			for (List<Long> subCorruptedBiometricIdList : Lists.partition(corruptedBiometricIdList, 1000)) {
				long startTimestampMilli = System.currentTimeMillis();
				String hql = "update BiometricEventInfo set phase=:newPhase, segmentSyncDateTime=:updateDateTime, updateDateTime=:updateDateTime where biometricId in (:biometricId)";
				int updateCount = session.createQuery(hql).setParameter("newPhase", BiometricEventPhase.DATA_ERROR)
						.setTimestamp("updateDateTime", new Date())
						.setParameterList("biometricId", subCorruptedBiometricIdList).executeUpdate();

				long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
				if (logger.isDebugEnabled() || timeTakenMilli > 300) {
					EtlLogger.PREF.info("In markBiometricEventsAsCorrupted: subCorruptedBiometricIdList: "
							+ subCorruptedBiometricIdList.size() + ", updateCount: " + updateCount
							+ ", timeTakenMilli: " + timeTakenMilli);
				}
			}
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	public void deleteTemplateDataInfoList(List<String> templateDataIdList) throws DaoException {
		try {
			long startTimestampMilli = System.currentTimeMillis();
			int updateCount = 0;
			String hql = "delete from BioTemplateDataInfo where templateDataId in (:templateDataIdList)";
			Session session = this.currentSession();

			for (List<String> subTemplateDataIdList : Lists.partition(templateDataIdList, 1000)) {
				updateCount += session.createQuery(hql).setParameterList("templateDataIdList", subTemplateDataIdList)
						.executeUpdate();
			}
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (logger.isDebugEnabled() || timeTakenMilli > 300) {
				EtlLogger.PREF
						.info("In deleteTemplateDataInfoList: templateDataIdListSize: " + templateDataIdList.size()
								+ ", updateCount: " + updateCount + ", timeTakenMilli: " + timeTakenMilli);
			}
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	@SuppressWarnings("unchecked")
	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Long afterBiometricId, int maxRecords) throws DaoException {
		try {
			Criteria criteria = this.currentSession().createCriteria(BiometricEventInfo.class)
					.add(Restrictions.eq("assignedSegmentId", segmentId))
					.add(Restrictions.gt("biometricId", afterBiometricId))
					.add(Restrictions.eq("status", BiometricEventStatus.ACTIVE));

			criteria.addOrder(Order.asc("biometricId"));
			criteria.setMaxResults(maxRecords);

			return (List<BiometricEventInfo>) criteria.list();
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	@SuppressWarnings("unchecked")
	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Date catchupFromDate, Long afterBiometricId, int maxRecords) throws DaoException {
		try {
			Criteria criteria = this.currentSession().createCriteria(BiometricEventInfo.class)
					.add(Restrictions.eq("assignedSegmentId", segmentId))
					.add(Restrictions.ge("updateDateTime", catchupFromDate))
					.add(Restrictions.gt("biometricId", afterBiometricId))
					.add(Restrictions.eq("status", BiometricEventStatus.ACTIVE));

			criteria.addOrder(Order.asc("biometricId"));
			criteria.setMaxResults(maxRecords);

			return (List<BiometricEventInfo>) criteria.list();
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	@SuppressWarnings("unchecked")
	public List<BiometricIdInfo> getActiveBiometricIdInfoList() throws DaoException {
		try {
			List<BiometricIdInfo> activeBiometricIdInfoList = this.currentSession()
					.createCriteria(BiometricIdInfo.class).add(Restrictions.gt("currentBiometricId", -1L)).list();

			return activeBiometricIdInfoList;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

}
