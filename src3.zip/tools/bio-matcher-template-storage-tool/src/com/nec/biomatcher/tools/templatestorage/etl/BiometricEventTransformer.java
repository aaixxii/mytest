package com.nec.biomatcher.tools.templatestorage.etl;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.InitializingBean;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateDataInfo;
import com.nec.biomatcher.comp.template.storage.util.TemplateFileUtil;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.exception.InvalidDataException;
import com.nec.biomatcher.tools.templatestorage.etl.service.EtlTemplateStorageService;

public class BiometricEventTransformer implements InitializingBean {

	private EtlContext etlContext;
	private EtlTemplateStorageService etlTemplateStorageService;

	private Map<Integer, String> templateStoragePathMap;

	public void transform() {
		Thread.currentThread().setName("ETL_transform_" + Thread.currentThread().getId());
		EtlLogger.CONFIG.info("In BiometricEventTransformer.transform");
		try {
			final LinkedBlockingQueue<BiometricEventInfo> transformerQueue = etlContext.getTransformerQueue();
			final LinkedBlockingQueue<BiKey<BiometricEventInfo, BioTemplateDataInfo>> loaderQueue = etlContext
					.getLoaderQueue();
			while (!ShutdownHook.isShutdownFlag) {
				BiometricEventInfo biometricEventInfo = null;
				try {
					biometricEventInfo = transformerQueue.poll(30, TimeUnit.SECONDS);
				} catch (Throwable th) {
					EtlLogger.ERROR.error("Error in BiometricEventTransformer.transform during transformerQueue.poll: "
							+ th.getMessage(), th);
				}

				if (biometricEventInfo == null) {
					if (etlContext.getIsExtractorCompletedFlag()) {
						if (transformerQueue.isEmpty()) {
							EtlLogger.STATUS.info(
									"In BiometricEventTransformer.transform: Extractor is completed and transformerQueue is empty");
							etlContext.setIsTransformerCompletedFlag(true);
							break;
						} else {
							continue;
						}
					} else {
						continue;
					}
				}

				byte[] templateData = null;
				try {
					templateData = TemplateFileUtil.getTemplateData(biometricEventInfo.getTemplateDataKey(),
							templateStoragePathMap);
					if (templateData == null || templateData.length == 0) {
						templateData = null;
						throw new InvalidDataException("templateData is null/empty for templateDataKey: "
								+ biometricEventInfo.getTemplateDataKey());
					}
				} catch (Throwable th) {
					EtlLogger.ERROR
							.error("Error in BiometricEventTransformer.transform during getTemplateData for templateDataKey: "
									+ biometricEventInfo.getTemplateDataKey() + " : " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
				}

				if (templateData != null) {
					BioTemplateDataInfo bioTemplateDataInfo = new BioTemplateDataInfo();
					bioTemplateDataInfo.setTemplateDataId(biometricEventInfo.getBiometricId().toString());
					bioTemplateDataInfo.setTemplateData(templateData);
					bioTemplateDataInfo.setCreateDateTime(new Date());
					bioTemplateDataInfo.setUpdateDateTime(bioTemplateDataInfo.getCreateDateTime());

					Uninterruptibles.putUninterruptibly(loaderQueue, new BiKey<BiometricEventInfo, BioTemplateDataInfo>(
							biometricEventInfo, bioTemplateDataInfo));
				} else {
					Uninterruptibles.putUninterruptibly(loaderQueue,
							new BiKey<BiometricEventInfo, BioTemplateDataInfo>(biometricEventInfo, null));
				}
			}
		} finally {
			EtlLogger.CONFIG.info("In BiometricEventTransformer.transform finally");
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		EtlLogger.CONFIG.info("In BiometricEventTransformer.afterPropertiesSet");

		templateStoragePathMap = etlTemplateStorageService.getTemplateStorageInfoMap();
		EtlLogger.CONFIG
				.info("In BiometricEventTransformer: templateStoragePathMapSize: " + templateStoragePathMap.size());

		if (templateStoragePathMap.isEmpty()) {
			throw new IllegalArgumentException("templateStoragePathMap is empty");
		}

		EtlLogger.CONFIG.info(
				"In BiometricEventTransformer: transformerConcurrency: " + etlContext.getTransformerConcurrency());

		for (int i = 0; i < etlContext.getTransformerConcurrency(); i++) {
			CommonTaskScheduler.CACHED_EXECUTORSERVICE.submit(this::transform);
			EtlLogger.CONFIG.info("In BiometricEventTransformer: After scheduling transformer task, index: " + (i + 1));
		}
	}

	public void setEtlContext(EtlContext etlContext) {
		this.etlContext = etlContext;
	}

	public void setEtlTemplateStorageService(EtlTemplateStorageService etlTemplateStorageService) {
		this.etlTemplateStorageService = etlTemplateStorageService;
	}

}
