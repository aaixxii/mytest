package com.nec.biomatcher.tools.templatestorage.etl.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateDataInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateStorageInfo;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.tools.templatestorage.etl.EtlLogger;
import com.nec.biomatcher.tools.templatestorage.etl.service.EtlTemplateStorageService;
import com.nec.biomatcher.tools.templatestorage.etl.service.dataAccess.EtlTemplateStorageDao;
import com.nec.biomatcher.tools.templatestorage.etl.service.exceptions.EtlTemplateStorageServiceException;

public class EtlTemplateStorageServiceImpl implements EtlTemplateStorageService {
	private EtlTemplateStorageDao etlTemplateStorageDao;

	public Map<Integer, String> getTemplateStorageInfoMap() throws EtlTemplateStorageServiceException {
		try {
			Map<Integer, String> templateStorageInfoMap = etlTemplateStorageDao
					.getAllEntity(BioTemplateStorageInfo.class).stream().collect(Collectors
							.toMap(BioTemplateStorageInfo::getStorageId, BioTemplateStorageInfo::getRootPath));
			return templateStorageInfoMap;
		} catch (Throwable th) {
			throw new EtlTemplateStorageServiceException("Error in getTemplateStorageInfoList: " + th.getMessage(), th);
		}
	}

	public void saveTemplateDataInfoList(
			Collection<BiKey<BiometricEventInfo, BioTemplateDataInfo>> bioEventTemplateDataInfoList)
			throws EtlTemplateStorageServiceException {
		PFLogger.start();
		try {
			List<Long> biometricIdList = new ArrayList<>();
			List<String> templateDataIdList = new ArrayList<>();
			List<Long> corruptedBiometricIdList = new ArrayList<>();
			List<BioTemplateDataInfo> bioTemplateDataInfoList = new ArrayList<>();

			for (BiKey<BiometricEventInfo, BioTemplateDataInfo> biKey : bioEventTemplateDataInfoList) {
				BiometricEventInfo biometricEventInfo = biKey.getA();
				BioTemplateDataInfo bioTemplateDataInfo = biKey.getB();
				if (bioTemplateDataInfo != null) {
					bioTemplateDataInfoList.add(bioTemplateDataInfo);
					templateDataIdList.add(bioTemplateDataInfo.getTemplateDataId());
					biometricIdList.add(biometricEventInfo.getBiometricId());
				} else {
					corruptedBiometricIdList.add(biometricEventInfo.getBiometricId());
					EtlLogger.CORRUPTED.info(biometricEventInfo.getBiometricId());
				}
			}

			if (!templateDataIdList.isEmpty()) {
				etlTemplateStorageDao.deleteTemplateDataInfoList(templateDataIdList);
			}

			for (BioTemplateDataInfo bioTemplateDataInfo : bioTemplateDataInfoList) {
				etlTemplateStorageDao.saveEntity(bioTemplateDataInfo);
			}

			if (biometricIdList.size() > 0) {
				etlTemplateStorageDao.updateBiometricEventTemplateDataKey(biometricIdList);
			}

			if (corruptedBiometricIdList.size() > 0) {
				etlTemplateStorageDao.markBiometricEventsAsCorrupted(corruptedBiometricIdList);
			}
		} catch (Throwable th) {
			throw new EtlTemplateStorageServiceException(th.getMessage(), th);
		} finally {
			PFLogger.end("bioEventTemplateDataInfoListSize: " + bioEventTemplateDataInfoList.size());
		}
	}

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Long afterBiometricId, int maxRecords) throws EtlTemplateStorageServiceException {
		PFLogger.start();
		try {
			return etlTemplateStorageDao.getActiveBiometricEventInfoListBySegmentIdAndBiometricId(segmentId,
					afterBiometricId, maxRecords);
		} catch (Throwable th) {
			throw new EtlTemplateStorageServiceException(th.getMessage(), th);
		} finally {
			PFLogger.end("segmentId: " + segmentId + ", afterBiometricId: " + afterBiometricId + ", maxRecords: "
					+ maxRecords);
		}
	}

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Date catchupFromDate, Long afterBiometricId, int maxRecords) throws EtlTemplateStorageServiceException {
		PFLogger.start();
		try {
			return etlTemplateStorageDao.getActiveBiometricEventInfoListBySegmentIdAndBiometricId(segmentId,
					catchupFromDate, afterBiometricId, maxRecords);
		} catch (Throwable th) {
			throw new EtlTemplateStorageServiceException(th.getMessage(), th);
		} finally {
			PFLogger.end("segmentId: " + segmentId + ", catchupFromDate: " + catchupFromDate + ", afterBiometricId: "
					+ afterBiometricId + ", maxRecords: " + maxRecords);
		}
	}

	public List<BiometricIdInfo> getActiveBiometricIdInfoList() throws EtlTemplateStorageServiceException {
		try {
			return etlTemplateStorageDao.getActiveBiometricIdInfoList();
		} catch (Throwable th) {
			throw new EtlTemplateStorageServiceException(th.getMessage(), th);
		}
	}

	public void setEtlTemplateStorageDao(EtlTemplateStorageDao etlTemplateStorageDao) {
		this.etlTemplateStorageDao = etlTemplateStorageDao;
	}
}
