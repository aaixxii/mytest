Tool: Template Data Storage Tool
Description: This tool copies the template files stored in file system to database.
- First it will save the template to  BIO_TEMPLATE_DATA_INFO
- Then update BIO_EVENT_INFO.TEMPLATE_DATA_KEY field with BIOMETRIC_ID

Note:
Before starting the tool, Please configure the datasource information in conf/spring-etl-config.xml file 