package com.nec.biomatcher.extractor.util;

import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.extractor.queueing.ExtractionJobQueueHelper;

import io.netty.util.internal.StringUtil;

public class ExtractionJobCancelingListener implements MessageListener<String> {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(ExtractionJobCancelingListener.class);
	
	private ExtractionJobQueueHelper extractionJobQueueHelper;
	
	public ExtractionJobCancelingListener() {
		logger.info("In ExtractionJobCancelingListener()");
	}

	@Override
	public void onMessage(final Message<String> meg) {		
		String msg = meg.getMessageObject();
		if (StringUtil.isNullOrEmpty(msg)) {
			logger.info("Recevied empty string, return");
			return;
		}		
		logger.info("Got message from notifyExtractJobCancelingTopic. Recevied messge:" + msg );
		if (this.extractionJobQueueHelper == null) {
			getExtractionJobQueueHelper();
		}
		String myExtractControllerId = extractionJobQueueHelper.getExtractionControllerId();
		if (StringUtil.isNullOrEmpty(myExtractControllerId)) {
			logger.info("myExtractControllerId is null or empty , return");
			return;
		}		
		logger.info("My extractionCotrol Id:" + myExtractControllerId);
		String receivedEcIds = msg.split(":")[0];
		if (!receivedEcIds.contains(myExtractControllerId)) {
			logger.info("Received ECIDs is not contain my Id, return");
			return;
		}
		String extractJobId =  msg.split(":")[1];
		if (StringUtils.isBlank(extractJobId)) {
			logger.info("rceived empty extraction job id. skip process.");
			return;
		}		
		try {
			ConcurrentHashMap<String, ExtractJobInfo> extReqMap = extractionJobQueueHelper.getExtractJobRequestMap();
			ExtractJobInfo extractJobInfo = extReqMap.get(extractJobId);
			if (extractJobInfo == null) {
				logger.warn("ExtractJob is not in my memory, jobId=" + extractJobId + " EC="+ myExtractControllerId + ". It may be finished or keeped in other EC.");				
			}
			
			extractionJobQueueHelper.deleteMyExtractJob(extractJobId);					
			logger.info("Success to delete extarctJob. extractJobId: " + extractJobId + " by EC:" + myExtractControllerId);
		} catch (Throwable th) {
			logger.error("Error in deleting extractJobId: " + extractJobId + " : " + th.getMessage(), th);
		}	
	}
	
	public void setExtractionJobQueueHelper(ExtractionJobQueueHelper extractionJobQueueHelper) {
		this.extractionJobQueueHelper = extractionJobQueueHelper;
	}	
	
	private void getExtractionJobQueueHelper() {
		if (this.extractionJobQueueHelper == null) {
			this.extractionJobQueueHelper = SpringServiceManager.getBean("extractionJobQueueHelper");
		}
	}
}
