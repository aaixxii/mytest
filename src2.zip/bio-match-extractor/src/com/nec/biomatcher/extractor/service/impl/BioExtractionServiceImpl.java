package com.nec.biomatcher.extractor.service.impl;

import java.io.Closeable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Stopwatch;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.ITopic;
import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeClientHelper;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeStatusCheckHelper;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.zmq.ZmqPushConnection;
import com.nec.biomatcher.comp.zmq.ZmqSendException;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.extractor.service.BioExtractionService;
import com.nec.biomatcher.extractor.service.exception.BioExtractionException;
import com.nec.biomatcher.extractor.service.exception.BioExtractionTimeoutException;
import com.nec.biomatcher.extractor.util.ExtractJobInfo;
import com.nec.biomatcher.extractor.util.ExtractProtobufUtil;
import com.nec.biomatcher.extractor.util.ExtractionJobCancelingListener;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.megha.proto.extract.ExtractRequestProto.ExtractRequest;

/**
 * The Class BioExtractionServiceImpl.
 */
public class BioExtractionServiceImpl implements BioExtractionService, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioExtractionServiceImpl.class);

	private static final Logger EXTRACT_JOB_NODE_REQUEST_LOGGER = Logger.getLogger("EXTRACT_JOB_NODE_REQUEST");
	private static final Logger EXTRACT_JOB_NODE_RESPONSE_LOGGER = Logger.getLogger("EXTRACT_JOB_NODE_RESPONSE");

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The bio matcher config service. */
	protected BioMatcherConfigService bioMatcherConfigService;

	private MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper;

	private JobSlotClusterService extractClusterService;
	
	private ITopic<String> notifyExtractJobCancelingTopic;
	
	private String notifyExtractJobCancelingTopicListenerId;
	

	

	/** The extraction controller id. */
	private String extractionControllerId;

	private MatcherNodeClientHelper matcherNodeClientHelper = new MatcherNodeClientHelper();

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	public String getExtractionControllerId() {
		return extractionControllerId;
	}

	public JobSlotClusterService getExtractClusterService() {
		return extractClusterService;
	}

	public void submitExtractionJob(String extractJobId, ExtractJobInfo extractJobInfo)
			throws BioMatcherNodeClientException, BioMatcherNodeConnectionException, BioMatcherNodeSendException,
			BioMatcherNodeReceiveException, BioExtractionTimeoutException {
		if (logger.isTraceEnabled())
			logger.trace("In submitExtractionJob: extractJobId: " + extractJobId);
		try {
			ExtractJobRequestDto request = extractJobInfo.getJobRequestDto();

			long minExtractJobTimeoutMilli = bioParameterService.getParameterValue("MIN_EXTRACT_JOB_TIMEOUT_MILLI",
					"DEFAULT", 500L);

			long timeoutMilli = extractJobInfo.getJobTimeoutMill();

			timeoutMilli = timeoutMilli - (System.currentTimeMillis() - extractJobInfo.getCreateTimestampMilli());

			if (timeoutMilli < minExtractJobTimeoutMilli) {
				throw new BioExtractionTimeoutException(
						"In submitExtractionJob: Not enough time left to execute extract job. timeoutMilli: "
								+ timeoutMilli + ", minExtractJobTimeoutMilli: " + minExtractJobTimeoutMilli);
			}

			long queuePollStartTimeMilli = System.currentTimeMillis();
			String extractNodeId = null;
			try {
				extractNodeId = extractClusterService.acquireJobSlot(timeoutMilli);
			} catch (Throwable th) {
				logger.error("Error during extractClusterService.acquireJobSlot: " + th.getMessage(), th);
				throw new BioMatcherNodeClientException(
						"Error during extractClusterService.acquireJobSlot: " + th.getMessage(), th);
			} finally {
				MetricsUtil.checkAndTime("FUNCTION.EXTRACT.ASSIGN_TIME_TAKEN",
						(System.currentTimeMillis() - queuePollStartTimeMilli), TimeUnit.MILLISECONDS);
			}

			if (extractNodeId == null) {
				throw new BioExtractionTimeoutException(
						"In submitExtractionJob: Extract job slot not available, waited for timeoutMilli: "
								+ timeoutMilli);
			}

			extractJobInfo.assignExtractNodeId(extractNodeId);					

			long queuePollTimeTakenMilli = System.currentTimeMillis() - queuePollStartTimeMilli;
			timeoutMilli = timeoutMilli - queuePollTimeTakenMilli;
			if (timeoutMilli < minExtractJobTimeoutMilli) {
				throw new BioExtractionTimeoutException(
						"In submitExtractionJob: Not enough time left to execute extract job. timeoutMilli: "
								+ timeoutMilli + ", queuePollTimeTakenMilli: " + queuePollTimeTakenMilli
								+ ", minExtractJobTimeoutMilli: " + minExtractJobTimeoutMilli);
			}

			submitExtractionJobInternal(extractJobId, extractNodeId, request, timeoutMilli);

			extractJobInfo.setSubmitTimestampMilli(System.currentTimeMillis());
		} catch (BioMatcherNodeConnectionException | BioMatcherNodeSendException | BioMatcherNodeClientException
				| BioExtractionTimeoutException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioMatcherNodeClientException("Error in submitExtractionJob: " + th.getMessage(), th);
		}
	}

	private void submitExtractionJobInternal(String extractJobId, String extractNodeId, ExtractJobRequestDto request,
			long timeoutMilli) throws BioMatcherNodeClientException, BioMatcherNodeConnectionException,
			BioMatcherNodeSendException, BioMatcherNodeReceiveException, BioExtractionTimeoutException {
		if (logger.isTraceEnabled())
			logger.trace("In submitExtractionJobInternal: extractJobId: " + extractJobId + ", timeoutMilli: "
					+ timeoutMilli);

		Stopwatch stopWatch = Stopwatch.createStarted();

		try (Closeable timer = MetricsUtil.time(BioComponentType.EN, extractNodeId, "EN_JOB_SEND_TIME_TAKEN")) {
			String extractCallbackUrl = getExtractResultCallbackUrl();

			ExtractRequest requestPayload = ExtractProtobufUtil.toProtobuf(extractJobId, request, extractCallbackUrl,
					bioParameterService);

			if (EXTRACT_JOB_NODE_REQUEST_LOGGER.isTraceEnabled()) {
				EXTRACT_JOB_NODE_REQUEST_LOGGER.trace("extractNodeId: " + extractNodeId + ", extractJobId: "
						+ extractJobId + ", requestPayload: " + requestPayload.toString());
			}

			String enConnectionUrl = getExtractNodeConnectionUrl(extractNodeId, BioConnectionType.WORKER);
			ZmqPushConnection.sendMessage(enConnectionUrl, extractNodeId + "_" + extractJobId,
					requestPayload.toByteArray());
		} catch (ZmqSendException ex) {
			logger.error("ZmqSendException in submitExtractionJobInternal: " + ex.getMessage(), ex);

			extractClusterService.notifyOffline(extractNodeId);

			BioMatcherNodeSendException sendEx = new BioMatcherNodeSendException(
					"ZmqSendException in submitExtractionJobInternal: " + ex.getMessage(), ex);

			matcherNodeClientHelper.handleSendReceiveError(extractNodeId, BioComponentType.EN, sendEx);

			throw sendEx;
		} catch (Throwable th) {
			logger.error(th.getClass().getSimpleName() + " Error in submitExtractionJobInternal: " + th.getMessage(),
					th);

			// extractClusterService.releaseJobSlot(extractNodeId);

			if (!(th instanceof BioMatcherNodeClientException)) {
				th = new BioMatcherNodeClientException(
						th.getClass().getName() + " in submitExtractionJobInternal: " + th.getMessage(), th);
			}

			matcherNodeClientHelper.handleSendReceiveError(extractNodeId, BioComponentType.EN, th);

			throw new BioMatcherNodeClientException("Error in submitExtractionJobInternal: " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = stopWatch.elapsed(TimeUnit.MILLISECONDS);
			if (timeTakenMilli > 5 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In submitExtractionJobInternal: TimeTakenMilli: " + timeTakenMilli
						+ ", extractNodeId: " + extractNodeId);
			}
		}
	}

	private final String getExtractResultCallbackUrl() throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(extractionControllerId,
				BioComponentType.EC, BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
					"Error in getExtractResultCallbackUrl: callback url is not configured for extractionControllerId: "
							+ extractionControllerId + ", connectionType: " + BioConnectionType.WORKER_CALLBACK
							+ ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	private final String getExtractNodeConnectionUrl(String extractNodeId, BioConnectionType bioConnectionType)
			throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(extractNodeId, BioComponentType.EN,
				bioConnectionType, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException("Extract node connection url is not configured for extractNodeId: "
					+ extractNodeId + ", BioComponentType: " + BioComponentType.EN + ", connectionType: "
					+ bioConnectionType + ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		try {
			synchronized (BioExtractionServiceImpl.class) {
				if (initializationCount.get() > 0) {
					CommonLogger.STATUS_LOG
							.warn("BioExtractionServiceImpl.afterPropertiesSet is called multiple times: initializationCount: "
									+ initializationCount.get());
					return;
				}

				initializationCount.incrementAndGet();

				extractClusterService = new JobSlotClusterService(BioComponentType.EC, BioComponentType.EN,
						(extractNodeId -> matcherNodeStatusCheckHelper.sendServerCapacity(extractNodeId)),
						bioMatcherConfigService, bioParameterService);

				extractionControllerId = extractClusterService.getControllerId();
				HazelcastInstance extHazelcastInstance = extractClusterService.getHazelcastInstance();
				this.notifyExtractJobCancelingTopic = extHazelcastInstance.getTopic("NotifyExtractJobCanceling");				
				notifyExtractJobCancelingTopicListenerId = this.notifyExtractJobCancelingTopic.addMessageListener(new ExtractionJobCancelingListener());						
				
			}
		} catch (Throwable th) {
			CommonLogger.STATUS_LOG.error("Error in BioExtractionServiceImpl.afterPropertiesSet: " + th.getMessage(),
					th);
			throw new BioExtractionException("Error in afterPropertiesSet: " + th.getMessage(), th);
		}

	}

	public void setMatcherNodeStatusCheckHelper(MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper) {
		this.matcherNodeStatusCheckHelper = matcherNodeStatusCheckHelper;
	}
	
	@Override
	public void notifyExtractJobCanceling(String msg) {
		notifyExtractJobCancelingTopic.publish(msg);		
	}

}
