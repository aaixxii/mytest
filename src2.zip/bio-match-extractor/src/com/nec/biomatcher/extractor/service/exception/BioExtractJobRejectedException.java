package com.nec.biomatcher.extractor.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioExtractJobRejectedException.
 */
public class BioExtractJobRejectedException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio extract job rejected exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioExtractJobRejectedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio extract job rejected exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioExtractJobRejectedException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio extract job rejected exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioExtractJobRejectedException(Throwable cause) {
		super(cause);
	}

}
