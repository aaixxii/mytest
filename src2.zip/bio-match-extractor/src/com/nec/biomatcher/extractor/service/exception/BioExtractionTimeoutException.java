package com.nec.biomatcher.extractor.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioExtractionTimeoutException.
 */
public class BioExtractionTimeoutException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio extraction timeout exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioExtractionTimeoutException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio extraction timeout exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioExtractionTimeoutException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio extraction timeout exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioExtractionTimeoutException(Throwable cause) {
		super(cause);
	}

}
