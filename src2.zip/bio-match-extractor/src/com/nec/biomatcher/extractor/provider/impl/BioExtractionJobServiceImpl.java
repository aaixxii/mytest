package com.nec.biomatcher.extractor.provider.impl;

import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.util.JobIdGenerator;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.extractor.queueing.ExtractionJobQueueHelper;
import com.nec.biomatcher.spec.services.BioExtractionJobService;
import com.nec.biomatcher.spec.services.exception.BioExtractionJobServiceException;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

/**
 * The Class BioExtractionJobServiceImpl.
 */
public class BioExtractionJobServiceImpl implements BioExtractionJobService, InitializingBean {

	/** The extraction job queue helper. */
	private ExtractionJobQueueHelper extractionJobQueueHelper;
	private JobIdGenerator jobIdGenerator;
	private String extractionControllerId;

	@Override
	public String submitExtractionJob(ExtractJobRequestDto jobRequestDto) throws BioExtractionJobServiceException {

		if (extractionControllerId == null) {
			throw new BioExtractionJobServiceException("Extraction Controller is not enabled on hostname: "
					+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		}

		String jobId = jobIdGenerator.nextId(extractionControllerId);

		NDC.clear();
		NDC.push("EX_JOBID#" + jobId);

		try {
			return extractionJobQueueHelper.submitExtractionJob(jobId, jobRequestDto);
		} catch (BioExtractionJobServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioExtractionJobServiceException(th.getMessage(), th);
		}
	}

	@Override
	public BioJobStatus getExtractionJobStatus(String jobId) throws BioExtractionJobServiceException {
		NDC.clear();
		NDC.push("EX_JOBID#" + jobId);
		try {
			return extractionJobQueueHelper.getExtractionJobStatus(jobId);
		} catch (Throwable th) {
			throw new BioExtractionJobServiceException(th.getMessage(), th);
		}
	}

	@Override
	public ExtractJobResultDto getExtractionJobResult(String jobId) throws BioExtractionJobServiceException {
		NDC.push("EX_JOBID#" + jobId);

		try {
			return extractionJobQueueHelper.getExtractionJobResult(jobId);
		} catch (Throwable th) {
			throw new BioExtractionJobServiceException(th.getMessage(), th);
		} finally {
			NDC.pop();
		}
	}

	@Override
	public void deleteExtractionJob(String jobId) throws BioExtractionJobServiceException {
		NDC.clear();
		NDC.push("EX_JOBID#" + jobId);

		try {
			extractionJobQueueHelper.deleteExtractionJob(jobId);
		} catch (Throwable th) {
			throw new BioExtractionJobServiceException(th.getMessage(), th);
		}
	}

	public void setExtractionJobQueueHelper(ExtractionJobQueueHelper extractionJobQueueHelper) {
		this.extractionJobQueueHelper = extractionJobQueueHelper;
	}

	public void setJobIdGenerator(JobIdGenerator jobIdGenerator) {
		this.jobIdGenerator = jobIdGenerator;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		extractionControllerId = extractionJobQueueHelper.getExtractionControllerId();
	}

}
