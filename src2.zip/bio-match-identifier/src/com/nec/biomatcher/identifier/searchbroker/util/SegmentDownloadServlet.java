package com.nec.biomatcher.identifier.searchbroker.util;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.identifier.util.SegmentFileReader;

public class SegmentDownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger logger = Logger.getLogger(SegmentDownloadServlet.class);

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			transferSegmentData(request, response);
		} catch (ServletException | IOException ex) {
			logger.error("Error in SegmentDownloadServlet.doPost: " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			logger.error("Error in SegmentDownloadServlet.doPost: " + th.getMessage(), th);
			throw new IOException(th.getMessage(), th);
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			transferSegmentData(request, response);
		} catch (ServletException | IOException ex) {
			logger.error("Error in SegmentDownloadServlet.doGet: " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			logger.error("Error in SegmentDownloadServlet.doGet: " + th.getMessage(), th);
			throw new IOException(th.getMessage(), th);
		}
	}

	private void transferSegmentData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String requestUri = request.getRequestURI();
		String segmentIdStr = StringUtils.substringAfterLast(requestUri.trim(), "/");
		Integer segmentId = StringUtil.stringToInt(segmentIdStr);
		if (segmentId == null) {
			throw new IOException(
					"Invalid segmentId specified in requestUri: " + requestUri + ", segmentIdStr: " + segmentIdStr);
		}

		SegmentFileReader segFileReader = new SegmentFileReader(segmentId);
		if (!segFileReader.checkExists()) {
			throw new IOException("Segment file does not exists for segmentId: " + segmentId + ", segmentFilePath: "
					+ segFileReader.getSegmentFilePath());
		}

		segFileReader.transferSegmentData(response);
	}
}
