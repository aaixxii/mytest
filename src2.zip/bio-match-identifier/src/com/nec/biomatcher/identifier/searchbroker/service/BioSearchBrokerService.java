package com.nec.biomatcher.identifier.searchbroker.service;

import java.util.Map;

import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.spec.services.BioSearchBrokerRemoteService;
import com.nec.biomatcher.spec.services.exception.BioSearchBrokerException;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;

/**
 * The Interface BioSearchBrokerService.
 */
public interface BioSearchBrokerService extends BioSearchBrokerRemoteService {

	/**
	 * Notify search node sync version.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @param segmentIdVersionMap
	 *            the segment id version map
	 * @throws BioSearchBrokerException
	 *             the bio search broker exception
	 */
	public void notifySearchNodeSyncVersion(String searchNodeId, Map<Integer, Long> segmentIdVersionMap)
			throws BioSearchBrokerException;

	public SegmentSyncResponseDto submitSegmentSyncRequest(String searchNodeId, SegmentSyncRequestDto request,
			long timeoutMilli) throws BioMatcherNodeClientException, BioMatcherNodeConnectionException,
			BioMatcherNodeSendException, BioMatcherNodeReceiveException;

}
