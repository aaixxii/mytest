package com.nec.biomatcher.identifier.searchbroker.tasks;

import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.log4j.Logger;

import com.google.common.base.MoreObjects;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.RateLimiter;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerConnectionInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.util.ServerStatusMonitor;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;
import com.nec.biomatcher.core.framework.common.concurrent.DynamicSemaphore;
import com.nec.biomatcher.core.framework.common.concurrent.VersionLatch;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchbroker.service.BioSearchBrokerService;
import com.nec.biomatcher.identifier.searchbroker.util.SegmentChangeSetReader;
import com.nec.biomatcher.identifier.util.SegmentFileReader;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentReportDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentStatus;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestType;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentUpdateDto;

/**
 * The Class SearchNodeDataDistributionTask.
 */
public class SearchNodeDataDistributionTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchNodeDataDistributionTask.class);

	private static final Logger STATUS_LOGGER = CommonLogger.STATUS_LOG;// Logger.getLogger("STATUS_LOG");

	/** The search node id. */
	private final String searchNodeId;

	private final DynamicSemaphore semaphore;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio search broker manager. */
	private BioSearchBrokerManager bioSearchBrokerManager;

	private BioSearchBrokerService bioSearchBrokerService;

	/** The bio match manager service. */
	private BioMatchManagerService bioMatchManagerService;

	private SegmentChangeSetReader segmentChangeSetReader;

	/** The search broker connected flag. */
	private BooleanLatch searchBrokerConnectedFlag;

	/** The matcher node online flag. */
	private BooleanLatch matcherNodeOnlineFlag;

	/** The segment data changed latch. */
	private VersionLatch segmentDataChangedLatch;

	/** The search broker enabled flag. */
	private BooleanLatch searchBrokerEnabledFlag;

	/** The has sync backlog flag. */
	private boolean hasSyncBacklogFlag = true;

	/** The has preparing flag. */
	private boolean hasPreparingFlag = true;

	/** The detected offline flag. */
	private boolean detectedOfflineFlag = true;

	private boolean hasAnySegmentUpdatesFlag = false;

	private boolean hasAnyChangeSetPayloadFlag = false;

	/** The is initialized. */
	private boolean isInitialized = false;

	/** The stop flag. */
	private volatile boolean stopFlag = false;

	private long lastDistributionTimestampMilli = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(2);

	private long previousOnlineStatusVersion = 0;

	private RateLimiter initRequestsRateLimiter = RateLimiter.create(1, 1, TimeUnit.SECONDS);
	private RateLimiter updateRequestsRateLimiter = RateLimiter.create(10);

	private Set<Integer> segmentIdSetForDeletion = new HashSet<>();

	/**
	 * Instantiates a new search node data distribution task.
	 *
	 * @param searchNodeId
	 *            the search node id
	 */
	public SearchNodeDataDistributionTask(String searchNodeId, DynamicSemaphore semaphore) {
		this.searchNodeId = searchNodeId;
		this.semaphore = semaphore;
		this.previousOnlineStatusVersion = ServerStatusMonitor.getStatusVersion(searchNodeId);
	}

	/**
	 * Stop.
	 */
	public void stop() {
		stopFlag = true;
	}

	@Override
	public void run() {
		Thread.currentThread()
				.setName("SB_TO_SN_SEG_UPDATES_DIST_TASK_" + searchNodeId + "_" + Thread.currentThread().getId());
		logger.info("SearchNodeDataDistributionTask started for searchNodeId: " + searchNodeId);

		Long segmentDataChangeNotifyVersion = Long.MIN_VALUE;

		while (!ShutdownHook.isShutdownFlag && !stopFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				searchBrokerEnabledFlag.waitForTrue();

				if (!BioServerState.ACTIVE
						.equals(bioMatcherConfigService.getServerInfo(searchNodeId).getServerState())) {
					logger.debug("Search node: " + searchNodeId + " server state is not configured as active");
					Thread.sleep(TimeUnit.SECONDS.toMillis(30));
					continue;
				}

				matcherNodeOnlineFlag.waitForTrue(30, TimeUnit.SECONDS);

				long waitIntervalMilli = 500L;
				if (!hasSyncBacklogFlag && !detectedOfflineFlag && !hasPreparingFlag && !hasAnySegmentUpdatesFlag) {
					waitIntervalMilli = TimeUnit.SECONDS.toMillis(60);
				} else if (hasAnySegmentUpdatesFlag) {
					waitIntervalMilli = 50L;
				} else if (hasSyncBacklogFlag) {
					waitIntervalMilli = 100L;
				}

				segmentDataChangeNotifyVersion = segmentDataChangedLatch.waitForChange(segmentDataChangeNotifyVersion,
						waitIntervalMilli, TimeUnit.MILLISECONDS);

				if (!stopFlag && semaphore.tryAcquire(waitIntervalMilli, TimeUnit.MILLISECONDS)) {
					try {
						if (!stopFlag
								&& searchBrokerConnectedFlag.waitForTrue(waitIntervalMilli, TimeUnit.MILLISECONDS)) {
							syncSegmentDataChanges();
						}
					} finally {
						semaphore.release();
					}
				}

			} catch (Throwable th) {
				logger.error("Errro in SearchNodeDataDistributionTask.run for searchNodeId: " + searchNodeId + " : "
						+ th.getMessage(), th);

				if (!stopFlag) {
					Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
				}
			}
		}

		logger.warn("Exiting SearchNodeDataDistributionTask: searchNodeId: " + searchNodeId + ", stopFlag: " + stopFlag
				+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioSearchBrokerManager = SpringServiceManager.getBean("bioSearchBrokerManager");
		bioSearchBrokerService = SpringServiceManager.getBean("bioSearchBrokerService");
		bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
		segmentChangeSetReader = SpringServiceManager.getBean("segmentChangeSetReader");

		searchBrokerConnectedFlag = bioSearchBrokerManager.getSearchBrokerConnectedFlag();
		// matcherNodePauseFlag
		// =bioSearchBrokerManager.getSearchNodePauseFlag(searchNodeId);
		matcherNodeOnlineFlag = bioSearchBrokerManager.getSearchNodeOnlineFlag(searchNodeId);
		segmentDataChangedLatch = segmentChangeSetReader.getSearchNodeSegmentDataChangedLatch(searchNodeId);
		searchBrokerEnabledFlag = bioSearchBrokerManager.getSearchBrokerEnabledFlag();

		isInitialized = true;
	}

	/**
	 * Sync segment data changes.
	 */
	private final void syncSegmentDataChanges() {
		try {

			// searchBrokerEnabledFlag.waitForTrue();

			// matcherNodePauseFlag.waitForFalse();

			boolean isOnline = matcherNodeOnlineFlag.waitForTrue(500, TimeUnit.MILLISECONDS);
			if (!isOnline) {
				detectedOfflineFlag = true;
			}
			boolean isIdleTimeout = false;

			if (!detectedOfflineFlag) {
				if (previousOnlineStatusVersion != ServerStatusMonitor.getStatusVersion(searchNodeId)) {
					logger.info("In syncSegmentDataChanges: online status version did not match for searchNodeId: "
							+ searchNodeId + ", previousOnlineStatusVersion: " + previousOnlineStatusVersion
							+ ", currentServerStatusVersion: " + ServerStatusMonitor.getStatusVersion(searchNodeId)
							+ ". So setting detectedOfflineFlag to true");
					detectedOfflineFlag = true;
				} else {
					long idleServerCheckDelayMilli = bioParameterService.getParameterValue(
							"IDLE_SERVER_CHECK_DELAY_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(2));
					if ((System.currentTimeMillis() - lastDistributionTimestampMilli) > idleServerCheckDelayMilli) {
						isIdleTimeout = true;
					}
				}
			}

			if (logger.isDebugEnabled()) {
				logger.debug("In syncSegmentDataChanges: searchNodeId: " + searchNodeId + ", isOnline: " + isOnline
						+ ", detectedOfflineFlag: " + detectedOfflineFlag + ", hasSyncBacklogFlag: "
						+ hasSyncBacklogFlag + ", previousOnlineStatusVersion: " + previousOnlineStatusVersion
						+ ", lastDistributionTimestampMilli: " + DateUtil.parseDate(
								new Date(lastDistributionTimestampMilli), DateUtil.FORMAT_DD_MM_YYYY_HH24_MM_SS_SSS));
			}

			Set<Integer> assignedSegmentIdSet = bioMatcherConfigService
					.getAssignedSegmentIdListBySearchNodeId(searchNodeId);

			SegmentSyncRequestDto segmentSyncRequestDto = null;

			if (detectedOfflineFlag || isIdleTimeout) {
				hasSyncBacklogFlag = true;
				segmentSyncRequestDto = new SegmentSyncRequestDto();
				segmentSyncRequestDto.setInstanceId(searchNodeId);
				segmentSyncRequestDto.setRequestType(SegmentSyncRequestType.INIT);
			} else {
				segmentSyncRequestDto = buildSegmentSyncRequest(searchNodeId);

				if (!segmentSyncRequestDto.hasSegmentUpdates() && (hasSyncBacklogFlag || hasPreparingFlag)) {
					segmentSyncRequestDto.setRequestType(SegmentSyncRequestType.INIT);
				}
			}

			hasAnySegmentUpdatesFlag = segmentSyncRequestDto.hasSegmentUpdates();

			if (SegmentSyncRequestType.INIT.equals(segmentSyncRequestDto.getRequestType())) {
				initRequestsRateLimiter.acquire();
			} else if (!hasAnyChangeSetPayloadFlag) {
				updateRequestsRateLimiter.acquire();
			}

			if (SegmentSyncRequestType.INIT.equals(segmentSyncRequestDto.getRequestType())
					|| segmentSyncRequestDto.hasSegmentUpdates()) {

				long syncRequestTimeoutMilli = bioParameterService.getParameterValue(
						"SEGMENT_SYNC_REQUEST_TIMEOUT_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(5));

				SegmentSyncResponseDto segmentSyncResponseDto = bioSearchBrokerService
						.submitSegmentSyncRequest(searchNodeId, segmentSyncRequestDto, syncRequestTimeoutMilli);

				if (segmentSyncResponseDto != null) {
					if (SegmentSyncRequestType.INIT.equals(segmentSyncRequestDto.getRequestType())) {
						if (detectedOfflineFlag) {
							STATUS_LOGGER
									.info("In SearchNodeDataDistributionTask.syncSegmentDataChanges: bioComponentType: "
											+ BioComponentType.SN.name() + ", serverId: " + searchNodeId
											+ " is online");
							bioSearchBrokerManager.notifySearchNodeOnline(searchNodeId);
						}
					}

					previousOnlineStatusVersion = ServerStatusMonitor.getStatusVersion(searchNodeId);
					lastDistributionTimestampMilli = System.currentTimeMillis();
					detectedOfflineFlag = false;
					hasSyncBacklogFlag = false;
					hasPreparingFlag = false;
					isIdleTimeout = false;
					segmentIdSetForDeletion.clear();

					logger.debug("SegmentReportDtoListSize for searchNodeId: " + searchNodeId + ", size:"
							+ segmentSyncResponseDto.getSegmentReportDtoList().size());

					if (segmentSyncResponseDto.getSegmentReportDtoList().size() > 0) {
						LinkedBlockingDeque<SegmentSyncResponseDto> notifySyncCompletedQueue = bioSearchBrokerManager
								.getNotifySyncCompletedQueue();
						notifySyncCompletedQueue.add(segmentSyncResponseDto);
					}

					ConcurrentHashMap<Integer, SegmentReportDto> currMatcherNodeSegmentVersionMap = bioSearchBrokerManager
							.getSearchNodeSegmentVersionMap(searchNodeId);

					Set<Integer> newSegmentIdSet = new HashSet<>();

					for (SegmentReportDto segmentReportDto : segmentSyncResponseDto.getSegmentReportDtoList()) {
						logger.debug("Response segmentReportDto from searchNodeId: " + searchNodeId + ", segmentId:"
								+ segmentReportDto.getSegmentId() + " : "
								+ ReflectionToStringBuilder.toString(segmentReportDto));

						newSegmentIdSet.add(segmentReportDto.getSegmentId());

						if (!assignedSegmentIdSet.contains(segmentReportDto.getSegmentId())) {
							hasSyncBacklogFlag = true;
							segmentIdSetForDeletion.add(segmentReportDto.getSegmentId());
							currMatcherNodeSegmentVersionMap.remove(segmentReportDto.getSegmentId());
						} else if (SegmentStatus.ACTIVE.equals(segmentReportDto.getStatus())) {
							currMatcherNodeSegmentVersionMap.put(segmentReportDto.getSegmentId(), segmentReportDto);

							long centralSegmentDataVersion = segmentChangeSetReader
									.getCentralSegmentDataVersion(segmentReportDto.getSegmentId());
							long searchNodeSegmentVersion = Math.max(
									MoreObjects.firstNonNull(segmentReportDto.getSegmentVersion(), -1L),
									MoreObjects.firstNonNull(segmentReportDto.getEndSegmentVersion(), -1L));

							if (centralSegmentDataVersion > 0 && centralSegmentDataVersion > searchNodeSegmentVersion) {
								hasSyncBacklogFlag = true;
								logger.debug(
										"Response segmentReportDto from searchNodeId: " + searchNodeId + ", segmentId:"
												+ segmentReportDto.getSegmentId() + ", centralSegmentDataVersion: "
												+ centralSegmentDataVersion + ", responseEndSegmentVersion: "
												+ Math.max(segmentReportDto.getSegmentVersion(),
														segmentReportDto.getEndSegmentVersion())
												+ ", hasSyncBacklogFlag: " + hasSyncBacklogFlag);
							}
						} else if (SegmentStatus.PREPARING.equals(segmentReportDto.getStatus())) {
							hasPreparingFlag = true;
							SegmentReportDto oldsegmentReportDto = currMatcherNodeSegmentVersionMap
									.get(segmentReportDto.getSegmentId());
							if (oldsegmentReportDto == null
									|| !SegmentStatus.PREPARING.equals(oldsegmentReportDto.getStatus())) {
								currMatcherNodeSegmentVersionMap.put(segmentReportDto.getSegmentId(), segmentReportDto);
							}
						} else {
							currMatcherNodeSegmentVersionMap.put(segmentReportDto.getSegmentId(), segmentReportDto);
						}
					}

					Set<Integer> missingSegmentIdSet = Sets.difference(assignedSegmentIdSet, newSegmentIdSet);
					if (!missingSegmentIdSet.isEmpty()) {
						for (Integer missingSegmentId : missingSegmentIdSet) {
							long centralSegmentDataVersion = segmentChangeSetReader
									.getCentralSegmentDataVersion(missingSegmentId);
							if (centralSegmentDataVersion > -1L) {
								hasSyncBacklogFlag = true;
								logger.warn("Segments are missing in searchNodeId: " + searchNodeId
										+ ", missingSegmentId: " + missingSegmentId + ", centralSegmentDataVersion: "
										+ centralSegmentDataVersion);
							}
						}
					}

					// Remove any additional segments which are in this map but
					// not in searchNode
					currMatcherNodeSegmentVersionMap.keySet().retainAll(newSegmentIdSet);
				} else {
					detectedOfflineFlag = true;
					hasSyncBacklogFlag = true;
					STATUS_LOGGER
							.error("In SearchNodeDataDistributionTask.syncSegmentDataChanges: SegmentSyncResponseDto is null for searchNodeId: "
									+ searchNodeId + ", treating searchNode as offline");
					bioSearchBrokerManager.notifySearchNodeOffline(searchNodeId);
				}
			} else {
				logger.debug("In syncSegmentDataChanges: No updates to sync for searchNodeId: " + searchNodeId);
			}
		} catch (BioMatcherNodeClientException | BioMatcherNodeConnectionException | BioMatcherNodeSendException
				| BioMatcherNodeReceiveException ex) {
			logger.error(ex.getClass().getSimpleName()
					+ " during SearchNodeDataDistributionTask.syncSegmentDataChanges for searchNodeId: " + searchNodeId
					+ " : " + ex.getMessage(), ex);
			STATUS_LOGGER.error(ex.getClass().getSimpleName()
					+ " during SearchNodeDataDistributionTask.syncSegmentDataChangesfor searchNodeId: " + searchNodeId
					+ ", treating searchNode as offline");
			detectedOfflineFlag = true;
			hasSyncBacklogFlag = true;
			bioSearchBrokerManager.notifySearchNodeOffline(searchNodeId);
		} catch (Throwable th) {
			logger.error("Error in SearchNodeDataDistributionTask.syncSegmentDataChanges for searchNodeId: "
					+ searchNodeId + " : " + th.getMessage(), th);
			STATUS_LOGGER.error("Error during SearchNodeDataDistributionTask.syncSegmentDataChangesfor searchNodeId: "
					+ searchNodeId + ", treating searchNode as offline");
			detectedOfflineFlag = true;
			hasSyncBacklogFlag = true;
			bioSearchBrokerManager.notifySearchNodeOffline(searchNodeId);
			Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
		}
	}

	/**
	 * Builds the segment sync request.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @return the segment sync request dto
	 * @throws Exception
	 *             the exception
	 */
	private SegmentSyncRequestDto buildSegmentSyncRequest(String searchNodeId) throws Exception {
		logger.debug("In buildSegmentSyncRequest for searchNodeId: " + searchNodeId);

		hasAnyChangeSetPayloadFlag = false;
		int segmentDownloadVersionDiffThresholdCount = bioParameterService
				.getParameterValue("SEGMENT_DOWNLOAD_VERSION_DIFF_THRESHOLD_COUNT", "DEFAULT", 1000);
		long maxSegmentSyncRequestPayloadSize = bioParameterService
				.getParameterValue("MAX_SEGMENT_SYNC_REQUEST_PAYLOAD_SIZE", "DEFAULT", 100L * 1024 * 1024);

		boolean segmentServerEnabledFlag = bioParameterService.getParameterValue("SB_SEGMENT_SERVER_ENABLED_FLAG",
				"DEFAULT", true);
		String searchBrokerId = bioSearchBrokerManager.getSearchBrokerId();

		SegmentSyncRequestDto segmentSyncRequestDto = new SegmentSyncRequestDto();
		segmentSyncRequestDto.setInstanceId(searchNodeId);
		segmentSyncRequestDto.setRequestType(SegmentSyncRequestType.UPDATE);

		Set<Integer> assignedSegmentIdSet = bioMatcherConfigService
				.getAssignedSegmentIdListBySearchNodeId(searchNodeId);
		logger.debug("In buildSegmentSyncRequest: assignedSegmentIdSet: " + assignedSegmentIdSet.size());

		ConcurrentHashMap<Integer, SegmentReportDto> matcherNodeSegmentVersionMap = bioSearchBrokerManager
				.getSearchNodeSegmentVersionMap(searchNodeId);
		AtomicLong totalChangeSetSize = new AtomicLong(0);

		Map<Integer, BiometricIdInfo> segmentIdBiometricIdInfoMap = bioMatcherConfigService
				.getSegmentIdBiometricIdInfoMap();
		Map<Integer, String> segmentIdTemplateTypeMap = bioMatcherConfigService.getSegmentIdTemplateTypeMap();
		Map<Integer, Set<String>> assignedSegmentIdSearchNodeIdListMap = bioMatcherConfigService
				.getAssignedSegmentIdSearchNodeIdListMapBySearchBrokerId(searchBrokerId);

		for (Integer segmentId : assignedSegmentIdSet) {
			logger.debug("In buildSegmentSyncRequest: assignedSegmentId: " + segmentId);

			long centralSegmentDataVersion = segmentChangeSetReader.getCentralSegmentDataVersion(segmentId);
			if (centralSegmentDataVersion <= 0L) {
				logger.debug("Ignoring assignedSegmentId: " + segmentId + " due to centralSegmentDataVersion: "
						+ centralSegmentDataVersion);

				if (matcherNodeSegmentVersionMap.containsKey(segmentId)) {
					segmentIdSetForDeletion.add(segmentId);
				}

				continue;
			}

			segmentIdSetForDeletion.remove(segmentId);

			BiometricIdInfo biometricIdInfo = segmentIdBiometricIdInfoMap.get(segmentId);
			BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigService.getMatcherBinInfo(biometricIdInfo.getBinId());
			MeghaTemplateParser meghaTemplateParser = null;

			try {
				meghaTemplateParser = bioMatcherConfigService.getBinIdMeghaTemplateParserMap()
						.get(biometricIdInfo.getBinId());
				if (meghaTemplateParser == null) {
					throw new Exception("Unable to get meghaTemplateParser for binId: " + biometricIdInfo.getBinId());
				}
			} catch (Throwable th) {
				logger.warn(
						"Error in buildSegmentSyncRequest searchNodeId: " + searchNodeId + ", segmentId: " + segmentId
								+ ", templateType: " + bioMatcherBinInfo.getTemplateType() + " : " + th.getMessage(),
						th);
				segmentIdSetForDeletion.add(segmentId);
				continue;
			}

			boolean newCurrentSegmentReportDtoFlag = false;
			SegmentReportDto currentSegmentReportDto = matcherNodeSegmentVersionMap.get(segmentId);

			if (currentSegmentReportDto == null) {
				logger.info("New SegmentReportDto is created for Search node: " + searchNodeId + ", segmentId: "
						+ segmentId);

				newCurrentSegmentReportDtoFlag = true;
				currentSegmentReportDto = new SegmentReportDto();
				currentSegmentReportDto.setSegmentId(segmentId);
				currentSegmentReportDto.setSegmentVersion(-1L);
				currentSegmentReportDto.setStatus(SegmentStatus.ACTIVE);

				matcherNodeSegmentVersionMap.put(segmentId, currentSegmentReportDto);
			} else if (SegmentStatus.DELETE.equals(currentSegmentReportDto.getStatus())
					|| SegmentStatus.ERROR.equals(currentSegmentReportDto.getStatus())) {
				logger.warn("Search node: " + searchNodeId + " is in " + currentSegmentReportDto.getStatus()
						+ " state for segmentId: " + segmentId + " from last reportDateTime: "
						+ currentSegmentReportDto.getReportDateTime());
				newCurrentSegmentReportDtoFlag = true;
				currentSegmentReportDto = new SegmentReportDto();
				currentSegmentReportDto.setSegmentId(segmentId);
				currentSegmentReportDto.setSegmentVersion(-1L);
				currentSegmentReportDto.setStatus(SegmentStatus.ACTIVE);

				matcherNodeSegmentVersionMap.put(segmentId, currentSegmentReportDto);
			} else if (SegmentStatus.PREPARING.equals(currentSegmentReportDto.getStatus())) {
				hasPreparingFlag = true;
				logger.info("Search node: " + searchNodeId + " is in preparing state for segmentId: " + segmentId
						+ " from last reportDateTime: " + currentSegmentReportDto.getReportDateTime());
				continue;
			} else if (!SegmentStatus.ACTIVE.equals(currentSegmentReportDto.getStatus())) {
				continue;
			}

			long searchNodeSegmentVersion = MoreObjects.firstNonNull(currentSegmentReportDto.getSegmentVersion(), -1L);

			if (centralSegmentDataVersion <= searchNodeSegmentVersion) {
				if (newCurrentSegmentReportDtoFlag) {
					SegmentUpdateDto segmentUpdateDto = new SegmentUpdateDto();
					segmentUpdateDto.setSegmentId(segmentId);
					segmentUpdateDto.setSegmentStatus(SegmentStatus.ACTIVE);
					segmentUpdateDto.setTotalRecords(0);
					segmentUpdateDto.setStartSegmentVersion(0L);
					segmentUpdateDto.setEndSegmentVersion(0L);
					segmentUpdateDto.setStartBiometricId(Math.max(1L, biometricIdInfo.getStartBiometricId()));
					segmentUpdateDto.setEndBiometricId(biometricIdInfo.getEndBiometricId());
					segmentUpdateDto.setTemplateType(bioMatcherBinInfo.getTemplateType());
					segmentUpdateDto.setMaxEventCount((byte) meghaTemplateParser.getMaxEventCount());

					segmentSyncRequestDto.getSegmentUpdateDtoList().add(segmentUpdateDto);
				}

				// Already search node had latest data
				if (logger.isTraceEnabled())
					logger.trace("In buildSegmentSyncRequest:  searchNodeId: " + searchNodeId
							+ " already had latest segment data for segmentId: " + segmentId + ", segmentVersion: "
							+ searchNodeSegmentVersion + ", centralSegmentDataVersion: " + centralSegmentDataVersion);
				continue;
			}

			if ((searchNodeSegmentVersion + segmentDownloadVersionDiffThresholdCount) < centralSegmentDataVersion) {
				// Huge difference between centralSegmentDataVersion and
				// searchNode segment version, so try notifying to download from
				// other search nodes

				SegmentUpdateDto segmentUpdateDto = null;
				int connectionUrlLength = 0;

				Set<String> searchNodeIdSet = assignedSegmentIdSearchNodeIdListMap
						.get(currentSegmentReportDto.getSegmentId());
				if (searchNodeIdSet != null) {
					for (String otherSearchNodeId : searchNodeIdSet) {
						if (otherSearchNodeId.equals(searchNodeId)) {
							continue;
						}

						ConcurrentHashMap<Integer, SegmentReportDto> otherMatcherNodeSegmentVersionMap = bioSearchBrokerManager
								.getSearchNodeSegmentVersionMap(otherSearchNodeId);
						if (otherMatcherNodeSegmentVersionMap == null) {
							continue;
						}

						SegmentReportDto otherSegmentReportDto = otherMatcherNodeSegmentVersionMap
								.get(currentSegmentReportDto.getSegmentId());
						if (otherSegmentReportDto == null || otherSegmentReportDto.getSegmentVersion() == null) {
							continue;
						}

						// Check if other node is having latest changeset data
						// and changesets more than
						// segmentDownloadVersionDiffCount
						if (otherSegmentReportDto.getSegmentVersion() < (searchNodeSegmentVersion
								+ segmentDownloadVersionDiffThresholdCount)) {
							// Not enough changes to download from other search
							// node
							continue;
						}

						if (!bioSearchBrokerManager.getSearchNodeOnlineFlag(otherSearchNodeId).getFlag()) {
							// Other search node id not online
							continue;
						}

						BioServerConnectionInfo connectionInfo = bioMatcherConfigService.getServerConnectionInfo(
								otherSearchNodeId, BioComponentType.SN, BioConnectionType.SEG_SERVER);
						if (connectionInfo == null || StringUtils.isBlank(connectionInfo.getConnectionUrl())) {
							continue;
						}

						if (segmentUpdateDto == null) {
							segmentUpdateDto = new SegmentUpdateDto();
							segmentUpdateDto.setSegmentId(segmentId);
							segmentUpdateDto.setSegmentStatus(SegmentStatus.ACTIVE);
							segmentUpdateDto.setTotalRecords(0);
							segmentUpdateDto.setStartSegmentVersion(0L);
							segmentUpdateDto.setEndSegmentVersion(0L);
							segmentUpdateDto.setStartBiometricId(Math.max(1L, biometricIdInfo.getStartBiometricId()));
							segmentUpdateDto.setEndBiometricId(biometricIdInfo.getEndBiometricId());
							segmentUpdateDto.setTemplateType(bioMatcherBinInfo.getTemplateType());
							segmentUpdateDto.setMaxEventCount((byte) meghaTemplateParser.getMaxEventCount());
						}

						if ((connectionInfo.getConnectionUrl().length() + 1 + connectionUrlLength) <= 256) {
							segmentUpdateDto.getSegmentDownloadUrlList().add(connectionInfo.getConnectionUrl());
							logger.debug("Adding segment download url for segmentId: " + segmentId + ", searchNodeId: "
									+ searchNodeId + ", url: " + connectionInfo.getConnectionUrl());

							connectionUrlLength += connectionInfo.getConnectionUrl().length() + 1;
						} else {
							break;
						}
					}
				}

				if (segmentUpdateDto != null) {
					segmentSyncRequestDto.getSegmentUpdateDtoList().add(segmentUpdateDto);
					continue;
				} else {
					if (segmentServerEnabledFlag && searchNodeSegmentVersion <= 0L) {
						BioServerConnectionInfo connectionInfo = bioMatcherConfigService.getServerConnectionInfo(
								searchBrokerId, BioComponentType.SB, BioConnectionType.SEG_SERVER);
						if (connectionInfo != null && StringUtils.isNotBlank(connectionInfo.getConnectionUrl())) {
							try {
								SegmentFileReader segmentFileReader = new SegmentFileReader(segmentId);
								if (segmentFileReader.isValid(-1L)) {
									if (segmentUpdateDto == null) {
										segmentUpdateDto = new SegmentUpdateDto();
										segmentUpdateDto.setSegmentId(segmentId);
										segmentUpdateDto.setSegmentStatus(SegmentStatus.ACTIVE);
										segmentUpdateDto.setTotalRecords(0);
										segmentUpdateDto.setStartSegmentVersion(0L);
										segmentUpdateDto.setEndSegmentVersion(0L);
										segmentUpdateDto.setStartBiometricId(
												Math.max(1L, biometricIdInfo.getStartBiometricId()));
										segmentUpdateDto.setEndBiometricId(biometricIdInfo.getEndBiometricId());
										segmentUpdateDto.setTemplateType(bioMatcherBinInfo.getTemplateType());
										segmentUpdateDto
												.setMaxEventCount((byte) meghaTemplateParser.getMaxEventCount());
									}

									segmentUpdateDto.getSegmentDownloadUrlList().add(connectionInfo.getConnectionUrl());
									logger.info("Adding SB segment download url for segmentId: " + segmentId
											+ ", searchNodeId: " + searchNodeId + ", url: "
											+ connectionInfo.getConnectionUrl());

									segmentSyncRequestDto.getSegmentUpdateDtoList().add(segmentUpdateDto);
									continue;
								}
							} catch (Throwable th) {
								logger.error("Error checking SegmentFileReader for segmentId: " + segmentId + " : "
										+ th.getMessage(), th);
							}
						}
					}

					if (logger.isDebugEnabled())
						logger.debug(
								"Other search nodes doesnt have latest segment changeset data, so will send changeset updates for segmentId: "
										+ segmentId + ", searchNodeSegmentVersion: " + searchNodeSegmentVersion
										+ ", centralSegmentDataVersion: " + centralSegmentDataVersion
										+ ", segmentDownloadVersionDiffThresholdCount: "
										+ segmentDownloadVersionDiffThresholdCount);
				}
			}

			if (totalChangeSetSize.get() >= maxSegmentSyncRequestPayloadSize) {
				if (logger.isDebugEnabled())
					logger.debug(
							"SegmentSyncRequest payload size had reached max limit, will include rest of the changes for segmentId: "
									+ segmentId + " in next sync, maxSegmentSyncRequestPayloadSize: "
									+ maxSegmentSyncRequestPayloadSize + ", payloadSize: " + totalChangeSetSize.get());
				hasSyncBacklogFlag = true;
				continue;
			}

			AtomicBoolean lockAcquiredFailedFlag = new AtomicBoolean(false);

			SegmentUpdateDto segmentUpdateDto = null;
			long getSegmentChangesStartTimestampMilli = System.currentTimeMillis();
			try {
				segmentUpdateDto = segmentChangeSetReader.getSegmentChangesAfter(segmentId, searchNodeSegmentVersion,
						lockAcquiredFailedFlag, totalChangeSetSize);
			} finally {
				long getSegmentChangesTimeTakenMilli = System.currentTimeMillis()
						- getSegmentChangesStartTimestampMilli;

				if (getSegmentChangesTimeTakenMilli > 300 || logger.isDebugEnabled()) {
					if (segmentUpdateDto != null) {
						logger.info("In buildSegmentSyncRequest: TimeTakenMilli: " + getSegmentChangesTimeTakenMilli
								+ " for searchNodeId: " + searchNodeId + ", segmentId: "
								+ segmentUpdateDto.getSegmentId() + ", totalRecords: "
								+ segmentUpdateDto.getTotalRecords() + ", startSegmentVersion: "
								+ segmentUpdateDto.getStartSegmentVersion() + ", endSegmentVersion: "
								+ segmentUpdateDto.getEndSegmentVersion() + ", lockAcquiredFailedFlag: "
								+ lockAcquiredFailedFlag.get());
					} else {
						logger.info("In buildSegmentSyncRequest: TimeTakenMilli: " + getSegmentChangesTimeTakenMilli
								+ ", SegmentUpdateDto is null for searchNodeId: " + searchNodeId + ", segmentId: "
								+ currentSegmentReportDto.getSegmentId() + ", segmentVersion: "
								+ searchNodeSegmentVersion + ", centralSegmentDataVersion: " + centralSegmentDataVersion
								+ ", lockAcquiredFailedFlag: " + lockAcquiredFailedFlag.get());
					}
				}
			}

			if (segmentUpdateDto != null) {
				segmentUpdateDto.setStartBiometricId(Math.max(1L, biometricIdInfo.getStartBiometricId()));
				segmentUpdateDto.setEndBiometricId(biometricIdInfo.getEndBiometricId());
				segmentUpdateDto.setTemplateType(segmentIdTemplateTypeMap.get(segmentId));

				segmentUpdateDto.setMaxEventCount((byte) meghaTemplateParser.getMaxEventCount());

				segmentSyncRequestDto.getSegmentUpdateDtoList().add(segmentUpdateDto);
				hasAnyChangeSetPayloadFlag = true;

			} else {
				if (lockAcquiredFailedFlag.get()) {
					hasSyncBacklogFlag = true;
				}
			}
		}

		if (segmentIdSetForDeletion.size() > 0) {
			for (Integer segmentId : segmentIdSetForDeletion) {
				SegmentUpdateDto segmentUpdateDto = new SegmentUpdateDto();
				segmentUpdateDto.setSegmentId(segmentId);
				segmentUpdateDto.setSegmentStatus(SegmentStatus.DELETE);

				segmentSyncRequestDto.getSegmentUpdateDtoList().add(segmentUpdateDto);
				CommonLogger.STATUS_LOG.info("In buildSegmentSyncRequest for searchNodeId: " + searchNodeId
						+ ", segmentId: " + segmentUpdateDto.getSegmentId() + ", segmentStatus: "
						+ segmentUpdateDto.getSegmentStatus());
			}
		}
		return segmentSyncRequestDto;
	}

}
