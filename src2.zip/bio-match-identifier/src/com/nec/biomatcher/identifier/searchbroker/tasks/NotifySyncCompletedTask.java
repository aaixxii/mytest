package com.nec.biomatcher.identifier.searchbroker.tasks;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.log4j.Logger;

import com.google.common.collect.DiscreteDomain;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Range;
import com.google.common.collect.RangeSet;
import com.google.common.collect.Table;
import com.google.common.collect.TreeRangeSet;
import com.google.common.util.concurrent.Uninterruptibles;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.Memonizer;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchbroker.service.BioSearchBrokerService;
import com.nec.biomatcher.identifier.searchbroker.util.SearchBrokerClusterClient;
import com.nec.biomatcher.identifier.util.SegmentationUtil;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentReportDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentStatus;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestType;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;

/**
 * The Class NotifySyncCompletedTask.
 */
public class NotifySyncCompletedTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(NotifySyncCompletedTask.class);

	/** The Constant getSearchNodeSegmentVersionFunction. */
	private static final Function<String, Map<Integer, Long>> getSearchNodeSegmentVersionFunction = Memonizer
			.memonize(((searchNodeId) -> {
				return new HashMap<Integer, Long>();
			}));

	/** The bio search broker manager. */
	private BioSearchBrokerManager bioSearchBrokerManager;

	/** The bio search broker service. */
	private BioSearchBrokerService bioSearchBrokerService;

	private BioMatcherConfigService bioMatcherConfigService;

	/** The notify sync completed queue. */
	private LinkedBlockingDeque<SegmentSyncResponseDto> notifySyncCompletedQueue;

	/** The is initialized. */
	private boolean isInitialized = false;

	/**
	 * Instantiates a new notify sync completed task.
	 */
	public NotifySyncCompletedTask() {
	}

	@Override
	public void run() {
		Thread.currentThread().setName("NOTIFY_SYNC_COMPLETED_TASK");

		logger.info("In NotifySyncCompletedTask.run");

		final List<SegmentSyncResponseDto> workingSegmentSyncResponseDtoList = new ArrayList<>();
		final List<SegmentReportDto> workingSegmentReportDtoList = new ArrayList<>();
		final Map<Integer, RangeSet<Long>> workingSegmentRangeSetMap = new HashMap<>();

		final Table<String, Integer, Long> workingSearchNodeSegmentVersionTable = HashBasedTable.create();

		while (!ShutdownHook.isShutdownFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				SegmentSyncResponseDto firstSegmentSyncResponseDto = notifySyncCompletedQueue.poll(30,
						TimeUnit.SECONDS);
				if (firstSegmentSyncResponseDto == null) {
					continue;
				}

				workingSegmentSyncResponseDtoList.add(firstSegmentSyncResponseDto);

				notifySyncCompletedQueue.drainTo(workingSegmentSyncResponseDtoList);

				Map<Integer, Integer> segmentIdBinIdMap = bioMatcherConfigService.getSegmentIdBinIdMap();

				workingSegmentSyncResponseDtoList.forEach((segmentSyncResponseDto) -> {

					Map<Integer, Long> oldSegmentIdVersionMap = getSearchNodeSegmentVersionFunction
							.apply(segmentSyncResponseDto.getInstanceId());

					segmentSyncResponseDto.getSegmentReportDtoList().forEach((segmentReportDto) -> {
						if (!SegmentSyncRequestType.INIT.equals(segmentSyncResponseDto.getRequestType())
								&& SegmentStatus.ACTIVE.equals(segmentReportDto.getStatus())) {
							workingSegmentReportDtoList.add(segmentReportDto);
						}

						if (SegmentStatus.ACTIVE.equals(segmentReportDto.getStatus())) {
							if (segmentReportDto.getEndSegmentVersion() != null
									&& segmentReportDto.getEndSegmentVersion() > 0) {
								workingSearchNodeSegmentVersionTable.put(segmentReportDto.getSearchNodeId(),
										segmentReportDto.getSegmentId(), segmentReportDto.getEndSegmentVersion());
							} else if (segmentReportDto.getSegmentVersion() != null
									&& segmentReportDto.getSegmentVersion() > 0) {
								if (oldSegmentIdVersionMap.get(segmentReportDto.getSegmentId()) == null) {
									workingSearchNodeSegmentVersionTable.put(segmentReportDto.getSearchNodeId(),
											segmentReportDto.getSegmentId(), segmentReportDto.getSegmentVersion());
								} else if (!segmentReportDto.getSegmentVersion()
										.equals(oldSegmentIdVersionMap.get(segmentReportDto.getSegmentId()))) {
									workingSearchNodeSegmentVersionTable.put(segmentReportDto.getSearchNodeId(),
											segmentReportDto.getSegmentId(), segmentReportDto.getSegmentVersion());
								}
							}
						} else {
							workingSearchNodeSegmentVersionTable.put(segmentReportDto.getSearchNodeId(),
									segmentReportDto.getSegmentId(), -1L);
						}
					});
				});

				workingSegmentReportDtoList.forEach((segmentReportDto) -> {
					if (segmentReportDto.getStartSegmentVersion() != null
							&& segmentReportDto.getEndSegmentVersion() != null
							&& segmentReportDto.getEndSegmentVersion() > 0) {

						Range<Long> chengeSetVersionRange = Range.closed(segmentReportDto.getStartSegmentVersion(),
								segmentReportDto.getEndSegmentVersion());

						if (!workingSegmentRangeSetMap.containsKey(segmentReportDto.getSegmentId())) {
							workingSegmentRangeSetMap.put(segmentReportDto.getSegmentId(), TreeRangeSet.create());
						}
						workingSegmentRangeSetMap.get(segmentReportDto.getSegmentId())
								.add(chengeSetVersionRange.canonical(DiscreteDomain.longs()));
					}
				});

				if (workingSegmentRangeSetMap.size() > 0) {
					for (Integer segmentId : workingSegmentRangeSetMap.keySet()) {
						Integer binId = segmentIdBinIdMap.get(segmentId);

						RangeSet<Long> segmentVersionRangeSet = workingSegmentRangeSetMap.get(segmentId);

						if (binId == null || segmentVersionRangeSet == null || segmentVersionRangeSet.isEmpty()) {
							continue;
						}

						SegmentationUtil.saveNotificationsFromSearchBroker(binId, segmentId, segmentVersionRangeSet,
								null);
					}
				}

				for (String searchNodeId : workingSearchNodeSegmentVersionTable.rowKeySet()) {
					Map<Integer, Long> segmentIdVersionMap = workingSearchNodeSegmentVersionTable.row(searchNodeId);
					if (segmentIdVersionMap != null && segmentIdVersionMap.size() > 0) {
						Map<Integer, Long> newSegmentIdVersionMap = new HashMap<>();
						Map<Integer, Long> oldSegmentIdVersionMap = getSearchNodeSegmentVersionFunction
								.apply(searchNodeId);
						for (Map.Entry<Integer, Long> entry : segmentIdVersionMap.entrySet()) {
							Integer segmentId = entry.getKey();
							Long newSegmentVersion = entry.getValue();
							Long oldSegmentVersion = oldSegmentIdVersionMap.get(segmentId);

							if (newSegmentVersion != null) {
								if (oldSegmentVersion == null) {
									newSegmentIdVersionMap.put(segmentId, newSegmentVersion);
								} else if (newSegmentVersion.equals(-1L)) {
									newSegmentIdVersionMap.put(segmentId, newSegmentVersion);
								} else if (newSegmentVersion > oldSegmentVersion) {
									newSegmentIdVersionMap.put(segmentId, newSegmentVersion);
								}
							}
						}

						if (newSegmentIdVersionMap.size() > 0) {
							bioSearchBrokerManager.notifySearchNodeSegmentVersionToController(searchNodeId,
									newSegmentIdVersionMap);
							oldSegmentIdVersionMap.putAll(newSegmentIdVersionMap);
							bioSearchBrokerService.notifySearchNodeSyncVersion(searchNodeId, newSegmentIdVersionMap);

							Gson gson = new GsonBuilder().setPrettyPrinting().create();
							Type mapType = new TypeToken<Map<Integer, Long>>() {
							}.getType();
							String updateSegInfos = gson.toJson(newSegmentIdVersionMap, mapType);
							String updateSnSegInfos = searchNodeId + "#" + updateSegInfos;
							logger.info(
									"Notify segment report to StrictSegmentSyncCallbackService, snId=" + searchNodeId);
							notifySegmentReportToStrictSyncCallbackService(updateSnSegInfos);
						}
					}
				}

				workingSegmentReportDtoList.clear();
				workingSegmentRangeSetMap.clear();
				workingSearchNodeSegmentVersionTable.clear();
				workingSegmentSyncResponseDtoList.clear();
			} catch (Throwable th) {
				logger.error("Error in NotifySyncCompletedTask.run : " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			}
		}

		CommonLogger.STATUS_LOG.warn("Exiting NotifySyncCompletedTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	/**
	 * 
	 * @param notifyMsg
	 */
	private void notifySegmentReportToStrictSyncCallbackService(String notifyMsg) {
		try {
			SearchBrokerClusterClient searchBrokerClusterClient = bioSearchBrokerManager.getSearchBrokerClusterClient();
			searchBrokerClusterClient.getNotifyStrictSyncCompleteTopic().publish(notifyMsg);
		} catch (Throwable th) {
			logger.error("Error in notifySnReportToStrictSegmentSyncCallbackService: " + th.getMessage(), th);
		}
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchBrokerManager = SpringServiceManager.getBean("bioSearchBrokerManager");
		bioSearchBrokerService = SpringServiceManager.getBean("bioSearchBrokerService");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		notifySyncCompletedQueue = bioSearchBrokerManager.getNotifySyncCompletedQueue();
		isInitialized = true;
	}

}
