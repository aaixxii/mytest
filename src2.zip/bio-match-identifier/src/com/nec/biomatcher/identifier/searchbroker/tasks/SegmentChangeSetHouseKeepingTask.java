package com.nec.biomatcher.identifier.searchbroker.tasks;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import org.apache.log4j.Logger;

import com.google.common.base.Stopwatch;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.ILock;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.core.framework.common.FileUtils;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.util.SegmentationUtil;

/**
 * The Class SegmentChangeSetHouseKeepingTask.
 */
public class SegmentChangeSetHouseKeepingTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SegmentChangeSetHouseKeepingTask.class);

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;
	private BioSearchBrokerManager bioSearchBrokerManager;

	/** The is initialized. */
	private boolean isInitialized = false;

	@Override
	public void run() {
		Thread.currentThread().setName("SEGMENT_CHANGESET_HOUSEKEEPING_TASK_" + Thread.currentThread().getId());

		logger.info("In SegmentChangeSetHouseKeepingTask.run");

		while (!ShutdownHook.isShutdownFlag) {
			long segmentChangeSetHkIntervalMilli = TimeUnit.MINUTES.toMillis(30);
			try {
				if (!isInitialized) {
					init();
				}

				segmentChangeSetHkIntervalMilli = bioParameterService.getParameterValue(
						"SEGMENT_CHANGESET_HOUSEKEEPING_INTERVAL_MILLI", "DEFAULT", segmentChangeSetHkIntervalMilli);

				performSegmentChangeSetHouseKeeping();

			} catch (Throwable th) {
				logger.error("Error in SegmentChangeSetHouseKeepingTask: " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			} finally {
				Uninterruptibles.sleepUninterruptibly(segmentChangeSetHkIntervalMilli, TimeUnit.MILLISECONDS);
			}
		}

		logger.warn("Exiting SegmentChangeSetHouseKeepingTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	public void performSegmentChangeSetHouseKeeping() {
		try {

			bioSearchBrokerManager.getSearchBrokerEnabledFlag().waitForTrue();
			ClusterInstance clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SB);

			Set<Integer> segmentIdSet = bioMatcherConfigService
					.getAssignedSegmentIdListBySearchBrokerId(bioSearchBrokerManager.getSearchBrokerId());
			Map<Integer, Integer> segmentIdBinIdMap = bioMatcherConfigService.getSegmentIdBinIdMap();
			int retentionMinutes = bioParameterService.getParameterValue("SEGMENT_CHANGESET_FILE_HK_RETENTION_MINUTES",
					"DEFAULT", 30);

			int currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);

			for (Integer segmentId : segmentIdSet) {
				Integer binId = segmentIdBinIdMap.get(segmentId);
				if (binId == null) {
					continue;
				}

				ILock lock = clusterInstance.getLock("PerformSegmentChangeSetHouseKeepingLock_" + segmentId);

				boolean acquiredFlag = lock.tryLock();
				if (!acquiredFlag) {
					continue;
				}

				int deletedFileCount = 0;
				int deletedFolderCount = 0;

				Stopwatch stopwatch = Stopwatch.createStarted();
				try {
					Path segmentChangeSetFolderPath = SegmentationUtil.getSegmentChangeSetFolderPath(binId, segmentId);

					Calendar retentionCal = Calendar.getInstance();
					retentionCal.add(Calendar.MINUTE, -retentionMinutes);

					Calendar workingCal = Calendar.getInstance();

					if (workingCal.get(Calendar.MINUTE) > retentionMinutes) {
						deletedFileCount += deleteOldSegmentChangeSetFilesInFolder(
								Paths.get(segmentChangeSetFolderPath.toString(),
										String.valueOf(workingCal.get(Calendar.HOUR_OF_DAY))),
								retentionCal);
					}

					int maxLoopCount = 6;

					// Delete Hourly lob data older than retention period
					for (int i = 0; i < maxLoopCount; i++) {
						workingCal.add(Calendar.HOUR_OF_DAY, -1);

						if (currentHour == workingCal.get(Calendar.HOUR_OF_DAY) || workingCal.after(retentionCal)) {
							deletedFileCount += deleteOldSegmentChangeSetFilesInFolder(
									Paths.get(segmentChangeSetFolderPath.toString(),
											String.valueOf(workingCal.get(Calendar.HOUR_OF_DAY))),
									retentionCal);
						} else {
							Path deleteFolderPath = Paths.get(segmentChangeSetFolderPath.toString(),
									String.valueOf(workingCal.get(Calendar.HOUR_OF_DAY)));
							if (FileUtils.deleteFolderQuietly(deleteFolderPath.toFile())) {
								deletedFolderCount++;
							}
						}
					}
				} finally {
					lock.unlock();

					stopwatch.stop();

					if (logger.isTraceEnabled() || stopwatch.elapsed(TimeUnit.SECONDS) > 30) {
						logger.info("In performSegmentChangeSetHouseKeeping: TimeTakenMilli: "
								+ stopwatch.elapsed(TimeUnit.MILLISECONDS) + ", binId: " + binId + ", segmentId: "
								+ segmentId + ", deletedFileCount: " + deletedFileCount + ", deletedFolderCount: "
								+ deletedFolderCount);
					}
				}
			}

		} catch (Throwable th) {
			logger.error("Error in performSegmentChangeSetHouseKeeping : " + th.getMessage(), th);
		}
	}

	private int deleteOldSegmentChangeSetFilesInFolder(Path segmentChangeSetFolder, Calendar retentionCal) {
		AtomicInteger deletedFileCount = new AtomicInteger(0);
		try {
			if (!Files.isDirectory(segmentChangeSetFolder)) {
				return deletedFileCount.get();
			}

			final long retentionTimeStampMilli = retentionCal.getTimeInMillis();

			try (Stream<Path> pathStream = Files.list(segmentChangeSetFolder)) {
				pathStream.forEach(segmentChangeSetFile -> {
					try {
						if (Files.isRegularFile(segmentChangeSetFile) && Files.getLastModifiedTime(segmentChangeSetFile)
								.toMillis() < retentionTimeStampMilli) {
							FileUtils.deleteFileQuietly(segmentChangeSetFile);
							deletedFileCount.incrementAndGet();
						}
					} catch (Throwable th) {
						logger.error("Error in deleteOldSegmentChangeSetFilesInFolder segmentChangeSetFile: "
								+ segmentChangeSetFile + " : " + th.getMessage(), th);
					}
				});
			}
		} catch (Throwable th) {
			logger.error("Error in deleteOldSegmentChangeSetFilesInFolder segmentChangeSetFolder: "
					+ segmentChangeSetFolder + " : " + th.getMessage(), th);
		}
		return deletedFileCount.get();
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		bioSearchBrokerManager = SpringServiceManager.getBean("bioSearchBrokerManager");
		isInitialized = true;
	}

}
