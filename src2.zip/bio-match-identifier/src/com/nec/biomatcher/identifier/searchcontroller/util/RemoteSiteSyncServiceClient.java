package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.BaseKeyedPooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericKeyedObjectPool;
import org.apache.log4j.Logger;
import org.springframework.remoting.RemoteConnectFailureException;
import org.springframework.remoting.caucho.HessianProxyFactoryBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;
import com.nec.biomatcher.spec.services.exception.BioSearchJobControllerServiceException;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;

public class RemoteSiteSyncServiceClient {

	private static final Logger logger = Logger.getLogger(RemoteSiteSyncServiceClient.class);

	/** The Constant servicePool. */
	private static final GenericKeyedObjectPool<String, BioSearchJobControllerService> servicePool = buildServicePool();

	/**
	 * Instantiates a new search controller service client.
	 */
	private RemoteSiteSyncServiceClient() {

	}

	public static void syncRemoteBiometricEvents(List<String> remoteSiteServerIdList, String sourceSiteId,
			String targetSiteId, List<BiometricEventSyncTypeDto> biometricEventSyncList)
			throws BioSearchJobControllerServiceException, RemoteConnectFailureException {
		for (String remoteServerId : remoteSiteServerIdList) {
			try {
				syncRemoteBiometricEvents(remoteServerId, sourceSiteId, targetSiteId, biometricEventSyncList);
				return;
			} catch (RemoteConnectFailureException ex) {
				throw ex;
			}
		}
	}

	private static void syncRemoteBiometricEvents(String remoteServerId, String sourceSiteId, String targetSiteId,
			List<BiometricEventSyncTypeDto> biometricEventSyncList)
			throws BioSearchJobControllerServiceException, RemoteConnectFailureException {
		try {
			BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(remoteServerId, BioComponentType.RSC,
					BioConnectionType.COMPONENT, BioProtocolType.HESSIAN);
			BioSearchJobControllerService service = servicePool.borrowObject(connectionUrl);
			try {
				service.syncRemoteBiometricEvents(sourceSiteId, targetSiteId, biometricEventSyncList);
			} finally {
				servicePool.returnObject(connectionUrl, service);
			}
		} catch (BioSearchJobControllerServiceException ex) {
			logger.error("BioSearchJobControllerServiceException while syncRemoteBiometricEvents on remoteServerId: "
					+ remoteServerId + " : " + ex.getMessage(), ex);
			throw ex;
		} catch (RemoteConnectFailureException ex) {
			logger.error("RemoteConnectFailureException while syncRemoteBiometricEvents on remoteServerId: "
					+ remoteServerId + " : " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			logger.error(
					"Error in syncRemoteBiometricEvents on remoteServerId: " + remoteServerId + " : " + th.getMessage(),
					th);
			throw new BioSearchJobControllerServiceException(th.getMessage(), th);
		}
	}

	/**
	 * Builds the service pool.
	 *
	 * @return the generic keyed object pool
	 */
	private static GenericKeyedObjectPool<String, BioSearchJobControllerService> buildServicePool() {

		BaseKeyedPooledObjectFactory<String, BioSearchJobControllerService> poolFactory = new BaseKeyedPooledObjectFactory<String, BioSearchJobControllerService>() {

			@Override
			public BioSearchJobControllerService create(String connectionUrl) throws Exception {
				BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");

				long timeoutMilli = bioParameterService.getParameterValue(
						"REMOTE_SITE_SYNC_CLIENT_HESSIAN_TIMEOUT_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(5));

				HessianProxyFactoryBean proxy = new HessianProxyFactoryBean();
				proxy.setBeanClassLoader(BioSearchJobControllerService.class.getClassLoader());
				proxy.setServiceUrl(connectionUrl);
				proxy.setOverloadEnabled(true);
				proxy.setReadTimeout(timeoutMilli);
				proxy.setServiceInterface(BioSearchJobControllerService.class);
				proxy.afterPropertiesSet();
				BioSearchJobControllerService service = (BioSearchJobControllerService) proxy.getObject();
				return service;
			}

			@Override
			public PooledObject<BioSearchJobControllerService> wrap(BioSearchJobControllerService value) {
				return new DefaultPooledObject<>(value);
			}
		};

		GenericKeyedObjectPool<String, BioSearchJobControllerService> servicePool = new GenericKeyedObjectPool<String, BioSearchJobControllerService>(
				poolFactory);
		servicePool.setMaxTotalPerKey(50);
		servicePool.setMinEvictableIdleTimeMillis(TimeUnit.MINUTES.toMillis(10));
		return servicePool;
	}

}
