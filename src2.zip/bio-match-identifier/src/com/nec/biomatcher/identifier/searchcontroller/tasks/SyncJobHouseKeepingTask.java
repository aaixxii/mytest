package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;

public class SyncJobHouseKeepingTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SyncJobHouseKeepingTask.class);

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	/** The bio search job controller service. */
	private BioSearchJobControllerService bioSearchJobControllerService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The search job queue housekeeping queue. */
	private DelayQueue<DelayedItem<String>> syncJobQueueHousekeepingQueue;

	/** The is initialized. */
	private boolean isInitialized = false;

	@Override
	public void run() {
		Thread.currentThread().setName("SYNC_JOB_HOUSEKEEPING_TASK_" + Thread.currentThread().getId());

		logger.info("In SyncJobHouseKeepingTask.run");

		while (!ShutdownHook.isShutdownFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				DelayedItem<String> delayedItem = null;
				while ((delayedItem = syncJobQueueHousekeepingQueue.poll()) != null) {
					String syncJobId = delayedItem.getItem();
					try {
						bioSearchJobControllerService.deleteSyncJob(syncJobId);
					} catch (Throwable th) {
						logger.error("Error in SyncJobHouseKeepingTask for syncJobId: " + syncJobId + " : "
								+ th.getMessage(), th);
					}
				}
			} catch (Throwable th) {
				logger.error("Error in SyncJobHouseKeepingTask: " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			} finally {
				Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
			}
		}
		logger.warn("Exiting SyncJobHouseKeepingTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
		bioSearchJobControllerService = SpringServiceManager.getBean("bioSearchJobControllerService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		syncJobQueueHousekeepingQueue = bioSearchControllerManager.getSyncJobQueueHousekeepingQueue();

		isInitialized = true;
	}

}
