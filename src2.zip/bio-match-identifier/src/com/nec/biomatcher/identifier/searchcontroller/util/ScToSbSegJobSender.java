package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.zmq.ZmqPushConnection;
import com.nec.biomatcher.comp.zmq.ZmqPushSocketRef;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.MultiSnSegmentJobInfoList;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfoList;

public class ScToSbSegJobSender {
	private static final Logger logger = Logger.getLogger(ScToSbSegJobSender.class);

	private static final ConcurrentHashMap<String, ScToSbSegJobSenderTask> scToSbSegJobSenderTaskMap = new ConcurrentHashMap<>();

	private BioMatcherConfigService bioMatcherConfigService;
	private BioParameterService bioParameterService;

	public void sendToSbSnGroup(String searchNodeGroupId, SnSegmentJobInfoList snSegmentJobInfoList) {
		ScToSbSegJobSenderTask scToSbSegJobSenderTask = scToSbSegJobSenderTaskMap.get(searchNodeGroupId);
		if (scToSbSegJobSenderTask == null) {
			scToSbSegJobSenderTask = scToSbSegJobSenderTaskMap.computeIfAbsent(searchNodeGroupId,
					(searchNodeGroupIdParam) -> new ScToSbSegJobSenderTask(searchNodeGroupIdParam));
		}
		scToSbSegJobSenderTask.addToQueue(snSegmentJobInfoList);
	}

	public class ScToSbSegJobSenderTask extends Thread {
		private ConcurrentLinkedQueue<SnSegmentJobInfoList> snSegmentJobInfoQueue = new ConcurrentLinkedQueue<>();
		private Semaphore waitSemaphore = new Semaphore(0);
		private String searchNodeGroupId;

		public ScToSbSegJobSenderTask(String searchNodeGroupId) {
			this.searchNodeGroupId = searchNodeGroupId;
			start();
		}

		public void addToQueue(SnSegmentJobInfoList snSegmentJobInfoList) {
			snSegmentJobInfoQueue.add(snSegmentJobInfoList);
			waitSemaphore.release();
		}

		@Override
		public void run() {
			final ZmqPushSocketRef zmqPushSocketRef = new ZmqPushSocketRef();
			try {
				Thread.currentThread()
						.setName("SC_TO_SB_SEG_JOB_SENDER_" + searchNodeGroupId + "_" + Thread.currentThread().getId());

				while (!ShutdownHook.isShutdownFlag) {
					try {
						waitSemaphore.drainPermits();
						if (!snSegmentJobInfoQueue.isEmpty() || waitSemaphore.tryAcquire(1, TimeUnit.SECONDS)) {
							sendSnSegmentJobInfoListToSb(searchNodeGroupId, snSegmentJobInfoQueue, zmqPushSocketRef);
						}
					} catch (Throwable th) {
						logger.error("Error in ScToSbSegJobSenderTask for searchNodeGroupId: " + searchNodeGroupId
								+ " : " + th.getMessage(), th);
					}
				}
			} finally {
				logger.warn("Exiting the ScToSbSegJobSenderTask for searchNodeGroupId: " + searchNodeGroupId
						+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
				scToSbSegJobSenderTaskMap.remove(searchNodeGroupId);
				ZmqPushConnection.closeSocketQuitely(zmqPushSocketRef.zmqPushSocket);
			}

		}
	}

	private void sendSnSegmentJobInfoListToSb(String searchNodeGroupId,
			ConcurrentLinkedQueue<SnSegmentJobInfoList> snSegmentJobInfoQueue, ZmqPushSocketRef zmqPushSocketRef) {
		if (logger.isDebugEnabled())
			logger.debug("In sendSnSegmentJobInfoListToSb for searchNodeGroupId: " + searchNodeGroupId);

		if (snSegmentJobInfoQueue == null) {
			return;
		}

		long startTimestampMilli = System.currentTimeMillis();

		MultiSnSegmentJobInfoList.Builder multiSnSegmentJobInfoListBuilder = MultiSnSegmentJobInfoList.newBuilder();
		int polledCount = 0;
		SnSegmentJobInfoList snSegmentJobInfoList = null;
		while (polledCount < 50 && (snSegmentJobInfoList = snSegmentJobInfoQueue.poll()) != null) {
			multiSnSegmentJobInfoListBuilder.addSnSegmentJobInfoList(snSegmentJobInfoList);
			polledCount++;
		}

		if (polledCount == 0) {
			return;
		}

		String searchBrokerId = null;
		int scToSbPayloadBufSize = 0;
		try {
			searchBrokerId = bioMatcherConfigService.getAssignedSearchBrokerIdBySearchNodeGroupId(searchNodeGroupId);
			if (StringUtils.isBlank(searchBrokerId)) {
				throw new BioMatcherConfigServiceException(
						"Cannot find active search broker for searchNodeGroupId: " + searchNodeGroupId);
			}

			initializeZmqPushSocket(getSearchBrokerConnectionUrl(searchBrokerId), zmqPushSocketRef);

			byte[] scToSbPayloadBuf = multiSnSegmentJobInfoListBuilder.build().toByteArray();
			scToSbPayloadBufSize = scToSbPayloadBuf.length;

			ZmqPushConnection.sendMessage(zmqPushSocketRef.zmqPushSocket, "SC_TO_SB_SEG_JOBS_" + searchBrokerId,
					scToSbPayloadBuf);
		} catch (Throwable th) {
			logger.error("Error in sendSnSegmentJobInfoListToSb while submission to searchNodeGroupId: "
					+ searchNodeGroupId + ", searchBrokerId: " + searchBrokerId + ", multiSnSegmentJobInfoListSize: "
					+ polledCount + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 50 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In sendSnSegmentJobInfoListToSb: TimeTakenMilli: " + timeTakenMilli
						+ " for searchNodeGroupId: " + searchNodeGroupId + ", searchBrokerId: " + searchBrokerId
						+ ", multiSnSegmentJobInfoListSize: " + polledCount + ", scToSbPayloadBufSize: "
						+ scToSbPayloadBufSize);
			}
		}
	}

	private final void initializeZmqPushSocket(String sbConnectionUrl, ZmqPushSocketRef zmqPushSocketRef)
			throws Exception {
		if (zmqPushSocketRef.zmqPushSocket == null) {
			zmqPushSocketRef.zmqPushSocket = ZmqPushConnection.createSocket(sbConnectionUrl);
		} else if (!zmqPushSocketRef.zmqPushSocket.connectionUrl.equals(sbConnectionUrl)
				|| zmqPushSocketRef.zmqPushSocket.isErrorSendFlag()) {
			ZmqPushConnection.closeSocketQuitely(zmqPushSocketRef.zmqPushSocket);
			zmqPushSocketRef.zmqPushSocket = ZmqPushConnection.createSocket(sbConnectionUrl);
		}
	}

	private final String getSearchBrokerConnectionUrl(String searchBrokerId) throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchBrokerId, BioComponentType.SB,
				BioConnectionType.JOB_DISTRIBUTOR, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
					"Search broker job distributor connection url is not configured for searchBrokerId: "
							+ searchBrokerId + ", BioComponentType: " + BioComponentType.SB + ", connectionType: "
							+ BioConnectionType.JOB_DISTRIBUTOR + ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}
}
