package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.IMap;
import com.hazelcast.core.IQueue;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.bioevent.BiometricIdService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.CustomRunnable;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.SegmentFileReader;
import com.nec.biomatcher.identifier.util.SegmentationUtil.SegmentFileHeaderConstants;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;

public class SegmentFileWriterTask implements CustomRunnable {

    /** The Constant logger. */
    private static final Logger logger = Logger.getLogger(SegmentFileWriterTask.class);

    private static final ExecutorService executorService = CommonTaskScheduler.CACHED_EXECUTORSERVICE;

    /** The bio search controller manager. */
    private BioSearchControllerManager bioSearchControllerManager;

    private BiometricEventService biometricEventService;

    private BioMatcherConfigService bioMatcherConfigService;

    private BiometricIdService biometricIdService;

    private BioMatchManagerService bioMatchManagerService;

    private BioParameterService bioParameterService;

    private TemplateDataService templateDataService;

    private IQueue<Integer> createFullSegmentFileRequestQueue;

    private IMap<Integer, String> createFullSegmentFileRequestMap;

    private String defaultTempSegmentFilePath;

    /** The is initialized. */
    private boolean isInitialized = false;

    /**
     * Instantiates a new segment change set writer task.
     */
    public SegmentFileWriterTask() {
    }

    @Override
    public void run(AtomicBoolean stopFlag) {
        logger.info("In SegmentFileWriterTask stopFlag: " + stopFlag);

        while (!ShutdownHook.isShutdownFlag && !stopFlag.get()) {
            try {
                if (!isInitialized) {
                    init();
                }

                Integer segmentId = createFullSegmentFileRequestQueue.poll(1, TimeUnit.MINUTES);
                if (segmentId == null) {
                    continue;
                }

                if (!createFullSegmentFileRequestMap.containsKey(segmentId)) {
                    continue;
                }

                boolean acquiredFlag = createFullSegmentFileRequestMap.tryLock(segmentId);
                if (!acquiredFlag) {
                    continue;
                }

                try {
                    createSegmentFile(segmentId);
                } finally {
                    createFullSegmentFileRequestMap.unlock(segmentId);
                }
            } catch (Throwable th) {
                logger.error("Error in SegmentFileWriterTask: " + th.getMessage(), th);
                Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
            }
        }
    }

    private void createSegmentFile(Integer segmentId) throws Exception {
        logger.info("In SegmentFileWriterTask.createSegmentFile: segmentId: " + segmentId);

        final AtomicBoolean errorFlag = new AtomicBoolean(false);

        PFLogger.start();
        try (Closeable timer = MetricsUtil.time(BioComponentType.SC, bioSearchControllerManager.getSearchControllerId(), "CREATE_SEGMENT_FILE_TIME_TAKEN")) {

            final BiometricIdInfo biometricIdInfo = biometricIdService.getBiometricIdInfoBySegmentId(segmentId);
            if (biometricIdInfo.getCurrentBiometricId() <= 0) {
                createFullSegmentFileRequestMap.set(segmentId, "No Data");
                return;
            }

            String segmentStorageBasePath = bioParameterService.getParameterValue("FULL_SEGMENT_STORAGE_PATH", "DEFAULT", new File(System.getProperty("user.home"), "storage/segmentfiles/data/").getAbsolutePath());
            Path targetSegmentFilePath = getFullSegmentFilePath(biometricIdInfo.getBinId(), segmentId, segmentStorageBasePath);

            logger.info("In createSegmentFile: targetSegmentFilePath: " + targetSegmentFilePath.toFile().getAbsolutePath());

            if (Files.exists(targetSegmentFilePath)) {
                SegmentFileReader segFileReader = new SegmentFileReader(segmentId);
                if (segFileReader.isValid(-1L)) {
                    logger.warn("In createSegmentFile: targetSegmentFilePath already exists: " + targetSegmentFilePath.toFile().getAbsolutePath());
                    createFullSegmentFileRequestMap.set(segmentId, "Already Exists : " + targetSegmentFilePath.getFileName());
                    return;
                } else {
                    logger.warn("Current segment file is not valid for segmentId: " + segmentId + ", segmentFilePath: " + segFileReader.getSegmentFilePath());
                }
            }

            createFullSegmentFileRequestMap.set(segmentId, "Building");

            Long maxEventSegmentVersion = biometricEventService.getMaxEventSegmentVersionBySegmentId(segmentId);
            if (maxEventSegmentVersion == null) {
                logger.error("maxEventSegmentVersion is null for segmentId: " + segmentId + " while createSegmentFile");
                createFullSegmentFileRequestMap.set(segmentId, "Max Version Not Available");
                return;
            } else if (maxEventSegmentVersion <= 0L) {
                logger.error("maxEventSegmentVersion is -1 for segmentId: " + segmentId + " while createSegmentFile");
                createFullSegmentFileRequestMap.set(segmentId, "Max Version is -1");
                return;
            }

            BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService.getMatcherSegmentInfo(segmentId);
            if (bioMatcherSegmentInfo == null) {
                logger.error("bioMatcherSegmentInfo is null for segmentId: " + segmentId + " while createSegmentFile");
                createFullSegmentFileRequestMap.set(segmentId, "Matcher Segment Not Available");
                return;
            }

            final MeghaTemplateParser meghaTemplateParser = bioMatcherConfigService.getBinIdMeghaTemplateParserMap().get(bioMatcherSegmentInfo.getBinId());

            final int templateSize = meghaTemplateParser.getTemplateDataSize();

            long fileSize = SegmentFileHeaderConstants.HEADER_SIZE + (biometricIdInfo.getEndBiometricId() - Math.max(1L, biometricIdInfo.getStartBiometricId()) + 1) * templateSize;

            int maxConcurrencyPerSegmentWriter = bioParameterService.getParameterValue("MAX_CONCURRENCY_PER_SEGMENT_WRITER", "DEFAULT", 5);

            int maxRecords = bioParameterService.getParameterValue("CREATE_SEGMENT_FILE_MAX_LOAD_COUNT", "DEFAULT", 10000);

            String segmentFileWriterTempPath = bioParameterService.getParameterValue("TEMP_WORKING_STORAGE_PATH", "DEFAULT", defaultTempSegmentFilePath);

            File segmentFile = new File(segmentFileWriterTempPath, "SEG_" + segmentId + ".work");

            Files.deleteIfExists(segmentFile.toPath());

            logger.info("In SegmentFileWriterTask.createSegmentFile: segmentId: " + segmentId + ", segmentFile: " + segmentFile.getAbsolutePath());
            try (RandomAccessFile raf = new RandomAccessFile(segmentFile, "rw")) {
                raf.setLength(fileSize);

                try (FileChannel fc = raf.getChannel()) {
                    final MappedByteBuffer headerMappedByteBuffer = fc.map(MapMode.READ_WRITE, 0, SegmentFileHeaderConstants.HEADER_SIZE);

                    final Semaphore concurrencySemaphore = new Semaphore(maxConcurrencyPerSegmentWriter);

                    final byte[] EMPTY_RECORD = new byte[templateSize];
                    EMPTY_RECORD[2] = 1;// Marking the control flag
                    Long biometricId = Math.max(1L, biometricIdInfo.getStartBiometricId()) - 1L;
                    while (!errorFlag.get() && biometricId < biometricIdInfo.getCurrentBiometricId()) {

                        List<BiometricEventInfo> biometricEventInfoList = biometricEventService.getActiveBiometricEventInfoListBySegmentId(segmentId, biometricId, maxRecords);

                        if (biometricEventInfoList.size() > 0) {
                            long firstBiometricId = biometricId + 1;
                            long lastBiometricId = biometricEventInfoList.get(0).getBiometricId();
                            if (firstBiometricId < lastBiometricId) {
                                writeEmptyTemplateData(segmentId, firstBiometricId, lastBiometricId - 1L, fc, Math.max(1L, biometricIdInfo.getStartBiometricId()), templateSize, errorFlag, EMPTY_RECORD);
                            }

                            firstBiometricId = biometricEventInfoList.get(biometricEventInfoList.size() - 1).getBiometricId() + 1;
                            lastBiometricId = Math.min(biometricId + maxRecords, biometricIdInfo.getEndBiometricId()); // biometricId+ maxRecords;
                            if (firstBiometricId <= lastBiometricId) {
                                writeEmptyTemplateData(segmentId, firstBiometricId, lastBiometricId, fc, Math.max(1L, biometricIdInfo.getStartBiometricId()), templateSize, errorFlag, EMPTY_RECORD);
                            }

                            if (maxConcurrencyPerSegmentWriter > 1) {
                                // Controlled executor based parallelism
                                int partitionSize = Math.max(biometricEventInfoList.size() / maxConcurrencyPerSegmentWriter, 1000);

                                Lists.partition(biometricEventInfoList, partitionSize).forEach(biometricEventInfoSubList -> {
                                    writeTemplateDataAsync(concurrencySemaphore, segmentId, biometricEventInfoSubList, fc, Math.max(1L, biometricIdInfo.getStartBiometricId()), templateSize, errorFlag, EMPTY_RECORD);
                                });

                            } else {
                                // JVM based parallelism
                                // Lists.partition(biometricEventInfoList, 1000).parallelStream().forEach(biometricEventInfoSubList -> {
                                // writeTemplateData(segmentId, biometricEventInfoSubList, fc, Math.max(1L, biometricIdInfo.getStartBiometricId()), templateSize, errorFlag, templateStoragePathMap, EMPTY_RECORD);
                                // });

                                writeTemplateData(segmentId, biometricEventInfoList, fc, Math.max(1L, biometricIdInfo.getStartBiometricId()), templateSize, errorFlag, EMPTY_RECORD);
                            }
                        } else {
                            long firstBiometricId = biometricId + 1;
                            long lastBiometricId = Math.min(biometricId + maxRecords, biometricIdInfo.getEndBiometricId());
                            if (firstBiometricId <= lastBiometricId) {
                                writeEmptyTemplateData(segmentId, firstBiometricId, lastBiometricId, fc, Math.max(1L, biometricIdInfo.getStartBiometricId()), templateSize, errorFlag, EMPTY_RECORD);
                            }
                        }

                        biometricId = biometricId + maxRecords;
                    }

                    if (maxConcurrencyPerSegmentWriter > 1) {
                        concurrencySemaphore.acquireUninterruptibly(maxConcurrencyPerSegmentWriter);
                    }

                    if (!errorFlag.get()) {
                        // CapsuleType type;BioId startId;BioId endId;BioId maxUsedId;VersionId version;
                        headerMappedByteBuffer.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

                        headerMappedByteBuffer.position(0);
                        headerMappedByteBuffer.putInt(meghaTemplateParser.getTemplateType().getTemplateTypeCode());
                        headerMappedByteBuffer.putLong(Math.max(1L, biometricIdInfo.getStartBiometricId()));
                        headerMappedByteBuffer.putLong(biometricIdInfo.getEndBiometricId());
                        headerMappedByteBuffer.putLong(maxEventSegmentVersion);
                        headerMappedByteBuffer.put((byte) meghaTemplateParser.getMaxEventCount());
                        headerMappedByteBuffer.put(new byte[3]); // Pad bytes
                        headerMappedByteBuffer.force();
                    }
                }
            }

            if (errorFlag.get()) {
                logger.info("In SegmentFileWriterTask.createSegmentFile: encountered error for segmentId " + segmentId);
                createFullSegmentFileRequestMap.put(segmentId, "Error");
                return;
            }

            // Files.copy(segmentFile.toPath(), targetSegmentFilePath, StandardCopyOption.REPLACE_EXISTING);
            FileUtils.copyFile(segmentFile, targetSegmentFilePath.toFile());
            logger.info("In SegmentFileWriterTask.createSegmentFile: After copying segment file to targetSegmentFile: " + targetSegmentFilePath.toFile().getAbsolutePath());

            boolean deleteFlag = Files.deleteIfExists(segmentFile.toPath());
            logger.info("In SegmentFileWriterTask.createSegmentFile: deleted working segmentFile: " + segmentFile.getAbsolutePath() + ", deleteFlag: " + deleteFlag);

            createFullSegmentFileRequestMap.put(segmentId, "Completed");

        } catch (Throwable th) {
            errorFlag.set(true);
            createFullSegmentFileRequestMap.put(segmentId, "Error: " + th.getMessage());
            logger.error("Error in SegmentFileWriterTask.createSegmentFile segmentId: " + segmentId + " : " + th.getMessage(), th);
        } finally {
            PFLogger.end("After creating segment file for segmentId: " + segmentId + ", errorFlag: " + errorFlag.get());
        }
    }

    public Path getFullSegmentFilePath(Integer binId, Integer segmentId, String basePath) throws IOException {
        Path targetSegmentFilePath = Paths.get(basePath, binId.toString(), segmentId.toString());

        Path parentFolder = targetSegmentFilePath.getParent();
        if (parentFolder != null) {
            Files.createDirectories(parentFolder);
        }

        return targetSegmentFilePath;
    }

    private final void writeTemplateDataAsync(Semaphore concurrencySemaphore, Integer segmentId, final List<BiometricEventInfo> biometricEventInfoList, final FileChannel fc, final Long startBiometricIdOffset, final int templateSize, final AtomicBoolean errorFlag, byte[] EMPTY_RECORD) {
        concurrencySemaphore.acquireUninterruptibly();
        try {
            executorService.execute(new Runnable() {
                public void run() {
                    try {
                        Thread.currentThread().setName("SEG_FILE_WRITER_" + segmentId + "_" + Thread.currentThread().getId());
                        writeTemplateData(segmentId, biometricEventInfoList, fc, startBiometricIdOffset, templateSize, errorFlag, EMPTY_RECORD);
                    } finally {
                        concurrencySemaphore.release();
                    }
                }
            });
        } catch (Throwable th) {
            logger.error("Error in SegmentFileWriterTask.writeTemplateDataAsync segmentId: " + segmentId + " : " + th.getMessage(), th);
            concurrencySemaphore.release();
            errorFlag.set(true);
        }
    }

    private static final void writeEmptyTemplateData(final Integer segmentId, long firstBiometricId, long lastBiometricId, FileChannel fc, final Long startBiometricIdOffset, final int templateSize, final AtomicBoolean errorFlag, byte[] EMPTY_RECORD) {
        PFLogger.start();
        try {
            long fcStartPosition = (SegmentFileHeaderConstants.HEADER_SIZE + ((firstBiometricId - startBiometricIdOffset) * templateSize));
            int mappedRegionSize = (int) ((lastBiometricId - firstBiometricId + 1) * templateSize);

            MappedByteBuffer mappedByteBuffer = fc.map(MapMode.READ_WRITE, fcStartPosition, mappedRegionSize);

            LongStream stream = LongStream.rangeClosed(firstBiometricId, lastBiometricId);
            stream.forEach((biometricId) -> {
                try {
                    mappedByteBuffer.position((int) ((biometricId - firstBiometricId) * templateSize));
                    mappedByteBuffer.put(EMPTY_RECORD, 0, templateSize);
                } catch (Throwable th) {
                    logger.error("Error in SegmentFileWriterTask.writeEmptyTemplateData record for segmentId: " + segmentId + ", biometricId: " + biometricId + " : " + th.getMessage(), th);
                }
            });
            stream.close();

            mappedByteBuffer.force();
        } catch (Throwable th) {
            logger.error("Error in SegmentFileWriterTask.writeEmptyTemplateData for segmentId: " + segmentId + " : " + th.getMessage(), th);
            errorFlag.set(true);
        } finally {
            PFLogger.end("After writing emptyTemplateData for segmentId: " + segmentId + ", firstBiometricId: " + firstBiometricId + ", lastBiometricId: " + lastBiometricId);
        }
    }

    private final void writeTemplateData(final Integer segmentId, final List<BiometricEventInfo> biometricEventInfoList, FileChannel fc, final Long startBiometricIdOffset, final int templateSize, final AtomicBoolean errorFlag, byte[] EMPTY_RECORD) {
        PFLogger.start();
        Long firstBiometricId = biometricEventInfoList.get(0).getBiometricId();
        Long lastBiometricId = biometricEventInfoList.get(biometricEventInfoList.size() - 1).getBiometricId();
		LongStream stream = null;
        try {
            long fcStartPosition = (SegmentFileHeaderConstants.HEADER_SIZE + ((firstBiometricId - startBiometricIdOffset) * templateSize));
            int mappedRegionSize = (int) ((lastBiometricId - firstBiometricId + 1) * templateSize);

            MappedByteBuffer mappedByteBuffer = fc.map(MapMode.READ_WRITE, fcStartPosition, mappedRegionSize);

            final Map<Long, BiometricEventInfo> biometricEventInfoMap = biometricEventInfoList.stream().collect(Collectors.toMap(BiometricEventInfo::getBiometricId, (p) -> p));

            stream = LongStream.rangeClosed(biometricEventInfoList.get(0).getBiometricId(), biometricEventInfoList.get(biometricEventInfoList.size() - 1).getBiometricId());
            stream.forEach((biometricId) -> {
	            	BiometricEventInfo biometricEventInfo = biometricEventInfoMap.get(biometricId);
	                mappedByteBuffer.position((int) ((biometricId - firstBiometricId) * templateSize));
	
	                boolean isWritten = false;
	                if (biometricEventInfo != null && BiometricEventStatus.ACTIVE.equals(biometricEventInfo.getStatus()) && (BiometricEventPhase.PENDING_SYNC.equals(biometricEventInfo.getPhase()) || BiometricEventPhase.SYNC_COMPLETED.equals(biometricEventInfo.getPhase())) && biometricEventInfo.getTemplateDataKey() != null
	                        && biometricEventInfo.getTemplateDataKey().length() > 0) {
	                    try {
	                        byte templateData[] = templateDataService.getTemplateData(biometricEventInfo.getTemplateDataKey());
	                        if (templateData == null || templateData.length != templateSize) {
	                            throw new IOException("Invalid template data size: " + (templateData == null ? 0 : templateData.length) + ", expected templateSize: " + templateSize + ", biometricId: " + biometricId + ", templateDataKey: " + biometricEventInfo.getTemplateDataKey());
	                        }
	                        mappedByteBuffer.put(templateData);
	                        isWritten = true;
	                    } catch (Throwable th) {
	                        logger.error("Error in SegmentFileWriterTask.writeTemplateData for segmentId: " + segmentId + ", biometricId: " + biometricId + " : " + th.getMessage(), th);
	                    }
	                }
	                if (!isWritten) {
                		try{
	                		mappedByteBuffer.put(EMPTY_RECORD, 0, templateSize);
	                	} catch (Throwable th) {
                   			 logger.error("Error in SegmentFileWriterTask.writeTemplateData record for segmentId: " + segmentId + ", biometricId: " + biometricId + " : " + th.getMessage(), th);
                		}
					}	
            });
            mappedByteBuffer.force();
        } catch (Throwable th) {
            logger.error("Error in SegmentFileWriterTask.writeTemplateData for segmentId: " + segmentId + " : " + th.getMessage(), th);
            errorFlag.set(true);
        } finally {
			if(stream != null){
            	stream.close();
			}
            PFLogger.end("After writing templateData for segmentId: " + segmentId + ", firstBiometricId: " + firstBiometricId + ", lastBiometricId: " + lastBiometricId);
        }
    }

    /**
     * Inits the.
     */
    private final void init() {
        bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
        bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
        biometricEventService = SpringServiceManager.getBean("biometricEventService");
        biometricIdService = SpringServiceManager.getBean("biometricIdService");
        bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
        bioParameterService = SpringServiceManager.getBean("bioParameterService");
        templateDataService = SpringServiceManager.getBean("templateDataService");

        createFullSegmentFileRequestQueue = bioSearchControllerManager.getCreateFullSegmentFileRequestQueue();
        createFullSegmentFileRequestMap = bioSearchControllerManager.getCreateFullSegmentFileRequestMap();

        defaultTempSegmentFilePath = (new File(System.getProperty("java.io.tmpdir"))).getAbsolutePath();

        isInitialized = true;
    }

}
