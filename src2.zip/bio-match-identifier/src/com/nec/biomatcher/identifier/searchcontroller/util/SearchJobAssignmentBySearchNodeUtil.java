package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.collections.ListUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Stopwatch;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.util.concurrent.AtomicLongMap;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentKeyedExecutor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.CustomKeyedRunnable;
import com.nec.biomatcher.core.framework.common.concurrent.DynamicSemaphore;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfo;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfoList;

public class SearchJobAssignmentBySearchNodeUtil implements InitializingBean {
	private static final Logger logger = Logger.getLogger(SearchJobAssignmentBySearchNodeUtil.class);

	private static final ConcurrentValuedHashMap<String, ConcurrentSkipListSet<JobEntry>> searchNodeSearchJobIdSetMap = new ConcurrentValuedHashMap<>(
			searchNodeId -> new ConcurrentSkipListSet<>());

	private static final AtomicLongMap<String> searchNodeParameterCheckTimestampMap = AtomicLongMap.create();

	private BioMatcherConfigService bioMatcherConfigService;

	private BioSearchControllerManager bioSearchControllerManager;

	private BioParameterService bioParameterService;

	private BioMatchManagerService bioMatchManagerService;

	private SearchJobAssignmentUtil searchJobAssignmentUtil;

	private ConcurrentKeyedExecutor<String> searchNodeJobAssignmentExecutor;

	private Function<String, Boolean> searchNodeOnlineCheckFunction = null;

	private ConcurrentHashMap<String, ScSearchJobInfo> searchJobInfoMap;

	private ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> scSearchNodePartitionedLoadMap;
	private ConcurrentValuedHashMap<String, ConcurrentValuedHashMap<String, SearchNodeCapacityGroupLoadInfo>> searchNodeIdSearchNodeCapacityMap;
	private ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap;
	private DynamicSemaphore acquireSlotConcurrencySemaphore;

	private String searchControllerId;

	private static final AtomicInteger initializationCount = new AtomicInteger();

	public final void addJobEntryForAssignment(String searchNodeId, JobEntry jobEntry, String capacityGroupId) {
		String key = searchNodeId + "|" + capacityGroupId;
		searchNodeSearchJobIdSetMap.getValue(key).add(jobEntry);
		searchNodeJobAssignmentExecutor.notifyData(key);
	}

	public final void addJobEntryForAssignment(Set<String> searchNodeIdSet, JobEntry jobEntry, String capacityGroupId) {
		for (String searchNodeId : searchNodeIdSet) {
			String key = searchNodeId + "|" + capacityGroupId;
			searchNodeSearchJobIdSetMap.getValue(key).add(jobEntry);
			searchNodeJobAssignmentExecutor.notifyData(key);
		}
	}

	public final void addJobEntryForAssignment(String searchNodeId, Collection<JobEntry> jobEntryList,
			String capacityGroupId) {
		String key = searchNodeId + "|" + capacityGroupId;
		if (jobEntryList != null && !jobEntryList.isEmpty()) {
			ConcurrentSkipListSet<JobEntry> snJobEntryList = searchNodeSearchJobIdSetMap.getValue(key);
			for (JobEntry jobEntry : jobEntryList) {
				snJobEntryList.add(jobEntry);
			}
			searchNodeJobAssignmentExecutor.notifyData(key);
		}
	}

	private Set<String> getAssignedSearchNodeIdList() {
		try {
			return bioMatcherConfigService.getAssignedSearchNodeIdList();
		} catch (Throwable th) {
			logger.error("Error in getAssignedSearchNodeIdList: " + th.getMessage(), th);
			return Collections.emptySet();
		}
	}

	private Set<String> getAssignedSearchNodeIdCapacityGroupIdKeyList() {
		try {
			return bioMatcherConfigService.getAssignedSearchNodeIdCapacityGroupIdKeyList();
		} catch (Throwable th) {
			logger.error("Error in getAssignedSearchNodeIdCapacityGroupIdKeyList: " + th.getMessage(), th);
			return Collections.emptySet();
		}
	}

	private final void updateSearchNodeCapacityGroupLoadInfo(String searchNodeId, String capacityGroupId,
			ConcurrentValuedHashMap<String, SearchNodeCapacityGroupLoadInfo> searchNodeCapacityMap) throws Exception {
		final String key = searchNodeId + "|" + capacityGroupId;

		if ((System.currentTimeMillis() - searchNodeParameterCheckTimestampMap.get(key)) < TimeUnit.SECONDS
				.toMillis(10)) {
			return;
		}

		synchronized (searchNodeId.intern()) {
			if ((System.currentTimeMillis() - searchNodeParameterCheckTimestampMap.get(key)) < TimeUnit.SECONDS
					.toMillis(10)) {
				return;
			}

			if (logger.isDebugEnabled())
				logger.debug("In updateSearchNodeCapacityGroupLoadInfo: searchNodeId: " + searchNodeId
						+ ", capacityGroupId: " + capacityGroupId);

			BioServerInfo bioServerInfo = bioMatcherConfigService.getServerInfo(searchNodeId);
			Map<String, Integer> snCapacityGroupMap = bioMatcherConfigService.getServerCapacityGroupMap(searchNodeId);

			int searchNodeCapacity = snCapacityGroupMap.getOrDefault(capacityGroupId, 0);
			if (searchNodeCapacity == 0) {
				SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = searchNodeCapacityMap.remove(capacityGroupId);
				if (searchNodeLoadInfo != null) {
					logger.info(
							"In updateSearchNodeCapacityGroupLoadInfo: removing searchNodeLoadInfo from searchNodeCapacityMap for capacityGroupId: "
									+ capacityGroupId + ", searchNodeId: " + searchNodeId
									+ " since searchNodeCapacity is 0");
				} else {
					logger.debug(
							"In updateSearchNodeCapacityGroupLoadInfo: removing searchNodeLoadInfo from searchNodeCapacityMap for capacityGroupId: "
									+ capacityGroupId + ", searchNodeId: " + searchNodeId
									+ " since searchNodeCapacity is 0");
				}
				return;
			}

			SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = searchNodeCapacityMap.getValue(capacityGroupId);

			float searchNodeJobOverloadFactor = bioMatcherConfigService.getSearchNodeFunctionCapacityOverloadFactorMap()
					.getOrDefault(capacityGroupId, 1.3f);
			boolean searchJobSlotAcquireLockFlag = bioParameterService
					.getParameterValue("SEARCH_JOB_SLOT_ACQUIRE_LOCK_FLAG", "DEFAULT", false);

			searchNodeLoadInfo.updateParameters(bioServerInfo.getServerGroupId(), searchNodeCapacity,
					searchNodeJobOverloadFactor);
			searchNodeLoadInfo.setSearchJobSlotAcquireLockFlag(searchJobSlotAcquireLockFlag);
			if (logger.isDebugEnabled())
				logger.debug(
						"In updateSearchNodeCapacityGroupLoadInfo: After updating searchNodeLoadInfo for capacityGroupId: "
								+ capacityGroupId + ", searchNodeId: " + searchNodeId + ", searchNodeCapacity: "
								+ searchNodeCapacity);

			searchNodeParameterCheckTimestampMap.put(key, System.currentTimeMillis());
		}
	}

	class SearchJobAssignmentBySearchNodeTask implements CustomKeyedRunnable<String> {
		private final Logger logger = Logger.getLogger(SearchJobAssignmentBySearchNodeTask.class);

		@Override
		public void run(AtomicBoolean stopFlag, String searchNodeIdCapacityGroupIdKey, Semaphore keyDataWaitSemaphore) {
			ConcurrentSkipListSet<JobEntry> searchJobEntrySet = searchNodeSearchJobIdSetMap
					.getValue(searchNodeIdCapacityGroupIdKey);

			String[] splitArray = searchNodeIdCapacityGroupIdKey.split("\\|");
			final String searchNodeId = splitArray[0];
			final String capacityGroupId = splitArray[1];

			ConcurrentValuedHashMap<String, SearchNodeCapacityGroupLoadInfo> searchNodeCapacityMap = searchNodeIdSearchNodeCapacityMap
					.getValue(searchNodeId);

			List<JobEntry> pendingAssignmentJobEntryList = new ArrayList<>();
			AtomicBoolean noFreeSlotsFlag = new AtomicBoolean(false);
			AtomicBoolean hasSvtMissFlag = new AtomicBoolean(false);
			AtomicInteger preAcquiredSlots = new AtomicInteger(0);
			while (!ShutdownHook.isShutdownFlag && !stopFlag.get()) {
				NDC.clear();
				NDC.push(searchNodeId);
				try {
					boolean segmentVersionTargetEnabledFlag = bioParameterService
							.getParameterValue("SEGMENT_VERSION_TARGET_ENABLED_FLAG", "DEFAULT", false);
					boolean scToSnDirectSegmentJobDistributionFlag = bioParameterService
							.getParameterValue("SC_TO_SN_DIRECT_SEGMENT_JOB_DISTRIBUTION_FLAG", "DEFAULT", true);
					long searchJobRescheduleDelayMilli = bioParameterService
							.getParameterValue("SEARCH_JOB_RESCHEDULE_DELAY_MILLI", "DEFAULT", 5L);
					boolean lockDuringSearchJobAssignmentFlag = bioParameterService
							.getParameterValue("LOCK_DURING_SEARCH_JOB_ASSIGNMENT_FLAG", "DEFAULT", true);
					boolean isFunctionCapacityGroupControlEnabled = bioParameterService
							.getParameterValue("FUNCTION_CAPACITY_GROUP_CONTROL_ENABLED_FLAG", "DEFAULT", false);

					if (searchJobEntrySet.isEmpty()) {
						if (!keyDataWaitSemaphore.tryAcquire(30, TimeUnit.SECONDS)) {
							if (searchJobEntrySet.isEmpty()) {
								continue;
							}
						}
					}

					if (!searchNodeOnlineCheckFunction.apply(searchNodeId)) {
						Uninterruptibles.sleepUninterruptibly(10, TimeUnit.MILLISECONDS);
					}

					updateSearchNodeCapacityGroupLoadInfo(searchNodeId, capacityGroupId, searchNodeCapacityMap);

					List<Integer> searchNodeSegmentIdList = bioMatcherConfigService
							.getSortedSearchNodeIdSegmentIdListMap().getValue(searchNodeId);
					if (searchNodeSegmentIdList.isEmpty()) {
						Uninterruptibles.sleepUninterruptibly(1, TimeUnit.SECONDS);
						searchNodeSegmentIdList = bioMatcherConfigService.getSortedSearchNodeIdSegmentIdListMap()
								.getValue(searchNodeId);
					}

					final Map<Integer, Long> liveSearchNodeSegmentDataVersionMap = segmentVersionTargetEnabledFlag == false
							? null : bioMatchManagerService.getLiveMatcherNodeSegmentVersionMap(searchNodeId);
					SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = searchNodeCapacityMap.get(capacityGroupId);
					int jobAssignmentProcessedCount = 0;
					int totalAssignedSegmentJobCount = 0;
					try {
						preAcquiredSlots.set(0);
						noFreeSlotsFlag.set(false);

						JobEntry jobEntry = null;
						while (!noFreeSlotsFlag.get() && (jobEntry = searchJobEntrySet.pollFirst()) != null) {
							hasSvtMissFlag.set(false);							
							if (jobAssignmentProcessedCount == 0) {
								keyDataWaitSemaphore.drainPermits();
							}

							ScSearchJobInfo scSearchJobInfo = null;
							int assignedSegmentJobCount = 0;
							NDC.push(jobEntry.getJobId());
							PFLogger.start();
							try {
								scSearchJobInfo = searchJobInfoMap.get(jobEntry.getJobId());
								if (scSearchJobInfo == null) {
									logger.warn("ScSearchJobInfo is not available in searchJobInfoMap for searchJobId: "
											+ jobEntry.getJobId());
									continue;
								}

								if (!scSearchJobInfo.hasPendingSegmentIdsForAssignment()) {
									logger.debug(
											"No pending assignment segments for searchJobId: " + jobEntry.getJobId());
									continue;
								}

								if (searchNodeLoadInfo == null) {
									logger.warn("CapacityGroupKey: " + capacityGroupId
											+ " is not assigned, ignoring job assignment for searchJobId: "
											+ jobEntry.getJobId() + " by searchNodeId: " + searchNodeId);
									break;
								}

								if (searchNodeSegmentIdList.isEmpty()) {
									logger.warn("Segments are not assigned to searchNodeId: " + searchNodeId
											+ ", ignoring assignment for searchJobId: " + jobEntry.getJobId());
									continue;
								}

								if (!searchNodeLoadInfo.isSnOnline()) {
									if (logger.isDebugEnabled())
										logger.debug("Search node is offline for searchNodeId: " + searchNodeId
												+ ", capacityGroupId: " + searchNodeLoadInfo.capacityGroupId
												+ " during assignmentfor searchJobId: " + jobEntry.getJobId());
									pendingAssignmentJobEntryList.add(jobEntry);
									break;
								}

								List<Integer> filteredSortedSegmentIdSet = ListUtils.retainAll(searchNodeSegmentIdList,
										scSearchJobInfo.pendingSegmentIdRequestKeySetMap.keySet());

								Map<String, Integer> maxMultiSegmentJobCountMap = bioMatcherConfigService
										.getSearchFunctionMaxMultiSegmentJobCountMap();
								Integer maxMultiSegmentsPerSearchJob = maxMultiSegmentJobCountMap
										.getOrDefault(scSearchJobInfo.getFunctionCapacityGroupKey(), 1);
								if (maxMultiSegmentsPerSearchJob > 1) {
									SnSegmentJobInfoList snSegmentJobInfoList = assignJobsToSearchNodeByBatch(
											scSearchJobInfo, searchNodeLoadInfo, filteredSortedSegmentIdSet,
											liveSearchNodeSegmentDataVersionMap, searchControllerId, hasSvtMissFlag,
											noFreeSlotsFlag, preAcquiredSlots, maxMultiSegmentsPerSearchJob,
											lockDuringSearchJobAssignmentFlag);
									//TODO Redmine #16046
//									for(SnSegmentJobInfo segmentJobInfo :  snSegmentJobInfoList.getSnSegmentJobInfoList()){
//										logger.info("JOB_ID:" + snSegmentJobInfoList.getSearchJobId()  +
//												" SNID: "  + snSegmentJobInfoList.getSearchNodeId() + 
//												" TGT_SEGMENTS: " + segmentJobInfo.getSegmentIdList().toString());
//									}
									assignedSegmentJobCount = searchJobAssignmentUtil
											.sendAssignedSegmentJobsToRequestBuilder(snSegmentJobInfoList,
													searchNodeLoadInfo, scToSnDirectSegmentJobDistributionFlag);
								} else {
									SnSegmentJobInfoList snSegmentJobInfoList = assignJobsToSearchNodeBySegmentId(
											scSearchJobInfo, searchNodeLoadInfo, filteredSortedSegmentIdSet,
											liveSearchNodeSegmentDataVersionMap, searchControllerId, hasSvtMissFlag,
											noFreeSlotsFlag, preAcquiredSlots, lockDuringSearchJobAssignmentFlag);									
									//TODO Redmine #16046
//									for(SnSegmentJobInfo segmentJobInfo :  snSegmentJobInfoList.getSnSegmentJobInfoList()){
//										logger.info("JOB_ID:" + snSegmentJobInfoList.getSearchJobId()  +
//												" SNID: "  + snSegmentJobInfoList.getSearchNodeId() + 
//												" TGT_SEGMENTS: " + segmentJobInfo.getSegmentIdList().toString());
//									}
									assignedSegmentJobCount = searchJobAssignmentUtil
											.sendAssignedSegmentJobsToRequestBuilder(snSegmentJobInfoList,
													searchNodeLoadInfo, scToSnDirectSegmentJobDistributionFlag);
								}	

								totalAssignedSegmentJobCount += assignedSegmentJobCount;
								jobAssignmentProcessedCount++;

								if (scSearchJobInfo.isJobCompleted()) {
									logger.info(
											"In SearchJobAssignmentBySearchNodeTask: search job already marked for completion : searchNodeId: "
													+ searchNodeId + ", assignedSegmentJobCount: "
													+ assignedSegmentJobCount + ", pendingSegmentIdRequestKeySetSize: "
													+ scSearchJobInfo.pendingSegmentIdRequestKeySetMap.size()
													+ ", isJobCompleted: " + scSearchJobInfo.isJobCompleted());
								} else if (Collections.disjoint(filteredSortedSegmentIdSet,
										scSearchJobInfo.pendingSegmentIdRequestKeySetMap.keySet())) {
									if (logger.isDebugEnabled())
										logger.debug(
												"In SearchJobAssignmentBySearchNodeTask: No more segments to be assigned from searchNodeId: "
														+ searchNodeId + ", assignedSegmentJobCount: "
														+ assignedSegmentJobCount
														+ ", pendingSegmentIdRequestKeySetSize: "
														+ scSearchJobInfo.pendingSegmentIdRequestKeySetMap.size()
														+ ", isJobCompleted: " + scSearchJobInfo.isJobCompleted());
								} else {
									scSearchJobInfo.incrementJobRescheduledCount();
									if (assignedSegmentJobCount > 0) {
										//PriorityLogger.trace("SearchJobAssignmentBySearchNodeTask", "assignJobToSN", jobEntry.getJobId(), jobEntry.getPriority(), LocalDateTime.now());
										jobEntry.setHighestPriority();										
									}

									if (noFreeSlotsFlag.get()) {
										// addJobEntryForAssignment(searchNodeId,
										// jobEntry, capacityGroupId);
										searchJobEntrySet.add(jobEntry);
									} else {
										pendingAssignmentJobEntryList.add(jobEntry);
									}
								}
							} catch (Throwable th) {
								logger.error(
										"Error while job assignment for searchNodeId: " + searchNodeId
												+ ", searchJobId: " + jobEntry.getJobId() + " : " + th.getMessage(),
										th);
								pendingAssignmentJobEntryList.add(jobEntry);
							} finally {
								PFLogger.end(200,
										"searchJobId: " + jobEntry.getJobId() + ", searchNodeId: " + searchNodeId
												+ ", assignedSegmentJobCount: " + assignedSegmentJobCount
												+ ", hasSvtMissFlag: " + hasSvtMissFlag.get() + ", noFreeSlotsFlag: "
												+ noFreeSlotsFlag.get());
								NDC.pop();

								if (assignedSegmentJobCount > 0 && scSearchJobInfo != null
										&& scSearchJobInfo.isJobCompleted()) {
									// This block is to handle if assignment is
									// done concurrently when job completion is
									// in progress
									logger.info("Detected search job completed for searchJobId: " + jobEntry.getJobId()
											+ ", will be releasing the assigned slots");
									scSearchJobInfo.releasePendingSegmentJobs(snPartitionedLoadMap);
								}
							}
						}

						if (noFreeSlotsFlag.get()) {
							if (!searchNodeLoadInfo.autoCorrectSearchNodeSegmentJobCounter(searchJobInfoMap)) {
								if (logger.isDebugEnabled())
									logger.debug("No free slots available for assignment for searchNodeId: "
											+ searchNodeId + ", capacityGroupId: " + searchNodeLoadInfo.capacityGroupId
											+ ", searchJobId: " + jobEntry.getJobId() + ", actualFreeSlots: "
											+ searchNodeLoadInfo.getActualFreeSlots() + " , calculatedFreeSlots: "
											+ searchNodeLoadInfo.getCalculatedFreeSlots() + ", snCurrentLoad: "
											+ searchNodeLoadInfo.getCurrentLoadFromReader() + ", scCurrentLoad: "
											+ searchNodeLoadInfo.getScCurrentLoadFromReader());
							}
						}

					} finally {
						if (preAcquiredSlots.get() > 0 && searchNodeLoadInfo != null) {
							searchNodeLoadInfo.releaseSlots(preAcquiredSlots.get());
							preAcquiredSlots.set(0);
						}

						if (pendingAssignmentJobEntryList.size() > 0) {
							// addJobEntryForAssignment(searchNodeId,
							// pendingAssignmentJobEntryList, capacityGroupId);

							searchJobEntrySet.addAll(pendingAssignmentJobEntryList);
							searchNodeJobAssignmentExecutor.notifyData(searchNodeIdCapacityGroupIdKey);

							pendingAssignmentJobEntryList.clear();
						}

						if (jobAssignmentProcessedCount > 0 && totalAssignedSegmentJobCount == 0) {
							if (logger.isDebugEnabled())
								logger.debug("Before sleeping for searchJobRescheduleDelayMilli: "
										+ searchJobRescheduleDelayMilli + " for searchNodeId: " + searchNodeId
										+ ", totalAssignedSegmentJobCount: " + totalAssignedSegmentJobCount
										+ ", jobAssignmentProcessedCount: " + jobAssignmentProcessedCount
										+ ", noFreeSlotsFlag: " + noFreeSlotsFlag.get());
							Uninterruptibles.sleepUninterruptibly(searchJobRescheduleDelayMilli, TimeUnit.MILLISECONDS);
						}
					}
				} catch (Throwable th) {
					logger.error("Error in SearchJobAssignmentBySearchNodeTask for searchNodeId: " + searchNodeId
							+ " : " + th.getMessage(), th);
				}
			}
		}
	}

	public final SnSegmentJobInfoList assignJobsToSearchNodeBySegmentId(ScSearchJobInfo scSearchJobInfo,
			SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo, Collection<Integer> assignedSegmentIdSet,
			Map<Integer, Long> liveSearchNodeSegmentDataVersionMap, String searchControllerId,
			AtomicBoolean hasSvtMissFlag, AtomicBoolean noFreeSlotsFlag, AtomicInteger preAcquiredSlots,
			boolean lockDuringSearchJobAssignmentFlag) {
		if (scSearchJobInfo.isJobCompleted()) {
			return null;
		}

		SnSegmentJobInfoList.Builder snSegmentJobInfoListBuilder = null;
		final long startTimeMilli = System.currentTimeMillis();
		AtomicInteger assignedJobCount = new AtomicInteger();
		boolean slotAcquiredFlag = false;
		boolean slotUsedFlag = false;
		Stopwatch acquireSlotStopWatch = Stopwatch.createUnstarted();
		final Lock assignmentInProgressLock = scSearchJobInfo.getAssignmentInProgressLock().readLock();
		int acquireSlotCountRequest = 0;
		int actualAcquiredSlotCount = 0;
		final AtomicBoolean isFairAssignmentRequiredFlag = new AtomicBoolean(false);
		try {
			int assignedSegmentIdSetSize = assignedSegmentIdSet.size();
			if (assignedSegmentIdSetSize == 0) {
				return null;
			}

			if (preAcquiredSlots.get() <= 0) {
				acquireSlotStopWatch.start();
				acquireSlotCountRequest = assignedSegmentIdSetSize;
				actualAcquiredSlotCount = searchNodeLoadInfo.tryAcquireSlotsForAssignment(acquireSlotCountRequest,
						isFairAssignmentRequiredFlag, acquireSlotConcurrencySemaphore);
				preAcquiredSlots.set(actualAcquiredSlotCount);
				acquireSlotStopWatch.stop();

				if (preAcquiredSlots.get() <= 0) {
					noFreeSlotsFlag.set(true);
					return null;
				}
			}

			int loopCounter = 0;
			for (Integer segmentId : assignedSegmentIdSet) {
				loopCounter++;

				ConcurrentSkipListSet<String> requestKeySet = scSearchJobInfo.pendingSegmentIdRequestKeySetMap
						.get(segmentId);
				if (requestKeySet == null) {
					scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
					continue;
				}

				if (liveSearchNodeSegmentDataVersionMap != null) {
					long taggedSegmentDataVersion = scSearchJobInfo.taggedSegmentVersionMap.getOrDefault(segmentId,
							-1L);
					long searchNodeSegVersion = liveSearchNodeSegmentDataVersionMap.getOrDefault(segmentId, -1L);
					if (taggedSegmentDataVersion > searchNodeSegVersion) {
						// Search node segment version is less than the central
						// server data version tagged to the job,
						// So dont allocate this segment job to this search node
						if (logger.isTraceEnabled()) {
							logger.trace("In assignJobsToSearchNode: SVT Check: Ignoring assignment for searchJobId: "
									+ scSearchJobInfo.searchJobId + " to searchNodeId: "
									+ searchNodeLoadInfo.searchNodeId + ", segmentId: " + segmentId
									+ ", taggedSegmentDataVersion: " + taggedSegmentDataVersion
									+ ", searchNodeSegVersion: " + searchNodeSegVersion);
						}

						if (requestKeySet.isEmpty()) {
							scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
						}
						hasSvtMissFlag.set(true);
						continue;
					}
				}

				if (!slotAcquiredFlag) {
					slotUsedFlag = false;
					if (preAcquiredSlots.get() <= 0) {
						acquireSlotStopWatch.start();
						acquireSlotCountRequest = Math.max(1, assignedSegmentIdSetSize - loopCounter + 1);
						actualAcquiredSlotCount = searchNodeLoadInfo.tryAcquireSlotsForAssignment(
								acquireSlotCountRequest, isFairAssignmentRequiredFlag, acquireSlotConcurrencySemaphore);
						preAcquiredSlots.addAndGet(actualAcquiredSlotCount);
						acquireSlotStopWatch.stop();
					}

					if (preAcquiredSlots.get() > 0) {
						preAcquiredSlots.decrementAndGet();
						slotAcquiredFlag = true;
					} else {
						noFreeSlotsFlag.set(true);
						if (logger.isDebugEnabled())
							logger.debug("In assignJobsToSearchNodeBySegmentId: No free slots available on "
									+ searchNodeLoadInfo.searchNodeId + " for assigning to searchJobId: "
									+ scSearchJobInfo.searchJobId + ", snCurrentLoad: "
									+ searchNodeLoadInfo.getCurrentLoadFromReader() + ", snScCurrentLoad: "
									+ searchNodeLoadInfo.getScCurrentLoadFromReader());
						break;
					}
				}

				if (lockDuringSearchJobAssignmentFlag) {
					assignmentInProgressLock.lock();
				}
				try {
					String requestKey = requestKeySet.pollFirst();
					if (requestKey == null) {
						scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
						continue;
					}

					String segmentJobId = scSearchJobInfo.searchJobId + "|" + UUID.randomUUID().toString() + "|"
							+ searchNodeLoadInfo.searchNodeId + "|" + requestKey;

					long currentTimeMillis = System.currentTimeMillis();

					scSearchJobInfo.inProgressSegmentJobIdSet.put(segmentJobId, currentTimeMillis);

					slotUsedFlag = true;
					slotAcquiredFlag = false;

					if (requestKeySet.isEmpty()) {
						scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
					}

					scSearchJobInfo.lastAssignmentDateTimeMilli = currentTimeMillis;
					if (scSearchJobInfo.fisrtAssignmentDateTimeMilli == -1) {
						scSearchJobInfo.fisrtAssignmentDateTimeMilli = currentTimeMillis;
					}

					SnSegmentJobInfo.Builder snSegmentJobInfoDto = SnSegmentJobInfo.newBuilder();
					snSegmentJobInfoDto.setSegmentJobId(segmentJobId);
					snSegmentJobInfoDto.setRequestKey(requestKey);
					snSegmentJobInfoDto.addSegmentId(segmentId);

					assignedJobCount.incrementAndGet();

					if (snSegmentJobInfoListBuilder == null) {
						snSegmentJobInfoListBuilder = SnSegmentJobInfoList.newBuilder();
						snSegmentJobInfoListBuilder.setSearchJobId(scSearchJobInfo.searchJobId);
						snSegmentJobInfoListBuilder.setSearchNodeId(searchNodeLoadInfo.searchNodeId);
						snSegmentJobInfoListBuilder.setAssignmentServerId(searchControllerId);
						snSegmentJobInfoListBuilder.setSearchControllerId(searchControllerId);
						snSegmentJobInfoListBuilder.setJobTimeoutMilli(scSearchJobInfo.jobTimeoutMilli);
						snSegmentJobInfoListBuilder.setJobCreateTimestampMilli(scSearchJobInfo.createDateTimeMilli);
						snSegmentJobInfoListBuilder.setAssignmentDelayMilli(
								scSearchJobInfo.lastAssignmentDateTimeMilli - scSearchJobInfo.createDateTimeMilli);
					}

					snSegmentJobInfoListBuilder.addSnSegmentJobInfo(snSegmentJobInfoDto.build());
				} finally {
					if (lockDuringSearchJobAssignmentFlag) {
						assignmentInProgressLock.unlock();
					}
				}
			}
		} finally {
			if (slotAcquiredFlag && !slotUsedFlag) {
				preAcquiredSlots.incrementAndGet();
			}

			if (preAcquiredSlots.get() > 0 && isFairAssignmentRequiredFlag.get()) {
				// Not enough permits, so better to release the extra slots
				// immediately, so other cluster member can assign to pending
				// jobs
				searchNodeLoadInfo.releaseSlots(preAcquiredSlots.get());
				preAcquiredSlots.set(0);
			}

			long timeTakenMilli = System.currentTimeMillis() - startTimeMilli;
			if (logger.isTraceEnabled() || timeTakenMilli > 50) {
				CommonLogger.PERF_LOG.info("In assignJobsToSearchNodeBySegmentId: TimeTakenMilli: " + timeTakenMilli
						+ ", slotAcquireTimeTaken: " + acquireSlotStopWatch.elapsed(TimeUnit.MILLISECONDS)
						+ ", searchJobId: " + scSearchJobInfo.searchJobId + ", searchNodeId: "
						+ searchNodeLoadInfo.searchNodeId + ", assignedJobCount: " + assignedJobCount
						+ ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader() + ", snScCurrentLoad: "
						+ searchNodeLoadInfo.getScCurrentLoadFromReader() + ", noFreeSlotsFlag: "
						+ noFreeSlotsFlag.get() + ", hasSvtMissFlag: " + hasSvtMissFlag.get() + ", preAcquiredSlots: "
						+ preAcquiredSlots.get() + ", pendingSegmentIdRequestKeySetMapSize: "
						+ scSearchJobInfo.pendingSegmentIdRequestKeySetMap.size());
			}
		}

		if (snSegmentJobInfoListBuilder != null) {
			scSearchJobInfo.lastAssignmentDateTimeMilli = System.currentTimeMillis();
			scSearchJobInfo.totalAssignedSegmentJobCount.addAndGet(assignedJobCount.get());
			snSegmentJobInfoListBuilder.setAssignmentDelayMilli(
					scSearchJobInfo.lastAssignmentDateTimeMilli - scSearchJobInfo.createDateTimeMilli);
			return snSegmentJobInfoListBuilder.build();
		}

		return null;
	}

	public final SnSegmentJobInfoList assignJobsToSearchNodeByBatch(ScSearchJobInfo scSearchJobInfo,
			SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo, Collection<Integer> assignedSegmentIdSet,
			Map<Integer, Long> liveSearchNodeSegmentDataVersionMap, String searchControllerId,
			AtomicBoolean hasSvtMissFlag, AtomicBoolean noFreeSlotsFlag, AtomicInteger preAcquiredSlots,
			int maxMultiSegmentsPerSearchJob, boolean lockDuringSearchJobAssignmentFlag) {
		if (!scSearchJobInfo.hasPendingSegmentIdsForAssignment() || searchNodeLoadInfo.getCalculatedFreeSlots() <= 0) {
			return null;
		}

		Stopwatch acquireSlotStopWatch = Stopwatch.createUnstarted();
		final long startTimeMilli = System.currentTimeMillis();
		int acquiredSlotCount = 0;
		int assignedJobCount = 0;
		int batchedJobCount = 0;
		int acquireSlotCountRequest = 0;
		int actualAcquiredSlotCount = 0;
		final AtomicBoolean isFairAssignmentRequiredFlag = new AtomicBoolean(false);
		try {
			int assignedSegmentIdSetSize = assignedSegmentIdSet.size();
			if (assignedSegmentIdSetSize == 0) {
				return null;
			}

			if (preAcquiredSlots.get() <= 0) {
				acquireSlotStopWatch.start();
				acquireSlotCountRequest = Math.max(1, assignedSegmentIdSetSize / maxMultiSegmentsPerSearchJob);
				actualAcquiredSlotCount = searchNodeLoadInfo.tryAcquireSlotsForAssignment(acquireSlotCountRequest,
						isFairAssignmentRequiredFlag, acquireSlotConcurrencySemaphore);
				preAcquiredSlots.set(actualAcquiredSlotCount);
				acquireSlotStopWatch.stop();

				if (preAcquiredSlots.get() <= 0) {
					noFreeSlotsFlag.set(true);
					return null;
				}
			}

			final Lock assignmentInProgressLock = scSearchJobInfo.getAssignmentInProgressLock().readLock();

			ArrayListMultimap<String, SnSegmentJobInfo.Builder> requestKeySnSegmentJobInfoDtoMap = null;
			while (!noFreeSlotsFlag.get() && !scSearchJobInfo.jobCompletedFlag && !Collections
					.disjoint(assignedSegmentIdSet, scSearchJobInfo.pendingSegmentIdRequestKeySetMap.keySet())) {
				boolean slotAcquiredFlag = false;
				boolean slotUsedFlag = false;
				String requestKey = null;

				try {
					int loopCounter = 0;
					for (Integer segmentId : assignedSegmentIdSet) {
						loopCounter++;

						ConcurrentSkipListSet<String> requestKeySet = scSearchJobInfo.pendingSegmentIdRequestKeySetMap
								.get(segmentId);
						if (requestKeySet == null) {
							scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
							continue;
						}

						if (liveSearchNodeSegmentDataVersionMap != null) {
							long taggedSegmentDataVersion = scSearchJobInfo.taggedSegmentVersionMap
									.getOrDefault(segmentId, -1L);
							long searchNodeSegVersion = liveSearchNodeSegmentDataVersionMap.getOrDefault(segmentId,
									-1L);
							if (taggedSegmentDataVersion > searchNodeSegVersion) {
								// Search node segment version is less than the
								// central server data version tagged to the
								// job,
								// So dont allocate this segment job to this
								// search node
								if (logger.isTraceEnabled()) {
									logger.trace(
											"In assignJobsToSearchNode: SVT Check: Ignoring assignment for searchJobId: "
													+ scSearchJobInfo.searchJobId + " to searchNodeId: "
													+ searchNodeLoadInfo.searchNodeId + ", segmentId: " + segmentId
													+ ", taggedSegmentDataVersion: " + taggedSegmentDataVersion
													+ ", searchNodeSegVersion: " + searchNodeSegVersion);
								}

								if (requestKeySet.isEmpty()) {
									scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
								}
								hasSvtMissFlag.set(true);
								continue;
							}
						}

						if (!slotAcquiredFlag) {
							slotUsedFlag = false;
							if (preAcquiredSlots.get() <= 0) {
								acquireSlotStopWatch.start();
								acquireSlotCountRequest = Math.max(1,
										(assignedSegmentIdSetSize - loopCounter + 1) / maxMultiSegmentsPerSearchJob);
								actualAcquiredSlotCount = searchNodeLoadInfo.tryAcquireSlotsForAssignment(
										acquireSlotCountRequest, isFairAssignmentRequiredFlag,
										acquireSlotConcurrencySemaphore);
								preAcquiredSlots.addAndGet(actualAcquiredSlotCount);
								acquireSlotStopWatch.stop();
							}

							if (preAcquiredSlots.get() > 0) {
								preAcquiredSlots.decrementAndGet();
								slotAcquiredFlag = true;
							} else {
								noFreeSlotsFlag.set(true);
								if (logger.isDebugEnabled())
									logger.debug("In assignJobsToSearchNodeByBatch: No free slots available on "
											+ searchNodeLoadInfo.searchNodeId + " for assigning to searchJobId: "
											+ scSearchJobInfo.searchJobId + ", snCurrentLoad: "
											+ searchNodeLoadInfo.getCurrentLoadFromReader() + ", snScCurrentLoad: "
											+ searchNodeLoadInfo.getScCurrentLoadFromReader());
								break;
							}
						}

						if (lockDuringSearchJobAssignmentFlag) {
							assignmentInProgressLock.lock();
						}
						try {
							if (requestKey == null) {
								requestKey = requestKeySet.pollFirst();
								if (requestKey == null) {
									scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
									continue;
								}
							} else {
								if (!requestKeySet.remove(requestKey)) {
									continue;
								}
							}

							if (requestKeySet.isEmpty()) {
								scSearchJobInfo.pendingSegmentIdRequestKeySetMap.remove(segmentId);
							}

							if (requestKeySnSegmentJobInfoDtoMap == null) {
								requestKeySnSegmentJobInfoDtoMap = ArrayListMultimap.create();
							}

							SnSegmentJobInfo.Builder snSegmentJobInfoDto = null;
							if (slotUsedFlag && requestKeySnSegmentJobInfoDtoMap.containsKey(requestKey)) {
								List<SnSegmentJobInfo.Builder> snSegmentJobInfoBuilderList = requestKeySnSegmentJobInfoDtoMap
										.get(requestKey);

								snSegmentJobInfoDto = (SnSegmentJobInfo.Builder) snSegmentJobInfoBuilderList
										.get(snSegmentJobInfoBuilderList.size() - 1);
							}

							if (snSegmentJobInfoDto == null) {
								String segmentJobId = scSearchJobInfo.searchJobId + "|" + UUID.randomUUID().toString()
										+ "|" + searchNodeLoadInfo.searchNodeId + "|" + requestKey;

								long currentTimeMillis = System.currentTimeMillis();

								scSearchJobInfo.inProgressSegmentJobIdSet.put(segmentJobId, currentTimeMillis);

								scSearchJobInfo.lastAssignmentDateTimeMilli = currentTimeMillis;
								if (scSearchJobInfo.fisrtAssignmentDateTimeMilli == -1) {
									scSearchJobInfo.fisrtAssignmentDateTimeMilli = currentTimeMillis;
								}

								snSegmentJobInfoDto = SnSegmentJobInfo.newBuilder();
								snSegmentJobInfoDto.setSegmentJobId(segmentJobId);
								snSegmentJobInfoDto.setRequestKey(requestKey);
								snSegmentJobInfoDto.addSegmentId(segmentId);

								slotUsedFlag = true;

								assignedJobCount++;

								acquiredSlotCount++;

								scSearchJobInfo.totalAssignedSegmentJobCount.incrementAndGet();

								requestKeySnSegmentJobInfoDtoMap.put(requestKey, snSegmentJobInfoDto);
							} else {
								scSearchJobInfo.lastAssignmentDateTimeMilli = System.currentTimeMillis();

								snSegmentJobInfoDto.addSegmentId(segmentId);

								scSearchJobInfo.totalBatchedSegmentJobCount.incrementAndGet();

								batchedJobCount++;

								if (snSegmentJobInfoDto.getSegmentIdCount() >= maxMultiSegmentsPerSearchJob) {
									slotAcquiredFlag = false;
									slotUsedFlag = false;
								}
							}
						} finally {
							if (lockDuringSearchJobAssignmentFlag) {
								assignmentInProgressLock.unlock();
							}
						}
					}
				} finally {
					if (slotAcquiredFlag && !slotUsedFlag) {
						preAcquiredSlots.incrementAndGet();
					}
				}

				if (requestKey == null) {
					break;
				}
			}

			if (requestKeySnSegmentJobInfoDtoMap != null && requestKeySnSegmentJobInfoDtoMap.size() > 0) {
				scSearchJobInfo.lastAssignmentDateTimeMilli = System.currentTimeMillis();

				SnSegmentJobInfoList.Builder snSegmentJobInfoListBuilder = SnSegmentJobInfoList.newBuilder();
				snSegmentJobInfoListBuilder.setSearchJobId(scSearchJobInfo.searchJobId);
				snSegmentJobInfoListBuilder.setSearchNodeId(searchNodeLoadInfo.searchNodeId);
				snSegmentJobInfoListBuilder.setAssignmentServerId(searchControllerId);
				snSegmentJobInfoListBuilder.setSearchControllerId(searchControllerId);
				snSegmentJobInfoListBuilder.setJobTimeoutMilli(scSearchJobInfo.jobTimeoutMilli);
				snSegmentJobInfoListBuilder.setJobCreateTimestampMilli(scSearchJobInfo.createDateTimeMilli);
				snSegmentJobInfoListBuilder.setAssignmentDelayMilli(
						scSearchJobInfo.lastAssignmentDateTimeMilli - scSearchJobInfo.createDateTimeMilli);
				requestKeySnSegmentJobInfoDtoMap.values().forEach(snSegmentJobInfoBuilder -> snSegmentJobInfoListBuilder
						.addSnSegmentJobInfo(snSegmentJobInfoBuilder.build()));

				return snSegmentJobInfoListBuilder.build();
			}

			return null;
		} finally {
			if (preAcquiredSlots.get() > 0 && isFairAssignmentRequiredFlag.get()) { // acquireSlotCountRequest>actualAcquiredSlotCount)
																					// {
				// Not enough permits, so better to release the extra slots
				// immediately, so other cluster members can use them for
				// assignment
				searchNodeLoadInfo.releaseSlots(preAcquiredSlots.get());
				preAcquiredSlots.set(0);
			}

			long timeTakenMilli = System.currentTimeMillis() - startTimeMilli;
			if (timeTakenMilli > 50 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In assignJobsToSearchNodeByBatch: TimeTakenMilli: " + timeTakenMilli
						+ ", searchJobId: " + scSearchJobInfo.searchJobId + ", searchNodeId: "
						+ searchNodeLoadInfo.searchNodeId + ", acquiredSlotCount: " + acquiredSlotCount
						+ ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader() + ", snScCurrentLoad: "
						+ searchNodeLoadInfo.getScCurrentLoadFromReader() + ", assignedJobCount: " + assignedJobCount
						+ ", batchedJobCount: " + batchedJobCount + ", maxMultiSegmentsPerSearchJob: "
						+ maxMultiSegmentsPerSearchJob + ", noFreeSlotsFlag: " + noFreeSlotsFlag.get()
						+ ", hasSvtMissFlag: " + hasSvtMissFlag.get() + ", preAcquiredSlots: " + preAcquiredSlots.get()
						+ ", pendingSegmentIdRequestKeySetMapSize: "
						+ scSearchJobInfo.pendingSegmentIdRequestKeySetMap.size());
			}
		}
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatchManagerService(BioMatchManagerService bioMatchManagerService) {
		this.bioMatchManagerService = bioMatchManagerService;
	}

	public void setSearchJobAssignmentUtil(SearchJobAssignmentUtil searchJobAssignmentUtil) {
		this.searchJobAssignmentUtil = searchJobAssignmentUtil;
	}

	@Override
	public synchronized void afterPropertiesSet() throws Exception {
		logger.info("In SearchJobAssignmentBySearchNodeUtil: afterPropertiesSet : initializationCount: "
				+ initializationCount.get());

		if (initializationCount.get() > 0) {
			logger.warn(
					"In SearchJobAssignmentBySearchNodeUtil: afterPropertiesSet : Already initialized: initializationCount: "
							+ initializationCount.get());
			return;
		}

		bioParameterService.deleteParameter("LOCK_DURING_SEARCH_JOB_ASSIGNMEN_FLAG", "DEFAULT");
		bioParameterService.deleteParameter("BULK_ACQUIRE_SEARCH_JOB_SLOTS_FLAG", "DEFAULT");

		bioParameterService.compareAndSetParameterValue("SEARCH_JOB_RESCHEDULE_DELAY_MILLI", "DEFAULT", "100", "5");

		searchNodeOnlineCheckFunction = (searchNodeId) -> bioSearchControllerManager
				.getSearchNodeOnlineFlag(searchNodeId);

		searchControllerId = bioSearchControllerManager.getSearchControllerId();

		searchJobInfoMap = bioSearchControllerManager.getSearchJobInfoMap();

		scSearchNodePartitionedLoadMap = bioSearchControllerManager.getScSearchNodePartitionedLoadMap();

		searchNodeIdSearchNodeCapacityMap = new ConcurrentValuedHashMap<>(
				searchNodeId -> new ConcurrentValuedHashMap<String, SearchNodeCapacityGroupLoadInfo>(
						capacityGroupId -> scSearchNodePartitionedLoadMap
								.getValue(new TriKey<>(searchControllerId, searchNodeId, capacityGroupId))));

		snPartitionedLoadMap = new ConcurrentValuedHashMap<>(key -> scSearchNodePartitionedLoadMap
				.getValue(new TriKey<>(searchControllerId, key.getA(), key.getB())));

		Supplier<Integer> acquireSlotConcurrencySupplier = BioParameterService
				.getIntSupplier("SEARCH_NODE_JOB_ASSIGNMENT_ACQUIRE_SLOT_CONCURRENCY_COUNT", "DEFAULT", -1);
		if (acquireSlotConcurrencySupplier.get() > 0) {
			acquireSlotConcurrencySemaphore = DynamicSemaphore
					.getInstance("SEARCH_JOB_ASSIGNMENT_ACQUIRE_SLOT_CONCURRENCY", acquireSlotConcurrencySupplier);
		}

		if (searchControllerId != null) {
			Supplier<Integer> searchNodeJobAssignmentConcurrencySupplier = BioParameterService
					.getIntSupplier("SEARCH_NODE_JOB_ASSIGNMENT_CONCURRENCY_COUNT", "DEFAULT", 1);

			searchNodeJobAssignmentExecutor = new ConcurrentKeyedExecutor<>("SEARCH_NODE_JOB_ASSIGNMENT",
					() -> getAssignedSearchNodeIdCapacityGroupIdKeyList(), new SearchJobAssignmentBySearchNodeTask(),
					searchNodeJobAssignmentConcurrencySupplier);
		}

		initializationCount.incrementAndGet();
	}
}
