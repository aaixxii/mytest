package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class StrictSyncCallbackKey implements Serializable {

	private static final long serialVersionUID = -3360367637379431669L;
	private String syncJobId;
	private String externalId;
	private String eventId;
	private String callbackUrl;

	public StrictSyncCallbackKey(String syncJobId, String externalId, String eventId, String callbackUrl) {
		this.syncJobId = syncJobId;
		this.externalId = externalId;
		this.eventId = eventId;
		this.callbackUrl = callbackUrl;
	}

	public StrictSyncCallbackKey() {

	}

	public String getSyncJobId() {
		return syncJobId;
	}

	public void setSyncJobId(String syncJobId) {
		this.syncJobId = syncJobId;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public StrictSyncCallbackKey getKeys(String exteranlId, String eventId) {
		if (exteranlId.equals(this.getExternalId()) && eventId.equals(this.getEventId())) {
			return new StrictSyncCallbackKey(syncJobId, externalId, eventId, callbackUrl);
		} else {
			return null;
		}
	}

	public String[] getKeysByJobId(String jobId) {
		if (this.getSyncJobId().equals(jobId)) {
			return new String[] { syncJobId, externalId, eventId, callbackUrl };
		} else {
			return null;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (!(obj instanceof StrictSyncCallbackKey)) {
			return false;
		} else {
			StrictSyncCallbackKey other = (StrictSyncCallbackKey) obj;
			return new EqualsBuilder().append(getSyncJobId(), other.getSyncJobId())
					.append(getExternalId(), other.getExternalId()).append(getEventId(), other.getEventId())
					.append(getCallbackUrl(), other.getCallbackUrl()).isEquals();
		}
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(getSyncJobId()).append(getExternalId()).append(getEventId())
				.append(getCallbackUrl()).toHashCode();
	}
}
