package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.util.List;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.util.ClearRemoteCacheUtil;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.service.BioSearchControllerService;
import com.nec.biomatcher.identifier.searchcontroller.util.SearchBrokerServiceClient;

/**
 * The Class SearchBrokerFailoverTask.
 */
public class SearchBrokerFailoverTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchBrokerFailoverTask.class);

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	/** The bio search controller service. */
	private BioSearchControllerService bioSearchControllerService;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	private BioMatchManagerService bioMatchManagerService;

	/** The search broker failover queue. */
	private DelayQueue<DelayedItem<String>> searchBrokerFailoverQueue = null;

	/** The is initialized. */
	private boolean isInitialized = false;

	/**
	 * Instantiates a new search broker failover task.
	 */
	public SearchBrokerFailoverTask() {
	}

	@Override
	public void run() {
		Thread.currentThread().setName("SEARCH_BROKER_FAILOVER_TASK");
		logger.info("In SearchBrokerFailoverTask.run");

		while (!ShutdownHook.isShutdownFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				String searchBrokerId = null;
				{
					DelayedItem<String> delayedItem = searchBrokerFailoverQueue.poll(30, TimeUnit.SECONDS);
					if (delayedItem == null) {
						continue;
					}
					searchBrokerId = delayedItem.getItem();
				}

				logger.info("In SearchBrokerFailoverTask: searchBrokerId: " + searchBrokerId);

				bioSearchControllerManager.acquireSearchBrokerFailoverLock();
				try {
					BioServerInfo searchBrokerInfo = bioMatchManagerService.getServerInfo(searchBrokerId);
					if (searchBrokerInfo == null) {
						CommonLogger.STATUS_LOG
								.warn("In SearchBrokerFailoverTask: cannot find searchBroker with searchBrokerId: "
										+ searchBrokerId);
						continue;
					}

					if (!BioServerState.ACTIVE.equals(searchBrokerInfo.getServerState())) {
						CommonLogger.STATUS_LOG
								.warn("In SearchBrokerFailoverTask: searchBroker is not active for searchBrokerId: "
										+ searchBrokerId + ", status: " + searchBrokerInfo.getServerState());
						continue;
					}

					try {
						SearchBrokerServiceClient.echo(searchBrokerId, "Check search broker online");
						CommonLogger.STATUS_LOG
								.info("In SearchBrokerFailoverTask: searchBroker echo is successfull for searchBrokerId: "
										+ searchBrokerId + ", so no need to failover");
						continue;
					} catch (Throwable th) {
					}

					List<BioServerInfo> standbySearchBrokerList = bioMatchManagerService
							.getServerInfoListByComponentType(BioComponentType.SB, BioServerState.STANDBY);
					if (standbySearchBrokerList.size() == 0) {
						CommonLogger.STATUS_LOG.warn(
								"In SearchBrokerFailoverTask: searchBrokers not available in stanby state, will check after 1 minute");
						searchBrokerFailoverQueue
								.put(new DelayedItem<String>(searchBrokerId, TimeUnit.MINUTES.toMillis(1)));
						continue;
					}

					// Find the searchbroker which is online
					boolean failoverSuccessFlag = false;
					for (BioServerInfo standbySearchBroker : standbySearchBrokerList) {
						try {
							try {
								SearchBrokerServiceClient.echo(standbySearchBroker.getServerId(),
										"Check search broker online");
								CommonLogger.STATUS_LOG
										.info("In SearchBrokerFailoverTask: searchBroker echo is successfull for standbySearchBroker: "
												+ standbySearchBroker.getServerId());
							} catch (Throwable th) {
								CommonLogger.STATUS_LOG.error("Error during failover from searchBrokerId: "
										+ searchBrokerId + " to standbySearchBrokerId: "
										+ standbySearchBroker.getServerId() + " : " + th.getMessage(), th);
								continue;
							}

							standbySearchBroker.setServerState(BioServerState.ACTIVE);
							standbySearchBroker.setServerGroupId(searchBrokerInfo.getServerGroupId());
							standbySearchBroker.setSubSystemGroupId(searchBrokerInfo.getSubSystemGroupId());

							// Update current searchbroker to disabled
							searchBrokerInfo.setServerState(BioServerState.DISABLED);
							searchBrokerInfo.setServerGroupId(null);
							searchBrokerInfo.setSubSystemGroupId(null);

							bioMatcherConfigService.updateServerInfo(searchBrokerInfo);

							bioMatcherConfigService.updateServerInfo(standbySearchBroker);

							boolean disabledFlag = false;
							try {
								SearchBrokerServiceClient.notifySearchBrokerDisabled(searchBrokerId);
								disabledFlag = true;
							} catch (Throwable th) {
								logger.debug("Error during notifySearchBrokerDisabled for searchBrokerId: "
										+ searchBrokerId + " : " + th.getMessage(), th);
							}

							try {
								SearchBrokerServiceClient.notifySearchBrokerEnabled(standbySearchBroker.getServerId());

								failoverSuccessFlag = true;

								logger.info("In SearchBrokerFailoverTask: failover successfull from searchBrokerId: "
										+ searchBrokerId + " to standbySearchBrokerId: "
										+ standbySearchBroker.getServerId());
							} catch (Throwable th) {
								logger.error("Error during notifySearchBrokerEnabled for standbySearchBrokerId: "
										+ standbySearchBroker.getServerId() + " : " + th.getMessage(), th);

								// Revert the changes
								searchBrokerInfo.setServerState(BioServerState.ACTIVE);
								searchBrokerInfo.setServerGroupId(standbySearchBroker.getServerGroupId());
								searchBrokerInfo.setSubSystemGroupId(standbySearchBroker.getSubSystemGroupId());

								searchBrokerInfo.setServerState(BioServerState.STANDBY);
								standbySearchBroker.setServerGroupId(null);
								standbySearchBroker.setSubSystemGroupId(null);

								bioMatcherConfigService.updateServerInfo(searchBrokerInfo);
								bioMatcherConfigService.updateServerInfo(standbySearchBroker);

								if (disabledFlag) {
									try {
										SearchBrokerServiceClient.notifySearchBrokerEnabled(searchBrokerId);
									} catch (Throwable th1) {
										logger.debug(
												"Error during notifySearchBrokerEnabled while reverting for searchBrokerId: "
														+ searchBrokerId + " : " + th.getMessage(),
												th);
									}
								}
							}

							ClearRemoteCacheUtil.clearRemoteCache();

							if (failoverSuccessFlag) {
								break;
							}

						} catch (Throwable th) {
							logger.error("Error during failover from searchBrokerId: " + searchBrokerId
									+ " to standbySearchBrokerId: " + standbySearchBroker.getServerId() + " : "
									+ th.getMessage(), th);
							ClearRemoteCacheUtil.clearRemoteCache();
						}
					}

					if (!failoverSuccessFlag) {
						searchBrokerFailoverQueue.add(new DelayedItem<String>(searchBrokerId, 1000));
					}
				} catch (Throwable th) {
					logger.error("Error in SearchBrokerFailoverTask while processing searchBrokerId: " + searchBrokerId
							+ " : " + th.getMessage(), th);
					searchBrokerFailoverQueue.add(new DelayedItem<String>(searchBrokerId, 1000));
				} finally {
					bioSearchControllerManager.releaseSearchBrokerFailoverLock();
				}
			} catch (Throwable th) {
				logger.error("Error in SearchBrokerFailoverTask: " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			}
		}

		logger.warn("Exiting SearchBrokerFailoverTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
		bioSearchControllerService = SpringServiceManager.getBean("bioSearchControllerService");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");

		searchBrokerFailoverQueue = bioSearchControllerManager.getSearchBrokerFailoverQueue();

		isInitialized = true;
	}
}
