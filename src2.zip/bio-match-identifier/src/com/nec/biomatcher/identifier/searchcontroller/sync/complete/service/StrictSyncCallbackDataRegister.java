package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import static com.nec.biomatcher.identifier.util.SearchConstants.ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * 
 * @author 000001A006PBP<br/>
 *         StrictSyncCallbackDataRegister insert data about strict callback to
 *         memory using sync requests data
 */
public class StrictSyncCallbackDataRegister implements Runnable {
	private String syncJobId;
	private String callbackUrl;
	private List<BiometricEventInfo> modifiedBiometricEventInfoList;
	private StrictSegmentSyncCallbackService strictCallbackService;

	private static final Logger logger = Logger.getLogger(StrictSyncCallbackDataRegister.class);

	public StrictSyncCallbackDataRegister(String syncJobId, String url,
			List<BiometricEventInfo> modifiedBiometricEventInfoList) {
		this.syncJobId = syncJobId;
		this.callbackUrl = url;
		this.modifiedBiometricEventInfoList = modifiedBiometricEventInfoList;
		init();
	}

	private void init() {
		strictCallbackService = SpringServiceManager.getBean("strictSegmentSyncCallbackService");
	}

	@Override
	public void run() {
		registerStrictSyncCallbackData();
	}

	/**
	 * 
	 * @param syncJobId
	 * @param callbackurl
	 * @param modifiedBiometricEventInfoList
	 */
	public void registerStrictSyncCallbackData() {
		logger.info("Registering strcit sync data to StrictSegmentSyncCallbackService, syncJobId=" + syncJobId);
		// strictCallbackService.checkNewSegAssing();
		try {
			ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = StrictSegmentSyncCallbackService
					.getPreSnSegVerMap();
			ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = StrictSegmentSyncCallbackService
					.getStrictSyncCallbackMap();

			ConcurrentHashMap<String, List<StrictSyncCallbackKey>> jobIdKeyMap = StrictSegmentSyncCallbackService
					.getJobIdKeyMap();			
			
			if (preSnSegVerMap.size() == 0 || modifiedBiometricEventInfoList.size() == 0) {
				logger.warn("No data to process in StrictSyncCallbackDataRegister, return.");
				return;
			}			
			List<StrictSyncCallbackKey> strictkeyList = new ArrayList<>();
			modifiedBiometricEventInfoList.parallelStream().forEach(biometricEventInfo -> {
				StrictSyncCallbackKey key = new StrictSyncCallbackKey(syncJobId, biometricEventInfo.getExternalId(),
						biometricEventInfo.getEventId(), callbackUrl);
				strictkeyList.add(key);
				preSnSegVerMap.entrySet().parallelStream().forEach(e -> {
					if (e.getKey().getSegmentId().intValue() == biometricEventInfo.getAssignedSegmentId().intValue()
							&& e.getKey().getBinId().intValue() == biometricEventInfo.getBinId().intValue()) {
						strictSyncCallbackMap.put(key, e.getValue());
					}
				});
			});
			jobIdKeyMap.put(syncJobId, strictkeyList);		
		} catch (Exception e) {
			String errMsg = "An error occurred in registerStrictSyncCallbackData()";
			logger.warn(errMsg + ", send faild results");
			StrictSegmentSyncCallbackServiceException ex = new StrictSegmentSyncCallbackServiceException(e);
			ex.setJobId(syncJobId);
			ex.setErrmsg(errMsg);
			ex.setErrCode(ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS);
			strictCallbackService.faildStrictSyncCallback(ex);
		}
	}
}
