package com.nec.biomatcher.identifier.searchcontroller.util.metrics;

import static com.codahale.metrics.MetricRegistry.name;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricSet;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.queueing.SearchJobQueueHelper;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;

public class SearchControllerGuageSet implements MetricSet {
	private final String searchControllerId;
	private final BioSearchControllerManager bioSearchControllerManager;
	private final SearchJobQueueHelper searchJobQueueHelper;
	private final BioMatcherConfigService bioMatcherConfigService;

	public SearchControllerGuageSet(BioSearchControllerManager bioSearchControllerManager,
			SearchJobQueueHelper searchJobQueueHelper, BioMatcherConfigService bioMatcherConfigService) {
		this.bioSearchControllerManager = bioSearchControllerManager;
		this.searchJobQueueHelper = searchJobQueueHelper;
		this.bioMatcherConfigService = bioMatcherConfigService;
		this.searchControllerId = searchJobQueueHelper.getSearchControllerId();
	}

	@Override
	public Map<String, Metric> getMetrics() {
		final Map<String, Metric> gauges = new HashMap<String, Metric>();

		gauges.put("totalSearchJobsReceived", new Gauge<Long>() {
			@Override
			public Long getValue() {
				return searchJobQueueHelper.getSearchJobCounter().get();
			}
		});

		gauges.put("activeSearchJobs", new Gauge<Integer>() {
			@Override
			public Integer getValue() {
				return searchJobQueueHelper.getSearchJobInfoMap().size();
			}
		});

		gauges.put("pendingSearchJobAssignment", new Gauge<Integer>() {
			@Override
			public Integer getValue() {
				return searchJobQueueHelper.getPendingSearchJobQueueMap().size();
			}
		});

		gauges.put("totalSyncJobsReceived", new Gauge<Long>() {
			@Override
			public Long getValue() {
				return searchJobQueueHelper.getSyncJobCounter().get();
			}
		});

		gauges.put("activeSyncJobs", new Gauge<Integer>() {
			@Override
			public Integer getValue() {
				return searchJobQueueHelper.getSyncJobInfoMap().size();
			}
		});

		gauges.put("pendingJobCallbacks", new Gauge<Long>() {
			@Override
			public Long getValue() {
				return InMemoryManager.getPendingTaskCallbackQueueCount();
			}
		});

		final ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> scSearchNodePartitionedLoadMap = bioSearchControllerManager
				.getScSearchNodePartitionedLoadMap();
		Set<String> searchNodeIdList = null;
		try {
			searchNodeIdList = bioMatcherConfigService.getAssignedSearchNodeIdList();
		} catch (Throwable th) {
			searchNodeIdList = Collections.emptySet();
		}

		searchNodeIdList.stream().forEach(searchNodeId -> {
			MetricSet snDetailsMetricSet = new MetricSet() {
				public Map<String, Metric> getMetrics() {
					final Map<String, Metric> snGauges = new HashMap<String, Metric>();

					snGauges.put("snStatus", new Gauge<Boolean>() {
						public Boolean getValue() {
							return bioSearchControllerManager.getSearchNodeOnlineFlag(searchNodeId);
						}
					});
					Map<String, Integer> capacityGroupMap = null;
					try {
						capacityGroupMap = bioMatcherConfigService.getServerCapacityGroupMap(searchNodeId);
					} catch (Throwable th) {
						capacityGroupMap = Collections.emptyMap();
					}

					for (String capacityGroupKey : capacityGroupMap.keySet()) {
						SearchNodeCapacityGroupLoadInfo searchNodeCapacityGroupLoadInfo = scSearchNodePartitionedLoadMap
								.getValue(new TriKey<String, String, String>(searchControllerId, searchNodeId,
										capacityGroupKey));

						MetricSet cpDetailsMetricSet = new MetricSet() {
							@Override
							public Map<String, Metric> getMetrics() {
								final Map<String, Metric> cpGauges = new HashMap<String, Metric>();

								cpGauges.put("scSnMaxCapacity", new Gauge<Integer>() {
									public Integer getValue() {
										return searchNodeCapacityGroupLoadInfo.getScCurrentLoad();
									}
								});

								cpGauges.put("snCurrentLoad", new Gauge<Integer>() {
									public Integer getValue() {
										return searchNodeCapacityGroupLoadInfo.getCurrentLoadFromReader();
									}
								});

								cpGauges.put("snMaxCapacity", new Gauge<Integer>() {
									public Integer getValue() {
										return searchNodeCapacityGroupLoadInfo.getSearchNodeCapacity();
									}
								});

								return cpGauges;
							}
						};

						snGauges.put(name("searchCapacityDetails", capacityGroupKey), cpDetailsMetricSet);
					}

					return snGauges;
				}
			};

			gauges.put(name("snDetails", searchNodeId), snDetailsMetricSet);
		});

		return Collections.unmodifiableMap(gauges);
	}

}
