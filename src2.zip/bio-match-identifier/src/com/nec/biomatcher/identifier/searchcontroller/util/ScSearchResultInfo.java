package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.util.CommonProtobufUtil;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ExceptionMessageFormatter;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.ValuedHashMap;
import com.nec.biomatcher.identifier.util.SearchConstants;
import com.nec.biomatcher.spec.transfer.job.search.SearchFusedScoreDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchHitCandidate;
import com.nec.biomatcher.spec.transfer.job.search.SearchHitEvent;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchRawScoreDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchRegionScore;
import com.nec.biomatcher.spec.transfer.job.search.SearchStatistics;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.ProbeInfoDto;
import com.nec.megha.proto.search.SearchResponseProto.Candidate;
import com.nec.megha.proto.search.SearchResponseProto.Event;
import com.nec.megha.proto.search.SearchResponseProto.FusedScore;
import com.nec.megha.proto.search.SearchResponseProto.ProbeInfo;
import com.nec.megha.proto.search.SearchResponseProto.RawScore;
import com.nec.megha.proto.search.SearchResponseProto.RegionScore;
import com.nec.megha.proto.search.SearchResponseProto.SearchResponse;
import com.nec.megha.proto.search.SearchResponseProto.Statistics;

public class ScSearchResultInfo {
	public static final Logger logger = Logger.getLogger(ScSearchResultInfo.class);

	private final int maxCandidates;
	private final int internalMaxCandidates;
	private final Lock lock = new ReentrantLock();

	private ConcurrentLinkedQueue<SearchResponseInfo> searchResponseInfoList = new ConcurrentLinkedQueue<>();;
	private List<ErrorMessageDto> errorList;
	private ValuedHashMap<Integer, CandidateListInfo> binIdCandidateListMap;
	private ValuedHashMap<String, ProbeInfoDto> probeInfoMap;
	private ValuedHashMap<Integer, SearchStatistics> binIdSearchStatisticsMap;
	private final AtomicInteger searchResponseCounter = new AtomicInteger();

	public ScSearchResultInfo(int maxCandidates, int internalMaxCandidates) {
		this.maxCandidates = maxCandidates;
		this.internalMaxCandidates = internalMaxCandidates;
	}

	public AtomicInteger getSearchResponseCounter() {
		return searchResponseCounter;
	}

	public synchronized final void appendSearchResponse(final SearchResponse searchResponse, String requestKey,
			boolean isErrorResponseFlag) {
		searchResponseInfoList.add(new SearchResponseInfo(requestKey, isErrorResponseFlag, searchResponse));
		searchResponseCounter.incrementAndGet();
	}

	public final void limitToMaxCandidates(final Map<Integer, Integer> segmentIdBinIdMap,
			final Map<Integer, Integer> binIdMaxEventCountMap, boolean forceLock) {
		if (forceLock) {
			lock.lock();
			try {
				limitToMaxCandidatesSync(segmentIdBinIdMap, binIdMaxEventCountMap);
			} finally {
				lock.unlock();
			}
		} else {
			if (lock.tryLock()) {
				try {
					limitToMaxCandidatesSync(segmentIdBinIdMap, binIdMaxEventCountMap);
				} finally {
					lock.unlock();
				}
			}
		}
	}

	private synchronized final void limitToMaxCandidatesSync(final Map<Integer, Integer> segmentIdBinIdMap,
			final Map<Integer, Integer> binIdMaxEventCountMap) {
		if (logger.isDebugEnabled())
			logger.debug("In limitToMaxCandidatesSync: searchResponseInfoListSize: " + searchResponseInfoList.size());

		SearchResponseInfo searchResponseInfo = null;
		while ((searchResponseInfo = searchResponseInfoList.poll()) != null) {
			final SearchResponse searchResponse = searchResponseInfo.searchResponse;
			final String requestKey = searchResponseInfo.requestKey;

			if (logger.isDebugEnabled())
				logger.debug("In limitToMaxCandidatesSync: searchResponseMsgId: " + searchResponse.getMsgId()
						+ ", requestKey: " + requestKey + ", searchResponseCandidateCount: "
						+ searchResponse.getCandidateCount() + ", isErrorResponseFlag: "
						+ searchResponseInfo.isErrorResponseFlag + ", hasErrorList: " + (errorList != null));

			if (searchResponseInfo.isErrorResponseFlag) {
				if (errorList == null) {
					errorList = new ArrayList<>();
				}

				Date now = new Date();
				if (searchResponse.getStatus().getErrorCount() > 0) {
					for (com.nec.megha.proto.common.CommonProto.Error error : searchResponse.getStatus()
							.getErrorList()) {
						errorList.add(buildErrorMessageDto(error));
						while (error.hasInner()) {
							error = error.getInner();
							errorList.add(buildErrorMessageDto(error));
						}
					}
				} else {
					errorList.add(new ErrorMessageDto(SearchConstants.SEARCH_RESPONSE_ERROR,
							"Search response status success flag is false", null, now));
				}

				continue;
			}

			if (errorList != null) {
				// Has some errors, so no need to build candidate list
				continue;
			}

			if (searchResponse.getStatisticsCount() > 0) {
				if (binIdSearchStatisticsMap == null) {
					binIdSearchStatisticsMap = new ValuedHashMap<>(binId -> new SearchStatistics(binId, 0L, 0L));
				}
				for (Statistics statistics : searchResponse.getStatisticsList()) {
					Integer binId = segmentIdBinIdMap.getOrDefault(statistics.getSegmentId(), 0);

					SearchStatistics searchStatistics = binIdSearchStatisticsMap.getValue(binId);
					searchStatistics.setReadCount(searchStatistics.getReadCount() + statistics.getReadCount());
					searchStatistics.setMatchCount(searchStatistics.getMatchCount() + statistics.getMatchCount());
				}
			}

			if (searchResponse.getCandidateCount() == 0) {
				continue;
			}

			if (binIdCandidateListMap == null) {
				binIdCandidateListMap = new ValuedHashMap<>(
						binId -> new CandidateListInfo(binIdMaxEventCountMap.getOrDefault(binId, 0).equals(1)));
			}

			for (Candidate candidate : searchResponse.getCandidateList()) {
				Integer binId = segmentIdBinIdMap.getOrDefault(candidate.getSegmentId(), 0);

				CandidateListInfo candidateListInfo = binIdCandidateListMap.getValue(binId);
				candidateListInfo.addCandidate(candidate, requestKey);
			}

			if (searchResponse.getProbeInfoCount() > 0) {
				if (probeInfoMap == null) {
					probeInfoMap = new ValuedHashMap<>(key -> new ProbeInfoDto());
				}
				for (ProbeInfo probeInfo : searchResponse.getProbeInfoList()) {
					String key = probeInfo.getAlgType().name() + "_" + probeInfo.getSubType().name();
					if (probeInfoMap.containsKey(key)) {
						continue;
					}
					ProbeInfoDto probeInfoDto = probeInfoMap.getValue(key);
					probeInfoDto.setAlgorithmType(CommonProtobufUtil.getAlgorithmType(probeInfo.getAlgType()));
					probeInfoDto.setPosition(CommonProtobufUtil.getImagePosition(probeInfo.getSubType()));
					if (probeInfo.hasQuality()) {
						probeInfoDto.setQuality(probeInfo.getQuality());
					}
				}
			}
		}

	}

	public synchronized SearchJobResultDto getConsolidatedSearchResult(ScSearchJobInfo scSearchJobInfo,
			final Map<Integer, Integer> segmentIdBinIdMap, final Map<Integer, Integer> binIdMaxEventCountMap) {

		limitToMaxCandidatesSync(segmentIdBinIdMap, binIdMaxEventCountMap);

		SearchJobResultDto jobResultDto = new SearchJobResultDto();
		jobResultDto.setJobId(scSearchJobInfo.searchJobId);
		jobResultDto.setStatus(BioJobStatus.COMPLETED);
		jobResultDto.setJobMode(scSearchJobInfo.jobMode);

		long startTimestampMilli = 0;

		// long writeStamp = stampedLock.writeLock();
		try {
			startTimestampMilli = System.currentTimeMillis();

			if (errorList != null && !errorList.isEmpty()) {
				jobResultDto.setErrorList(new ArrayList<>(errorList));
				return jobResultDto;
			}

			if (probeInfoMap != null && !probeInfoMap.isEmpty()) {
				jobResultDto.setProbeInfoList(new ArrayList<>(probeInfoMap.values()));
			}

			if (binIdSearchStatisticsMap != null && !binIdSearchStatisticsMap.isEmpty()) {
				jobResultDto.setSearchStatisticsList(new ArrayList<>(binIdSearchStatisticsMap.values()));
			}

			if (binIdCandidateListMap == null || binIdCandidateListMap.isEmpty()) {
				return jobResultDto;
			}

			// To exclude duplicates, Most likely when using simulator we are
			// getting duplicate hits
			Map<String, SearchHitEvent> hitEventKeyMap = new HashMap<>();
			Set<String> hitEventRawScoreKeySet = new HashSet<>();

			for (Entry<Integer, CandidateListInfo> entry : binIdCandidateListMap.entrySet()) {
				Integer binId = entry.getKey();
				CandidateListInfo candidateListInfo = entry.getValue();
				jobResultDto.getCandidateResultList().addAll(
						buildSearchHitCandidateList(binId, candidateListInfo, hitEventKeyMap, hitEventRawScoreKeySet));
			}

			return jobResultDto;
		} catch (Throwable th) {
			logger.error("Error in getConsolidatedSearchResult for searchJobId: " + scSearchJobInfo.searchJobId + " : "
					+ th.getMessage(), th);

			ErrorMessageDto errorMessageDto = new ErrorMessageDto(SearchConstants.ERROR_CODE_GENERAL,
					"Error during search result consolidation: " + th.getMessage(),
					ExceptionMessageFormatter.format(th));
			jobResultDto.getErrorList().add(errorMessageDto);

			return jobResultDto;
		} finally {
			// stampedLock.unlockWrite(writeStamp);

			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (logger.isTraceEnabled() || timeTakenMilli > 50) {
				CommonLogger.PERF_LOG.info("In getConsolidatedSearchResult: TimeTakenMilli: " + timeTakenMilli
						+ " for searchJobId: " + scSearchJobInfo.searchJobId + ", candidateResultListSize: "
						+ (jobResultDto.hasCandidateResultList() ? jobResultDto.getCandidateResultList().size() : 0));
			}
		}
	}

	private final ErrorMessageDto buildErrorMessageDto(com.nec.megha.proto.common.CommonProto.Error error) {		
		ErrorMessageDto errorMessageDto = null;
		if (error.getCode() == 99999) {
			String errCode = null;
			String erriDetailMsg = null;
			String errMsg = error.getMsg();		
			if (errMsg.startsWith("{")) {
				errMsg = errMsg.substring(1, errMsg.length());
			}		
			if (errMsg.endsWith("}")) {
				errMsg = errMsg.substring(0, errMsg.length() - 1);
			}	
			int errCodeFirstIndex = errMsg.indexOf(":");
			int errCodeLastIndex = errMsg.indexOf(",");
			if (errCodeFirstIndex > 0 && errCodeLastIndex > 0) {
				errCode = errMsg.substring(errCodeFirstIndex + 2, errCodeLastIndex -1);
				errMsg = errMsg.substring(errCodeLastIndex + "errorMessage".length() + 5, errMsg.length());
			}			
			errCode = errCode !=null ? errCode: "9999";				
			int erriDetailIndex = errMsg.indexOf("errorDetail");
			int errDateIndex = errMsg.indexOf("errorDateTime");
			if (erriDetailIndex > 0 && errDateIndex > 0) {
				String oldMes = errMsg;
				errMsg = errMsg.substring(0, erriDetailIndex -3);
				erriDetailMsg = oldMes.substring(erriDetailIndex + "errorDetail".length() + 4, errDateIndex - 3);
			} else if (errDateIndex > 0){
				errMsg = errMsg.substring(0, errDateIndex -3);
			}			
						
			try {			
				errorMessageDto = GsonSerializer.fromJson(error.getMsg(), ErrorMessageDto.class);				
			} catch (Throwable th) {
				logger.error(th.getMessage(), th);
			}
			if (errorMessageDto == null) {
				errorMessageDto = new ErrorMessageDto(errCode, errMsg, erriDetailMsg, new Date());
			}
		} else {
			errorMessageDto = new ErrorMessageDto(String.valueOf(error.getCode()), error.getMsg(), null, new Date());
		}
		return errorMessageDto;
	}

	private List<SearchHitCandidate> buildSearchHitCandidateList(Integer binId, CandidateListInfo candidateListInfo,
			Map<String, SearchHitEvent> hitEventKeyMap, Set<String> hitEventRawScoreKeySet) {
		List<SearchHitCandidate> searchHitCandidateList = new ArrayList<>();

		for (CandidateInfo candidateInfo : candidateListInfo.candidateInfoSet) {

			SearchHitCandidate searchHitCandidate = new SearchHitCandidate();
			searchHitCandidate.setExternalId(candidateInfo.externalId);
			searchHitCandidate.setBinId(binId);
			searchHitCandidate.setRequestItemKey(candidateListInfo.requestKey);
			searchHitCandidate.setScore(candidateInfo.overallScore);

			String candidateKey = "" + candidateInfo.externalId + "|" + binId + "|" + candidateListInfo.requestKey;

			Map<ImagePosition, SearchFusedScoreDto> currentFusedScoreMap = new HashMap<>();

			buildSearchHitCandidate(searchHitCandidate, candidateInfo.candidate, currentFusedScoreMap, candidateKey,
					hitEventKeyMap, hitEventRawScoreKeySet);

			if (candidateInfo.otherCandidates != null && !candidateInfo.otherCandidates.isEmpty()) {
				for (Candidate candidate : candidateInfo.otherCandidates) {
					buildSearchHitCandidate(searchHitCandidate, candidate, currentFusedScoreMap, candidateKey,
							hitEventKeyMap, hitEventRawScoreKeySet);
				}
			}

			searchHitCandidateList.add(searchHitCandidate);

			if (searchHitCandidateList.size() >= maxCandidates) {
				break;
			}
		}

		return searchHitCandidateList;
	}

	private void buildSearchHitCandidate(SearchHitCandidate searchHitCandidate, Candidate candidate,
			Map<ImagePosition, SearchFusedScoreDto> currentFusedScoreMap, String candidateKey,
			Map<String, SearchHitEvent> hitEventKeyMap, Set<String> hitEventRawScoreKeySet) {
		if (candidate.getFusedScoreCount() > 0) {
			for (FusedScore fusedScore : candidate.getFusedScoreList()) {
				ImagePosition imagePosition = ImagePosition.enumOf(fusedScore.getFingerPosition().getNumber());

				SearchFusedScoreDto searchFusedScoreDto = currentFusedScoreMap.get(imagePosition);
				if (searchFusedScoreDto == null) {
					currentFusedScoreMap.put(imagePosition,
							new SearchFusedScoreDto(imagePosition, fusedScore.getScore()));
				} else if (searchFusedScoreDto.getScore() <= fusedScore.getScore()) {
					searchFusedScoreDto.setScore(fusedScore.getScore());
				}
			}
		}

		if (candidate.getEventCount() > 0) {
			for (Event event : candidate.getEventList()) {
				String hitEventKey = candidateKey + "|" + event.getEventId();

				SearchHitEvent searchHitEvent = hitEventKeyMap.get(hitEventKey);
				if (searchHitEvent == null) {
					searchHitEvent = new SearchHitEvent();
					searchHitEvent.setEventId(event.getEventId());
					searchHitCandidate.getHitEventList().add(searchHitEvent);

					hitEventKeyMap.put(hitEventKey, searchHitEvent);
				}

				if (event.hasCompositeScore()) {
					searchHitEvent.setCompositeScore(event.getCompositeScore());
				}

				if (event.getRawScoreCount() > 0) {
					for (RawScore rawScore : event.getRawScoreList()) {
						String hitEventRawScoreKey = hitEventKey;

						SearchRawScoreDto rawScoreDto = new SearchRawScoreDto();
						if (rawScore.hasAlgType()) {
							rawScoreDto.setAlgorithmType(CommonProtobufUtil.getAlgorithmType(rawScore.getAlgType()));
							hitEventRawScoreKey += "|" + rawScore.getAlgType().name();
						}

						if (rawScore.hasSubType()) {
							rawScoreDto.setImagePosition(CommonProtobufUtil.getImagePosition(rawScore.getSubType()));
							hitEventRawScoreKey += "|" + rawScore.getSubType().name();
						}

						if (rawScore.hasFeType()) {
							String feType = StringUtils.strip(rawScore.getFeType(), "\0");
							if (StringUtils.isNotBlank(feType)) {
								rawScoreDto.setFeType(feType);
								hitEventRawScoreKey += "|" + feType;
							}
						}

						if (rawScore.hasScore()) {
							rawScoreDto.setScore(rawScore.getScore());
						}

						if (rawScore.hasQuality()) {
							rawScoreDto.setQuality(rawScore.getQuality());
						}

						if (rawScore.hasAxis()) {
							rawScoreDto.setAxis(rawScore.getAxis());
						}

						if (rawScore.getRegionScoreCount() > 0) {
							for (RegionScore regionScore : rawScore.getRegionScoreList()) {
								rawScoreDto.getRegionScoreList().add(new SearchRegionScore(regionScore.getX(),
										regionScore.getY(), regionScore.getScore()));
							}
						}

						if (!hitEventRawScoreKeySet.contains(hitEventRawScoreKey)) {
							searchHitEvent.getRawScoreList().add(rawScoreDto);

							hitEventRawScoreKeySet.add(hitEventRawScoreKey);
						}
					}
				}
			}
		}
	}

	private class SearchResponseInfo {
		final String requestKey;
		final boolean isErrorResponseFlag;
		final SearchResponse searchResponse;

		public SearchResponseInfo(String requestKey, boolean isErrorResponseFlag, SearchResponse searchResponse) {
			this.requestKey = requestKey;
			this.isErrorResponseFlag = isErrorResponseFlag;
			this.searchResponse = searchResponse;
		}
	}

	private class CandidateListInfo {
		final boolean mergeByExternalIdFlag;
		String requestKey;
		TreeSet<CandidateInfo> candidateInfoSet = new TreeSet<>();
		HashMap<String, CandidateInfo> mergeMap = new HashMap<>();

		public CandidateListInfo(boolean mergeByExternalIdFlag) {
			this.mergeByExternalIdFlag = mergeByExternalIdFlag;
		}

		public void addCandidate(Candidate candidate, String requestKey) {
			this.requestKey = requestKey;

			CandidateInfo candidateInfo = new CandidateInfo(candidate);

			if (mergeByExternalIdFlag) {
				CandidateInfo currentCandidateInfo = mergeMap.get(candidateInfo.externalId);
				if (currentCandidateInfo != null) {
					currentCandidateInfo.addOther(candidateInfo);
					if (currentCandidateInfo.overallScore < candidateInfo.overallScore) {
						candidateInfoSet.remove(currentCandidateInfo);

						currentCandidateInfo.overallScore = candidateInfo.overallScore;
						candidateInfoSet.add(currentCandidateInfo);
					}

					if (logger.isDebugEnabled())
						logger.debug("In addCandidate:merge: After merge externalId: " + candidateInfo.externalId
								+ ", overallScore: " + candidateInfo.overallScore + ", candidateInfoSetSize: "
								+ candidateInfoSet.size() + ", otherCandidatesSize: "
								+ currentCandidateInfo.otherCandidates.size());
				} else {
					// First we will add to the candidateInfoMap, later point of
					// time we will remove it depending on maxCandidates
					// if we remove now, we will lose the event information if
					// we get the proper hit later
					// In order to make sure we dont keep too many elements, we
					// limit by internalMaxCandidates for now.
					if (candidateInfoSet.size() < internalMaxCandidates) {
						mergeMap.put(candidateInfo.externalId, candidateInfo);
						candidateInfoSet.add(candidateInfo);
						if (logger.isDebugEnabled())
							logger.debug("In addCandidate:merge: After adding externalId: " + candidateInfo.externalId
									+ ", overallScore: " + candidateInfo.overallScore + ", candidateInfoSetSize: "
									+ candidateInfoSet.size());
					} else if (candidateInfoSet.last().compareTo(candidateInfo) > 0) {
						// Switch
						mergeMap.remove(candidateInfoSet.pollLast().externalId);
						mergeMap.put(candidateInfo.externalId, candidateInfo);
						candidateInfoSet.add(candidateInfo);
						if (logger.isDebugEnabled())
							logger.debug("In addCandidate:merge: After replacing externalId: "
									+ candidateInfo.externalId + ", overallScore: " + candidateInfo.overallScore
									+ ", candidateInfoSetSize: " + candidateInfoSet.size() + ", internalMaxCandidates: "
									+ internalMaxCandidates);

					}
				}
			} else {
				candidateInfoSet.add(candidateInfo);

				if (candidateInfoSet.size() > maxCandidates) {
					candidateInfoSet.pollLast();
				}
			}
		}
	}

	private class CandidateInfo implements Comparable<CandidateInfo> {
		final String externalId;
		int overallScore;
		final Candidate candidate;
		List<Candidate> otherCandidates;

		public CandidateInfo(final Candidate candidate) {
			this.externalId = candidate.getExternalId();
			this.overallScore = candidate.hasOverallScore() ? candidate.getOverallScore() : 0;
			this.candidate = candidate;
		}

		public final void addOther(final CandidateInfo candidateInfo) {
			if (otherCandidates == null) {
				otherCandidates = new ArrayList<>();
			}
			otherCandidates.add(candidateInfo.candidate);
		}

		@Override
		public final int compareTo(CandidateInfo other) {
			if (this == other) {
				return 0;
			}

			int compare = Integer.compare(other.overallScore, overallScore);
			if (compare == 0) {
				compare = externalId.compareTo(other.externalId);
			}
			return compare;
		}

		public final boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}

			if (!(obj instanceof CandidateInfo)) {
				return false;
			}

			return externalId.equals(((CandidateInfo) obj).externalId);
		}

		@Override
		public final int hashCode() {
			return externalId.hashCode();
		}
	}

}
