package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;

/**
 * The Class SearchJobHouseKeepingTask.
 */
public class SearchJobHouseKeepingTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchJobHouseKeepingTask.class);

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	/** The bio search job controller service. */
	private BioSearchJobControllerService bioSearchJobControllerService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The search job queue housekeeping queue. */
	private DelayQueue<DelayedItem<String>> searchJobQueueHousekeepingQueue;

	/** The is initialized. */
	private boolean isInitialized = false;

	@Override
	public void run() {
		Thread.currentThread().setName("SEARCH_JOB_HOUSEKEEPING_TASK_" + Thread.currentThread().getId());

		logger.info("In SearchJobHouseKeepingTask.run");

		while (!ShutdownHook.isShutdownFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				DelayedItem<String> delayedItem = null;
				while ((delayedItem = searchJobQueueHousekeepingQueue.poll()) != null) {
					String searchJobId = delayedItem.getItem();
					try {
						bioSearchJobControllerService.deleteSearchJob(searchJobId);
					} catch (Throwable th) {
						logger.error("Error in SearchJobHouseKeepingTask for searchJobId: " + searchJobId + " : "
								+ th.getMessage(), th);
					} finally {
						logger.info("In SearchJobHouseKeepingTask.run searchJobId: " + searchJobId + ", delaySeconds: "
								+ delayedItem.getDelay(TimeUnit.SECONDS));
					}
				}
			} catch (Throwable th) {
				logger.error("Error in SearchJobHouseKeepingTask: " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			} finally {
				Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
			}
		}
		logger.warn("Exiting SearchJobHouseKeepingTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
		bioSearchJobControllerService = SpringServiceManager.getBean("bioSearchJobControllerService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		searchJobQueueHousekeepingQueue = bioSearchControllerManager.getSearchJobQueueHousekeepingQueue();

		isInitialized = true;
	}
}
