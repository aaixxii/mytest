package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.io.Serializable;

public class SyncSnSegVerInfo implements Serializable {

	private static final long serialVersionUID = 5181484067173789516L;
	private String snNodeId;
	private Integer binId;
	private Integer segmentId;
	private Long segmentVersion;
	private Boolean isSyncCompelted;

	public SyncSnSegVerInfo(String snNodeId, Integer binId, Integer segmentId, Long segmentVersion,
			Boolean isSyncCompelted) {
		this.snNodeId = snNodeId;
		this.binId = binId;
		this.segmentId = segmentId;
		this.segmentVersion = segmentVersion;
		this.isSyncCompelted = isSyncCompelted;
	}

	public SyncSnSegVerInfo() {

	}

	public boolean keyIsEqual(Integer binId, Integer segmentId) {
		if (this.binId == null || this.segmentId == null || binId == null || segmentId == null)
			return false;
		if (binId.intValue() == this.getBinId().intValue() && segmentId.intValue() == this.getSegmentId().intValue()) {
			return true;
		} else {
			return false;
		}
	}

	public String getSnNodeId() {
		return snNodeId;
	}

	public void setSnNodeId(String snNodeId) {
		this.snNodeId = snNodeId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public Long getSegmentVersion() {
		return segmentVersion;
	}

	public void setSegmentVersion(Long segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public Boolean getIsSyncCompelted() {
		return isSyncCompelted;
	}

	public void setIsSyncCompelted(Boolean isSyncCompelted) {
		this.isSyncCompelted = isSyncCompelted;
	}

}
