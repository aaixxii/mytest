package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

public enum SyncSegmentType {
	INSERT("1"), UPDATE("2"), DELETE("3");

	private final String value;

	private SyncSegmentType(String v) {
		value = v;
	}

	public String getValue() {
		return value;
	}

	public static SyncSegmentType fromVal(String val) {
		for (SyncSegmentType p : SyncSegmentType.values()) {
			if (p.getValue().equals(val))
				return p;
		}
		return null;
	}
}
