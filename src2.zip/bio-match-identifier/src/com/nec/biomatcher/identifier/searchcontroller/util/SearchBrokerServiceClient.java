package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.BaseKeyedPooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericKeyedObjectPool;
import org.apache.log4j.Logger;
import org.springframework.remoting.RemoteConnectFailureException;
import org.springframework.remoting.caucho.HessianProxyFactoryBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.services.BioSearchBrokerRemoteService;
import com.nec.biomatcher.spec.services.exception.BioSearchBrokerException;

/**
 * The Class SearchBrokerServiceClient.
 */
public class SearchBrokerServiceClient {
	private static final Logger logger = Logger.getLogger(SearchBrokerServiceClient.class);

	/** The Constant servicePool. */
	private static final GenericKeyedObjectPool<String, BioSearchBrokerRemoteService> servicePool = buildServicePool();

	/**
	 * Instantiates a new search broker service client.
	 */
	private SearchBrokerServiceClient() {
	}

	/**
	 * Echo.
	 *
	 * @param searchBrokerId
	 *            the search broker id
	 * @param message
	 *            the message
	 * @return the string
	 * @throws RemoteConnectFailureException
	 *             the remote connect failure exception
	 * @throws BioSearchBrokerException
	 *             the bio search broker exception
	 */
	public static String echo(String searchBrokerId, String message)
			throws RemoteConnectFailureException, BioSearchBrokerException {
		try {
			BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchBrokerId, BioComponentType.SB,
					BioConnectionType.COMPONENT, BioProtocolType.HESSIAN);

			BioSearchBrokerRemoteService service = servicePool.borrowObject(connectionUrl);
			try {
				return service.echo(message);
			} finally {
				servicePool.returnObject(connectionUrl, service);
			}

		} catch (RemoteConnectFailureException ex) {
			logger.error("RemoteConnectFailureException while echo on searchBrokerId: " + searchBrokerId + " : "
					+ ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			throw new BioSearchBrokerException(
					"Error in echo on searchBrokerId: " + searchBrokerId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Notify search broker enabled.
	 *
	 * @param searchBrokerId
	 *            the search broker id
	 * @throws RemoteConnectFailureException
	 *             the remote connect failure exception
	 * @throws BioSearchBrokerException
	 *             the bio search broker exception
	 */
	public static void notifySearchBrokerEnabled(String searchBrokerId)
			throws RemoteConnectFailureException, BioSearchBrokerException {
		try {
			BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchBrokerId, BioComponentType.SB,
					BioConnectionType.COMPONENT, BioProtocolType.HESSIAN);

			BioSearchBrokerRemoteService service = servicePool.borrowObject(connectionUrl);
			try {
				service.notifySearchBrokerEnabled(searchBrokerId);
			} finally {
				servicePool.returnObject(connectionUrl, service);
			}
		} catch (RemoteConnectFailureException ex) {
			logger.error("RemoteConnectFailureException while notifySearchBrokerEnabled on searchBrokerId: "
					+ searchBrokerId + " : " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			throw new BioSearchBrokerException(
					"Error in notifySearchBrokerEnabled on searchBrokerId: " + searchBrokerId + " : " + th.getMessage(),
					th);
		}
	}

	/**
	 * Notify search broker disabled.
	 *
	 * @param searchBrokerId
	 *            the search broker id
	 * @throws RemoteConnectFailureException
	 *             the remote connect failure exception
	 * @throws BioSearchBrokerException
	 *             the bio search broker exception
	 */
	public static void notifySearchBrokerDisabled(String searchBrokerId)
			throws RemoteConnectFailureException, BioSearchBrokerException {
		try {
			BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchBrokerId, BioComponentType.SB,
					BioConnectionType.COMPONENT, BioProtocolType.HESSIAN);

			BioSearchBrokerRemoteService service = servicePool.borrowObject(connectionUrl);
			try {
				service.notifySearchBrokerDisabled(searchBrokerId);
			} finally {
				servicePool.returnObject(connectionUrl, service);
			}
		} catch (RemoteConnectFailureException ex) {
			logger.error("RemoteConnectFailureException while notifySearchBrokerDisabled on searchBrokerId: "
					+ searchBrokerId + " : " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			throw new BioSearchBrokerException("Error in notifySearchBrokerDisabled on searchBrokerId: "
					+ searchBrokerId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Builds the service pool.
	 *
	 * @return the generic keyed object pool
	 */
	private static GenericKeyedObjectPool<String, BioSearchBrokerRemoteService> buildServicePool() {

		BaseKeyedPooledObjectFactory<String, BioSearchBrokerRemoteService> poolFactory = new BaseKeyedPooledObjectFactory<String, BioSearchBrokerRemoteService>() {

			@Override
			public BioSearchBrokerRemoteService create(String connectionUrl) throws Exception {
				BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");

				long timeoutMilli = bioParameterService.getParameterValue("SEARCH_BROKER_HESSIAN_TIMEOUT_MILLI",
						"DEFAULT", TimeUnit.MINUTES.toMillis(2));

				HessianProxyFactoryBean proxy = new HessianProxyFactoryBean();
				proxy.setBeanClassLoader(BioSearchBrokerRemoteService.class.getClassLoader());
				proxy.setServiceUrl(connectionUrl);
				proxy.setOverloadEnabled(true);
				proxy.setReadTimeout(timeoutMilli);
				proxy.setServiceInterface(BioSearchBrokerRemoteService.class);
				proxy.afterPropertiesSet();
				BioSearchBrokerRemoteService service = (BioSearchBrokerRemoteService) proxy.getObject();
				return service;
			}

			@Override
			public PooledObject<BioSearchBrokerRemoteService> wrap(BioSearchBrokerRemoteService value) {
				return new DefaultPooledObject<>(value);
			}
		};

		GenericKeyedObjectPool<String, BioSearchBrokerRemoteService> servicePool = new GenericKeyedObjectPool<String, BioSearchBrokerRemoteService>(
				poolFactory);
		servicePool.setMaxTotalPerKey(500);
		servicePool.setMinEvictableIdleTimeMillis(TimeUnit.MINUTES.toMillis(5));
		return servicePool;
	}

}
