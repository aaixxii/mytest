package com.nec.biomatcher.identifier.searchcontroller.util;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;

import io.netty.util.internal.StringUtil;

public class SearchJobCancelingListener implements MessageListener<String> {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchJobCancelingListener.class);

	private BioSearchControllerManager bioSearchControllerManager;
	private LobImageService lobImageService;

	/**
	 * Instantiates a new search node segment version listener.
	 */
	public SearchJobCancelingListener() {
		logger.info("In SearchNodeSegmentVersionListener()");
	}

	@Override
	public void onMessage(final Message<String> meg) {
		String msg = meg.getMessageObject();
		if (StringUtil.isNullOrEmpty(msg)) {
			logger.info("Recevied empty string, return");
			return;
		}		
		logger.info("Got message from notifySearchJobCancelingTopic. Recevied messge:" + msg);
		if (bioSearchControllerManager == null)
			bioSearchControllerManager = getBioSearchControllerManager();
		
		String mySearchControllerId = bioSearchControllerManager.getSearchControllerId();
		if (StringUtil.isNullOrEmpty(mySearchControllerId)) {
			logger.info("MySearchControllerId is null or empty , return");
			return;
		}
		logger.info("My seacrchCotrol Id:" + mySearchControllerId);
		String receivedScIds = msg.split(":")[0];		
		if (!receivedScIds.contains(mySearchControllerId)) {
			logger.info("Received SCIDS is not contain my Id, return");
			return;
		}
	
		String searchJobId = msg.split(":")[1];
		if (StringUtils.isBlank(searchJobId)) {
			logger.info("rceived empty search job id. skip process.");
			return;
		}
		try {
			ScSearchJobInfo scSearchJobInfo = bioSearchControllerManager.getSearchJobInfoMap().remove(searchJobId);
			if (scSearchJobInfo == null) {
				logger.warn("Search Job is not in my memory, jobId=" + searchJobId + " SC=" + mySearchControllerId + ". It may be finished or keeped in other SC.");					
				
			}

			ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> scSearchNodePartitionedLoadMap = bioSearchControllerManager
					.getScSearchNodePartitionedLoadMap();
			ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap = new ConcurrentValuedHashMap<>(
					key -> scSearchNodePartitionedLoadMap
							.getValue(new TriKey<>(mySearchControllerId, key.getA(), key.getB())));
			
			if (snPartitionedLoadMap != null && snPartitionedLoadMap.size() > 1) {
				scSearchJobInfo.releasePendingSegmentJobs(snPartitionedLoadMap);
			}
			
			if (scSearchJobInfo != null) {
				bioSearchControllerManager.getPendingSearchJobQueueMap().getValue(scSearchJobInfo.capacityGroupKey)
						.remove(scSearchJobInfo.getJobEntry());
				if (scSearchJobInfo.isFunctionSlotAcquiredFlag()) {
					scSearchJobInfo.releaseFunctionSlot(bioSearchControllerManager.getMatcherFunctionControlUtil());
				}
			}
			
			if (lobImageService == null) {
				lobImageService = getLobImageService();
			}
			lobImageService.deleteLobsByLobId(searchJobId);
			bioSearchControllerManager.getSearchJobQueueHousekeepingQueue()
					.remove(new DelayedItem<String>(searchJobId, 0));
			InMemoryManager.removeFromTimeoutQueue(searchJobId);
			logger.info("Success to delete SearchJob. searchJobId: " + searchJobId + " by SC:" + mySearchControllerId);

		} catch (Throwable th) {
			logger.error("Error deleting lob for searchJobId: " + searchJobId + " : " + th.getMessage(), th);
		}
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setLobImageService(LobImageService lobImageService) {
		this.lobImageService = lobImageService;
	}

	private LobImageService getLobImageService() {
		return SpringServiceManager.getBean("lobImageService");
	}

	private BioSearchControllerManager getBioSearchControllerManager() {
		return SpringServiceManager.getBean("bioSearchControllerManager");
	}
}
