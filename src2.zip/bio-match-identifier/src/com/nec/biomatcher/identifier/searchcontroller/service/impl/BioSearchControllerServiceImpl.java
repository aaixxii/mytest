package com.nec.biomatcher.identifier.searchcontroller.service.impl;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.template.storage.TemplateStorageService;
import com.nec.biomatcher.identifier.searchcontroller.service.BioSearchControllerService;

/**
 * The Class BioSearchControllerServiceImpl.
 */
public class BioSearchControllerServiceImpl implements BioSearchControllerService {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioSearchControllerServiceImpl.class);

	/** The biometric event service. */
	private BiometricEventService biometricEventService;

	/** The bio match manager service. */
	private BioMatchManagerService bioMatchManagerService;

	/** The template storage service. */
	private TemplateStorageService templateStorageService;

	public void setBioMatchManagerService(BioMatchManagerService bioMatchManagerService) {
		this.bioMatchManagerService = bioMatchManagerService;
	}

	public void setTemplateStorageService(TemplateStorageService templateStorageService) {
		this.templateStorageService = templateStorageService;
	}

	public void setBiometricEventService(BiometricEventService biometricEventService) {
		this.biometricEventService = biometricEventService;
	}

}
