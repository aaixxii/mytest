package com.nec.biomatcher.identifier.util;

import java.util.List;

import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;

public class SegmentChangeSetIndexInfo {
	private long indexTimestampMilli;
	private List<BiometricEventInfo> biometricEventInfoList;

	public SegmentChangeSetIndexInfo() {

	}

	public SegmentChangeSetIndexInfo(List<BiometricEventInfo> biometricEventInfoList) {
		indexTimestampMilli = System.currentTimeMillis();
		if (biometricEventInfoList != null && biometricEventInfoList.size() > 0) {
			this.biometricEventInfoList = biometricEventInfoList;
		}
	}

	public long getIndexTimestampMilli() {
		return indexTimestampMilli;
	}

	public void setIndexTimestampMilli(long indexTimestampMilli) {
		this.indexTimestampMilli = indexTimestampMilli;
	}

	public boolean hasBiometricEventInfoList() {
		return biometricEventInfoList != null && biometricEventInfoList.size() > 0;
	}

	public List<BiometricEventInfo> getBiometricEventInfoList() {
		return biometricEventInfoList;
	}

	public void setBiometricEventInfoList(List<BiometricEventInfo> biometricEventInfoList) {
		this.biometricEventInfoList = biometricEventInfoList;
	}

}
