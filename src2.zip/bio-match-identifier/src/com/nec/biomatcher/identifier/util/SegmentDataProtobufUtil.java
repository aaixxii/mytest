package com.nec.biomatcher.identifier.util;

import java.io.ByteArrayOutputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.io.LittleEndianDataOutputStream;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentReportDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentStatus;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestType;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentUpdateDto;
import com.nec.biomatcher.spec.transfer.model.TemplateType;
import com.nec.megha.proto.segment.SegmentReportProto.SegmentReport;
import com.nec.megha.proto.segment.SegmentSyncResponseProto.SegmentSyncResponse;

/**
 * The Class SegmentDataProtobufUtil.
 */
public class SegmentDataProtobufUtil {
	private static final Logger logger = Logger.getLogger(SegmentDataProtobufUtil.class);

	/**
	 * Convert SegmentSyncRequestDto to SegmentSyncRequest payload
	 * 
	 * Structure of SegmentSyncRequest payload
	 * 
	 * <pre>
	 * int SegmentUpdate count
	 * struct SegmentUpdate
	 * {
	 *  int         updateType;         //!< Type of the update - 1 (init), 2 (unassign), 3 (assign/update)
	 *  int         segId;              //!< Segment id
	 *  CapsuleType capsuleType;        //!< Type of the segment in turn determined by the capsules it contains
	 *  BioId       idBegin;            //!< Min Biometric id allocated for the seg.
	 *  BioId       idEnd;              //!< Max Biometric id allocated for the seg.
	 *  uint8_t maxEventCount; //!< Maximum number of templates or events allowed for this capsule type. This is needed here to create the segment from the update.
	 *  VersionId   versionBegin;       //!< Segment version begin - will be 0 for segment downloads.
	 *  VersionId   versionEnd;         //!< Segment version end - will be 0 for segment downloads.
	 *  char        downloadUrls[256];  //!< Manager uses this to send segment downloads. A list so that in case one SN is not reachable.
	 *  int         eventCount;         //!< Total number of records present in the update
	 *  int         updateDataLen;      //!< Length of the segment update data
	 *  byte        updateData[];       //!< This field is used for capsule updates from manager to SN. UpdateEvent: [8 bytes][1 byte][1 byte][variable byte]. 
	 *                                  //   The data will be of the format [version][event-type][bio-id][data]. Event-type = 0 will mean insert and the following data will be the capsule. 
	 *                                  //   Use the length of the capsule to read it. Event-type = 1 will mean delete and the data will not be present. 
	 *                                  //   The items will be ordered by version.
	 *  }
	 * </pre>
	 *
	 * @param request
	 *            the request
	 * @param templateTypeTemplateCodeMap
	 *            the template type template code map
	 * @return the byte[]
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */

	public static byte[] toRequestPayload(SegmentSyncRequestDto request) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		try (FilterOutputStream fos = MeghaTemplateUtil.DEFAULT_BYTE_ORDER == ByteOrder.BIG_ENDIAN
				? new DataOutputStream(baos) : new LittleEndianDataOutputStream(baos)) {
			DataOutput dos = (DataOutput) fos;

			if (SegmentSyncRequestType.INIT.equals(request.getRequestType())) {
				dos.writeInt(0);
				dos.writeInt(1);
				fos.flush();

				if (logger.isDebugEnabled())
					logger.debug("In toRequestPayload: segSyncRequestLogMap: INIT");

				return baos.toByteArray();
			}

			dos.writeInt(request.getSegmentUpdateDtoList().size());

			HashMap<Integer, SegmentStatus> segSyncRequestLogMap = new HashMap<>();

			for (SegmentUpdateDto segmentUpdateDto : request.getSegmentUpdateDtoList()) {
				segSyncRequestLogMap.put(segmentUpdateDto.getSegmentId(), segmentUpdateDto.getSegmentStatus());

				int templateTypeCode = TemplateType.nameMap.containsKey(segmentUpdateDto.getTemplateType())
						? TemplateType.getByName(segmentUpdateDto.getTemplateType()).getTemplateTypeCode() : 0;

				switch (segmentUpdateDto.getSegmentStatus()) {
				case DELETE:
					dos.writeInt(2);
					break;
				default:
					dos.writeInt(3);
					break;
				}
				;

				dos.writeInt(segmentUpdateDto.getSegmentId());

				dos.writeInt(templateTypeCode);

				dos.writeLong(
						segmentUpdateDto.getStartBiometricId() == null ? 0L : segmentUpdateDto.getStartBiometricId());
				dos.writeLong(segmentUpdateDto.getEndBiometricId() == null ? 0L : segmentUpdateDto.getEndBiometricId());

				dos.writeByte(segmentUpdateDto.getMaxEventCount());

				dos.writeLong(segmentUpdateDto.getStartSegmentVersion() == null ? 0L
						: segmentUpdateDto.getStartSegmentVersion());
				dos.writeLong(
						segmentUpdateDto.getEndSegmentVersion() == null ? 0L : segmentUpdateDto.getEndSegmentVersion());

				byte[] downloadUrls = new byte[256];
				if (segmentUpdateDto.hadSegmentDownloadUrlList()) {
					int position = 0;
					for (String downloadUrl : segmentUpdateDto.getSegmentDownloadUrlList()) {
						byte[] tempData = downloadUrl.getBytes(StandardCharsets.UTF_8);
						if (position == 0 || (position + tempData.length + 1) <= downloadUrls.length) {
							if (position != 0) {
								downloadUrls[position++] = ',';
							}
							System.arraycopy(tempData, 0, downloadUrls, position, tempData.length);
							position += tempData.length;
						} else {
							break;
						}
					}
				}
				dos.write(downloadUrls);

				dos.writeInt(segmentUpdateDto.getTotalRecords() == null ? 0 : segmentUpdateDto.getTotalRecords());

				if (segmentUpdateDto.getSegmentChangeSetData() != null
						&& segmentUpdateDto.getSegmentChangeSetData().length > 0) {
					dos.writeInt(segmentUpdateDto.getSegmentChangeSetData().length);
					dos.write(segmentUpdateDto.getSegmentChangeSetData());
				} else {
					dos.writeInt(0);
				}
			}

			fos.flush();

			if (logger.isDebugEnabled())
				logger.debug("In toRequestPayload: segSyncRequestLogMap: " + segSyncRequestLogMap.toString());
		}

		return baos.toByteArray();
	}

	/**
	 * Gets the segment sync response.
	 *
	 * @param response
	 *            the response
	 * @param requestType
	 *            the request type
	 * @return the segment sync response
	 */
	public static SegmentSyncResponseDto getSegmentSyncResponse(SegmentSyncResponse response,
			SegmentSyncRequestType requestType) {
		SegmentSyncResponseDto responseDto = new SegmentSyncResponseDto();
		responseDto.setRequestType(requestType);
		if (response.hasInstanceId()) {
			responseDto.setInstanceId(response.getInstanceId());
		}

		HashMap<Integer, SegmentStatus> segSyncResponseLogMap = new HashMap<>();

		if (response.getSegReportCount() > 0) {
			for (SegmentReport segmentReport : response.getSegReportList()) {
				SegmentReportDto segmentReportDto = new SegmentReportDto();
				segmentReportDto.setSegmentId(segmentReport.getSegId());
				segmentReportDto.setSearchNodeId(response.getInstanceId());
				segmentReportDto.setReportDateTime(new Date());

				if (segmentReport.hasVersionBegin()) {
					segmentReportDto.setStartSegmentVersion(segmentReport.getVersionBegin());
				}

				if (segmentReport.hasVersionEnd()) {
					segmentReportDto.setEndSegmentVersion(segmentReport.getVersionEnd());
					segmentReportDto.setSegmentVersion(segmentReport.getVersionEnd());
				}

				if (segmentReport.hasVersion()) {
					segmentReportDto.setSegmentVersion(segmentReport.getVersion());
				}

				switch (segmentReport.getStatus()) {
				case ACTIVE:
					segmentReportDto.setStatus(SegmentStatus.ACTIVE);
					break;
				case ERROR:
					segmentReportDto.setStatus(SegmentStatus.ERROR);
					break;
				case PREPARING:
					segmentReportDto.setStatus(SegmentStatus.PREPARING);
					break;
				default:
					throw new IllegalArgumentException("Unknown SegmentReport status: " + segmentReport.getStatus());
				}

				// if(segmentReport.getCorruptVersionIdCount()>0) {
				// segmentReportDto.getCorruptedSegmentVersionIdList().addAll(segmentReport.getCorruptVersionIdList());
				// }

				segSyncResponseLogMap.put(segmentReportDto.getSegmentId(), segmentReportDto.getStatus());

				responseDto.getSegmentReportDtoList().add(segmentReportDto);
			}
		}

		if (logger.isDebugEnabled())
			logger.debug("In getSegmentSyncResponse: segSyncResponseLogMap: " + segSyncResponseLogMap.toString());

		return responseDto;
	}
}
