package com.nec.biomatcher.identifier.util;

/**
 * The Class SearchConstants.
 */
public class SearchConstants {

	/** The Constant ERROR_CODE_GENERAL. */
	public static final String ERROR_CODE_GENERAL = "SC001";

	/** The Constant ERROR_CODE_JOB_EXECUTION. */
	public static final String ERROR_CODE_SEARCH_JOB_EXECUTION = "SC002";

	/** The Constant ERROR_CODE_JOB_TIMEOUT. */
	public static final String ERROR_CODE_SEARCH_JOB_TIMEOUT = "SC003";

	/** The Constant ERROR_CODE_REJECTED. */
	public static final String SEARCH_RESPONSE_ERROR = "SC004";

	/** The Constant ERROR_CODE_LOBSTREAM_ACCESS. */
	public static final String ERROR_CODE_LOBSTREAM_ACCESS = "SC005";

	/** The Constant ERROR_CODE_SERIALIZATION. */
	public static final String ERROR_CODE_SERIALIZATION = "SC006";

	/** The Constant ERROR_CODE_EXTRACT_NODE_ERROR. */
	public static final String ERROR_CODE_SEARCH_NODE_ERROR = "SC007";

	/** The Constant ERROR_CODE_SEARCH_EXTRACTION. */
	public static final String ERROR_CODE_SEARCH_EXTRACTION = "SC008";

	public static final String ERROR_CODE_SYNC_EXTRACTION = "SC009";

	public static final String ERROR_CODE_SYNC_EXECUTION = "SC010";

	public static final String ERROR_CODE_SYNC_JOB_TIMEOUT = "SC011";

	public static final String ERROR_CODE_INVALID_TEMPLATE = "SC012";

	public static final String ERROR_CODE_STRIC_SYNC_JOB_TIMEOUT = "SC013";

	public static final String ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS = "SC013";

	public static final String STRICT_JOB_MODE = "STRICT";

}
