package com.nec.biomatcher.identifier.util;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.remoting.RemoteConnectFailureException;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.util.JobIdGenerator;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.GuavaCacheCleaner;
import com.nec.biomatcher.core.framework.common.HessianSerializer;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;

public class SearchJobPayloadCache {
	private static final Logger logger = Logger.getLogger(SearchJobPayloadCache.class);

	private static LoadingCache<String, BiKey<BioMatcherJobRequestPayload, Throwable>> bioSearchJobRequestPayloadCache;
	private static LoadingCache<String, BiKey<BioMatcherJobResultPayload, Throwable>> bioSearchJobResultPayloadCache;

	private static LobImageService lobImageService;

	public static final void cacheSearchJobRequestPayload(String searchJobId, BioMatcherJobRequestPayload payload) {
		if (bioSearchJobRequestPayloadCache == null) {
			initializeSearchJobRequestPayloadCache();
		}

		bioSearchJobRequestPayloadCache.put(searchJobId, new BiKey<>(payload, null));
	}

	public static final void clearSearchJobRequestPayloadCache(String searchJobId) {
		if (bioSearchJobRequestPayloadCache != null) {
			bioSearchJobRequestPayloadCache.invalidate(searchJobId);
		}
	}

	public static final BiKey<BioMatcherJobRequestPayload, Throwable> getSearchJobRequestPayload(String searchJobId)
			throws Throwable {
		if (bioSearchJobRequestPayloadCache == null) {
			initializeSearchJobRequestPayloadCache();
		}

		return bioSearchJobRequestPayloadCache.get(searchJobId);
	}

	public static final void cacheSearchJobResultPayload(String searchJobId, BioMatcherJobResultPayload payload) {
		if (bioSearchJobResultPayloadCache == null) {
			initializeSearchJobResultPayloadCache();
		}

		bioSearchJobResultPayloadCache.put(searchJobId, new BiKey<>(payload, null));
	}

	public static final void clearSearchJobResultPayloadCache(String searchJobId) {
		if (bioSearchJobResultPayloadCache != null) {
			bioSearchJobResultPayloadCache.invalidate(searchJobId);
		}
	}

	public static final BiKey<BioMatcherJobResultPayload, Throwable> getSearchJobResultPayload(String searchJobId)
			throws Throwable {
		if (bioSearchJobResultPayloadCache == null) {
			initializeSearchJobResultPayloadCache();
		}

		return bioSearchJobResultPayloadCache.get(searchJobId);
	}

	private static final BiKey<BioMatcherJobRequestPayload, Throwable> getSearchJobRequestPayloadInternal(
			String searchJobId) {
		long startTimestampMilli = System.currentTimeMillis();
		boolean isRemoteCall = false;
		String searchControllerId = null;
		try {
			searchControllerId = JobIdGenerator.getUserPrefix(searchJobId);

			if (searchControllerId != null
					&& !searchControllerId.equals(LocalServerComponents.getSearchControllerId())) {
				isRemoteCall = true;

				try {
					isRemoteCall = true;
					SearchJobRequestDto searchJobRequestDto = RemoteSearchJobControllerUtil
							.getSearchJobRequest(searchJobId, searchControllerId);

					BioMatcherJobRequestPayload bioMatcherJobRequestPayload = new BioMatcherJobRequestPayload();
					bioMatcherJobRequestPayload.setSearchJobRequest(searchJobRequestDto);

					return new BiKey<>(bioMatcherJobRequestPayload, null);
				} catch (RemoteConnectFailureException ex) {
					logger.error("RemoteConnectFailureException in getSearchJobRequestPayloadInternal for searchJobId: "
							+ searchJobId + ", searchControllerId: " + searchControllerId + " : " + ex.getMessage(),
							ex);
				} catch (Throwable th) {
					return new BiKey<>(null, th);
				}
			}

			byte lobData[] = getLobData(searchJobId, "req");

			BioMatcherJobRequestPayload bioMatcherJobRequestPayload = HessianSerializer.unmarshal(lobData);

			if (bioMatcherJobRequestPayload == null) {
				throw new Exception("Unable to unmarshal BioMatcherJobRequestPayload for searchJobId: " + searchJobId);
			}

			return new BiKey<>(bioMatcherJobRequestPayload, null);
		} catch (Throwable th) {
			logger.error("Error in getSearchJobRequestPayloadInternal : " + th.getMessage(), th);
			return new BiKey<>(null, th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 20 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In getSearchJobRequestPayloadInternal: TimeTakenMilli: " + timeTakenMilli
						+ " for searchJobId: " + searchJobId
						+ (searchControllerId == null ? "" : (", searchControllerId=" + searchControllerId))
						+ (isRemoteCall ? ", isRemoteCall=true" : ""));
			}
		}
	}

	private static final BiKey<BioMatcherJobResultPayload, Throwable> getSearchJobResultPayloadInternal(
			String searchJobId) {
		long startTimestampMilli = System.currentTimeMillis();
		boolean isRemoteCall = false;
		String searchControllerId = null;
		try {
			searchControllerId = JobIdGenerator.getUserPrefix(searchJobId);

			if (searchControllerId != null
					&& !searchControllerId.equals(LocalServerComponents.getSearchControllerId())) {
				isRemoteCall = true;

				try {
					isRemoteCall = true;
					SearchJobResultDto searchJobResultDto = RemoteSearchJobControllerUtil
							.getSearchJobResult(searchJobId, searchControllerId);

					BioMatcherJobResultPayload bioMatcherJobResultPayload = new BioMatcherJobResultPayload();
					bioMatcherJobResultPayload.setBioMatcherJobResult(searchJobResultDto);

					return new BiKey<>(bioMatcherJobResultPayload, null);
				} catch (RemoteConnectFailureException ex) {
					logger.error("RemoteConnectFailureException in getSearchJobResultPayloadInternal for searchJobId: "
							+ searchJobId + ", searchControllerId: " + searchControllerId + " : " + ex.getMessage(),
							ex);
				} catch (Throwable th) {
					return new BiKey<>(null, th);
				}
			}

			byte lobData[] = getLobData(searchJobId, "res");

			BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(lobData);

			if (bioMatcherJobResultPayload == null) {
				throw new Exception("Unable to unmarshal BioMatcherJobResultPayload for searchJobId: " + searchJobId);
			}

			return new BiKey<>(bioMatcherJobResultPayload, null);
		} catch (Throwable th) {
			logger.error("Error in getSearchJobResultPayloadInternal : " + th.getMessage(), th);
			return new BiKey<>(null, th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 30 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In getSearchJobResultPayloadInternal: TimeTakenMilli: " + timeTakenMilli
						+ " for searchJobId: " + searchJobId + (isRemoteCall ? ", isRemoteCall=true" : ""));
			}
		}
	}

	private static final byte[] getLobData(String lobId, String lobType)
			throws LobImageServiceException, LobImageNotFoundException {
		if (lobImageService == null) {
			lobImageService = SpringServiceManager.getBean("lobImageService");
		}

		return lobImageService.getLobData(lobId, lobType);
	}

	private static final synchronized void initializeSearchJobRequestPayloadCache() {
		if (bioSearchJobRequestPayloadCache == null) {

			logger.info("In initializeSearchJobRequestPayloadCache");

			int maxSearchJobRequestPayloadCacheCount = BioParameterService
					.getIntSupplier("MAX_SEARCH_JOB_REQUEST_PAYLOAD_CACHE_COUNT", "DEFAULT", 200).get();
			long searchJobRequestPayloadCacheExpiryMilli = BioParameterService.getLongSupplier(
					"SEARCH_JOB_REQUEST_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(60)).get();

			bioSearchJobRequestPayloadCache = CacheBuilder.newBuilder()
					.maximumSize(maxSearchJobRequestPayloadCacheCount)
					// .softValues()
					.concurrencyLevel(200)
					.expireAfterWrite(searchJobRequestPayloadCacheExpiryMilli, TimeUnit.MILLISECONDS)
					// .recordStats()
					.build(new CacheLoader<String, BiKey<BioMatcherJobRequestPayload, Throwable>>() {
						public BiKey<BioMatcherJobRequestPayload, Throwable> load(String searchJobId) {
							return getSearchJobRequestPayloadInternal(searchJobId);
						}
					});
			boolean registerGuavaCacheCleanerFlag = BioParameterService
					.getBooleanSupplier("REGISTER_GUAVA_CACHE_CLEANER_FLAG", "DEFAULT", false).get();
			if (registerGuavaCacheCleanerFlag) {
				GuavaCacheCleaner.registerCache("SEARCH_JOB_REQUEST_PAYLOAD_CACHE", bioSearchJobRequestPayloadCache);
			}
		}
	}

	private static final synchronized void initializeSearchJobResultPayloadCache() {
		if (bioSearchJobResultPayloadCache == null) {
			logger.info("In initializeSearchJobResultPayloadCache");

			int maxSearchJobResultPayloadCacheCount = BioParameterService
					.getIntSupplier("MAX_SEARCH_JOB_RESULT_PAYLOAD_CACHE_COUNT", "DEFAULT", 200).get();
			long searchJobResultPayloadCacheExpiryMilli = BioParameterService.getLongSupplier(
					"SEARCH_JOB_RESULT_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(30)).get();

			bioSearchJobResultPayloadCache = CacheBuilder.newBuilder().maximumSize(maxSearchJobResultPayloadCacheCount)
					// .softValues()
					.concurrencyLevel(200)
					.expireAfterWrite(searchJobResultPayloadCacheExpiryMilli, TimeUnit.MILLISECONDS)
					// .recordStats()
					.build(new CacheLoader<String, BiKey<BioMatcherJobResultPayload, Throwable>>() {
						public BiKey<BioMatcherJobResultPayload, Throwable> load(String searchJobId) {
							return getSearchJobResultPayloadInternal(searchJobId);
						}
					});

			boolean registerGuavaCacheCleanerFlag = BioParameterService
					.getBooleanSupplier("REGISTER_GUAVA_CACHE_CLEANER_FLAG", "DEFAULT", false).get();
			if (registerGuavaCacheCleanerFlag) {
				GuavaCacheCleaner.registerCache("SEARCH_JOB_RESULT_PAYLOAD_CACHE", bioSearchJobResultPayloadCache);
			}
		}
	}

}
