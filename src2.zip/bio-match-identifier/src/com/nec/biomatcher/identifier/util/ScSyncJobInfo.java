package com.nec.biomatcher.identifier.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.biometrics.InsertBiometricEventDto;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobType;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.InsertTemplateInfo;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;

public class ScSyncJobInfo {
	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(ScSyncJobInfo.class);

	/** The search job id. */
	private final String syncJobId;

	/** The callback url. */
	private final String callbackUrl;

	/** The job mode. */
	private final String jobMode;

	/** The create date time milli. */
	private final long createDateTimeMilli = System.currentTimeMillis();

	/** The has errors flag. */
	private boolean hasErrorsFlag = false;

	/** The job completed flag. */
	private boolean jobCompletedFlag = false;

	private List<BiometricEventSyncTypeDto> eventSyncTypeDtoList;

	private Map<String, InsertBiometricEventDto> extractionJobInsertEventMap = new HashMap<>();

	private List<String> extractionJobIdList = new ArrayList<>();

	private SyncJobResultDto errorSyncJobResultDto;

	private long syncStartDateTimeMilli = -1;

	private long extractionCompletedDateTimeMilli = -1;

	private long templateVerifyTimeTakenMilli = 0L;

	private boolean timeoutErrorFlag;

	private boolean syncExtractErrorFlag;

	private boolean functionSlotAcquiredFlag = false;

	public ScSyncJobInfo(String syncJobId, List<BiometricEventSyncTypeDto> eventSyncTypeDtoList, String callbackUrl,
			String jobMode) {
		this.syncJobId = syncJobId;
		this.eventSyncTypeDtoList = eventSyncTypeDtoList;
		this.callbackUrl = callbackUrl;
		this.jobMode = jobMode;
	}

	public synchronized void addExtractionJobInfo(String extractionJobId,
			InsertBiometricEventDto insertBiometricEventDto) {
		extractionJobInsertEventMap.put(extractionJobId, insertBiometricEventDto);
		extractionJobIdList.add(extractionJobId);
	}

	public synchronized boolean hasPendingExtractionJobs() {
		return extractionJobInsertEventMap.size() > 0;
	}

	public synchronized boolean hasExtractionError() {
		return errorSyncJobResultDto != null;
	}

	public synchronized SyncJobResultDto addExtractionResult(ExtractJobResultDto extractionResult,
			LinkedBlockingQueue<String> pendingSyncJobQueue, BioMatcherConfigService bioMatcherConfigService)
			throws BioMatcherConfigServiceException {
		if (errorSyncJobResultDto != null) {
			return errorSyncJobResultDto;
		}

		InsertBiometricEventDto insertBiometricEventDto = extractionJobInsertEventMap
				.remove(extractionResult.getJobId());

		if (insertBiometricEventDto == null) {
			errorSyncJobResultDto = new SyncJobResultDto();
			errorSyncJobResultDto.setJobId(syncJobId);
			errorSyncJobResultDto.setStatus(BioJobStatus.COMPLETED);
			errorSyncJobResultDto.getErrorList().add(new ErrorMessageDto(SearchConstants.ERROR_CODE_SYNC_EXTRACTION,
					"Cannot find extraction job info for extractionJobId: " + extractionResult.getJobId()));
			logger.warn("In addExtractionResult: Cannot find extraction job info for extractionJobId: "
					+ extractionResult.getJobId() + ", syncJobId: " + syncJobId);

			extractionJobInsertEventMap.clear();
			if (eventSyncTypeDtoList != null) {
				eventSyncTypeDtoList.clear();
			}

			return errorSyncJobResultDto;
		}

		Map<String, byte[]> templateDataMap = extractionResult.getTemplateInfoList().stream().collect(
				Collectors.toMap(TemplateInfo::getTemplateType, TemplateInfo::getTemplateData, (s1, s2) -> s2));

		for (InsertTemplateInfo insertTemplateInfo : insertBiometricEventDto.getInsertTemplateInfoList()) {
			if (insertTemplateInfo.getTemplateType() == null) {
				insertTemplateInfo.setTemplateType(
						bioMatcherConfigService.getMatcherBinInfo(insertTemplateInfo.getBinId()).getTemplateType());
			}

			byte[] templateData = templateDataMap.get(insertTemplateInfo.getTemplateType());
			if (templateData == null || templateData.length == 0) {
				errorSyncJobResultDto = new SyncJobResultDto();
				errorSyncJobResultDto.setJobId(syncJobId);
				errorSyncJobResultDto.setStatus(BioJobStatus.COMPLETED);
				errorSyncJobResultDto.getErrorList().add(new ErrorMessageDto(SearchConstants.ERROR_CODE_SYNC_EXTRACTION,
						"Sync image extraction did not return sync template for templateType: "
								+ insertTemplateInfo.getTemplateType() + ", binId: " + insertTemplateInfo.getBinId()
								+ ", extractionJobId: " + extractionResult.getJobId()));
				logger.warn(
						"In addExtractionResult: Sync image extraction did not return sync template for templateType: "
								+ insertTemplateInfo.getTemplateType() + ", binId: " + insertTemplateInfo.getBinId()
								+ ", syncJobId: " + syncJobId + ", extractionJobId: " + extractionResult.getJobId());

				extractionJobInsertEventMap.clear();
				if (eventSyncTypeDtoList != null) {
					eventSyncTypeDtoList.clear();
				}

				return errorSyncJobResultDto;
			} else {
				insertTemplateInfo.setTemplateData(templateData);
			}
		}

		if (extractionJobInsertEventMap.size() == 0) {
			logger.debug(
					"All syncJob extractions are completed, submitting sync job to pendingSyncJobQueue for syncJobId: "
							+ syncJobId + ", delayFromCreateDateTimeMilli: " + getDelayFromCreateDateTime());
			pendingSyncJobQueue.offer(syncJobId);
		}

		return null;
	}

	public boolean isHasErrorsFlag() {
		return hasErrorsFlag;
	}

	public void setHasErrorsFlag(boolean hasErrorsFlag) {
		this.hasErrorsFlag = hasErrorsFlag;
	}

	public boolean isJobCompletedFlag() {
		return jobCompletedFlag;
	}

	public void setJobCompletedFlag(boolean jobCompletedFlag) {
		this.jobCompletedFlag = jobCompletedFlag;
	}

	public String getSyncJobId() {
		return syncJobId;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public String getJobMode() {
		return jobMode;
	}

	public long getCreateDateTimeMilli() {
		return createDateTimeMilli;
	}

	public long getDelayFromCreateDateTime() {
		return System.currentTimeMillis() - createDateTimeMilli;
	}

	public List<BiometricEventSyncTypeDto> getEventSyncTypeDtoList() {
		return eventSyncTypeDtoList;
	}

	public void setEventSyncTypeDtoList(List<BiometricEventSyncTypeDto> eventSyncTypeDtoList) {
		this.eventSyncTypeDtoList = eventSyncTypeDtoList;
	}

	public Map<String, InsertBiometricEventDto> getExtractionJobInsertEventMap() {
		return extractionJobInsertEventMap;
	}

	public void setExtractionJobInsertEventMap(Map<String, InsertBiometricEventDto> extractionJobInsertEventMap) {
		this.extractionJobInsertEventMap = extractionJobInsertEventMap;
	}

	public List<String> getExtractionJobIdList() {
		return extractionJobIdList;
	}

	public void setExtractionJobIdList(List<String> extractionJobIdList) {
		this.extractionJobIdList = extractionJobIdList;
	}

	public SyncJobResultDto getErrorSyncJobResultDto() {
		return errorSyncJobResultDto;
	}

	public void setErrorSyncJobResultDto(SyncJobResultDto errorSyncJobResultDto) {
		this.errorSyncJobResultDto = errorSyncJobResultDto;
	}

	public long getExtractionCompletedDateTimeMilli() {
		return extractionCompletedDateTimeMilli;
	}

	public void setExtractionCompletedDateTimeMilli(long extractionCompletedDateTimeMilli) {
		this.extractionCompletedDateTimeMilli = extractionCompletedDateTimeMilli;
	}

	public boolean isTimeoutErrorFlag() {
		return timeoutErrorFlag;
	}

	public void setTimeoutErrorFlag(boolean timeoutErrorFlag) {
		this.timeoutErrorFlag = timeoutErrorFlag;
	}

	public boolean isSyncExtractErrorFlag() {
		return syncExtractErrorFlag;
	}

	public void setSyncExtractErrorFlag(boolean syncExtractErrorFlag) {
		this.syncExtractErrorFlag = syncExtractErrorFlag;
	}

	public long getExtractTimeTakenMilli() {
		if (extractionCompletedDateTimeMilli == -1L) {
			return 0;
		} else {
			return extractionCompletedDateTimeMilli - createDateTimeMilli;
		}
	}

	public long getSyncTimeTakenMilli() {
		if (syncStartDateTimeMilli == -1L) {
			return 0;
		} else if (extractionCompletedDateTimeMilli == -1L) {
			return System.currentTimeMillis() - createDateTimeMilli;
		} else {
			return System.currentTimeMillis() - extractionCompletedDateTimeMilli;
		}
	}

	public long getSyncStartDateTimeMilli() {
		return syncStartDateTimeMilli;
	}

	public void setSyncStartDateTimeMilli(long syncStartDateTimeMilli) {
		this.syncStartDateTimeMilli = syncStartDateTimeMilli;
	}

	public long getTemplateVerifyTimeTakenMilli() {
		return templateVerifyTimeTakenMilli;
	}

	public void setTemplateVerifyTimeTakenMilli(long templateVerifyTimeTakenMilli) {
		this.templateVerifyTimeTakenMilli = templateVerifyTimeTakenMilli;
	}

	public boolean isFunctionSlotAcquiredFlag() {
		return functionSlotAcquiredFlag;
	}

	public void markFunctionSlotAcquired() {
		this.functionSlotAcquiredFlag = true;
	}

	public synchronized void releaseFunctionSlot(MatcherFunctionControlUtil matcherFunctionControlUtil) {
		if (functionSlotAcquiredFlag) {
			matcherFunctionControlUtil.releaseFunctionSlot(BioMatcherJobType.ENROLL.name());
			functionSlotAcquiredFlag = false;
		}
	}
}
