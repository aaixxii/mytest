package com.nec.biomatcher.identifier.util;

public class SearchClusterKeyConstants {
	public static final String CENTRAL_SEGMENTDATA_VERSION_MAP = "CENTRAL_SEGMENTDATA_VERSION_MAP";
	public static final String SEARCH_NODE_SEGMENT_DATA_VERSION_MAP = "SEARCH_NODE_SEGMENT_DATA_VERSION_MAP";
}
