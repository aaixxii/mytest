package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

public class TemplateInfo {
	String type;
	byte[] data;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public TemplateInfo(String type, byte[] data) {
		this.type = type;
		this.data = data;
	}
}
