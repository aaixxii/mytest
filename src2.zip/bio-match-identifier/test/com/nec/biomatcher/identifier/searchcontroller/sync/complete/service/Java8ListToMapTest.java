package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.junit.Test;

public class Java8ListToMapTest {

	@Test
	public void test() {
		List<TestBean> beanList = new ArrayList<>();
		beanList.add(new TestBean("jack", 29));
		beanList.add(new TestBean("Tom", 25));
		beanList.add(new TestBean("kitty", 25));
		beanList.add(new TestBean("hurry", 30));

		// List<String> tmp1 = Arrays.asList(new TestBean("Tom", 25).getName());
		// List<String> tmp2 = Arrays.asList(new TestBean("kitty",
		// 30).getName());
		// tmp1.addAll(tmp2); this is bug

		Map<Integer, List<String>> jdk8MultiMap = beanList.stream().filter((TestBean o) -> o != null)
				.collect(Collectors.toMap(new Function<TestBean, Integer>() {
					@Override
					public Integer apply(TestBean testBean) {
						return testBean.getAge();
					}
				}, new Function<TestBean, List<String>>() {
					@Override
					public List<String> apply(TestBean testBean) {
						List<String> tmp = new ArrayList<>();
						tmp.add(testBean.getName());
						return tmp;
					}
				}, new BinaryOperator<List<String>>() {
					@Override
					public List<String> apply(List<String> st1, List<String> st2) {
						st1.addAll(st2);
						return st1;
					}
				}, new Supplier<Map<Integer, List<String>>>() {
					@Override
					public Map<Integer, List<String>> get() {
						return new HashMap<>();
					}
				}

		));
		System.out.println(jdk8MultiMap.size());
	}

	@Test
	public void test1() {
		List<TestBean> beanList = new ArrayList<>();
		beanList.add(new TestBean("jack", 29));
		beanList.add(new TestBean("Tom", 25));
		beanList.add(new TestBean("kitty", 25));
		beanList.add(new TestBean("hurry", 30));

		Map<String, TestBean> jdk8Map = beanList.stream()
				.collect(Collectors.toMap(TestBean::getName, java.util.function.Function.identity()));
		System.out.println(jdk8Map.size());

	}

	@Test
	public void test2() {
		List<TestBean> beanList = new ArrayList<>();
		beanList.add(new TestBean("jack", 29));
		beanList.add(new TestBean("Tom", 25));
		beanList.add(new TestBean("kitty", 25));
		beanList.add(new TestBean("hurry", 30));

		Map<Integer, List<String>> jdk8MultiMap = beanList.stream().filter(o -> o != null)
				.collect(Collectors.toMap(TestBean::getAge, (TestBean o) -> {
					List<String> tmp = new ArrayList<>();
					tmp.add(o.getName());
					return tmp;
				}, (x, y) -> {
					x.addAll(y);
					return x;
				}, HashMap::new));
		System.out.println(jdk8MultiMap.size());
	}

	public class TestBean {
		private String name;
		private Integer age;

		public TestBean() {
		}

		public TestBean(String name, Integer age) {
			this.name = name;
			this.age = age;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getAge() {
			return age;
		}

		public void setAge(Integer age) {
			this.age = age;
		}

		@Override
		public String toString() {
			{
				return "TestBean{" + "name='" + name + '\'' + ", age=" + age + '}';
			}
		}
	}

}
