package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

/**
 * 
 * @author 000001A006PBP<br/>
 *         ProcessSnReportTask update SN segments report to memory for strict
 *         callback
 *
 */
public class ProcessSnReportTaskForTest2 {
	private static int SEGMENT_REDUNDANCY;
	private String reportMeg;
	ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = new ConcurrentHashMap<>();
	ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = new ConcurrentHashMap<>();

	/**
	 * Constructor of class
	 * 
	 * @param message
	 */
	public ProcessSnReportTaskForTest2() {
	}

	/**
	 * Initialize class
	 */
	private void init() {
		SEGMENT_REDUNDANCY = 1;
		this.reportMeg = createReportString();
		this.preSnSegVerMap = createPreSnSegVerMap();
		createStrcitMap();

	}

	public static void main(String[] args) {
		ProcessSnReportTaskForTest2 test = new ProcessSnReportTaskForTest2();
		test.init();
		test.handleSnSegmentReportMeg();
	}

	/**
	 * 
	 * @param reportMeg
	 */
	public void handleSnSegmentReportMeg() {
		try {

			if (reportMeg == null || reportMeg.isEmpty()) {
				System.out.println("Receied empty sn report, skip process!");
				return;
			}
			Map<Integer, Integer> segmentIdBinIdMap = createSegVerMap();
			if (reportMeg == null || reportMeg.isEmpty()) {
				System.out.println("Receied empty sn report, skip process!");
				return;
			}
			if (segmentIdBinIdMap.isEmpty()) {
				System.out.println("The size of segmentIdBinIdMap is zero, skip process!");
			}
			int index = reportMeg.indexOf("#");
			String snId = reportMeg.substring(0, index);
			String jsonMapString = reportMeg.substring(index + 1, reportMeg.length());
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			Map<Integer, Long> snReportMap = new HashMap<>();
			Type mapType = new TypeToken<Map<Integer, Long>>() {
			}.getType();
			snReportMap = gson.fromJson(jsonMapString, mapType);
			snReportMap.entrySet().stream().forEach(e -> {
				Integer binId = segmentIdBinIdMap.get(e.getKey());
				if (binId == null) {
					System.out.println("The BinId is null for segment:" + e.getKey() + " Skip to update sn report!");
					return;
				}
				updatePreSnSegVerMap(snId, binId, e.getKey(), e.getValue());
				updateStrictSyncCallbackMap(snId, binId, e.getKey(), e.getValue());
				System.out.println("Loop one in handleSnSegmentReportMeg!!");
			});
			checkCangCallback();
			System.out.println("Loop completed in handleSnSegmentReportMeg!!");

		} catch (Exception e) {
			System.out.println("Error occurred in handleSnSegmentReportMeg");

		}
	}

	private Map<Integer, Integer> createSegVerMap() {
		Map<Integer, Integer> segmentBinIdMap = new HashMap<>();
		segmentBinIdMap.put(Integer.valueOf(9), 35);
		return segmentBinIdMap;
	}

	private static String createReportString() {
		Map<Integer, Long> newSegmentIdVersionMap = new HashMap<>();
		newSegmentIdVersionMap.put(Integer.valueOf(9), 1001L);
		newSegmentIdVersionMap.put(Integer.valueOf(10), 2000L);
		Gson objGson = new GsonBuilder().setPrettyPrinting().create();
		Type mapType = new TypeToken<Map<Integer, Long>>() {
		}.getType();
		objGson.toJson(newSegmentIdVersionMap, mapType);
		String mapToJson = objGson.toJson(newSegmentIdVersionMap, mapType);
		mapToJson = "SN001" + "#" + mapToJson;
		return mapToJson;
	}

	private void createStrcitMap() {
		StrictSyncCallbackKey key = new StrictSyncCallbackKey("SC-JOB1", "142028975", "1927258727",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> seg9VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		seg9VerInfos.add(sn1);
		strictSyncCallbackMap.put(key, seg9VerInfos);
		System.out.println("Print strictSyncCallbackMap in createStrcitMap()!");
		Iterator<Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>>> it = strictSyncCallbackMap.entrySet().iterator();
		while (it.hasNext()) {
			Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> tmp = it.next();
			System.out.println(tmp.getKey().getEventId());
			System.out.println(tmp.getKey().getExternalId());
			System.out.println(tmp.getKey().getSyncJobId());
			System.out.println(tmp.getKey().getCallbackUrl());
			List<SyncSnSegVerInfo> list = tmp.getValue();
			for (SyncSnSegVerInfo info : list) {
				System.out.println(info.getSnNodeId());
				System.out.println(info.getBinId());
				System.out.println(info.getSegmentId());
				System.out.println(info.getSegmentVersion());
				System.out.println(info.getIsSyncCompelted());
			}
		}
	}

	private ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> createPreSnSegVerMap() {
		ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preMap = new ConcurrentHashMap<>();
		List<SyncSnSegVerInfo> seg9VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		seg9VerInfos.add(sn1);
		SegIdBinKey key = new SegIdBinKey(Integer.valueOf(9), Integer.valueOf(35));
		preMap.put(key, seg9VerInfos);
		System.out.println("Print preSnSegVerMap in createPreSnSegVerMap()!");
		Iterator<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> it = preMap.entrySet().iterator();
		while (it.hasNext()) {
			Entry<SegIdBinKey, List<SyncSnSegVerInfo>> tmp = it.next();
			System.out.println(tmp.getKey().getBinId());
			System.out.println(tmp.getKey().getSegmentId());
			List<SyncSnSegVerInfo> list = tmp.getValue();
			System.out.println("List<SyncSnSegVerInfo> size=" + list.size());
			for (SyncSnSegVerInfo info : list) {
				System.out.println(info.getSnNodeId());
				System.out.println(info.getBinId());
				System.out.println(info.getSegmentId());
				System.out.println(info.getSegmentVersion());
				System.out.println(info.getIsSyncCompelted());
			}
		}
		return preMap;

	}

	/**
	 * 
	 * @param snId
	 * @param binId
	 * @param segId
	 * @param segVer
	 */
	public void updateStrictSyncCallbackMap(String snId, Integer binId, Integer segId, Long segVer) {
		try {
			if (strictSyncCallbackMap.size() < 1) {
				System.out.println("The size of strictSyncCallbackMap is zero! skip callback!");
				return;
			}
			Predicate<SyncSnSegVerInfo> predicate = info -> info.getBinId() != null && info.getSegmentId() != null
					&& info.getSnNodeId() != null && info.getBinId().intValue() == binId.intValue()
					&& info.getSegmentId().intValue() == segId.intValue() && info.getSnNodeId().equals(snId)
					&& segVer.longValue() > info.getSegmentVersion().longValue();

			strictSyncCallbackMap.entrySet().stream().forEach(entry -> {
				Optional<SyncSnSegVerInfo> found = entry.getValue().stream().filter(predicate).findFirst();
				if (found.isPresent()) {
					found.get().setSegmentVersion(segVer);
					found.get().setIsSyncCompelted(Boolean.TRUE);
					return;
				}
			});
		} catch (Exception e) {
			String errMsg = "An error occurred in updateStrictSyncCallbackMap";
			System.out.println(errMsg + e.getMessage());
		}

	}

	/**
	 * 
	 * @param snId
	 * @param segId
	 * @param segVer
	 * @return
	 * @return
	 */
	public void updatePreSnSegVerMap(String snId, Integer binId, Integer segId, Long segVer) {
		try {
			if (preSnSegVerMap.isEmpty()) {
				System.out.println("The size of strictSyncCallbackMap is zero! skip process!");
				return;
			}
			Predicate<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> predicate = oneSet -> oneSet.getKey().getSegmentId()
					.intValue() == segId.intValue() && oneSet.getKey().getBinId().intValue() == binId.intValue();
			List<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> tmp = preSnSegVerMap.entrySet().stream().filter(predicate)
					.collect(Collectors.toList());
			if (tmp.isEmpty()) {
				System.out.println("No data to process sn report:snId:" + snId + "segId:" + segId + "binId:" + binId);
				return;
			}
			tmp.forEach(entry -> {
				entry.getValue().stream().forEach(segInfo -> {
					if (segInfo.getSegmentId().intValue() == segId.intValue() && segInfo.getSnNodeId().equals(snId)
							&& segInfo.getBinId().intValue() == binId.intValue()
							&& segVer.longValue() > segInfo.getSegmentVersion().longValue()) {
						segInfo.setSegmentVersion(segVer);
						return;
					}
				});
			});

		} catch (Exception e) {
			String errMsg = "An error occurred in updatePreSnSegVerMap";
			System.out.println(errMsg + e.getMessage());

		}

	}

	public void checkCangCallback() {
		if (strictSyncCallbackMap.size() < 1) {
			System.out.println("The size of strictSyncCallbackMap is zero! skip callback!");
			return;
		}
		System.out.println("Print strictSyncCallbackMap !!!!");
		Iterator<Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>>> it = strictSyncCallbackMap.entrySet().iterator();
		while (it.hasNext()) {
			Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> tmp = it.next();
			System.out.println(tmp.getKey().getEventId());
			System.out.println(tmp.getKey().getExternalId());
			System.out.println(tmp.getKey().getSyncJobId());
			System.out.println(tmp.getKey().getCallbackUrl());
			List<SyncSnSegVerInfo> list = tmp.getValue();
			for (SyncSnSegVerInfo info : list) {
				System.out.println(info.getSnNodeId());
				System.out.println(info.getBinId());
				System.out.println(info.getSegmentId());
				System.out.println(info.getSegmentVersion());
				System.out.println(info.getIsSyncCompelted());
			}
		}
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getIsSyncCompelted() == Boolean.TRUE;
		strictSyncCallbackMap.entrySet().stream().forEach(e -> {
			long redundancy = e.getValue().stream().count();
			assert (redundancy == SEGMENT_REDUNDANCY);
			if (e.getValue().stream().filter(predicate).count() >= SEGMENT_REDUNDANCY) {
				System.out.println("Can call Callback to client");
			}
		});
	}

}
