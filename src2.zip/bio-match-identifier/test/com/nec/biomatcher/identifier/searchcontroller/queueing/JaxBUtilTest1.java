package com.nec.biomatcher.identifier.searchcontroller.queueing;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JaxBUtilTest1 {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testUnmarshal() {

	}

	@Test
	public void testMarshal() throws IOException {
		URL url = Thread.currentThread().getContextClassLoader().getResource("requestdata/req.xml");
		if (url == null) return;
		File file = new File(url.getPath());
		StringBuilder contentBuilder = new StringBuilder();
		try (Stream<String> stream = Files.lines(Paths.get(file.getPath()), StandardCharsets.UTF_8)) {
			stream.forEach(s -> contentBuilder.append(s).append("\n"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		String resutl = contentBuilder.toString();

		System.out.println(resutl);
	}
	
	@Test
	public void testMessage() {
		String searchJobId = "search_job_001";
		StringBuilder sb = new StringBuilder();
		String mySearchControllerId = "SC001";
		String[] testSerId = {"SC001", "SC002", "SC003"};
		for (int i = 0; i < testSerId.length; i++) {
				sb.append(testSerId[i]);
				sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1);
		String notifyMsg = sb.toString() + ":" + searchJobId; 		
		System.out.println(notifyMsg);	
		String notifyedMsg = notifyMsg.split(":")[0];
		if (notifyedMsg.contains(mySearchControllerId)) {
			System.out.println("Received  message id contain myId");
		} else {
			System.out.println("Received SC is not equal my Id, return");
		}			
	}
}
