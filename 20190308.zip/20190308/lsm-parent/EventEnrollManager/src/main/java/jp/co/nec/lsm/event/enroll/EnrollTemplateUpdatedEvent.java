package jp.co.nec.lsm.event.enroll;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.event.enroll.common.EnrollReceiverEnum;

/**
 * @author liuyq <br>
 */
public class EnrollTemplateUpdatedEvent extends EnrollAbstractEvent {
	private static final long serialVersionUID = 1L;

	private boolean isEnrollJob = true;

	public EnrollTemplateUpdatedEvent(long batchJobId,
			EnrollNotifierEnum enrollNotify, EnrollReceiverEnum enrollReceiver,
			boolean isEnrollJob) {
		setBatchJobId(batchJobId);
		setEnrollNotifier(enrollNotify);
		setEnrollReceiver(enrollReceiver);

		this.setEnrollJob(isEnrollJob);
	}

	public void setEnrollJob(boolean isEnrollJob) {
		this.isEnrollJob = isEnrollJob;
	}

	public boolean isEnrollJob() {
		return isEnrollJob;
	}
}
