package jp.co.nec.lsm.event.enroll;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.event.enroll.common.EnrollReceiverEnum;

/**
 * @author liuyq <br>
 */
public class EnrollSegmentSynchronizedEvent extends EnrollAbstractEvent {
	private static final long serialVersionUID = 1L;

	public EnrollSegmentSynchronizedEvent(long batchJobId,
			EnrollNotifierEnum enrollNotify, EnrollReceiverEnum enrollReceiver) {
		setBatchJobId(batchJobId);
		setEnrollNotifier(enrollNotify);
		setEnrollReceiver(enrollReceiver);
	}
}
