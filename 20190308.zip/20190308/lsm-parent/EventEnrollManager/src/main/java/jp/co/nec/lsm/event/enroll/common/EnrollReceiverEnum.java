package jp.co.nec.lsm.event.enroll.common;

/**
 * @author mozj
 */
public enum EnrollReceiverEnum {

	// receiver: TME Update Batch Job service
	TemplateManagerBean("TME_TemplateManagerBean"),

	// receiver: TME Enroll Segment Sync Service
	EnrollSegmentSyncService("TME_EnrollSegmentSyncService"),

	// receiver: TME Enroll Response Service
	EnrollResponseService("TME_EnrollResponseService"),

	// receiver: TME PollTimerStart Bean
	EnrollJobPollTimerStarterBean("TME_EnrollJobPollTimerStartBeanService"),

	// receiver: TME PollTimerStart Bean
	EnrollMFEPollTimerStarterBean("TME_EnrollMFEPollTimerStartBeanService"),

	EnrollBatchJobGetterTimerStartBean(
			"TME_EnrollBatchJobGetterTimerStartBeanService"),

	// receiver: TME HeartBeatPollTimerStart Bean
			EnrollHeartbeatStarterBean("TME_EnrollHeartbeatStarterBean");

	private String detailMessage;

	public String getDetailMessage() {
		return detailMessage;
	}

	private EnrollReceiverEnum(String detailMessage) {
		this.detailMessage = detailMessage;
	}
}
