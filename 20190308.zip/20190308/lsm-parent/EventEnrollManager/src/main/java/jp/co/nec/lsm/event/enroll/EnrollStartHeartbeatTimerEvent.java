package jp.co.nec.lsm.event.enroll;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.event.enroll.common.EnrollReceiverEnum;

public class EnrollStartHeartbeatTimerEvent extends EnrollAbstractEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7870751727242049231L;

	private int pollDuraton;
	
	public EnrollStartHeartbeatTimerEvent(int pollDuraton,
			EnrollNotifierEnum enrollNotify, EnrollReceiverEnum enrollReceiver) {
		this.pollDuraton = pollDuraton;
		setEnrollNotifier(enrollNotify);
		setEnrollReceiver(enrollReceiver);
	}
	
	public int getPollDuraton()
	{
		return pollDuraton;
	}
}
