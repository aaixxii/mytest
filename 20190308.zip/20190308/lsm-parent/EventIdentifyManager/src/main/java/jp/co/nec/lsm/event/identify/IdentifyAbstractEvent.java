package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.constants.IdentifyEventConstants;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;

/**
 * @author jimy <br>
 * <br>
 *         this class define the basic of event information <br>
 *         <B>include<B> <br>
 *         * receive target ipAddress <br>
 *         * batch job id <br>
 *         * identify Notifier information <br>
 *         * identify Receiver information <br>
 */
public abstract class IdentifyAbstractEvent implements Event {

	private static final long serialVersionUID = 1L;

	/** jMS Receiver target ipAddress **/
	private String ipAddress = IdentifyEventConstants.DEFAULT_IP_ADDRESS;

	/** batchJobId **/
	private long batchJobId;

	/** identify Notifier information, which service **/
	private IdentifyNotifierEnum identifyNotifier;

	/** identify Receiver information, which service **/
	private IdentifyReceiverEnum identifyReceiver;

	/**
	 * get jMS message selector <br>
	 * the MDB receiver will define the jMS selector like following..<br>
	 * 
	 * <source>@ActivationConfigProperty(propertyName = "messageSelector",
	 * propertyValue = "messageReceiver = 'XXXXXX'")<source>
	 * 
	 * @return messageReceiver
	 */
	@Override
	public String getMessageSelector() {
		return getIdentifyReceiver().name();
	}

	/**
	 * receive target ipAddress <br>
	 * default is localHost(127.0.0.1)
	 * 
	 * @return ipAddress
	 */
	public String getIpAddress() {
		if (null == ipAddress || "".equals(ipAddress)) {
			ipAddress = IdentifyEventConstants.DEFAULT_IP_ADDRESS;
		}
		return ipAddress;
	}

	/**
	 * setIpAddress
	 * 
	 * @param ipAddress
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * define this method in order to output the Notifier and Receiver detail
	 * information conveniently
	 * 
	 * @return String[] Notifier and Receiver detail information
	 */
	@Override
	public String[] getTraceMessage() {
		if (identifyNotifier == null || identifyReceiver == null)
			return null;
		String[] traceMessages = new String[] { "NOTIFIER",
				identifyNotifier.getDetailMessage(), "RECEIVER",
				identifyReceiver.getDetailMessage() };
		return traceMessages;
	}

	@Override
	public long getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	public IdentifyReceiverEnum getIdentifyReceiver() {
		return identifyReceiver;
	}

	public void setIdentifyReceiver(IdentifyReceiverEnum receiver) {
		this.identifyReceiver = receiver;
	}

	public IdentifyNotifierEnum getIdentifyNotifier() {
		return identifyNotifier;
	}

	public void setIdentifyNotifier(IdentifyNotifierEnum notify) {
		this.identifyNotifier = notify;
	}
}
