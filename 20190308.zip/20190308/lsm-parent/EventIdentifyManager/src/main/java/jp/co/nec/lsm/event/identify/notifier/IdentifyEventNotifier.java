package jp.co.nec.lsm.event.identify.notifier;

import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;

/**
 * @author liuyq <br>
 * 
 */
public interface IdentifyEventNotifier {
	/**
	 * send identify system Event using jMS
	 * 
	 * @param event
	 */
	public void sendEvent(IdentifyAbstractEvent event);
}
