package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;

/**
 * @author jimy <br>
 * 
 */
public class IdentifyMergerJobDoneEvent extends IdentifyAbstractEvent {
	private static final long serialVersionUID = 1L;

	public IdentifyMergerJobDoneEvent(long batchJobId,
			IdentifyNotifierEnum identifyNotifier,
			IdentifyReceiverEnum identifyReceiver) {
		setBatchJobId(batchJobId);
		setIdentifyNotifier(identifyNotifier);
		setIdentifyReceiver(identifyReceiver);
	}
}
