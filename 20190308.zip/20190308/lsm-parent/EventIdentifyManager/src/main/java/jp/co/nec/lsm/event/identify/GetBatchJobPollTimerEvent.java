package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;

public class GetBatchJobPollTimerEvent extends IdentifyAbstractEvent {
	private static final long serialVersionUID = 1L;

	public GetBatchJobPollTimerEvent(long batchJobId,
			IdentifyNotifierEnum identifyNotifier,
			IdentifyReceiverEnum identifyReceiver) {
		setBatchJobId(batchJobId);
		setIdentifyNotifier(identifyNotifier);
		setIdentifyReceiver(identifyReceiver);
	}
}
