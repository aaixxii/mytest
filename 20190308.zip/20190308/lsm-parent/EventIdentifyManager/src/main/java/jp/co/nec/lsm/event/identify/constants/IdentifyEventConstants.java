package jp.co.nec.lsm.event.identify.constants;

/**
 * @author liuyq <br>
 *         identify enent
 * 
 */
public final class IdentifyEventConstants {
	/** default local IP address **/
	public static final String DEFAULT_IP_ADDRESS = "127.0.0.1";
}
