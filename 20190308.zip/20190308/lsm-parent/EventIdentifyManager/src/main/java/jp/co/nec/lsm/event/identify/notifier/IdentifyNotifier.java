package jp.co.nec.lsm.event.identify.notifier;

import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyEventRuntimeException;
import jp.co.nec.lsm.event.sender.EventSender;
import jp.co.nec.lsm.event.sender.EventSenderJMSLocalImpl;
import jp.co.nec.lsm.event.sender.EventSenderJMSRemoteImpl;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 * 
 *         this class is selector of identify notifier <br>
 *         TMA and TMI common function <br>
 *         fetch the different EventSender instance base on different receiver <br>
 *         the main difference is send event to different queue <br>
 *         1 aggregation_queue_event (the remote machine) <br>
 *         2 identify_queue_event (local machine) <br>
 *         3 identify_prepare_template_event (local machine) <br>
 */
public class IdentifyNotifier implements IdentifyEventNotifier {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(IdentifyNotifier.class);

	/** the event instance that will be sent **/
	protected IdentifyAbstractEvent event;

	/**
	 * switch different Receiver to build the EventSender instance <br>
	 * using this instance to send the event to target message driver bean<br>
	 */
	@Override
	public void sendEvent(IdentifyAbstractEvent event) {
		printLogMessage("start public function sendEvent.");

		EventSender eventSender = null;

		// switch different Receiver to build the EventSender instance
		switch (event.getIdentifyReceiver()) {

		case IdentifySyncWithAggregationServiceBean:
			eventSender = EventSenderJMSRemoteImpl.getInstance(event
					.getIpAddress(), JNDIConstants.IDENTIFY_QUEUE);
			break;
		case IdentifyBatchJobResultService:
		case AggregationHeartbeatStarterBean:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.AGGREGATION_QUEUE);
			break;
		case IdentifyPrepareTemplateService:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.IDENTIFY_PREPARE_TMEPLATE_QUEUE);
			break;
		case IdentifyJobPollTimerStartBean:
		case IdentifyUSCPollTimerStartBean:
		case BatchJobDeliveryCheckPollTimerStarterBean:
		case GetIdentifyBatchJobPollTimerStarterBean:
		case IdentifyPrepareSegmentJobService:
		case IdentifyHeartbeatStarterBean:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.IDENTIFY_QUEUE);
			break;
		case IdentifyBatchJobResultSendFailedReceiver:
			eventSender = EventSenderJMSRemoteImpl.getInstance(event
					.getIpAddress(), JNDIConstants.IDENTIFY_LAST_EVENT_QUEUE);
			break;		

		default:
			throw new IdentifyEventRuntimeException(
					"the event is not support..");
		}

		eventSender.convertAndSend(event);
		printLogMessage("end public function sendEvent.");

	}

	/**
	 * clear the jMS remote connection cache <br>
	 * when master TMI is down, the slavery TMI will replace <br>
	 * but the connection cache store in TMA remain point the master TMI already
	 * down<br>
	 * this may cause an connection exception<br>
	 * 
	 * after clear the cache, TMA will reconnect to slavery TMI<br>
	 * 
	 * @param event
	 */
	public void clearJmsRemoteConnectionCache(IdentifyAbstractEvent event) {
		EventSenderJMSRemoteImpl.clearJmsCache();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
