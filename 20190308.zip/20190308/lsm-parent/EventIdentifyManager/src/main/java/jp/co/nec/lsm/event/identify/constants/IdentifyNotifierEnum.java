package jp.co.nec.lsm.event.identify.constants;

/**
 * @author liuyq <br>
 * 
 */
public enum IdentifyNotifierEnum {

	// notifier: TMI System Initialization service
	SystemInitializationBean("TMI_SystemInitializationBean"),
	
	TMASystemInitializationBean("TMA_SystemInitializationBean"),
	
	// notifier: TMI Accepted service
	IdentifyAcceptService("TMI_AcceptService"),

	// notifier: TMI PrepareTemplate service
	IdentifyPrepareTemplateService("TMI_PrepareTemplateService"),

	// notifier: TMI PrepareSegmentJob service
	IdentifyPrepareSegmentJobService("TMI_PrepareSegmentJobService"),

	// notifier: TMA SyncAggregation service
	IdentifySyncAggregationService("TMA_SyncAggregationService"),

	// notifier: TMA BatchJobResult service
	IdentifyBatchJobResultService("TMA_BatchJobResultService"),

	// notifier: TMA Poll bean service
	IdentifyTmaPollbeanService("TMA_PollbeanService"),
	
	//notifier: TMI Heartbeat Start bean
	IdentifyHeartbeatStarterBean("TMI_IdentifyHeartbeatStarterBean"),
	//notifier: TMA_DLQ_Service
	AggregationDeadLevelQueueService("TMA_AggregationDeadLevelQueueService"),
	//notifier: TMA Heartbeat Start bean
	AggregationHeartbeatStarterBean("TMA_IdentifyHeartbeatStarterBean")
	;

	private String detailMessage;

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	private IdentifyNotifierEnum(String detailMessage) {
		this.detailMessage = detailMessage;
	}
}
