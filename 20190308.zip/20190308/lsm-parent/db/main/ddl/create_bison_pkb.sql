CREATE OR REPLACE PACKAGE BODY TRANSACTION_MANAGER_API
IS

    -- Application exception error numbers.
    c_error_no_find_segment CONSTANT NUMBER := -20003;
    c_error_optimistic_lock CONSTANT NUMBER := -20005;

    c_segment_head_lenth CONSTANT NUMBER := 20;
    


    /**
     * IdentifyPersonBiometricsDao call this proc to select each top level job's template 
     * from person_biometrics by a list of referenceId.
     */
    PROCEDURE get_batch_templates
    (
        p_batch_job_reference_ids       varchar_table_type,
        p_refcursor OUT sys_refcursor
    )
    IS
    BEGIN
    OPEN p_refcursor FOR
        SELECT 
        /* tmi: get_batch_templates */
            REFERENCE_ID , BIOMETRIC_DATA
        FROM
        /* select template from table PERSON_BIOMETRICS by reference ids */
            PERSON_BIOMETRICS
        WHERE REFERENCE_ID IN (SELECT * FROM TABLE(CAST(p_batch_job_reference_ids AS varchar_table_type)));

        --log_api.debug(g_ctx, 'get_batch_templates returning.');
    EXCEPTION
        WHEN OTHERS THEN
            --log_api.error(g_ctx, 'get_batch_templates failed.');
            RAISE;
    END get_batch_templates;


    /**
     * check reference_id whether existence. 
     */
    PROCEDURE reference_id_check
    (
        p_refcursor         OUT sys_refcursor,
        p_reference_ids     IN  VARCHAR_TABLE_TYPE
    )
    IS
    BEGIN

        OPEN p_refcursor FOR
        SELECT REFERENCE_ID AS REFERENCE_ID FROM PERSON_BIOMETRICS
            /* tme: reference_id_check */
            /* select reference_id from table PERSON_BIOMETRICS by reference ids */
            WHERE REFERENCE_ID IN (SELECT * FROM TABLE(CAST(p_reference_ids AS varchar_table_type)));

    EXCEPTION
        WHEN OTHERS THEN
            --log_api.error(g_ctx, 'get_batch_templates failed.');
            RAISE;
    END reference_id_check;



    /*
     * Helper procedure for add_biometrics_tm, handles the case where a new
     * segment has to be created  for the template being registered. 
     * Add a new segment info into SEGMENTS and its detail version info
     * into SEGMENT_VERSION_DETAIL
     */
    PROCEDURE create_new_segment
    (
        p_segment_length  NUMBER,
        p_start_bio_id    NUMBER,
        p_end_bio_id      NUMBER,
        p_record_count    NUMBER
    )
    IS
        l_segment_id    NUMBER;
        l_new_segment_id NUMBER;
    BEGIN
        -- get segment id.
        l_segment_id := SEGMENTS_SEQ.NEXTVAL;

        -- Add a new segment info into SEGMENTS
        INSERT INTO SEGMENTS
        (
            SEGMENT_ID,
            BIO_ID_START,
            BIO_ID_END,
            BINARY_LENGTH_COMPACTED,
            RECORD_COUNT,
            VERSION,
            GENERATION,
            BINARY_LENGTH_UNCOMPACTED
        )
        /* tme: create_new_segment */
        /* insert a new segment into table SEGMENTS */
        VALUES
        (
            l_segment_id,
            p_start_bio_id,
            p_end_bio_id,
            p_segment_length,
            p_record_count,
            0,
            0,
            p_segment_length
        )
        RETURNING SEGMENT_ID INTO l_new_segment_id;

        --- Add detail version info into SEGMENT_VERSION_DETAIL
        INSERT INTO SEGMENT_VERSION_DETAIL
        (
            SEGMENT_ID,
            VERSION,
            BIO_ID_START,
            BIO_ID_END,
            UPDATE_TS,
            RECORD_COUNT,
            CHANGE_TYPE
        )
        /* tme: create_new_segment */
        /* insert a new segment version detail into table SEGMENT_VERSION_DETAIL */
        VALUES
        (
            l_segment_id,
            0,
            p_start_bio_id,
            p_end_bio_id,
            systimestamp,
            p_record_count,
            0
        );
    EXCEPTION
        WHEN OTHERS THEN
            --log_api.error(g_ctx, 'create_new_segment failed.');
            RAISE;
    END create_new_segment;



    /*
     * Helper procedure for add_biometrics(), handles the case
     * where the template fits in an existing segment.
     * Update a existing segment info into SEGMENTS and
     * add its detail version info into SEGMENT_VERSION_DETAIL
     */
    PROCEDURE update_existing_segment
    (
        p_last_segment_id         NUMBER,
        p_last_segment_length     NUMBER,
        p_start_bio_id            NUMBER,
        p_end_bio_id              NUMBER,
        p_count                   NUMBER,
        p_template_size           NUMBER
    )
    IS
        l_new_end        NUMBER;
        l_new_rec_count  NUMBER;
        l_new_version    NUMBER;
    BEGIN

        IF (p_last_segment_id = -1) THEN
            RAISE_APPLICATION_ERROR(c_error_optimistic_lock,
                    'There is not any data in SEGMENTS table.' , TRUE);
        END IF;

        -- get segment size of the last segment.
        SELECT RECORD_COUNT INTO l_new_rec_count
            /* tme: update_existing_segment */
            /* select recode count of p_last_segment_id fromm SEGMENTS */
            FROM SEGMENTS WHERE SEGMENT_ID = p_last_segment_id;
            
        SELECT VERSION INTO l_new_version 
            /* tme: update_existing_segment */
            /* select version of p_last_segment_id fromm SEGMENTS */
            FROM SEGMENTS WHERE SEGMENT_ID = p_last_segment_id;
            
        SELECT BIO_ID_END INTO l_new_end 
            /* tme: update_existing_segment */
            /* select biometrics end id of p_last_segment_id fromm SEGMENTS */
            FROM SEGMENTS WHERE SEGMENT_ID = p_last_segment_id;

        --- When adding data, both compacted and uncompacted binary lengths go up.
        l_new_rec_count  := l_new_rec_count + p_count;
        l_new_version    := l_new_version + 1;

        IF (l_new_end < p_end_bio_id) THEN
            l_new_end := p_end_bio_id;
        END IF;

        -- Update a existing segment info into SEGMENTS
        UPDATE SEGMENTS
        /* tme: update_existing_segment */
        /* update segment info to table SEGMENTS */
        SET 
            BIO_ID_END    = l_new_end,
            BINARY_LENGTH_COMPACTED  = BINARY_LENGTH_COMPACTED + p_count * p_template_size,
            RECORD_COUNT  = l_new_rec_count,
            VERSION       = l_new_version,
            GENERATION      = l_new_version,
            BINARY_LENGTH_UNCOMPACTED  = p_last_segment_length
        WHERE SEGMENT_ID = p_last_segment_id;

        --- At this point we expect that we are the only ones updating
        --- the segment, so if the insert didn't insert any rows
        --- then somebody else got there first.
        --- Current protocol - raise an exception.
        IF (SQL%ROWCOUNT = 0) THEN
            RAISE_APPLICATION_ERROR(c_error_optimistic_lock, 'Segment ' || p_last_segment_id ||
                    ' changed during update_existing_segment(), orginial revision:' ||
                    (l_new_version - 1) , TRUE);
        END IF;

        --- Add detail version info into SEGMENT_VERSION_DETAIL
        INSERT INTO SEGMENT_VERSION_DETAIL
        (
            SEGMENT_ID,
            VERSION,
            BIO_ID_START,
            BIO_ID_END,
            UPDATE_TS,
            RECORD_COUNT,
            CHANGE_TYPE
        )
        /* tme: update_existing_segment */
        /* insert a new segment version detail into table SEGMENT_VERSION_DETAIL */
        VALUES
        (
            p_last_segment_id,
            l_new_version,
            p_start_bio_id,
            p_end_bio_id,
            systimestamp,
            p_count,
            0
        );
    EXCEPTION
        WHEN OTHERS THEN
            --log_api.error(g_ctx, 'update_existing_segment failed.');
            RAISE;
    END update_existing_segment;


    /**
     * Update an existing segment and create new segment detail record,
     * Or create new segment and create new segment detail record.
     * return new segment detail record count.
     */
    FUNCTION modify_segments
    (
        p_segment_detail_count  IN  NUMBER,
        p_last_segment_id       IN  NUMBER,
        p_last_segment_length   IN  NUMBER,
        p_start_bio_id          IN  NUMBER,
        p_end_bio_id            IN  NUMBER,
        p_count                 IN  NUMBER,
        p_template_size         IN  NUMBER
    ) RETURN NUMBER
    IS
        l_segment_detail_count    NUMBER := 0;
    BEGIN
        l_segment_detail_count := p_segment_detail_count;

        IF (l_segment_detail_count = 0 AND p_last_segment_id != -1)
        THEN
            --- If newly added data + overhead will fit in existing segment.
            update_existing_segment(p_last_segment_id, p_last_segment_length,
            /* tme: add_biometrics call update_existing_segment */
                    p_start_bio_id, p_end_bio_id, p_count, p_template_size);
        ELSE
            --- new template won't fit, need to create a new segment.
            create_new_segment(p_last_segment_length, p_start_bio_id, p_end_bio_id,
            /* tme: add_biometrics cal create_new_segment */
                    p_count);
        END IF;

        l_segment_detail_count := l_segment_detail_count + 1;
        
        RETURN l_segment_detail_count;
    EXCEPTION
        WHEN OTHERS THEN
            --log_api.error(g_ctx, 'modify_segments failed.');
            RAISE;
    END modify_segments;


    /**
     * 
     */
    FUNCTION add_new_biometrics_record
    (
        p_reference_id        IN  VARCHAR2,
        p_biometric_data      IN  BLOB,
        p_bio_date_len        IN  NUMBER,
        p_bio_id              IN  NUMBER
    ) RETURN NUMBER
    IS
        l_insert_flag            NUMBER := 1;
    BEGIN
        l_insert_flag := 1;
            
        INSERT INTO person_biometrics
        (
            biometrics_id,
            reference_id,
            biometric_data,
            biometric_data_len,
            date_added
        )
        /* tme: add_biometrics */
        /* intsert a new recode into table person_biometrics */
        VALUES
        (
            p_bio_id,
            p_reference_id,
            p_biometric_data,
            p_bio_date_len,
            systimestamp
        );
        
        RETURN l_insert_flag;
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            l_insert_flag := 0;
            
            RETURN l_insert_flag;
        WHEN OTHERS THEN
            --log_api.error(g_ctx, 'add_new_biometrics_record failed.');
            RAISE;
    END add_new_biometrics_record;



    /**
     * EnrollPersonBiometricDao call this proc to
     * Registers new data into the system. 
     * Either an existing segment is updated, or a new segment is created.
     */
    PROCEDURE add_biometrics
    (
        p_seg_refcursor    OUT sys_refcursor,
        p_per_refcursor    OUT sys_refcursor,
        p_duplication_ids  OUT VARCHAR_TABLE_TYPE,
        p_reference_ids     IN VARCHAR_TABLE_TYPE,
        p_biometric_data    IN BLOB_TABLE_TYPE
    )
    IS
        l_insert_flag            NUMBER := 1;
        l_bio_id                 NUMBER := 0;
        l_bio_date_len           NUMBER := 0;
        l_last_bio_id            NUMBER := -1;

        l_count                  NUMBER := 0;      -- added data count of person_biometrics

        l_start_bio_id           NUMBER := 0;      -- start biometric id of an segment version detail 
        l_end_bio_id             NUMBER := 0;      -- end biometric id of an segment version detail 
        l_segment_detail_count   NUMBER := 0;      -- added data count of segment version detail
        l_max_segment_size       NUMBER := 0;      -- the max size of a segment

        l_last_segment_length    NUMBER := 0;      -- segment size of last segment
        l_last_segment_version   NUMBER := 0;      -- segment version of last segment
        l_last_segment_id        NUMBER := 0;      -- segment id of last segment
        l_last_segment_count     NUMBER := 0;      -- segment id of last segment

        l_array_count            NUMBER := 0;
        l_segment_id_out         NUMBER := 0;
    BEGIN
        LOCK TABLE PERSON_BIOMETRICS IN EXCLUSIVE MODE;
        
        -- get segment size of the last segment.
        SELECT CASE WHEN MAX(SEGMENT_ID) IS NULL THEN -1 ELSE MAX(SEGMENT_ID) END
        /* tme: add_biometrics */
        /* select max segment id of table SEGMENTS( if null, -1 is selected ) for l_last_segment_id */
            INTO l_last_segment_id FROM SEGMENTS;

        IF l_last_segment_id = -1 THEN 
            l_count := 0;
            l_last_segment_length := 0;
            l_last_segment_version := 0;
        ELSE
            SELECT RECORD_COUNT INTO l_last_segment_count
            /* tme: add_biometrics */
            /* select recode count of l_last_segment_id fromm SEGMENTS */
                FROM SEGMENTS WHERE SEGMENT_ID = l_last_segment_id;
            SELECT BINARY_LENGTH_UNCOMPACTED INTO l_last_segment_length
            /* tme: add_biometrics */
            /* select binary length of l_last_segment_id fromm SEGMENTS */
                FROM SEGMENTS WHERE SEGMENT_ID = l_last_segment_id;
            SELECT VERSION INTO l_last_segment_version
            /* tme: add_biometrics */
            /* select version of l_last_segment_id fromm SEGMENTS */
                FROM SEGMENTS WHERE SEGMENT_ID = l_last_segment_id;
        END IF;

        l_segment_id_out := l_last_segment_id;
        l_last_bio_id := -1;

        --get max size of a sgment.
        SELECT PROPERTY_VALUE INTO l_max_segment_size
        /* tme: add_biometrics */
        /* select max segment size from table SYSTEM_CONFIG */
            FROM SYSTEM_CONFIG WHERE PROPERTY_NAME = 'BEHAVIOR.MAX_SEGMENT_SIZE' AND ROWNUM = 1;
            
        --get template size.
        SELECT PROPERTY_VALUE INTO l_bio_date_len
        /* tme: add_biometrics */
        /* select template size from table SYSTEM_CONFIG */
            FROM SYSTEM_CONFIG WHERE PROPERTY_NAME = 'PERSON_TEMPLATE_SIZE' AND ROWNUM = 1;

        l_max_segment_size := l_max_segment_size - c_segment_head_lenth;

        -- init table
        l_array_count := 0;
        p_duplication_ids := VARCHAR_TABLE_TYPE();

        -- insert all biometric data into person_biometrics and 
        -- update an exiting segment or create a new segment.
        FOR j IN p_reference_ids.first..p_reference_ids.last
        LOOP
            l_bio_id := PERSON_BIOMETRICS_SEQ.NEXTVAL;
            IF (l_last_bio_id = -1)
            THEN
                l_last_bio_id := l_bio_id;
            END IF;
            -- insert one biometric data into person_biometrics
            l_insert_flag := add_new_biometrics_record(p_reference_ids(j), p_biometric_data(j),
                    l_bio_date_len, l_bio_id);

            IF (l_insert_flag = 1)
            THEN
                -- update an exiting segment or create a new segment.
                IF (l_last_segment_length + l_bio_date_len > l_max_segment_size)
                THEN 
                    IF (l_count > 0) 
                    THEN 
                        -- update an exiting segment or create a new segment.
                        l_segment_detail_count := modify_segments(l_segment_detail_count,
                                l_last_segment_id, l_last_segment_length, l_start_bio_id,
                                l_end_bio_id, l_count, l_bio_date_len);
                    ELSE
                        l_last_segment_id := -1;
                    END IF;

                    /* tme: add_biometrics */
                    l_count := 1;
                    l_start_bio_id := l_bio_id;
                    l_end_bio_id := l_bio_id;
                    l_last_segment_length := l_bio_date_len;
                    l_last_segment_count := 1;
                ELSE
                    /* tme: add_biometrics */
                    IF (l_start_bio_id = 0)
                    THEN
                        l_start_bio_id := l_bio_id;
                    END IF;

                    l_end_bio_id := l_bio_id;

                    l_last_segment_length := l_last_segment_length + l_bio_date_len;
                    l_last_segment_count := l_last_segment_count + 1;

                    l_count := l_count + 1;
                END IF;
            ELSE
                p_duplication_ids.extend;
                l_array_count := l_array_count + 1;
                p_duplication_ids(l_array_count) := p_reference_ids(j);
            END IF;
        END LOOP;

        IF (l_count > 0) 
        THEN 
            -- modify segments 
            l_segment_detail_count := modify_segments(l_segment_detail_count,
                    l_last_segment_id, l_last_segment_length, l_start_bio_id,
                    l_end_bio_id, l_count, l_bio_date_len);
        END IF;

        -- get added segment detail info
        OPEN p_seg_refcursor FOR
            SELECT /*+ INDEX(SEGMENT_VERSION_DETAIL SEG_VER_DTL_LOCAL_IDX) */
                 SEGMENT_ID, VERSION, BIO_ID_START, BIO_ID_END
            /* tme: add_biometrics */
            /* select segment version details which are inserted in this time */
            FROM SEGMENT_VERSION_DETAIL
            WHERE (
                    (SEGMENT_ID > l_segment_id_out) OR
                    (SEGMENT_ID = l_segment_id_out AND VERSION > l_last_segment_version)
                  ) AND CHANGE_TYPE = 0
            ORDER BY SEGMENT_ID, VERSION;

        OPEN p_per_refcursor FOR
            SELECT pb.BIOMETRICS_ID, CAST(pb.REFERENCE_ID AS VARCHAR2(64)) AS REFERENCE_ID
            /* tme: add_biometrics */
            /* select reference ids which are inserted in this time */
            FROM PERSON_BIOMETRICS pb
            WHERE pb.BIOMETRICS_ID >= l_last_bio_id
            ORDER BY pb.BIOMETRICS_ID;

    EXCEPTION
        WHEN OTHERS THEN
            -- log_api.error(g_ctx, 'add_biometrics_tm failed');
            RAISE;
    END add_biometrics;



     /**
      * TMEContactTimesSPHelper call this proc to updates the appropriate timestamps
      * in the mu_contacts table for a given PID unit.
      */
    PROCEDURE update_contact_times
    (
        p_mu_id IN NUMBER,
        p_update_heartbeat_flag IN NUMBER,
        p_update_report_flag IN NUMBER
    )
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;
        BEGIN
            IF p_update_heartbeat_flag = 1 AND p_update_report_flag = 1 THEN
              UPDATE  mu_contacts
              /* tm: update_contact_times */
              /* update last_contact_ts and last_report_ts of table mu_contacts */
              SET     last_contact_ts = systimestamp,
                      last_report_ts = systimestamp
              WHERE mu_id = p_mu_id;
            ELSIF p_update_heartbeat_flag = 1 AND p_update_report_flag = 0 THEN
              UPDATE mu_contacts
              /* tm: update_contact_times */
              /* update last_contact_ts of table mu_contacts */
                SET last_contact_ts = systimestamp
                WHERE mu_id = p_mu_id;
            ELSIF p_update_heartbeat_flag = 0 AND p_update_report_flag = 1 THEN
              UPDATE mu_contacts
              /* tm: update_contact_times */
              /* update last_report_ts of table mu_contacts */
                SET last_report_ts = systimestamp
                WHERE mu_id = p_mu_id;
            END IF;
            COMMIT;
    END update_contact_times;



    /**
     * insert extractjob info into ENROLL_JOB_QUEUE
     */
    PROCEDURE insert_extractjob_queue
    (
        p_count            OUT  NUMBER,
        p_extractjob_list   IN  EXTRACTJOB_TABLE_TYPE,
        p_request_list      IN  BLOB_TABLE_TYPE
    )
    IS
        l_count        NUMBER := 0;
        l_extractjob   EXTRACTJOB_OBJECT;
    BEGIN
        FOR i IN p_extractjob_list.first..p_extractjob_list.last
        LOOP
            l_extractjob := p_extractjob_list(i);

            -- insert extractjob info into ENROLL_JOB_QUEUE
            INSERT INTO ENROLL_JOB_QUEUE
            (
                BATCHJOB_ID,
                JOB_INDEX,
                REQUEST_ID,
                REFERENCE_ID,
                RETURN_CODE,
                ERROR_CODE,
                ERROR_MESSAGE,
                RESENDABLE,
                REQUEST
            )
            /* tme: insert_extractjob_queue */
            /* insert extractjob info into ENROLL_JOB_QUEUE */
            VALUES
            (
                l_extractjob.BATCHJOB_ID,
                l_extractjob.JOB_INDEX,
                l_extractjob.REQUEST_ID,
                l_extractjob.REFERENCE_ID,
                l_extractjob.RETURN_CODE,
                l_extractjob.ERROR_CODE,
                l_extractjob.ERROR_MESSAGE,
                l_extractjob.RESENDABLE,
                p_request_list(i)
            );

            l_count := l_count + SQL%ROWCOUNT;

        END LOOP;

        p_count := l_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END insert_extractjob_queue;

/**
     * insert extractjob info into ENROLL_JOB_QUEUE
     */
    PROCEDURE insert_identifyjob_queue
    (
        p_count            OUT  NUMBER,
        p_identifyjob_list   IN  IDENTIFYJOB_TABLE_TYPE,
        p_request_list      IN  BLOB_TABLE_TYPE
    )
    IS
        l_count        NUMBER := 0;
        l_identifyjob   IDENTIFYJOB_OBJECT;
    BEGIN
        FOR i IN p_identifyjob_list.first..p_identifyjob_list.last
        LOOP
            l_identifyjob := p_identifyjob_list(i);

            -- insert identifyjob info into IDENTIFY_JOB_QUEUE
            INSERT INTO IDENTIFY_JOB_QUEUE
            (
                BATCHJOB_ID,
                JOB_INDEX,
                REQUEST_ID,
                REFERENCE_ID,
                REFERENCE_URL,
                MD5_CHECK_SUM,
                MAX_CANDIDATES,
                REQUEST
            )
            /* tme: insert_identifyjob_queue */
            /* insert identifyjob info into IDENTIFY_JOB_QUEUE */
            VALUES
            (
                l_identifyjob.BATCHJOB_ID,
                l_identifyjob.JOB_INDEX,
                l_identifyjob.REQUEST_ID,
                l_identifyjob.REFERENCE_ID,
                l_identifyjob.REFERENCE_URL,
                l_identifyjob.MD5_CHECK_SUM,
                l_identifyjob.MAX_CANDIDATES,
                p_request_list(i)
            );

            l_count := l_count + SQL%ROWCOUNT;

        END LOOP;

        p_count := l_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END insert_identifyjob_queue;

    /**
     * update extractjob result
     */
    PROCEDURE update_extractjob_queue
    (
        p_count             OUT NUMBER,
        p_extractjob_list   IN  EXTRACTJOB_TABLE_TYPE,
        p_response_list     IN  BLOB_TABLE_TYPE
    )
    IS
        l_count        NUMBER := 0;
        l_extractjob   EXTRACTJOB_OBJECT;
    BEGIN
        FOR i IN p_extractjob_list.first..p_extractjob_list.last
        LOOP
            l_extractjob := p_extractjob_list(i);

            -- update extractjob result
            UPDATE ENROLL_JOB_QUEUE
            SET
                RETURN_CODE = l_extractjob.RETURN_CODE,
                ERROR_CODE = l_extractjob.ERROR_CODE,
                ERROR_MESSAGE = l_extractjob.ERROR_MESSAGE,
                RESENDABLE = l_extractjob.RESENDABLE,
                RESPONSE =  p_response_list(i)
            /* tme: update_extractjob_queue */
            /* update extractjob result */
            WHERE BATCHJOB_ID = l_extractjob.BATCHJOB_ID AND JOB_INDEX = l_extractjob.JOB_INDEX;

            l_count := l_count + SQL%ROWCOUNT;

        END LOOP;

        p_count := l_count;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END update_extractjob_queue;




    /**
     * update mu_segment map into mu_segment table
     */
    PROCEDURE update_mu_segment
    (
        p_count           OUT  NUMBER,
        p_unit_type        IN  NUMBER,
        p_mu_segment_map   IN  MUSEGMENT_TABLE_TYPE
    )
    IS
        l_count                NUMBER := 0;
        l_mu_segment_record    MUSEGMENT_OBJECT;
    BEGIN
        LOCK TABLE MU_SEGMENTS IN EXCLUSIVE MODE;

        DELETE FROM MU_SEGMENTS WHERE MU_ID IN (SELECT MU_ID FROM MATCH_UNITS WHERE TYPE = p_unit_type);

        FOR i IN p_mu_segment_map.first..p_mu_segment_map.last
        LOOP
            l_mu_segment_record := p_mu_segment_map(i);

            INSERT INTO MU_SEGMENTS
            (
                MU_ID,
                SEGMENT_ID,
                RANK,
                ASSIGNED_TS
            )
            /* tm: update_mu_segment */
            /* insert mu_segment map info into MU_SEGMENTS */
            VALUES
            (
                l_mu_segment_record.MU_ID,
                l_mu_segment_record.SEGMENT_ID,
                l_mu_segment_record.RANK,
                systimestamp
            );

            l_count := l_count + SQL%ROWCOUNT;
       END LOOP;

        p_count := l_count;
        commit;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END update_mu_segment;


    /*
     * update segment info when delete a registered data.
     */
    PROCEDURE update_segment_info
    (
        p_bio_id              IN  NUMBER,
        p_reference_id        IN  VARCHAR2,
        p_template_size       IN  NUMBER,
        p_segment_id         OUT  NUMBER,
        p_segment_version    OUT  NUMBER
    )
    IS
        l_segment_id               NUMBER := 0;
        l_segment_length           NUMBER := 0;
        l_segment_record_count     NUMBER := 0;
        l_segment_version          NUMBER := 0;
    BEGIN
        SELECT CASE WHEN SEGMENT_ID IS NULL THEN -1 ELSE SEGMENT_ID END INTO l_segment_id
        /* tme: update_segment_info */
        /* select SEGMENT_ID fromm SEGMENTS */
            FROM SEGMENTS WHERE p_bio_id >= BIO_ID_START AND p_bio_id <= BIO_ID_END;

        IF l_segment_id = -1 
        THEN
            RAISE_APPLICATION_ERROR(c_error_no_find_segment,
                'Can not find segment for p_bio_id ' || p_bio_id, TRUE);
        END IF;

        SELECT VERSION INTO l_segment_version
        /* tme: update_segment_info */
        /* select VERSION fromm SEGMENTS */
            FROM SEGMENTS WHERE SEGMENT_ID = l_segment_id;

        l_segment_version := l_segment_version +1;

        UPDATE SEGMENTS
        /* tme: update_segment_info */
        /* update segment info into SEGMENTS */
        SET BINARY_LENGTH_COMPACTED = BINARY_LENGTH_COMPACTED - p_template_size, 
            RECORD_COUNT = RECORD_COUNT - 1,
            GENERATION = l_segment_version, 
            VERSION = l_segment_version
            WHERE SEGMENT_ID = l_segment_id;

        INSERT INTO SEGMENT_VERSION_DETAIL
            (SEGMENT_ID, VERSION, BIO_ID_START, UPDATE_TS, RECORD_COUNT, CHANGE_TYPE, REFERENCE_ID)
            /* tme: update_segment_info */
            /* add segment detail version info into SEGMENT_VERSION_DETAIL */
            VALUES
            (l_segment_id, l_segment_version, p_bio_id, systimestamp, 0, 1, p_reference_id);

        UPDATE /*+ INDEX(SEGMENT_VERSION_DETAIL SEG_VER_DTL_LOCAL_IDX) */ SEGMENT_VERSION_DETAIL
            SET RECORD_COUNT = RECORD_COUNT - 1
            /* tme: update_segment_info */
            /* update segment detail version info into SEGMENT_VERSION_DETAIL */
            WHERE  SEGMENT_ID = l_segment_id AND CHANGE_TYPE = 0
                AND p_bio_id >= BIO_ID_START AND p_bio_id <= BIO_ID_END;

        p_segment_id := l_segment_id;
        p_segment_version := l_segment_version;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END update_segment_info;



    /**
     * Deletes registered data from the system.
     * Removes the data from person_biometrics,
     * and updates all the affected segments.
     */
    PROCEDURE delete_biometrics
    (
        p_delete_count    OUT  NUMBER,
        p_refcursor       OUT  sys_refcursor,
        p_reference_id     IN  VARCHAR2
    )
    IS
        l_bio_id               NUMBER := 0;
        l_delete_count         NUMBER := 0;
        l_segment_id           NUMBER := 0;
        l_segment_version      NUMBER := 0;
        l_mu_segment_record    MUSEGMENT_OBJECT;
        l_template_size        NUMBER := 0;
    BEGIN
        LOCK TABLE PERSON_BIOMETRICS IN EXCLUSIVE MODE;

        SELECT  CASE WHEN MAX(BIOMETRICS_ID) IS NULL THEN -1 ELSE MAX(BIOMETRICS_ID) END
        /* tme: delete_biometrics */
        /* select BIOMETRICS_ID PERSON_BIOMETRICS */
                INTO l_bio_id FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = p_reference_id;

        --get template size.
        SELECT PROPERTY_VALUE INTO l_template_size
        /* tme: add_biometrics */
        /* select template size from table SYSTEM_CONFIG */
            FROM SYSTEM_CONFIG WHERE PROPERTY_NAME = 'PERSON_TEMPLATE_SIZE' AND ROWNUM = 1;

        IF l_bio_id = -1
        THEN
            p_delete_count := 0;
        ELSE
             DELETE FROM PERSON_BIOMETRICS
            /* tme: delete_biometrics */
            /* delete biometrics from PERSON_BIOMETRICS */
                WHERE REFERENCE_ID = p_reference_id;

            -- update segment info when delete a registered data.
            update_segment_info(l_bio_id, p_reference_id, l_template_size, l_segment_id,
                l_segment_version);

            p_delete_count := 1;

        END IF;

        OPEN p_refcursor FOR
            SELECT /*+ INDEX(SEGMENT_VERSION_DETAIL SEG_VER_DTL_LOCAL_IDX) */ 
                SEGMENT_ID, VERSION, BIO_ID_START, BIO_ID_END
                /* tme: delete_biometrics */
                /* select segment version details which are inserted in this time */
                FROM SEGMENT_VERSION_DETAIL
                WHERE SEGMENT_ID = l_segment_id AND VERSION = l_segment_version;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE;
    END delete_biometrics;


END TRANSACTION_MANAGER_API;
/
