CREATE OR REPLACE PACKAGE TRANSACTION_MANAGER_API
IS

    PROCEDURE get_batch_templates
    (
        p_batch_job_reference_ids   IN  varchar_table_type,
        p_refcursor                OUT  sys_refcursor
    );

    /***
     *** Registers new data into the system. 
     *** Either an existing segment is updated, or a new segment is created.
     */
    PROCEDURE add_biometrics
    (
        p_seg_refcursor    OUT  sys_refcursor,
        p_per_refcursor    OUT  sys_refcursor,
        p_duplication_ids  OUT  VARCHAR_TABLE_TYPE,
        p_reference_ids     IN  VARCHAR_TABLE_TYPE,
        p_biometric_data    IN  BLOB_TABLE_TYPE
    );

    PROCEDURE update_contact_times
    (
        p_mu_id IN NUMBER,
        p_update_heartbeat_flag  IN  NUMBER,
        p_update_report_flag     IN  NUMBER
    );

    /***
     *** check reference_id whether existence. 
     */
    PROCEDURE reference_id_check
    (
        p_refcursor        OUT  sys_refcursor,
        p_reference_ids     IN  VARCHAR_TABLE_TYPE
    );
    
    
    /***
     ***  insert extractjob info into ENROLL_JOB_QUEUE
     */
    PROCEDURE insert_extractjob_queue
    (
        p_count            OUT  NUMBER,
        p_extractjob_list   IN  EXTRACTJOB_TABLE_TYPE,
        p_request_list      IN  BLOB_TABLE_TYPE
    );

    /***
     ***  insert extractjob info into IDENTIFY_JOB_QUEUE
     */
    PROCEDURE insert_identifyjob_queue
    (
        p_count            OUT  NUMBER,
        p_identifyjob_list   IN  IDENTIFYJOB_TABLE_TYPE,
        p_request_list      IN  BLOB_TABLE_TYPE
    );

    /***
     ***  update extractjob result
     */
    PROCEDURE update_extractjob_queue
    (
        p_count            OUT  NUMBER,
        p_extractjob_list   IN  EXTRACTJOB_TABLE_TYPE,
        p_response_list     IN  BLOB_TABLE_TYPE
    );


    /***
     ***  update mu_segment map into mu_segment table
     */
    PROCEDURE update_mu_segment
    (
        p_count           OUT  NUMBER,
        p_unit_type        IN  NUMBER,
        p_mu_segment_map   IN  MUSEGMENT_TABLE_TYPE
    );
    
    
    
    /***
     *** Deletes registered data from the system.
     *** Removes the data from person_biometrics,
     *** and updates all the affected segments.
     */
    PROCEDURE delete_biometrics
    (
        p_delete_count    OUT  NUMBER,
        p_refcursor       OUT  sys_refcursor,
        p_reference_id     IN  VARCHAR2
    );

END ;
/
