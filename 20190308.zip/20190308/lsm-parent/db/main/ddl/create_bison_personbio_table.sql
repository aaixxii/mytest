
CREATE TABLE PERSON_BIOMETRICS
(
    BIOMETRICS_ID                  NUMBER(28,0) NOT NULL,
    REFERENCE_ID                   CHAR(36) NOT NULL,
    BIOMETRIC_DATA                 BLOB NOT NULL,
    BIOMETRIC_DATA_LEN             NUMBER NOT NULL,
    DATE_ADDED                     TIMESTAMP(6) DEFAULT systimestamp NOT NULL,
    CORRUPTED_FLAG                 NUMBER(1,0) DEFAULT 0 NOT NULL,
    CONSTRAINT BIOMETRICS_ID_PK PRIMARY KEY (BIOMETRICS_ID) USING INDEX
)
MAXTRANS 255
PARTITION BY RANGE(BIOMETRICS_ID)
    (
		  PARTITION PERSON_BIOMETRICS_P001 VALUES LESS THAN (10000000) TABLESPACE BISON_BIOMETRICS_DATA_001
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_001  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_001
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P002 VALUES LESS THAN (20000000) TABLESPACE BISON_BIOMETRICS_DATA_002
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_002  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_002
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P003 VALUES LESS THAN (30000000) TABLESPACE BISON_BIOMETRICS_DATA_003
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_003  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_003
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P004 VALUES LESS THAN (40000000) TABLESPACE BISON_BIOMETRICS_DATA_004
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_004  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_004
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P005 VALUES LESS THAN (50000000) TABLESPACE BISON_BIOMETRICS_DATA_005
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_005  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_005
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P006 VALUES LESS THAN (60000000) TABLESPACE BISON_BIOMETRICS_DATA_006
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_006  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_006
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P007 VALUES LESS THAN (70000000) TABLESPACE BISON_BIOMETRICS_DATA_007
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_007  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_007
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P008 VALUES LESS THAN (80000000) TABLESPACE BISON_BIOMETRICS_DATA_008
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_008  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_008
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P009 VALUES LESS THAN (90000000) TABLESPACE BISON_BIOMETRICS_DATA_009
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_009  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_009
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P010 VALUES LESS THAN (100000000) TABLESPACE BISON_BIOMETRICS_DATA_010
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_010  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_010
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P011 VALUES LESS THAN (110000000) TABLESPACE BISON_BIOMETRICS_DATA_011
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_011  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_011
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P012 VALUES LESS THAN (120000000) TABLESPACE BISON_BIOMETRICS_DATA_012
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_012  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_012
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P013 VALUES LESS THAN (130000000) TABLESPACE BISON_BIOMETRICS_DATA_013
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_013  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_013
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P014 VALUES LESS THAN (140000000) TABLESPACE BISON_BIOMETRICS_DATA_014
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_014  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_014
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P015 VALUES LESS THAN (150000000) TABLESPACE BISON_BIOMETRICS_DATA_015
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_015  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_015
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P016 VALUES LESS THAN (160000000) TABLESPACE BISON_BIOMETRICS_DATA_016
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_016  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_016
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P017 VALUES LESS THAN (170000000) TABLESPACE BISON_BIOMETRICS_DATA_017
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_017  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_017
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P018 VALUES LESS THAN (180000000) TABLESPACE BISON_BIOMETRICS_DATA_018
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_018  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_018
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P019 VALUES LESS THAN (190000000) TABLESPACE BISON_BIOMETRICS_DATA_019
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_019  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_019
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P020 VALUES LESS THAN (200000000) TABLESPACE BISON_BIOMETRICS_DATA_020
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_020  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_020
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P021 VALUES LESS THAN (210000000) TABLESPACE BISON_BIOMETRICS_DATA_021
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_021  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_021
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P022 VALUES LESS THAN (220000000) TABLESPACE BISON_BIOMETRICS_DATA_022
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_022  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_022
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P023 VALUES LESS THAN (230000000) TABLESPACE BISON_BIOMETRICS_DATA_023
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_023  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_023
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P024 VALUES LESS THAN (240000000) TABLESPACE BISON_BIOMETRICS_DATA_024
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_024  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_024
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P025 VALUES LESS THAN (250000000) TABLESPACE BISON_BIOMETRICS_DATA_025
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_025  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_025
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P026 VALUES LESS THAN (260000000) TABLESPACE BISON_BIOMETRICS_DATA_026
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_026  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_026
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P027 VALUES LESS THAN (270000000) TABLESPACE BISON_BIOMETRICS_DATA_027
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_027  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_027
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P028 VALUES LESS THAN (280000000) TABLESPACE BISON_BIOMETRICS_DATA_028
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_028  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_028
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P029 VALUES LESS THAN (290000000) TABLESPACE BISON_BIOMETRICS_DATA_029
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_029  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_029
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P030 VALUES LESS THAN (300000000) TABLESPACE BISON_BIOMETRICS_DATA_030
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_030  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_030
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P031 VALUES LESS THAN (310000000) TABLESPACE BISON_BIOMETRICS_DATA_031
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_031  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_031
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P032 VALUES LESS THAN (320000000) TABLESPACE BISON_BIOMETRICS_DATA_032
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_032  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_032
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P033 VALUES LESS THAN (330000000) TABLESPACE BISON_BIOMETRICS_DATA_033
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_033  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_033
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P034 VALUES LESS THAN (340000000) TABLESPACE BISON_BIOMETRICS_DATA_034
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_034  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_034
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P035 VALUES LESS THAN (350000000) TABLESPACE BISON_BIOMETRICS_DATA_035
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_035  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_035
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P036 VALUES LESS THAN (360000000) TABLESPACE BISON_BIOMETRICS_DATA_036
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_036  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_036
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P037 VALUES LESS THAN (370000000) TABLESPACE BISON_BIOMETRICS_DATA_037
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_037  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_037
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P038 VALUES LESS THAN (380000000) TABLESPACE BISON_BIOMETRICS_DATA_038
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_038  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_038
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P039 VALUES LESS THAN (390000000) TABLESPACE BISON_BIOMETRICS_DATA_039
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_039  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_039
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P040 VALUES LESS THAN (400000000) TABLESPACE BISON_BIOMETRICS_DATA_040
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_040  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_040
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P041 VALUES LESS THAN (410000000) TABLESPACE BISON_BIOMETRICS_DATA_041
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_041  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_041
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P042 VALUES LESS THAN (420000000) TABLESPACE BISON_BIOMETRICS_DATA_042
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_042  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_042
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P043 VALUES LESS THAN (430000000) TABLESPACE BISON_BIOMETRICS_DATA_043
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_043  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_043
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P044 VALUES LESS THAN (440000000) TABLESPACE BISON_BIOMETRICS_DATA_044
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_044  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_044
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P045 VALUES LESS THAN (450000000) TABLESPACE BISON_BIOMETRICS_DATA_045
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_045  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_045
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P046 VALUES LESS THAN (460000000) TABLESPACE BISON_BIOMETRICS_DATA_046
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_046  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_046
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P047 VALUES LESS THAN (470000000) TABLESPACE BISON_BIOMETRICS_DATA_047
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_047  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_047
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P048 VALUES LESS THAN (480000000) TABLESPACE BISON_BIOMETRICS_DATA_048
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_048  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_048
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P049 VALUES LESS THAN (490000000) TABLESPACE BISON_BIOMETRICS_DATA_049
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_049  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_049
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P050 VALUES LESS THAN (500000000) TABLESPACE BISON_BIOMETRICS_DATA_050
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_050  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_050
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P051 VALUES LESS THAN (510000000) TABLESPACE BISON_BIOMETRICS_DATA_051
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_051  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_051
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P052 VALUES LESS THAN (520000000) TABLESPACE BISON_BIOMETRICS_DATA_052
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_052  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_052
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P053 VALUES LESS THAN (530000000) TABLESPACE BISON_BIOMETRICS_DATA_053
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_053  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_053
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P054 VALUES LESS THAN (540000000) TABLESPACE BISON_BIOMETRICS_DATA_054
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_054  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_054
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P055 VALUES LESS THAN (550000000) TABLESPACE BISON_BIOMETRICS_DATA_055
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_055  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_055
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P056 VALUES LESS THAN (560000000) TABLESPACE BISON_BIOMETRICS_DATA_056
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_056  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_056
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P057 VALUES LESS THAN (570000000) TABLESPACE BISON_BIOMETRICS_DATA_057
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_057  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_057
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P058 VALUES LESS THAN (580000000) TABLESPACE BISON_BIOMETRICS_DATA_058
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_058  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_058
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P059 VALUES LESS THAN (590000000) TABLESPACE BISON_BIOMETRICS_DATA_059
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_059  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_059
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P060 VALUES LESS THAN (600000000) TABLESPACE BISON_BIOMETRICS_DATA_060
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_060  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_060
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P061 VALUES LESS THAN (610000000) TABLESPACE BISON_BIOMETRICS_DATA_061
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_061  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_061
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P062 VALUES LESS THAN (620000000) TABLESPACE BISON_BIOMETRICS_DATA_062
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_062  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_062
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P063 VALUES LESS THAN (630000000) TABLESPACE BISON_BIOMETRICS_DATA_063
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_063  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_063
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P064 VALUES LESS THAN (640000000) TABLESPACE BISON_BIOMETRICS_DATA_064
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_064  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_064
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P065 VALUES LESS THAN (650000000) TABLESPACE BISON_BIOMETRICS_DATA_065
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_065  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_065
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P066 VALUES LESS THAN (660000000) TABLESPACE BISON_BIOMETRICS_DATA_066
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_066  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_066
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P067 VALUES LESS THAN (670000000) TABLESPACE BISON_BIOMETRICS_DATA_067
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_067  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_067
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P068 VALUES LESS THAN (680000000) TABLESPACE BISON_BIOMETRICS_DATA_068
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_068  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_068
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P069 VALUES LESS THAN (690000000) TABLESPACE BISON_BIOMETRICS_DATA_069
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_069  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_069
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P070 VALUES LESS THAN (700000000) TABLESPACE BISON_BIOMETRICS_DATA_070
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_070  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_070
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P071 VALUES LESS THAN (710000000) TABLESPACE BISON_BIOMETRICS_DATA_071
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_071  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_071
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P072 VALUES LESS THAN (720000000) TABLESPACE BISON_BIOMETRICS_DATA_072
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_072  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_072
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P073 VALUES LESS THAN (730000000) TABLESPACE BISON_BIOMETRICS_DATA_073
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_073  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_073
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P074 VALUES LESS THAN (740000000) TABLESPACE BISON_BIOMETRICS_DATA_074
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_074  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_074
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P075 VALUES LESS THAN (750000000) TABLESPACE BISON_BIOMETRICS_DATA_075
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_075  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_075
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P076 VALUES LESS THAN (760000000) TABLESPACE BISON_BIOMETRICS_DATA_076
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_076  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_076
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P077 VALUES LESS THAN (770000000) TABLESPACE BISON_BIOMETRICS_DATA_077
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_077  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_077
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P078 VALUES LESS THAN (780000000) TABLESPACE BISON_BIOMETRICS_DATA_078
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_078  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_078
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P079 VALUES LESS THAN (790000000) TABLESPACE BISON_BIOMETRICS_DATA_079
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_079  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_079
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P080 VALUES LESS THAN (800000000) TABLESPACE BISON_BIOMETRICS_DATA_080
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_080  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_080
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P081 VALUES LESS THAN (810000000) TABLESPACE BISON_BIOMETRICS_DATA_081
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_081  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_081
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P082 VALUES LESS THAN (820000000) TABLESPACE BISON_BIOMETRICS_DATA_082
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_082  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_082
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P083 VALUES LESS THAN (830000000) TABLESPACE BISON_BIOMETRICS_DATA_083
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_083  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_083
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P084 VALUES LESS THAN (840000000) TABLESPACE BISON_BIOMETRICS_DATA_084
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_084  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_084
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P085 VALUES LESS THAN (850000000) TABLESPACE BISON_BIOMETRICS_DATA_085
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_085  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_085
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P086 VALUES LESS THAN (860000000) TABLESPACE BISON_BIOMETRICS_DATA_086
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_086  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_086
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P087 VALUES LESS THAN (870000000) TABLESPACE BISON_BIOMETRICS_DATA_087
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_087  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_087
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P088 VALUES LESS THAN (880000000) TABLESPACE BISON_BIOMETRICS_DATA_088
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_088  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_088
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P089 VALUES LESS THAN (890000000) TABLESPACE BISON_BIOMETRICS_DATA_089
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_089  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_089
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P090 VALUES LESS THAN (900000000) TABLESPACE BISON_BIOMETRICS_DATA_090
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_090  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_090
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P091 VALUES LESS THAN (910000000) TABLESPACE BISON_BIOMETRICS_DATA_091
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_091  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_091
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P092 VALUES LESS THAN (920000000) TABLESPACE BISON_BIOMETRICS_DATA_092
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_092  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_092
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P093 VALUES LESS THAN (930000000) TABLESPACE BISON_BIOMETRICS_DATA_093
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_093  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_093
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P094 VALUES LESS THAN (940000000) TABLESPACE BISON_BIOMETRICS_DATA_094
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_094  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_094
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P095 VALUES LESS THAN (950000000) TABLESPACE BISON_BIOMETRICS_DATA_095
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_095  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_095
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P096 VALUES LESS THAN (960000000) TABLESPACE BISON_BIOMETRICS_DATA_096
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_096  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_096
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P097 VALUES LESS THAN (970000000) TABLESPACE BISON_BIOMETRICS_DATA_097
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_097  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_097
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P098 VALUES LESS THAN (980000000) TABLESPACE BISON_BIOMETRICS_DATA_098
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_098  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_098
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P099 VALUES LESS THAN (990000000) TABLESPACE BISON_BIOMETRICS_DATA_099
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_099  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_099
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P100 VALUES LESS THAN (1000000000) TABLESPACE BISON_BIOMETRICS_DATA_100
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_100  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_100
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P101 VALUES LESS THAN (1010000000) TABLESPACE BISON_BIOMETRICS_DATA_101
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_101  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_101
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P102 VALUES LESS THAN (1020000000) TABLESPACE BISON_BIOMETRICS_DATA_102
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_102  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_102
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P103 VALUES LESS THAN (1030000000) TABLESPACE BISON_BIOMETRICS_DATA_103
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_103  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_103
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P104 VALUES LESS THAN (1040000000) TABLESPACE BISON_BIOMETRICS_DATA_104
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_104  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_104
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P105 VALUES LESS THAN (1050000000) TABLESPACE BISON_BIOMETRICS_DATA_105
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_105  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_105
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P106 VALUES LESS THAN (1060000000) TABLESPACE BISON_BIOMETRICS_DATA_106
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_106  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_106
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P107 VALUES LESS THAN (1070000000) TABLESPACE BISON_BIOMETRICS_DATA_107
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_107  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_107
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P108 VALUES LESS THAN (1080000000) TABLESPACE BISON_BIOMETRICS_DATA_108
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_108  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_108
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P109 VALUES LESS THAN (1090000000) TABLESPACE BISON_BIOMETRICS_DATA_109
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_109  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_109
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
		, PARTITION PERSON_BIOMETRICS_P110 VALUES LESS THAN (1100000000) TABLESPACE BISON_BIOMETRICS_DATA_110
            LOB (BIOMETRIC_DATA) STORE AS SECUREFILE PERSON_BIO_DATA_SEG_110  (
                TABLESPACE  BISON_BIOMETRICS_LOB_DATA_110
                ENABLE      STORAGE IN ROW
                CHUNK       16384
                RETENTION   AUTO
                NOCACHE
                LOGGING
                STORAGE (
                            INITIAL          64M
                            MINEXTENTS       1
                            MAXEXTENTS       UNLIMITED
                            PCTINCREASE      0
                            BUFFER_POOL      DEFAULT
               )
           ) 
	)
ENABLE ROW MOVEMENT;
