
spool create_tablespaces.log

prompt
prompt Creating tablespaces for SEG_VER_DETAIL_DATA...

CREATE  TABLESPACE BISON_SEG_VER_DETAIL_DATA
    DATAFILE
    '&&bison_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for DM_SEG_VER_DETAIL_DATA...

CREATE  TABLESPACE BISON_DM_SEG_VER_DETAIL_DATA
    DATAFILE 
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED,
    '&&bison_dm_seg_ver_diskgroup' SIZE 4G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

