#!/bin/bash 

CREATE_JOB_Q_SCRIPT=ddl/create_bison_jobq_table.sql
CREATE_JOB_Q_SCRIPT_SEED=seed/create_bison_jobq_table_sql_seed.txt
PARTITION_SIZE=30
LINE_BREAK_REPLACE_CH="<N>"

function echo_create_bjq_tab_partition_key() {
	local day_of_partition_name=$1
	local day_of_partition_key=$2
	local job_type=$3

	echo -n "        PARTITION ${job_type}_BJ_P${day_of_partition_name} VALUES LESS THAN (TO_DATE('${day_of_partition_key} 00:00:00', 'DD-MM-YYYY HH24.MI.SS')) TABLESPACE BISON_ENROLL_BJ_DATA $LINE_BREAK_REPLACE_CH"
}

function echo_create_bjq_tab_partition_option() {
	local cur_number=$1
	local last_number=$2
	local line=""

	if [ $cur_number != $last_number ]; then
		line=$LINE_BREAK_REPLACE_CH
	fi
		
	echo -n "        PCTFREE  10 $LINE_BREAK_REPLACE_CH"
	echo -n "        INITRANS 1 $LINE_BREAK_REPLACE_CH"
	echo -n "        MAXTRANS 255 $LINE_BREAK_REPLACE_CH"
	echo -n "        LOGGING $LINE_BREAK_REPLACE_CH"
	echo -n "        STORAGE  $LINE_BREAK_REPLACE_CH"
	echo -n "        ( $LINE_BREAK_REPLACE_CH"
	echo -n "            INITIAL     64M  $LINE_BREAK_REPLACE_CH"
	echo -n "            MINEXTENTS  1 $LINE_BREAK_REPLACE_CH"
	echo -n "            MAXEXTENTS  UNLIMITED $LINE_BREAK_REPLACE_CH"
	echo -n "            PCTINCREASE 0 $LINE_BREAK_REPLACE_CH"
	echo -n "            BUFFER_POOL DEFAULT $LINE_BREAK_REPLACE_CH"
	echo -n "        ) $line"
}

function echo_create_bjq_tab() {
	local job_type=$1
	local partition_num=$2
	local day_of_partition_name=""
	local day_of_partition_key=""

	for i in `seq 1 $partition_num`
	do
		day_of_partition_name=`calc_day_of_partition_name $i`
		day_of_partition_key=`cal_day_of_partition_key $i` 
		echo_create_bjq_tab_partition_key $day_of_partition_name $day_of_partition_key $job_type
		echo_create_bjq_tab_partition_option $i $partition_num
		echo_conma_of_partition_separate $i $partition_num
	done
}


function echo_conma_of_partition_separate() {
	local cur_number=$1
	local last_number=$2

	if [ $cur_number != $last_number ]; then
		echo -n "        ,$LINE_BREAK_REPLACE_CH"
	fi
}
		
function calc_day_of_partition_name() {
	local how_long_target_day_from_today=$1
	local today=`date +'%Y%m%d'`
	date -d "$how_long_target_day_from_today day $today" +'%Y%m%d'
}

function cal_day_of_partition_key() {
	local how_long_target_day_from_today=$1
	local today=`date +'%Y%m%d'`
	date -d "$how_long_target_day_from_today day $today" +'%d-%m-%Y'
}

function create_partition_define_line() {
	local partition_define_txt=""

	for job_type in ENROLL IDENTIFY
	do
		partition_define_txt=`echo_create_bjq_tab $job_type $PARTITION_SIZE`
		replace_partition_define_line $job_type "$partition_define_txt"
	done
}

function replace_partition_define_line() {
	local job_type=$1
	local partition_define_txt=$2

	sed "s/<${job_type}_PARTITION_DEFINE>/${partition_define_txt}/g" $CREATE_JOB_Q_SCRIPT > tmp
	cat tmp > $CREATE_JOB_Q_SCRIPT
	rm -f tmp
}
	

function copy_job_q_creation_seed_script() {
	cp -f $CREATE_JOB_Q_SCRIPT_SEED $CREATE_JOB_Q_SCRIPT
}

function replace_line_break() {
	cat $CREATE_JOB_Q_SCRIPT | sed "s/$LINE_BREAK_REPLACE_CH/\n/g" > tmp 
	cat tmp > $CREATE_JOB_Q_SCRIPT
	rm -f tmp
}

function main() {
	clear
	copy_job_q_creation_seed_script
	create_partition_define_line 
	replace_line_break 
}

main
