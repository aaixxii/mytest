
spool create_tablespaces.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

accept bison_person_bio_diskgroup char prompt 'Enter ASM disk group to create PERSON_BIO tablespaces (need heading plus):';
accept bison_seg_ver_diskgroup char prompt 'Enter ASM disk group to create SEGMENT_VERSION_DETAIL tablespaces (need heading plus):';
accept bison_dm_seg_ver_diskgroup char prompt 'Enter ASM disk group to create DM_SEGMENT_VERSION_DETAIL tablespaces (need heading plus):';
accept bison_ssdgroup char prompt 'Enter ASM ssd group to create JOB_QUEUE and default tablespaces (need heading plus):';

prompt Create BISON Tablespaces

@ddl/create_bison_system_tablespaces.sql
@ddl/create_bison_seg_ver_detail_tablespaces.sql
@ddl/create_bison_personbio_tablespaces.sql

prompt
prompt Success creating Tablespaces!!
prompt

exit success;
