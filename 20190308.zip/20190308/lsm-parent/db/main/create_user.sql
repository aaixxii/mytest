
spool create_user.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

accept bison_user char prompt 'Enter BISON database username:';
accept bison_pwd  char prompt 'Enter BISON database user password:';

----------------------------------------------
prompt
prompt Creating BISON schema owner...
prompt

create user          &&bison_user 
identified by        &&bison_pwd 
default tablespace   BISON_SYSTEM_DATA
temporary tablespace temp;

grant connect to                   &&bison_user;
grant resource to                  &&bison_user;
grant unlimited tablespace to      &&bison_user;

--- ### TEMPORARY GRANT
grant dba                       to &&bison_user;

prompt
prompt Success creating BISON user!!
prompt

exit success;
