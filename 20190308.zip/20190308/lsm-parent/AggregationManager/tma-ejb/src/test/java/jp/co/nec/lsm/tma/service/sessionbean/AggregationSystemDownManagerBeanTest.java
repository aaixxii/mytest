package jp.co.nec.lsm.tma.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationSystemDownManagerBeanTest {
    
    @Resource
    private DataSource dataSource;

	@Resource
	private AggregationSystemDownManagerBean systemDownManagerBean;
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager manager;
	private TransactionManagerHelper tmaHelper;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@PostConstruct
	public void init() {
		tmaHelper = new TransactionManagerHelper(manager, dataSource, TMType.TMA);
	}

	@Test
	public void testShutdown() {
		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity ame = tmaHelper.createOrLookupVersion(now, "2.3.0");
		assertNotSame(ame.getState(), TmState.EXITED);
		systemDownManagerBean.shutdown();
		now = DateUtil.getCurrentDate();
		ame = tmaHelper.lookup();
		assertEquals(ame.getState(), TmState.EXITED);
	}

}
