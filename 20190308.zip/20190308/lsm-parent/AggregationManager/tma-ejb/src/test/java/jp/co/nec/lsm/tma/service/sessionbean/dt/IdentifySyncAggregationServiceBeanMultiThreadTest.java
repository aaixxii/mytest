package jp.co.nec.lsm.tma.service.sessionbean.dt;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;
import jp.co.nec.lsm.tma.common.util.TMASwitchUtil;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.service.pojo.IdentifySyncAggregationServiceBean;
import jp.co.nec.lsm.tma.service.sessionbean.BatchSegmentJobMapInitializerBean;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;
import junit.framework.Assert;

import org.databene.contiperf.PerfTest;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

/**
 * 
 */
public class IdentifySyncAggregationServiceBeanMultiThreadTest {

	private BatchSegmentJobMapInitializerRemote batchSegmentJobMapInitializerBean;
	private IdentifySyncAggregationServiceBean identifySyncAggregationServiceBean;

	private BatchSegmentJobManager queueManager;

	private final static long bJobIdStart = 10000;
	private final static long bJobCount = 5;
	private final static int jobIdStart = 100;
	private final static int jobCount = 1000;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 20;
	private final static int segmentEachCount = 10;
	private final static int maxCandidate = 10;

	@Rule
	public ContiPerfRule i = new ContiPerfRule();

	public IdentifySyncAggregationServiceBeanMultiThreadTest() {
		batchSegmentJobMapInitializerBean = new BatchSegmentJobMapInitializerBean();
		identifySyncAggregationServiceBean = new IdentifySyncAggregationServiceBean();
	}

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
		BatchSegmentJobMap batchSegmentJobMap = null;
		for (long i = bJobIdStart; i < bJobIdStart + bJobCount; i++) {
			// create BatchSegmentJobMap data
			batchSegmentJobMap = UtilCreateData.createBatchSegmentJobMapData(i,
					jobIdStart, jobCount, maxCandidate, segmentIdStart,
					segmentCount);
			batchSegmentJobMapInitializerBean
					.receiveBatchJobAndInitSpace(batchSegmentJobMap);
		}

		Assert
				.assertEquals(queueManager.getIdentifyResults().size(),
						bJobCount);
		Assert.assertEquals(queueManager.getBatchSegmentJobMaps().size(),
				bJobCount);
	}

	@After
	public void tearDown() throws Exception {
		queueManager.clear();
	}

	@Test
	@PerfTest(invocations = 200, threads = 5)
	public void testMergeIdentifyResult() {
		for (long i = bJobIdStart; i < bJobCount; i++) {
			try {
				// create IdentifyResult data
				IdentifyResult identifyResult = UtilCreateData
						.createIdentifyResultData(i, jobIdStart, jobCount,
								maxCandidate, segmentIdStart, segmentEachCount,
								maxCandidate, ReSendable.EMPTY);

				Assert.assertNotNull(queueManager.getBatchSegmentJobMap(i));
				Assert.assertNotNull(queueManager.getIdentifyResult(i));

				identifySyncAggregationServiceBean
						.mergeIdentifyResult(TMASwitchUtil
								.switchIdentifyResult(identifyResult));

				Assert.assertNotNull(queueManager.getBatchSegmentJobMap(i));
				Assert.assertNotNull(queueManager.getIdentifyResult(i));
				Assert.assertEquals(queueManager.getIdentifyResults().size(),
								1);
				Assert.assertTrue(0 != queueManager.getIdentifyResult(i)
						.getSearchJobResults().get(jobIdStart).getCandidates()
						.get(1).getScaledScore());
			} catch (Exception e) {
				if (e instanceof TMRuntimeException) {
					Assert.assertNotNull(queueManager
							.getBatchSegmentJobMap(i));
					Assert.assertNotNull(queueManager
							.getIdentifyResult(i));
				} else {
					throw new AggregationRuntimeException(e.getMessage());
				}
			}
		}
	}

}
