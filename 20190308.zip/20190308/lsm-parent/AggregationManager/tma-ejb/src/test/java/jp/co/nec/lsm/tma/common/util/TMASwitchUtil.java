package jp.co.nec.lsm.tma.common.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.AmrInfo;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.AMRState;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

public final class TMASwitchUtil {

	/**
	 * switch IdentifyResult to IdentifyResultRequest
	 * 
	 * @param identifyResult
	 * @return
	 */
	public final static IdentifyJobResultRequest switchIdentifyResult(
			IdentifyResult identifyResult) {
		IdentifyJobResultRequest.Builder jobResultRequestBuilder = IdentifyJobResultRequest
				.newBuilder();
		jobResultRequestBuilder.setGmvId(1000);
		jobResultRequestBuilder.setReadCount(0L);
		jobResultRequestBuilder.setBatchJobId(identifyResult.getBatchJobId())
				.addAllSegmentId(identifyResult.getSegmentIds());

		IdentifyJobResultRequestProto.IdentifyJobResult.Builder jobResultBuilder;

		for (IdentifyJobResult jobResult : identifyResult.getSearchJobResults()
				.values()) {
			if (null != jobResult) {
				jobResultBuilder = IdentifyJobResultRequestProto.IdentifyJobResult
						.newBuilder();

				AMRState state = jobResult.getaMRState();

				AmrInfo.Builder amrInfo = AmrInfo.newBuilder();
				amrInfo.setFace(Long.parseLong(state.getFaceActualCount()));
				amrInfo.setFinger(Long.parseLong(state.getFingerActualCount()));
				amrInfo.setIrisLeft(Long.parseLong(state
						.getIris_leftActualCount()));
				amrInfo.setIrisRight(Long.parseLong(state
						.getIris_rightActualCount()));
				amrInfo.setMfm1(Long.parseLong(state.getMfm_1ActualCount()));
				amrInfo.setMfm2(Long.parseLong(state.getMfm_2ActualCount()));
				amrInfo.setRead(Long.parseLong(state.getReadActualCount()));
				amrInfo.setPassed1St(Long.parseLong(state
						.getPassedFActualCount()));
				amrInfo.setPassed2Nd(Long.parseLong(state
						.getPassedSActualCount()));
				amrInfo.setPassed3Rd(Long.parseLong(state
						.getPassedTActualCount()));

				jobResultBuilder.setJobIndex(jobResult.getJobIndex())
						.setReturnCode(jobResult.getReturnCode())
						.addAllCandidate(jobResult.getCandidates())
						.setAmrInfo(amrInfo);

				jobResultRequestBuilder.addIdentifyJobResult(jobResultBuilder);
			}
		}
		return jobResultRequestBuilder.build();
	}

	/**
	 * candidate ObjectArrayList to Object array
	 * 
	 * @param candidateList
	 * @return
	 */
	public static Object[] switchCandidates(
			ObjectArrayList<Candidate> candidateList) {
		return candidateList.elements();
	}

}
