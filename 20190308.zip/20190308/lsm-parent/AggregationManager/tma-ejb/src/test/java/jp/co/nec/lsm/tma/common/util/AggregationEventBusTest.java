package jp.co.nec.lsm.tma.common.util;

import java.util.List;

import javax.jms.JMSException;

import org.jboss.util.Strings;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidate;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidateList;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.exception.EventRuntimeException;
import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.IdentifyMergerJobDoneEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.event.identify.notifier.IdentifyNotifier;
import jp.co.nec.lsm.event.sender.AbstractEventSender;
import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestBuilder;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestSender;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import mockit.Mock;
import mockit.MockUp;


public class AggregationEventBusTest {

	private BatchSegmentJobManager queueManager;
	private final static long bJobIdStart = 10000;
	private final static int jobIdStart = 1;
	private final static int bJobCount = 2;
	private final static int jobCount = 100;
	private final static int maxCandidate = 10;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 2000;

	// memory Scores
	public final static int[] memoryScores = { 9999, 8888, 7777, 6666, 5555,
			4444, 3333, 2222, 1111, 1000 };

	@Before
	public void setUp() throws Exception {

		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();

		// create memory data
		IdentifyResult identifyResult = null;
		BatchSegmentJobMap batchSegmentJobMap = null;
		for (int i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobIdStart, jobCount, memoryScores,
					segmentCount, maxCandidate);
			batchSegmentJobMap = UtilCreateData.createBatchSegmentJobMapData(
					bJobIdStart + i, jobIdStart, jobCount, maxCandidate,
					segmentIdStart, segmentCount);
			batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.RUNNING);
			queueManager.add(batchSegmentJobMap);
			queueManager.add(identifyResult);
			identifyResult = null;
		}
	}

	@After
	public void tearDown() throws Exception {
		queueManager.clear();
	}
	
	@Test
	public void testnotifyIdentifyBatchjobSendFailed_OK() {		
		long batchJobId = 1000l;		
		String tmiIP = "127.0.0.1";
		
		IdentifyAbstractEvent testEvent = null;
		testEvent = new IdentifyMergerJobDoneEvent(
					batchJobId,
					IdentifyNotifierEnum.IdentifyBatchJobResultService,
					IdentifyReceiverEnum.IdentifyBatchJobResultSendFailedReceiver);
		testEvent.setIpAddress(tmiIP);
		
		new MockUp<AbstractEventSender>() {
			@Mock
			public void convertAndSend(Event testEvent){	
				return ;
			}			
		};		
		boolean success = AggregationEventBus.notifyIdentifyBatchjobSendFailed(batchJobId, tmiIP);
		Assert.assertTrue(success);
	}
	
	@Test
	public void testnotifyIdentifyBatchjobSendFailed_failed() {		
		
		long batchJobId = 1000l;		
		String tmiIP = "127.0.0.1";
		
		IdentifyAbstractEvent testEvent = null;
		testEvent = new IdentifyMergerJobDoneEvent(
					batchJobId,
					IdentifyNotifierEnum.IdentifyBatchJobResultService,
					IdentifyReceiverEnum.IdentifyBatchJobResultSendFailedReceiver);
		testEvent.setIpAddress(tmiIP);
		
		new MockUp<AbstractEventSender>() {
			@Mock
			public void convertAndSend(Event testEvent){
				String errorMessage = "JMSException while queueing HTTP JMS Message";
				JMSException e = new JMSException(errorMessage);
				throw new EventRuntimeException(errorMessage, e);
				
			}			
		};		
		boolean failed = AggregationEventBus.notifyIdentifyBatchjobSendFailed(batchJobId, tmiIP);
		Assert.assertFalse(failed);	
	}

	@Test
	public void sendBatchSegmentJobMapToTMITmaIpnull() {
		Assert.assertFalse(AggregationEventBus.sendBatchSegmentJobMapToTMI(
				null, null));
	}

	private void setNotifyException() {
		new MockUp<IdentifyNotifier>() {
			@SuppressWarnings("unused")
			@Mock
			public void sendEvent(IdentifyAbstractEvent event) {
				int a = 1 / 0;
			}
		};
	}

	@Test
	public void sendBatchSegmentJobMapToTMINotifyException() {
		setNotifyException();
		BatchSegmentJobMap batchSegmentJobMap = new BatchSegmentJobMap();
		batchSegmentJobMap.setbJobId(121212L);
		Assert.assertFalse(AggregationEventBus.sendBatchSegmentJobMapToTMI(
				batchSegmentJobMap, "192.168.1.1"));
	}

	@Test
	public void notifyBatchjobDoneException() {
		setNotifyException();
		BatchSegmentJobMap batchSegmentJobMap = new BatchSegmentJobMap();
		batchSegmentJobMap.setbJobId(121212L);
		AggregationEventBus.notifyBatchjobDone(1212L);
	}

	private void setSend500Mock() {
		new MockUp<IdentifyResultRequestSender>() {
			@Mock
			public HttpResponse sendIdentifyResponse(
					IdentifyResultRequest identifyResponse, String url,
					Integer timeout) {
				HttpResponse response = new HttpResponse();
				response.setHttpResponseCode(500);
				response.setHttpResponseErrorMessage("test response error");
				return response;
			}
		};
	}

	@Test
	public void sendIdentifyResponseToTransformer500() {
		setSend500Mock();
		IdentifyResult identifyResult = queueManager
				.getIdentifyResult(bJobIdStart);
		boolean failed ;
		try {
			failed = AggregationEventBus.sendIdentifyResponseToTransformer(
					identifyResult, "", 1000);
		} catch (AggregationRuntimeException ex) {
			Assert.assertEquals(ex.getMessage(), "test response error");
			return;
		}
		Assert.assertFalse(failed);
	}

	@Test
	public void testcreateIdentifyResultRequest() {
		IdentifyResult identifyResult = queueManager
				.getIdentifyResult(bJobIdStart);
		IdentifyResultRequest identifyResultRequest = IdentifyResultRequestBuilder
				.createIdentifyResultRequest(identifyResult);
		Assert.assertEquals(bJobIdStart, identifyResultRequest.getBatchJobId());
		Assert.assertEquals(jobCount,
				identifyResultRequest.getBusinessMessageCount());

		try {
			for (int i = 0; i < jobCount; i++) {
				CPBBusinessMessage businessMsg = CPBBusinessMessage
						.parseFrom(identifyResultRequest.getBusinessMessage(i));
				// CPBRequest
				Assert.assertEquals("RequestId-" + (i + jobIdStart),
						businessMsg.getRequest().getRequestId());
				Assert.assertEquals(E_REQUESET_TYPE.CLEAR, businessMsg
						.getRequest().getRequestType());

				// CPBResponse
				Assert.assertEquals("0", businessMsg.getResponse().getStatus());
				Assert.assertEquals(Strings.EMPTY, businessMsg.getResponse()
						.getErrorMessage());

				// CPBDataBlock
				CPBDataBlock dataBlock = businessMsg.getDataBlock();

				// CPBCandidateList
				CPBCandidateList candidateList = dataBlock.getCandidateList();
				Assert.assertEquals(maxCandidate,
						candidateList.getCandidatesCount());
				Assert.assertEquals(false, candidateList.getMore());

				// CPBCandidate
				CPBCandidate c = candidateList.getCandidates(0);
				Assert.assertEquals(3, c.getScoreCount());
				Assert.assertEquals(memoryScores[0], c.getScaledScore());
			}
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSendTransformerHasEmptyCandidate() {
		// init
		queueManager.clear();

		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart, jobIdStart,
						jobCount, maxCandidate, segmentIdStart, segmentCount);
		queueManager.add(batchSegmentJobMap);

		int[] memoryScores = { 9999, 8888, 7777, 6666, 5555, 4444, 3333, 2222,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE };
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(bJobIdStart, jobIdStart, jobCount,
						memoryScores, segmentCount, maxCandidate);
		queueManager.add(identifyResult);

		// assert
		try {
			identifyResult = queueManager.getIdentifyResult(bJobIdStart);

			Assert.assertEquals(maxCandidate + 1, identifyResult
					.getSearchJobResults().get(0).getCandidates().size());

			IdentifyResultRequest identifyResultRequest = IdentifyResultRequestBuilder
					.createIdentifyResultRequest(identifyResult);
			for (int i = 0; i < jobCount; i++) {
				CPBBusinessMessage businessMsg = CPBBusinessMessage
						.parseFrom(identifyResultRequest.getBusinessMessage(i));
				// CPBDataBlock
				CPBDataBlock dataBlock = businessMsg.getDataBlock();
				// CPBCandidateList
				CPBCandidateList candidateList = dataBlock.getCandidateList();

				Assert.assertTrue(maxCandidate > candidateList
						.getCandidatesCount());
				Assert.assertEquals(8, candidateList.getCandidatesCount());
				Assert.assertEquals(false, candidateList.getMore());
			}
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSendTransformerAllEmptyCandidate() {
		// init
		queueManager.clear();

		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart, jobIdStart,
						jobCount, maxCandidate, segmentIdStart, segmentCount);
		queueManager.add(batchSegmentJobMap);

		int[] memoryScores = { Integer.MIN_VALUE, Integer.MIN_VALUE,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE };
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(bJobIdStart, jobIdStart, jobCount,
						memoryScores, segmentCount, maxCandidate,
						ReturnCode.JobFailed, ReSendable.YES);

		queueManager.add(identifyResult);

		// assert
		try {
			identifyResult = queueManager.getIdentifyResult(bJobIdStart);

			Assert.assertEquals(maxCandidate + 1, identifyResult
					.getSearchJobResults().get(0).getCandidates().size());

			IdentifyResultRequest identifyResultRequest = IdentifyResultRequestBuilder
					.createIdentifyResultRequest(identifyResult);
			for (int i = 0; i < jobCount; i++) {
				CPBBusinessMessage businessMsg = CPBBusinessMessage
						.parseFrom(identifyResultRequest.getBusinessMessage(i));
				// reSendable
				Assert.assertTrue(businessMsg.getResponse().hasResendable());
				Assert.assertEquals(businessMsg.getResponse().getResendable(),
						ReSendable.YES.getContent());

				// CPBDataBlock
				CPBDataBlock dataBlock = businessMsg.getDataBlock();

				Assert.assertFalse(dataBlock.hasCandidateList());

			}
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSendTransformerAMRInfo() {
		// init
		queueManager.clear();

		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart, jobIdStart,
						jobCount, maxCandidate, segmentIdStart, segmentCount);
		queueManager.add(batchSegmentJobMap);

		int[] memoryScores = { Integer.MIN_VALUE, Integer.MIN_VALUE,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE,
				Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE };
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(bJobIdStart, jobIdStart, jobCount,
						memoryScores, segmentCount, maxCandidate,
						ReturnCode.JobSuccess, ReSendable.EMPTY);

		queueManager.add(identifyResult);

		// assert
		try {
			identifyResult = queueManager.getIdentifyResult(bJobIdStart);

			Assert.assertEquals(maxCandidate + 1, identifyResult
					.getSearchJobResults().get(0).getCandidates().size());

			IdentifyResultRequest identifyResultRequest = IdentifyResultRequestBuilder
					.createIdentifyResultRequest(identifyResult);
			for (int i = 0; i < jobCount; i++) {
				CPBBusinessMessage businessMsg = CPBBusinessMessage
						.parseFrom(identifyResultRequest.getBusinessMessage(i));
				// CPBDataBlock
				CPBDataBlock dataBlock = businessMsg.getDataBlock();

				// reSendable
				Assert.assertFalse(businessMsg.getResponse().hasResendable());

				int DataGroupCont = dataBlock.getDataGroupCount();
				Assert.assertEquals(1, DataGroupCont);
				CPBDataGroup dataGroup = dataBlock.getDataGroupList().get(0);
				List<CPBDataElement> elements = dataGroup.getDataElementList();

				for (CPBDataElement element : elements) {
					String name = element.getElementName();

					if (name.equals("face") || name.equals("finger")
							|| name.equals("iris-left")
							|| name.equals("passed-first")) {
						Assert.assertEquals(String.valueOf(i),
								element.getElementValue());
					} else if (name.equals("iris-right")
							|| name.equals("passed-second")) {
						Assert.assertEquals(String.valueOf(i * 2),
								element.getElementValue());
					} else if (name.equals("passed-third")) {
						Assert.assertEquals(String.valueOf(i * 3),
								element.getElementValue());
					} else {
						Assert.assertEquals(String.valueOf(0),
								element.getElementValue());
					}
				}

				// Assert.assertFalse(dataBlock.hasCandidateList());

			}
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
	}

}
