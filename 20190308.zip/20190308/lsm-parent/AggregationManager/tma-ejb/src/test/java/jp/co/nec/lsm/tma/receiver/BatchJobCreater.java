package jp.co.nec.lsm.tma.receiver;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.LongArraySet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

import org.jboss.util.Strings;


public class BatchJobCreater {		
	
	public IdentifyResult createBatchJobResult(Long batchJobId,Integer jobIndex) {		 
		 String requestId = "requestIdForTest_00000010";
		 String referenceId = "referenceIdForTest_00000010";
		 int maxCandidate = 30;
		 ReturnCode returnCode = ReturnCode.JobSuccess;
	         String errorCode = Strings.EMPTY;	
		 boolean isOverMaxCandidates = false;
		 String errorMessage = Strings.EMPTY;
	     IdentifyJobResult topResult = new IdentifyJobResult();
	     topResult.setJobIndex(jobIndex);
	     topResult.setRequestId(requestId);
	     topResult.setReferenceId(referenceId);
	     topResult.setOverMaxCandidates(isOverMaxCandidates);
	     topResult.setMaxCandidate(maxCandidate);
	     topResult.setReturnCode(returnCode);
	     topResult.setErrorMessage(errorMessage);
	     topResult.setErrorCode(errorCode);	   
	     Int2ObjectArrayMap<IdentifyJobResult> mySearchJobResults =
	    		 new Int2ObjectArrayMap<IdentifyJobResult>();
	     mySearchJobResults.put(jobIndex, topResult);
	     LongArraySet segmentIds = new LongArraySet() ;
	     for (int j = 0 ; j < 50 ; j++) {
	    	 segmentIds.add(j);
	     }
	     long readCount = 30l;		     
	     IdentifyResult batchResult = new IdentifyResult();
	     batchResult.setBatchJobId(batchJobId);
	     batchResult.setSearchJobResults(mySearchJobResults);
	     batchResult.getReadCount();
	     batchResult.setReadCount(readCount); 
		return batchResult;
		
	}
	
	public BatchSegmentJobMap createBatchSegmentJobMap(Long batchJobId,Integer jobIndex) {
		SearchJobInfo jobInfo = new SearchJobInfo(); 
		List<SearchJobInfo> topSearchJobInfos = new ArrayList<SearchJobInfo>();
		topSearchJobInfos.add(jobIndex, jobInfo);
		SegmentMap testMap = new SegmentMap();		
		Map<Long, SegmentMap> topSegmentMaps = new HashMap<Long, SegmentMap>();	
		topSegmentMaps.put(10L, testMap);
		BatchJobMapStatus testBatchJobStatus = BatchJobMapStatus.TMA_WORKING_DONE;		
		BatchSegmentJobMap testSegmentJobMap = new BatchSegmentJobMap();
		testSegmentJobMap.setbJobId(batchJobId);
		testSegmentJobMap.setBatchJobStatus(testBatchJobStatus);
		testSegmentJobMap.setSegmentMaps(topSegmentMaps);
		testSegmentJobMap.setSearchJobInfos(topSearchJobInfos);	
			 
		return testSegmentJobMap;		
	}
}
