package jp.co.nec.lsm.tma.core.score;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectCollection;

import java.util.List;
import java.util.UUID;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tma.common.util.TMASwitchUtil;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.merger.TopLevelInfoMerger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 */
public class TopLevelCandidateMergerTest {

	private static Logger log = LoggerFactory
			.getLogger(TopLevelCandidateMergerTest.class);

	private final static long bJobIdStart = 10000;
	private final static int jobIdStart = 0;
	private final static int bJobCount = 2;
	private final static int jobCount = 100;
	private final static int maxCandidate = 10;
	private final static int segmentCount = 2000;
	private final static int segmentEachCount = 10;

	private BatchSegmentJobManager queueManager;

	// memory Scores
	public final static int[] memoryScores = { 9999, 8888, 7777, 6666, 5555,
			4444, 3333, 2222, 1111, 1000 };
	public final static int[] initMemoryScores = { Integer.MIN_VALUE,
			Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE,
			Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE,
			Integer.MIN_VALUE, Integer.MIN_VALUE, Integer.MIN_VALUE };

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();

		// create memory data
		IdentifyResult identifyResult = null;
		for (int i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobIdStart, jobCount, memoryScores,
					segmentCount, maxCandidate);

			queueManager.add(identifyResult);
			identifyResult = null;
		}
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testMergeTopLevelCandidates() {
		// merge Scores
		int[] mergeScores = { 9990, 8888, 7770, 6666, 5550, 4440, 3330, 2220,
				1110, 0 };
		// expectedMergedValues Scores
		int[] expectedMergedValues = { 9999, 9990, 8888, 8888, 7777, 7770,
				6666, 6666, 5555, 5550 };

		long mergeBJobId = bJobIdStart + 1;
		// modify memory data
		IdentifyResult identifyResultSpecial = queueManager
				.getIdentifyResult(mergeBJobId);
		identifyResultSpecial.getSearchJobResults().put(
				jobIdStart + jobCount - 1, null);
		identifyResultSpecial.getSearchJobResults()
				.get(jobIdStart + jobCount - 2).setMaxCandidate(0);
		identifyResultSpecial.getSearchJobResults()
				.get(jobIdStart + jobCount - 3)
				.setCandidates(new ObjectArrayList<Candidate>());
		identifyResultSpecial.getSearchJobResults()
				.get(jobIdStart + jobCount - 4)
				.setReturnCode(ReturnCode.JobSuccess);

		// create merge data
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(mergeBJobId, jobIdStart, jobCount,
						mergeScores, segmentEachCount, maxCandidate);
		identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 4)
				.setReturnCode(ReturnCode.JobFailed);
		identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 5)
				.setCandidates(new ObjectArrayList<Candidate>());

		TopLevelInfoMerger.mergeTopLevel(
				queueManager.getIdentifyResult(mergeBJobId),
				TMASwitchUtil.switchIdentifyResult(identifyResult));

		// check
		identifyResult = queueManager.getIdentifyResult(mergeBJobId);
		Object[] cs = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		int[] mergedScores = new int[memoryScores.length];
		for (int i = 0; i < memoryScores.length; i++) {
			mergedScores[i] = ((Candidate) cs[i]).getScaledScore();
		}

		// expectedMergedValues Scores
		Assert.assertArrayEquals(expectedMergedValues, mergedScores);
	}

	@Test
	public void testMergeTopLevelCandidate() {
		// merge Scores
		int[] mergeScoresMin = { 999, 888, 777, 666, 555, 444, 333, 222, 111, 0 };
		int[] mergeScores = { 9990, 8888, 7770, 6666, 5550, 4440, 3330, 2220,
				1110, 0 };
		// expectedMergedValues Scores
		int[] expectedMergedValues = { 9999, 9990, 8888, 8888, 7777, 7770,
				6666, 6666, 5555, 5550 };

		List<Candidate> candidateListMU = UtilCreateData
				.createCandidatesData(mergeScores);
		ObjectArrayList<Candidate> candidateList = UtilCreateData
				.createCandidatesData(memoryScores);

		Object[] candidates = candidateList.elements();

		long startTime = System.nanoTime();
		TopLevelCandidateMerger.mergeTopLevelCandidate(candidates,
				candidates.length, candidateListMU, candidateListMU.size());
		long endTime = System.nanoTime();

		log.debug("jp.co.nec.lsm.tma.core.MergeTopLevelCandidate.mergeTopLevelCandidate function: "
				+ (endTime - startTime) / 1000000.000);

		int[] mergedScore = new int[10];

		for (int i = 0; i < candidates.length; i++) {
			mergedScore[i] = ((Candidate) candidates[i]).getScaledScore();
		}

		Assert.assertArrayEquals(expectedMergedValues, mergedScore);

		//
		candidateListMU = UtilCreateData.createCandidatesData(mergeScoresMin);
		candidateList = UtilCreateData.createCandidatesData(memoryScores);

		candidates = candidateList.elements();

		startTime = System.nanoTime();
		TopLevelCandidateMerger.mergeTopLevelCandidate(candidates,
				candidates.length, candidateListMU, candidateListMU.size());
		endTime = System.nanoTime();

		log.debug("jp.co.nec.lsm.tma.core.MergeTopLevelCandidate.mergeTopLevelCandidate function: "
				+ (endTime - startTime) / 1000000.000);

		mergedScore = new int[10];

		for (int i = 0; i < candidates.length; i++) {
			mergedScore[i] = ((Candidate) candidates[i]).getScaledScore();
		}

		Assert.assertArrayEquals(memoryScores, mergedScore);
	}

	@Test
	public void testMergeTopLevelCandidatesHasSameScore() {
		// merge Scores
		int[] mergeScores = { 9990, 8888, 7770, 6666, 5550, 4440, 3330, 2220,
				1110, 0 };
		// expectedMergedValues Scores
		int[] expectedMergedValues = { 9999, 9990, 8888, 8888, 7777, 7770,
				6666, 6666, 5555, 5550 };

		long mergeBJobId = bJobIdStart + 1;
		// create merge data
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(mergeBJobId, jobIdStart, jobCount,
						mergeScores, segmentEachCount, maxCandidate);

		TopLevelInfoMerger.mergeTopLevel(
				queueManager.getIdentifyResult(mergeBJobId),
				TMASwitchUtil.switchIdentifyResult(identifyResult));

		// check
		identifyResult = queueManager.getIdentifyResult(mergeBJobId);
		Object[] cs = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		int[] mergedScores = new int[memoryScores.length];
		for (int i = 0; i < memoryScores.length; i++) {
			mergedScores[i] = ((Candidate) cs[i]).getScaledScore();
		}
		// expectedMergedValues Scores
		Assert.assertArrayEquals(expectedMergedValues, mergedScores);
	}

	@Test
	public void testMergeTopLevelCandidatesMUEmpty() {
		int[] mergeScoresEmpty = {};

		long mergeBJobId = bJobIdStart + 1;
		// create merge data
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(mergeBJobId, jobIdStart, jobCount,
						mergeScoresEmpty, segmentEachCount, maxCandidate);

		TopLevelInfoMerger.mergeTopLevel(
				queueManager.getIdentifyResult(mergeBJobId),
				TMASwitchUtil.switchIdentifyResult(identifyResult));

		// check
		identifyResult = queueManager.getIdentifyResult(mergeBJobId);
		Object[] cs = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		int[] mergedScores = new int[memoryScores.length];
		for (int i = 0; i < memoryScores.length; i++) {
			mergedScores[i] = ((Candidate) cs[i]).getScaledScore();
		}
		// forecast Scores
		Assert.assertArrayEquals(memoryScores, mergedScores);
	}

	@Test
	public void testMergeTopLevelCandidatesMUAllEmpty() {
		int[] mergeScoresEmpty = {};

		long mergeBJobId = bJobIdStart + 1;
		queueManager.clear();
		// create memory data
		IdentifyResult identifyResult = null;
		for (int i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobIdStart, jobCount, initMemoryScores,
					segmentCount, maxCandidate);

			queueManager.add(identifyResult);
			identifyResult = null;
		}

		// create merge data
		identifyResult = UtilCreateData.createIdentifyResultData(mergeBJobId,
				jobIdStart, jobCount, mergeScoresEmpty, segmentEachCount,
				maxCandidate);

		TopLevelInfoMerger.mergeTopLevel(
				queueManager.getIdentifyResult(mergeBJobId),
				TMASwitchUtil.switchIdentifyResult(identifyResult));

		// check
		identifyResult = queueManager.getIdentifyResult(mergeBJobId);
		Object[] cs = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		int[] mergedScores = new int[memoryScores.length];
		for (int i = 0; i < memoryScores.length; i++) {
			mergedScores[i] = ((Candidate) cs[i]).getScaledScore();
		}
		// expectedMergedValues Scores
		Assert.assertArrayEquals(initMemoryScores, mergedScores);
	}

	@Test
	public void testReferenceIdAndScore() {
		int[] expectedMergedValues = { 9999, 9990, 8888, 7777, 7770, 6666,
				6666, 5555, 5550, 4444 };
		int[] mergeScores = { 9990, 8888, 7770, 6666, 5550, 4440, 3330, 2220,
				1110, 1 };

		long mergeBJobId = bJobIdStart + 1;

		String[] referenceIds = new String[mergeScores.length];

		String referenceIdExpect = "ReferenceId-"
				+ UUID.randomUUID().toString();
		System.out.println("referenceIdExpect: " + referenceIdExpect);

		for (int i = 0; i < mergeScores.length; i++) {
			if (i == 1) {
				ObjectCollection<IdentifyJobResult> jobResultValues = queueManager
						.getIdentifyResult(mergeBJobId).getSearchJobResults()
						.values();
				for (IdentifyJobResult jobResult : jobResultValues) {
					referenceIds[i] = referenceIdExpect;
					Candidate c = jobResult.getCandidates().get(i).toBuilder()
							.setReferenceId(referenceIdExpect).build();
					jobResult.getCandidates().set(i, c);
				}
			} else {
				referenceIds[i] = "ReferenceId-" + UUID.randomUUID().toString();
			}
		}

		// create merge data
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(mergeBJobId, jobIdStart, jobCount,
						referenceIds, mergeScores, segmentEachCount,
						maxCandidate);

		TopLevelInfoMerger.mergeTopLevel(
				queueManager.getIdentifyResult(mergeBJobId),
				TMASwitchUtil.switchIdentifyResult(identifyResult));

		// check
		identifyResult = queueManager.getIdentifyResult(mergeBJobId);
		Object[] cs = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		int[] mergedScores = new int[expectedMergedValues.length];
		for (int i = 0; i < expectedMergedValues.length; i++) {
			mergedScores[i] = ((Candidate) cs[i]).getScaledScore();
		}
		// forecast Scores
		Assert.assertArrayEquals(expectedMergedValues, mergedScores);
	}
}
