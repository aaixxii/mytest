package jp.co.nec.lsm.tma.timer;

import javax.ejb.EJB;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationHeartbeatStarterBeanTest {
	boolean isNotNull = false;
	@EJB
	private AggregationHeartbeatPollBean pollBean;

	@EJB
	private AggregationHeartbeatStarterBean timerStartBean;

	/**
	 * setMockMethod
	 */
	public void setJMSMockMethod() {
		new MockUp<ServiceLocator>() {
			@SuppressWarnings( { "unchecked" })
			@Mock
			public <T> T getLookUpJndiObject(String jndiName, Class<T> clazz) {
				if (isNotNull) {
					return (T) pollBean;
				}
				throw new AggregationRuntimeException("Test Exception");
			}
		};
	}

	@Test
	public void testTimeOut_NotBound() {
		isNotNull = false;
		setJMSMockMethod();

		timerStartBean.startTimer(10000);

		timerStartBean.timeout(null);
	}

	@Test
	public void testTimeOut_Bound() {
		isNotNull = true;
		setJMSMockMethod();

		timerStartBean.startTimer(10000);
		timerStartBean.timeout(null);
		timerStartBean.timeout(null);
	}

}
