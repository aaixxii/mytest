package jp.co.nec.lsm.tma.core.score;

import it.unimi.dsi.fastutil.objects.ObjectCollection;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tma.common.util.TMASwitchUtil;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.merger.TopLevelInfoMerger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 */
public class TopLevelCandidateMergerThreadTest {

	private final static long bJobIdStart = 10000;
	private final static int jobIdStart = 0;
	private final static int bJobCount = 2;
	private final static int jobCount = 100;
	private final static int maxCandidate = 10;
	private final static int segmentEachCount = 10;
	private final static int threadCount = 10;

	private BatchSegmentJobManager queueManager;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testMergeTopLevelCandidates() {
		// create memory data
		int[] memoryScores = { 9999, 8888, 7777, 6666, 5555, 4444, 3333, 2222,
				1111, 1 };
		IdentifyResult identifyResult = null;
		for (int i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobIdStart, jobCount, memoryScores,
					segmentEachCount, maxCandidate);

			// set maxCandidate
			ObjectCollection<IdentifyJobResult> SearchJobResults = identifyResult
					.getSearchJobResults().values();
			for (IdentifyJobResult jobInfo : SearchJobResults) {
				jobInfo.setMaxCandidate(maxCandidate);
			}

			queueManager.add(identifyResult);
			identifyResult = null;
		}
		long mergeBJobId = bJobIdStart + 1;

		// merge data
		ExecutorService service = Executors.newFixedThreadPool(threadCount);
		int[] mergeScores = memoryScores.clone();

		for (int i = 0; i < threadCount; i++) {
			for (int j = 0; j < memoryScores.length; j++) {
				mergeScores[j] = mergeScores[j] - 1;
			}
			service.execute(new MergeThread(mergeBJobId, mergeScores.clone()));
		}

		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		service.shutdown();

		// check
		identifyResult = queueManager.getIdentifyResult(mergeBJobId);
		Object[] candidates = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		List<Integer> mergedScoreList = new ArrayList<Integer>();
		for (Object candidate : candidates) {
			mergedScoreList.add(((Candidate) candidate).getScaledScore());
		}

		Integer[] mergedScores = new Integer[memoryScores.length];
		mergedScoreList.toArray(mergedScores);
		mergedScoreList = null;

		// // expectedMergedValues Scores
		Integer[] expectedMergedValues = { 9999, 9998, 9997, 9996, 9995, 9994,
				9993, 9992, 9991, 9990 };

		Assert.assertArrayEquals(expectedMergedValues, mergedScores);
	}

	class MergeThread extends Thread {

		private long mergeBJobId;
		private int[] mergeScores;

		public MergeThread(long mergeBJobId, int[] mergeScores) {
			this.mergeBJobId = mergeBJobId;
			this.mergeScores = mergeScores;
		}

		@Override
		public void run() {
			IdentifyResult identifyResult = UtilCreateData
					.createIdentifyResultData(mergeBJobId, jobIdStart,
							jobCount, mergeScores, segmentEachCount,
							maxCandidate);
			TopLevelInfoMerger.mergeTopLevel(
					queueManager.getIdentifyResult(mergeBJobId),
					TMASwitchUtil.switchIdentifyResult(identifyResult));
		}
	}
}
