package jp.co.nec.lsm.tma.db.entityhelpers;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationManagerHelperTest {
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;

	@Resource
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Test
	public void testCreateOrLookup() {
		clearRecord();
		TransactionManagerHelper mmHelper = new TransactionManagerHelper(
				entityManager, dataSource, TMType.TMA);
		TransactionManagerEntity tma = new TransactionManagerEntity();
		tma.setUniqueId("192.168.0.12");
		tma.setState(TmState.WORKING);
		tma.setLastHeartbeatTs(DateUtil.getCurrentDate());
		tma.setLastPollTs(DateUtil.getCurrentDate());
		tma.setContactUrl("http://localhost:8080/aggregationmanager");
		tma.setVersion("2.1.0");
		entityManager.persist(tma);

		TransactionManagerEntity actualMM = mmHelper.createOrLookup(DateUtil
				.getCurrentDate(), "2.1.0");
		assertEquals(tma.getVersion(), actualMM.getVersion());
	}

	private void clearRecord() {
		String insertSegments = "delete from TRANSACTION_MANAGERS";
		jdbcTemplate.execute(insertSegments);
	}
}
