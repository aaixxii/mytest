package jp.co.nec.lsm.tma.core.jobs;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.LongArraySet;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.BSJobStatus;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BatchSegmentJobManagerTest {

	private BatchSegmentJobManager queueManager;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testGetInstance() {
		assertTrue(null != queueManager);
	}

	@Test
	public void testAddBatchSegmentJobMap() {
		queueManager.add(new BatchSegmentJobMap());
		assertTrue(1 == queueManager.getBatchSegmentJobMaps().size());
	}

	@Test
	public void testprintBatchSegmentJobMap() {
		final long batchJobId = 1200L;
		IdentifyResult res = new IdentifyResult();
		res.setBatchJobId(batchJobId);
		queueManager.add(res);
		Map<Long, BatchSegmentJobMap> batchSJobMap = new HashMap<Long, BatchSegmentJobMap>();
		batchSJobMap.put(batchJobId, newBatchSegmentJobMap(batchJobId));
		String str = BatchSegmentJobManager
				.printBatchSegmentJobMap(batchSJobMap);
		assertTrue(200 < str.length());
	}

	@Test
	public void testAddIdentifyResult() {
		queueManager.add(new IdentifyResult());
		assertTrue(1 == queueManager.getIdentifyResults().size());
	}

	@Test
	public void testRemove() {
		final long batchJobId = 0L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		queueManager.add(newIdentifyResult(batchJobId));

		queueManager.remove(batchJobId);

		assertTrue(0 == queueManager.getIdentifyResults().size());
		assertTrue(0 == queueManager.getBatchSegmentJobMaps().size());
	}

	@Test
	public void testGetBatchSegmentJobMap() {
		final long batchJobId = 0L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		assertTrue(null != queueManager.getBatchSegmentJobMap(batchJobId));
	}

	@Test
	public void testGetIdentifyResult() {
		final long batchJobId = 0L;
		queueManager.add(newIdentifyResult(batchJobId));
		assertTrue(null != queueManager.getIdentifyResult(batchJobId));
	}

	@Test
	public void testGetBatchSegmentJobMaps() {
		long batchJobId = 0L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		queueManager.add(newBatchSegmentJobMap(batchJobId + 1));

		assertTrue(2 == queueManager.getBatchSegmentJobMaps().size());
	}

	@Test
	public void testGetIdentifyResults() {
		long batchJobId = 0L;
		queueManager.add(newIdentifyResult(batchJobId));
		queueManager.add(newIdentifyResult(batchJobId + 1));
		assertTrue(2 == queueManager.getIdentifyResults().size());
	}

	@Test
	public void setBatchJobStatus() {
		final long batchJobId = 0L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		queueManager.setBatchJobStatus(batchJobId, BatchJobMapStatus.RUNNING);
		assertTrue(BatchJobMapStatus.RUNNING == queueManager
				.getBatchSegmentJobMap(batchJobId).getBatchJobStatus());
	}

	@Test
	public void getBatchJobStatus() {
		final long batchJobId = 0L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		queueManager.setBatchJobStatus(batchJobId, BatchJobMapStatus.RUNNING);
		assertTrue(BatchJobMapStatus.RUNNING == queueManager
				.getBatchSegmentJobMapStatus(batchJobId));
	}

	@Test
	public void getSegmentJobMaps() {
		final long batchJobId = 0L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		assertTrue(0 == queueManager.getSegmentJobMaps(batchJobId).size());
	}

	@Test
	public void getSegmentIds() {
		final long batchJobId = 0L;
		queueManager.add(newIdentifyResult(batchJobId));
		assertTrue(0 == queueManager.getSegmentIds(batchJobId).size());
	}

	@Test
	public void hasBSJAlreadyReceived() {
		final long batchJobId = 0L;
		queueManager.add(newIdentifyResult(batchJobId));
		LongArraySet segmentIds = new LongArraySet();
		segmentIds.add(0L);
		segmentIds.add(1L);
		queueManager.getIdentifyResult(batchJobId).setSegmentIds(segmentIds);
		queueManager.hasBSJAlreadyReceived(batchJobId, segmentIds);
		assertTrue(0 == queueManager.getSegmentIds(batchJobId).size());

		queueManager.hasBSJAlreadyReceived(batchJobId, segmentIds);
		assertTrue(0 == queueManager.getSegmentIds(batchJobId).size());
	}

	@Test
	public void setBatchSegmentJobStatusDone() {
		final long batchJobId = 100L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		final long segmentSize = 5;
		for (long i = 0; i < segmentSize; i++) {
			if (i != 3) {
				SegmentMap segmentMap = new SegmentMap();
				segmentMap.setSegmentId(i);
				segmentMap
						.setBSJobStatus(BSJobStatus.READYTO_DELIVERY);
				queueManager.getBatchSegmentJobMap(batchJobId).getSegmentMaps()
						.put(i, segmentMap);
			} else {
				queueManager.getBatchSegmentJobMap(batchJobId).getSegmentMaps()
						.put(i, new SegmentMap());
			}
		}

		Map<Long, SegmentMap> segmentMaps = queueManager
				.getSegmentJobMaps(batchJobId);

		for (long i = 0; i < segmentSize; i++) {
			SegmentMap segmentMap = segmentMaps.get(i);
			if (null != segmentMap) {
				segmentMap.setBSJobStatus(BSJobStatus.DONE);
			}
		}

		for (long i = 0; i < segmentSize; i++) {
			Assert.assertTrue(queueManager.getBatchSegmentJobMap(batchJobId)
					.getSegmentMaps().get(i).getBSJobStatus() == BSJobStatus.DONE);
		}
	}

	@Test
	public void setSegmentMapNull() {
		final long batchJobId = 100L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		List<Long> segmentIds = new ArrayList<Long>();
		segmentIds.add(1L);
		segmentIds.add(2L);

		queueManager.setBatchSegmentJobStatusDone(batchJobId, segmentIds);

		Map<Long, SegmentMap> maps = queueManager.getBatchSegmentJobMap(
				batchJobId).getSegmentMaps();

		for (SegmentMap map : maps.values()) {
			Assert.assertEquals(BSJobStatus.READYTO_DELIVERY,
					map.getBSJobStatus());
		}
	}

	@Test
	public void isBatchJobDone() {
		final long batchJobId = 100L;
		queueManager.add(newIdentifyResult(batchJobId));
		final long segmentSize = 5;
		List<Long> segmentIdList = new ArrayList<Long>((int) segmentSize);
		for (long i = 0; i < segmentSize; i++) {
			queueManager.getSegmentIds(batchJobId).add(i);
			segmentIdList.add(i);
		}

		segmentIdList.remove(0);
		queueManager.hasBSJAlreadyReceived(batchJobId, segmentIdList);
		assertTrue(1 == queueManager.getSegmentIds(batchJobId).size());

		segmentIdList.add(0L);
		queueManager.hasBSJAlreadyReceived(batchJobId, segmentIdList);
		assertTrue(queueManager.isBatchJobDone(batchJobId));
	}

	@Test
	public void changeSendDoneEventFlag() {
		final long batchJobId = 100L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));

		assertFalse(queueManager.getBatchSegmentJobMap(batchJobId)
				.isSendDoneEvent());
		queueManager.changeSendDoneEventFlag(batchJobId, true);
		assertTrue(queueManager.getBatchSegmentJobMap(batchJobId)
				.isSendDoneEvent());
	}

	@Test
	public void isSendDoneEvent() {
		final long batchJobId = 100L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));

		queueManager.changeSendDoneEventFlag(batchJobId, true);
		assertTrue(queueManager.isSendDoneEvent(batchJobId));
	}

	@Test
	public void setBatchSegmentJobMapStatusDone() {
		final long batchJobId = 100L;
		queueManager.add(newBatchSegmentJobMap(batchJobId));

		assertTrue(BatchJobMapStatus.TMA_WORKING_DONE != queueManager
				.getBatchSegmentJobMap(batchJobId).getBatchJobStatus());

		queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
				BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE);

		assertTrue(BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE == queueManager
				.getBatchSegmentJobMap(batchJobId).getBatchJobStatus());
	}

	@Test
	public void setOverMaxCandidatesTrue() {
		final long batchJobId = 100L;
		final int jobIdStart = 1;
		final int jobCount = 10;
		final int maxCandidate = 10;
		final int candidateSize = 11;
		final int notOverMaxCandidateJobIndex = jobCount / 2;

		queueManager.add(UtilCreateData.createIdentifyResultData(batchJobId,
				jobIdStart, jobCount, candidateSize, 0, 2, maxCandidate,
				ReSendable.EMPTY));

		Int2ObjectArrayMap<IdentifyJobResult> jobResultList = queueManager
				.getIdentifyResult(batchJobId).getSearchJobResults();

		for (int i = 0; i < jobCount; i++) {
			IdentifyJobResult jobResult = jobResultList.get(i + jobIdStart);
			if (jobResult.getCandidates().get(jobResult.getMaxCandidate())
					.getScaledScore() > Integer.MIN_VALUE) {
				jobResult.setOverMaxCandidates(false);
			}
			if (i == notOverMaxCandidateJobIndex) {
				jobResult.setCandidates(new ObjectArrayList<Candidate>(0));
			}
		}

		for (int i = 0; i < jobCount; i++) {
			assertFalse(jobResultList.get(i + jobIdStart).isOverMaxCandidates());
		}

		queueManager.setOverMaxCandidatesTrue(batchJobId);

		for (int i = 0; i < jobCount; i++) {
			if (i == notOverMaxCandidateJobIndex) {
				assertFalse(jobResultList.get(i + jobIdStart)
						.isOverMaxCandidates());
			} else {
				assertTrue(jobResultList.get(i + jobIdStart)
						.isOverMaxCandidates());
			}
		}
	}

	@Test
	public void clear() {
		final long batchJobId = 100L;
		queueManager.add(newIdentifyResult(batchJobId));
		queueManager.add(newBatchSegmentJobMap(batchJobId));
		queueManager.add(newIdentifyResult(batchJobId + 1));

		Assert.assertEquals(1, queueManager.getBatchSegmentJobMaps().size());
		Assert.assertEquals(2, queueManager.getIdentifyResults().size());

		queueManager.clear();

		Assert.assertEquals(0, queueManager.getBatchSegmentJobMaps().size());
		Assert.assertEquals(0, queueManager.getIdentifyResults().size());
	}

	private static final String LINE = System.getProperty("line.separator");

	@Test
	public void testPrintBatchSegmentJobMap() {
		clearMemory();
		BatchSegmentJobMap bsjm = UtilCreateData.createBatchSegmentJobMapData(
				1212L, 10, 12, 1, 2);
		IdentifyResult result = UtilCreateData.createIdentifyResultData(1212L,
				1, 10, 10, 1, 2, 10, ReSendable.EMPTY);
		BatchSegmentJobManager.getInstance().add(bsjm);
		BatchSegmentJobManager.getInstance().add(result);

		String results = BatchSegmentJobManager
				.printBatchSegmentJobMap(queueManager.getBatchSegmentJobMaps());

		String expect = "============================================================================================================"
				+ "Mode=ACTIVE"
				+ "backlogs=1"
				+ ""
				+ "============================================================================================================"
				+ "BatchJobId:       1212	|	SegmentId:          1	|	SegmentStatus:          RUNNING"
				+ "BatchJobId:       1212	|	SegmentId:          2	|	SegmentStatus:          RUNNING"
				+ "-----------------------------------------------------------------------------------------------------------"
				+ "JobIndex:   1    ReturnCode: JobSuccess    JobIndex:   2    ReturnCode: JobSuccess"
				+ "JobIndex:   3    ReturnCode: JobSuccess    JobIndex:   4    ReturnCode: JobSuccess"
				+ "JobIndex:   5    ReturnCode: JobSuccess    JobIndex:   6    ReturnCode: JobSuccess"
				+ "JobIndex:   7    ReturnCode: JobSuccess    JobIndex:   8    ReturnCode: JobSuccess"
				+ "JobIndex:   9    ReturnCode: JobSuccess    JobIndex:  10    ReturnCode: JobSuccess"
				+ ""
				+ ""
				+ "============================================================================================================";
		Assert.assertEquals(results.replaceAll(LINE, ""), expect);
		clearMemory();
	}

	private void clearMemory() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	private BatchSegmentJobMap newBatchSegmentJobMap(long batchJobId) {
		return new BatchSegmentJobMap(batchJobId,
				new ArrayList<SearchJobInfo>(),
				new ConcurrentHashMap<Long, SegmentMap>(),
				BatchJobMapStatus.WAIT);
	}

	private IdentifyResult newIdentifyResult(long batchJobId) {
		return new IdentifyResult(batchJobId, new LongArraySet(),
				new Int2ObjectArrayMap<IdentifyJobResult>(), 0L);
	}

}
