package jp.co.nec.lsm.tma.common.constants;


/**
 * @author dongqk <br>
 * Aggregation Constants
 */
public class AggregationConstants {
	public static final int POLLING_DURATION = 3000; 	
	public static final String SUMMARY_SPLIT = "============================================================================================================";
}
