package jp.co.nec.lsm.tma.core.merger;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.core.amr.TopLevelAMRInfoMerger;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.score.TopLevelCandidateMerger;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TopLevelInfoMerger {
	private static Logger log = LoggerFactory
			.getLogger(TopLevelInfoMerger.class);

	/**
	 * private constructor
	 */
	private TopLevelInfoMerger() {
	}

	/**
	 * According to the BatchJobId and JobIndex, get each Job Object, merge
	 * ScaledScore, For IdentifyResult returned each USC, first, find the
	 * corresponding batchJob, and then merge data from job1 to jobn, if the
	 * score is higher than now, insert, otherwise give up
	 * 
	 * @param identifyResult
	 *            one batch Object in TMA Queue
	 * @param resultRequest
	 *            Merged Object from USC
	 */
	public static void mergeTopLevel(IdentifyResult identifyResult,
			IdentifyJobResultRequest resultRequest) {
		printLogMessage("start public function merge()...");

		StopWatch t = new StopWatch();
		t.start();

		final int resultRequestSize = resultRequest.getIdentifyJobResultCount();

		synchronized (identifyResult) {
			Int2ObjectArrayMap<IdentifyJobResult> topLeveLJobResults = identifyResult
					.getSearchJobResults();

			for (int i = 0; i < resultRequestSize; i++) {
				// Get IdentifyJobResult from USC
				IdentifyJobResultRequestProto.IdentifyJobResult topLevelJobResultFromUSC = resultRequest
						.getIdentifyJobResult(i);

				int jobIndex = topLevelJobResultFromUSC.getJobIndex();

				// Get SearchJobResult from TMA queue
				IdentifyJobResult topLevelJobResult = topLeveLJobResults
						.get(jobIndex);
				if (null == topLevelJobResult) {
					log.error(
							"BatchJobId: {}, doesnot have IdentifyJobResult which JobIndex is {} in the TMA queue...",
							new Object[] { identifyResult.getBatchJobId(),
									jobIndex });
					continue;
				}

				// merger the aMR information whatever the job
				// is successful or not
				// the only judgeMent is the protoBuffer has
				// this element
				if (topLevelJobResultFromUSC.hasAmrInfo()) {
					// merger AMR information
					TopLevelAMRInfoMerger.mergeTopLevelAMRInfo(
							topLevelJobResult.getaMRState(),
							topLevelJobResultFromUSC.getAmrInfo());
				}

				final int candidatesSize = topLevelJobResult.getCandidates()
						.size();
				final int candidatesFromUSCSize = topLevelJobResultFromUSC
						.getCandidateCount();

				// valid Params Error, if error, return false, else true
				if (!TopLevelCandidateMerger.isValidParams(
						topLevelJobResultFromUSC, topLevelJobResult,
						candidatesSize, candidatesFromUSCSize)) {
					continue;
				}

				// merge Candidates
				TopLevelCandidateMerger.mergeTopLevelCandidate(
						topLevelJobResult.getCandidates().elements(),
						candidatesSize,
						topLevelJobResultFromUSC.getCandidateList(),
						candidatesFromUSCSize);
			}
		}

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_TOP_LEVEL_CANDIDATE_MERGER,
				LogConstants.FUNCTION_MERGE, t.getTime());

		printLogMessage("end public function merge()...");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
