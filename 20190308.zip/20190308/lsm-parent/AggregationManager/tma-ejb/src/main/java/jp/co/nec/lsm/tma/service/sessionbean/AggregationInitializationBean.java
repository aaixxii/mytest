package jp.co.nec.lsm.tma.service.sessionbean;

import java.lang.management.ManagementFactory;
import java.util.Enumeration;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.event.JndiLookup;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.util.SafeCloseUtil;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDao;
import jp.co.nec.lsm.tma.db.dao.AggregationTransactionManagerDao;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;

/**
 * @author dongqk <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationInitializationBean {

	private static Logger log = LoggerFactory
			.getLogger(AggregationInitializationBean.class);

	@Resource(mappedName = "java:/JmsXA")
	private ConnectionFactory jmsConnectionFactory;
	
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private AggregationSystemConfigDao systemConfig;
	
	private AggregationTransactionManagerDao aggregationManagerDao;	

	/**
	 * constructor
	 */
	public AggregationInitializationBean() {			
	}
	
	@PostConstruct
	public void init() {
		systemConfig = new AggregationSystemConfigDao(entityManager, dataSource);
		aggregationManagerDao = new AggregationTransactionManagerDao(entityManager, dataSource);
	}

	/**
	 * start timer
	 * 
	 * @throws JMSException
	 */
    private void startTimer() throws JMSException {
        printLogMessage("Sending Message to TimerManagerMDB");
        if (this.jmsConnectionFactory == null) {
            jmsConnectionFactory = JndiLookup.lookUp(JNDIConstants.JmsFactory,
                    ConnectionFactory.class);
        }        
        Queue queue = JndiLookup.lookUp(JNDIConstants.AGGREGATION_STARTTIMER_QUEUE, Queue.class);  
        Connection connect = null;
        Session session = null;
        MessageProducer producer = null;
        try {
            connect = jmsConnectionFactory.createConnection();
            session = connect.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
            producer = session.createProducer(queue);
            Message msg = session.createTextMessage();
            producer.send(msg);
           log.info("Success send message to timer-startup-queue");
        } finally {
            SafeCloseUtil.close(producer);
            SafeCloseUtil.close(session);
            SafeCloseUtil.close(connect);
        }
    }


	/**
	 * 
	 * @param queueName
	 */   
    @SuppressWarnings("unused")
    private void removeJmsMessageOld(String queueName) {
//      String name = "jboss.messaging.destination:name=" + queueName + ", service=Queue";
//      ObjectName ObjectName = new ObjectName(name);   

        try {
            MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();
            StringBuilder sb = new StringBuilder();
            sb.append("org.hornetq:module=JMS,name=\"");
            sb.append(queueName);
            sb.append("\",type=Queue");
            ObjectName target = new ObjectName(sb.toString());

            String[] sig = new String[] { "java.lang.String" };
            mBeanServer.invoke(target, "removeMessages", new String[] { "" },
                    sig);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    @SuppressWarnings("unused")
    private void removeJmsMessage2(String queueName) { 
        InitialContext c = null;
        Session session = null;       
        Connection connection = null;
        QueueBrowser browser = null;
        try {
             c = new InitialContext();
            ConnectionFactory jmsConnectionFactory =  (ConnectionFactory) c.lookup(JNDIConstants.JmsFactory); 
            connection = jmsConnectionFactory .createConnection();
            Queue queue = (Queue) c.lookup(queueName);            
            session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE); 
             browser = session.createBrowser(queue);            
            Enumeration<?> msgs = browser.getEnumeration();
            if ( !msgs.hasMoreElements() ) { 
                System.out.println("No messages in queue");
            } else { 
                while (msgs.hasMoreElements()) { 
                    Message tempMsg = (Message)msgs.nextElement(); 
                    tempMsg.getJMSMessageID();
                    System.out.println("Message: " + tempMsg); 
                    tempMsg.acknowledge();                    
                }
            }          
               
        } catch (NamingException | JMSException e) {            
            e.printStackTrace();
        }  finally {           
            SafeCloseUtil.close(session);
            SafeCloseUtil.close(connection);
           
            try {
                browser.close();
                c.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }     

    }
    
    private void removeJmsMessage(String queueName) { 
        InitialContext c = null;
        Session session = null;       
        Connection connection = null;      
        try {
             c = new InitialContext();
            ConnectionFactory jmsConnectionFactory =  (ConnectionFactory) c.lookup(JNDIConstants.JmsFactory);           
            connection = jmsConnectionFactory .createConnection();
            Queue queue = (Queue) c.lookup(queueName);            
            session = connection.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
            MessageConsumer mc = session.createConsumer(queue);
           Message obj = null;
            while ((obj = mc.receive(100L)) != null) {
               obj.getJMSMessageID();
            } 
        } catch (NamingException | JMSException e) {            
            e.printStackTrace();
        }  finally {           
            SafeCloseUtil.close(session);
            SafeCloseUtil.close(connection);           
            try {               
                c.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


	/**
	 * initialize Aggregation start timer, sendEnter to TMI
	 */
	
	public void initializeAggregation() {
		printLogMessage("start public function initializeAggregation()...");

		// set start time in TRANSACTION_MANAGERS
		setStartupTime();

		// read properties from file write into DB
	    systemConfig.writeAllMissingProperties();
		
		//removeJmsMessage(QueueNames.AGGREGATION_QUEUE_NAME);
		removeJmsMessage(JNDIConstants.AGGREGATION_QUEUE);		

		
		//removeJmsMessage(QueueNames.AGGREGATION_STARTTIMER_QUEUE_NAME);
		removeJmsMessage(JNDIConstants.AGGREGATION_STARTTIMER_QUEUE);		
		
		//removeJmsMessage(QueueNames.AGGREGATION_DLQ_QUEUE_NAME);
		removeJmsMessage(JNDIConstants.AGGREGATION_DLQ_QUEUE);

		try {
			startTimer();
		} catch (JMSException e) {
			log.error("start Timer error..");
			throw new AggregationRuntimeException(
					"Failed to init because of JMSException", e);
		}
		
		// 
		notifyHeartbeatPollTimerService();

		// out put the TMA System Initialization
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput("AggregationInitializationBean",
					"initializeAggregation", "DETAIL",
					"TMA System Initialization successfully.."));
		}

		printLogMessage("end public function initializeAggregation()...");
	}

	/**
	 * insert MM startUpTime into MATCH_MANAGER_TIMES table.
	 */
	private void setStartupTime() {
		aggregationManagerDao.setStartupTime();
	}

	private void notifyHeartbeatPollTimerService()
	{
		int pollDuraton = systemConfig.getHeartbeatPollingDuration();
		AggregationEventBus.notifyHeartbeatPollTimerService(pollDuraton);
	}
	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
