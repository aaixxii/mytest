package jp.co.nec.lsm.tma.service.sessionbean;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.LongArraySet;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         receive and processing BatchSegmentJobMap from TMI<br>
 *         processing the transmitted data from MU
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BatchSegmentJobMapInitializerBean implements
		BatchSegmentJobMapInitializerRemote {

	private static Logger log = LoggerFactory
			.getLogger(BatchSegmentJobMapInitializerBean.class);

	@PostConstruct
	public void init() {
		printLogMessage("CNTR: BatchSegmentJobMapInitializerBean init");
	}

	public BatchSegmentJobMapInitializerBean() {
	}

	/**
	 * put the data from TMI into the memory queue, <br>
	 * set startTime to now,<br>
	 * initializeIdentifyResult space<br>
	 * 
	 * @param batchSegmentJobMap
	 *            the data from TMI
	 */
	@Override
	public void receiveBatchJobAndInitSpace(
			BatchSegmentJobMap batchSegmentJobMap) {
		printLogMessage("start public function receiveBatchJobAndInitSpace()...");

		StopWatch t = new StopWatch();
		t.start();

		if (null == batchSegmentJobMap) {
			log.error("error BatchSegmentJobMap from TMI is null...");
			throw new AggregationRuntimeException(
					"error BatchSegmentJobMap from TMI is null...");
		}

		// initialize IdentifyResult space in the memory queue
		initIdentifyResultSpace(batchSegmentJobMap);
		// add batchSegmentJobMap into the memory queue
		BatchSegmentJobManager.getInstance().add(batchSegmentJobMap);

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_BATCH_SEGMENT_JOB_MAP_INITIALIZER_BEAN,
				LogConstants.FUNCTION_RECEIVE_BATCHJOB_AND_INIT_SPACE,
				t.getTime(), "batch job id",
				String.valueOf(batchSegmentJobMap.getbJobId()));

		printLogMessage("end public function receiveBatchJobAndInitSpace()...");
	}

	/**
	 * initialize IdentifyResult space in the memory queue
	 * 
	 * @param batchSegmentJobMap
	 */
	private void initIdentifyResultSpace(BatchSegmentJobMap batchSegmentJobMap) {
		List<SearchJobInfo> jobInfoList = batchSegmentJobMap
				.getSearchJobInfos();
		final int jobInfoListSize = jobInfoList.size();

		if (0 == jobInfoListSize) {
			log.error("error SearchJobInfo list in BatchSegmentJobMap from TMI is null or empty...");
			throw new AggregationRuntimeException(
					"error SearchJobInfo list in BatchSegmentJobMap from TMI is null or empty...");
		}

		Int2ObjectArrayMap<IdentifyJobResult> jobResultMap = new Int2ObjectArrayMap<IdentifyJobResult>(
				jobInfoListSize);
		for (int i = 0; i < jobInfoListSize; i++) {
			SearchJobInfo jobInfo = jobInfoList.get(i);

			if (null == jobInfo) {
				continue;
			}

			jobResultMap.put(
					jobInfo.getJobId(),
					new IdentifyJobResult(jobInfo.getJobId(), jobInfo
							.getRequestId(), jobInfo.getReferenceId(), jobInfo
							.getMaxCandidate(), jobInfo.getReturnCode(),
							jobInfo.getErrorCode(), jobInfo.getErrorMessage(),
							jobInfo.getResendable()));
		}

		BatchSegmentJobManager.getInstance().add(
				new IdentifyResult(batchSegmentJobMap.getbJobId(),
						new LongArraySet(batchSegmentJobMap.getSegmentMaps()
								.keySet()), jobResultMap, 0L));
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
