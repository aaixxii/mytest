package jp.co.nec.lsm.tma.core.clientapi.response;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

/**
 * @author zhulk <br>
 *         This class used for response the result of batchJob or prepare Enroll
 *         Result.
 */
public class IdentifyResultRequestSender {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(IdentifyResultRequestSender.class);

	/**
	 * response the result of batchJob
	 * 
	 * @param batchJob
	 * @return
	 * @throws InvalidProtocolBufferException
	 */
	public HttpResponse sendIdentifyResponse(
			IdentifyResultRequest identifyResponse, String url, Integer timeout) {
		printLogMessage("start public function sendIdentifyResponse..");

		// send identify result to transformer
		try {
			InputStream inputStream = new ByteArrayInputStream(identifyResponse
					.toByteArray());

			Map<String, Object> httpClientParameters = new HashMap<String, Object>();

			// set no retry
			httpClientParameters.put(HttpClientParams.RETRY_HANDLER,
					new DefaultHttpMethodRetryHandler(0, false));
			// set connection and socket timeout
			httpClientParameters.put(HttpConnectionParams.SO_TIMEOUT, timeout);
			httpClientParameters.put(HttpConnectionParams.CONNECTION_TIMEOUT,
					timeout);

			HttpRequestSender httpRequestSender = new HttpRequestSender(
					httpClientParameters);
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.httpURLInfoOutput(identifyResponse
						.getBatchJobId(), url));
			}
			HttpResponse httpResponse = httpRequestSender.sendPostRequest(url,
					identifyResponse.getBatchJobId(), inputStream, null);

			if (log.isInfoEnabled()) {
				log.info("Finished post to {}  status: {} for batchJob {}.",
						new Object[] { url, httpResponse.getHttpResponseCode(),
								identifyResponse.getBatchJobId() });
			}
			return httpResponse;
		} catch (Exception e) {
			String message = "Exception when post batchJob "
					+ identifyResponse.getBatchJobId() + " to " + url;
			log.error(message);
			throw new AggregationRuntimeException(message, e);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}