package jp.co.nec.lsm.tma.core.clientapi.response;

/**
 * AMRState this class define the state of AMR
 * 
 * @author liuyq
 * 
 */
public class AMRState {

	/**
	 * get the last result that will response to transformer
	 */

	public String getReadActualCount() {
		return String.valueOf(this.read);
	}

	public String getMfm_1ActualCount() {
		return String.valueOf(this.mfm_1);
	}

	public String getMfm_2ActualCount() {
		return String.valueOf(this.mfm_2);
	}

	public String getFaceActualCount() {
		return String.valueOf(this.face);
	}

	public String getIris_leftActualCount() {
		return String.valueOf(this.iris_left);
	}

	public String getIris_rightActualCount() {
		return String.valueOf(this.iris_right);
	}

	public String getFingerActualCount() {
		return String.valueOf(this.finger);
	}

	public String getPassedFActualCount() {
		return String.valueOf(this.passedFirst);
	}

	public String getPassedSActualCount() {
		return String.valueOf(this.passedSecond);
	}

	public String getPassedTActualCount() {
		return String.valueOf(this.passedThird);
	}

	/**
	 * increase Count from usc
	 */

	public void increaseRead(long readPara) {
		this.read += readPara;
	}

	public void increaseMfm_1(long mfm_1Para) {
		this.mfm_1 += mfm_1Para;
	}

	public void increaseMfm_2(long mfm_2Para) {
		this.mfm_2 += mfm_2Para;
	}

	public void increaseFace(long facePara) {
		this.face += facePara;
	}

	public void increaseIris_left(long iris_leftPara) {
		this.iris_left += iris_leftPara;
	}

	public void increaseIris_right(long iris_rightPara) {
		this.iris_right += iris_rightPara;
	}

	public void increaseFinger(long fingerPara) {
		this.finger += fingerPara;
	}

	public void increasePassedF(long passedF) {
		this.passedFirst += passedF;
	}

	public void increasePassedS(long passedS) {
		this.passedSecond += passedS;
	}

	public void increasePassedT(long passedT) {
		this.passedThird += passedT;
	}

	/** after increase the count from usc, the result of actualCount **/
	private long read;
	private long mfm_1;
	private long mfm_2;
	private long face;
	private long iris_left;
	private long iris_right;
	private long finger;
	private long passedFirst;
	private long passedSecond;
	private long passedThird;

	/**
	 * AMRState construction
	 */
	public AMRState() {
	}
}
