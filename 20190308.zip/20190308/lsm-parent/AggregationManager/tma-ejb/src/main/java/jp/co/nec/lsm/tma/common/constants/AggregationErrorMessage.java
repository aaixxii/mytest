package jp.co.nec.lsm.tma.common.constants;

/**
 *@author dongqk <br>
 */
public enum AggregationErrorMessage {
	RETRY_TIMES_OVER("844010400")
	;

	private String errorCode;

	AggregationErrorMessage(String errorCode) {
		this.setErrorCode(errorCode);
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}
}
