package jp.co.nec.lsm.tma.core.clientapi.response;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectCollection;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.constants.BusinessMessageConstants;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.common.constants.AMRConstants;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidateList;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;

public class IdentifyResultRequestBuilder {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(IdentifyResultRequestSender.class);

	/**
	 * prepare Identify Result of Request basing Identify Batch Job
	 * 
	 * @param identifyResult
	 * @return
	 */
	public static IdentifyResultRequest createIdentifyResultRequest(
			IdentifyResult identifyResult) {
		printLogMessage("start private function createIdentifyResultRequest..");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		IdentifyResultRequest.Builder identifyResponse = IdentifyResultRequest
				.newBuilder();

		// create list for IdentifyResponse
		List<ByteString> resultList = prepareIndentifyJobResultInfo(identifyResult);

		// set IdentifyResponse values
		printLogMessage("set IdentifyResponse values..");

		identifyResponse.setBatchJobId(identifyResult.getBatchJobId());
		identifyResponse.addAllBusinessMessage(resultList);
		identifyResponse.setType(BatchType.IDENTIFY);

		// response Transformer the result of batchJob
		printLogMessage(" response Transformer the result of batchJob: "
				+ identifyResult.getBatchJobId() + ".");

		stopWatch.stop();

		PerformanceLogger.performanceOutput(LogConstants.COMPONENT_RESPONSE,
				LogConstants.FUNCTION_CREATE_RESULT_REQUEST,
				stopWatch.getTime());

		printLogMessage("end private function createIdentifyResultRequest..");

		return identifyResponse.build();
	}

	/**
	 * create list for IdentifyResponse
	 * 
	 * @param identifyResult
	 * @return
	 */
	private static List<ByteString> prepareIndentifyJobResultInfo(
			IdentifyResult identifyResult) {
		List<ByteString> resultList = new ArrayList<ByteString>();

		List<CPBBusinessMessage> businessMsgList = BatchSegmentJobManager
				.getInstance()
				.getBatchSegmentJobMap(identifyResult.getBatchJobId())
				.getBusinessMessages();
		// create list for EnrollResponse
		printLogMessage("create list for IdentifyResponse.");

		ObjectCollection<IdentifyJobResult> jobResultSet = identifyResult
				.getSearchJobResults().values();
		int index = 0;
		for (IdentifyJobResult jobResult : jobResultSet) {
			CPBBusinessMessage.Builder bussinessMsg = businessMsgList.get(
					index++).toBuilder();

			// dataBlock
			CPBDataBlock.Builder dataBlock = bussinessMsg.getDataBlockBuilder();

			// CPBCandidateList
			setCandidateListData(dataBlock, jobResult);

			// CPBProcessMetrics
			setProcessMetricsData(dataBlock.getProcessMetricBuilder(),
					identifyResult.getBatchJobId());

			// AMR info set
			setAMRInformation(dataBlock, jobResult);

			// CPBResponse
			setResponseData(bussinessMsg.getResponseBuilder(), jobResult);

			resultList.add(bussinessMsg.build().toByteString());
		}
		return resultList;
	}

	/**
	 * set Response data
	 * 
	 * @param response
	 * @param jobResult
	 */
	private static void setResponseData(CPBResponse.Builder response,
			IdentifyJobResult jobResult) {
		// CPBResponse
		if (jobResult.getReturnCode() == ReturnCode.JobSuccess) {
			response.setStatus(BusinessMessageConstants.RESPONSE_TOPJOB_STATUS_SUCCESS);
		} else {
			// set reSendable flag
			response.setResendable(jobResult.getResendable().getContent());
			response.setStatus(jobResult.getErrorCode()).setErrorMessage(
					jobResult.getErrorMessage());
		}

		// CPBResponseAttribute
		CPBResponseAttribute.Builder responseAttribute = CPBResponseAttribute
				.newBuilder();
		responseAttribute.setAttributeName(
				BusinessMessageConstants.REQUEST_PARAMETER_CREATED_TIMESTAMP)
				.setAttributeValue(
						DateUtil.formatUTC(DateUtil.getCurrentDate()));
		response.addResponseAttributes(responseAttribute);
	}

	/**
	 * set CandidateList Data
	 * 
	 * @param dataBlock
	 * @param jobResult
	 */
	private static void setCandidateListData(CPBDataBlock.Builder dataBlock,
			IdentifyJobResult jobResult) {
		if (jobResult.getReturnCode() == ReturnCode.JobSuccess) {
			CPBCandidateList.Builder candidateList = dataBlock
					.getCandidateListBuilder();
			ObjectArrayList<Candidate> candidates = jobResult.getCandidates();
			for (int i = 0, size = candidates.size(); i < size
					&& i < jobResult.getMaxCandidate(); i++) {
				if (candidates.get(i).getScaledScore() > Integer.MIN_VALUE) {
					candidateList.addCandidates(candidates.get(i)
							.getModalScore());
				}
			}
			candidateList.setMore(jobResult.isOverMaxCandidates());
		}
	}

	/**
	 * set AMR Information
	 * 
	 * @param dataGroup
	 * @param jobResult
	 */
	private static void setAMRInformation(CPBDataBlock.Builder dataBlock,
			IdentifyJobResult jobResult) {
		if (jobResult.getReturnCode() == ReturnCode.JobSuccess) {
			CPBDataGroup.Builder builder = CPBDataGroup.newBuilder();
			AMRState state = jobResult.getaMRState();
			builder.setGroupName(AMRConstants.AMR);
			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_READ)
					.setElementValue(state.getReadActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_MFM_1)
					.setElementValue(state.getMfm_1ActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_MFM_2)
					.setElementValue(state.getMfm_2ActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_FACE)
					.setElementValue(state.getFaceActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_IRIS_LEFT)
					.setElementValue(state.getIris_leftActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_IRIS_RIGHT)
					.setElementValue(state.getIris_rightActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_FINGER)
					.setElementValue(state.getFingerActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_PASSED_FIRST)
					.setElementValue(state.getPassedFActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_PASSED_SECOND)
					.setElementValue(state.getPassedSActualCount());

			builder.addDataElementBuilder()
					.setElementName(AMRConstants.AMR_PASSED_THIRD)
					.setElementValue(state.getPassedTActualCount());

			dataBlock.addDataGroup(builder);
		}
	}

	/**
	 * set ProcessMetrics Data
	 * 
	 * @param processMetrics
	 * @param jobResult
	 */
	private static void setProcessMetricsData(
			CPBProcessMetrics.Builder processMetrics, long batchJobId) {
		BatchSegmentJobMap batchSegmentJobMap = BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMap(batchJobId);

		CPBProcessInfo.Builder processMetric = CPBProcessInfo.newBuilder();
		processMetric
				.setProcessName(BusinessMessageConstants.REQUEST_PARAMETER_MATCH);

		// get batch job start time from memory
		// (AggregationPollBean set start time)
		// if memory start time is not set, set the current local time.
		Date startTime = batchSegmentJobMap.getStartTime();
		if (startTime == null) {
			startTime = DateUtil.getCurrentDate();
		}
		processMetric.setStartTime(DateUtil.formatUTC(startTime));

		processMetric.setEndTime(DateUtil.formatUTC(DateUtil.getCurrentDate()));
		processMetrics.addProcessMetric(processMetric);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
