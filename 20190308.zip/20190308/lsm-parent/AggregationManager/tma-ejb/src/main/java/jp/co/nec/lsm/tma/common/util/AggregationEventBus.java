package jp.co.nec.lsm.tma.common.util;

import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.IdentifyMergerJobDoneEvent;
import jp.co.nec.lsm.event.identify.IdentifyStartHeartbeatTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifySyncSegmentJobDoneEvent;
import jp.co.nec.lsm.event.identify.IdnetifyBatchjobResultsSendFailedEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.event.identify.notifier.IdentifyNotifier;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestBuilder;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestSender;
import jp.co.nec.lsm.tma.core.jobs.IdentifyResponseQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         This class for sent the notice.
 */
public class AggregationEventBus {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AggregationEventBus.class);

	private AggregationEventBus() {
	}

	/**
	 * send BatchSegmentJobMap which had done to TMI by JMS
	 * 
	 * @param batchSegmentJobMap
	 * @return
	 */
	public static boolean sendBatchSegmentJobMapToTMI(
			BatchSegmentJobMap batchSegmentJobMap, String tmiIpAddress) {
		printLogMessage("start public static function sendBatchSegmentJobMapToTMI..");

		if (null == tmiIpAddress || "".equals(tmiIpAddress)) {
			log.warn("TMI address IP is not given.");
			return false;
		}

		IdentifySyncSegmentJobDoneEvent event = new IdentifySyncSegmentJobDoneEvent(
				batchSegmentJobMap.getbJobId(),
				IdentifyNotifierEnum.IdentifyBatchJobResultService,
				IdentifyReceiverEnum.IdentifySyncWithAggregationServiceBean);
		event.setBatchJobId(batchSegmentJobMap.getbJobId());
		event.setIpAddress(tmiIpAddress);
		event.setBatchSegmentJobMap(batchSegmentJobMap);

		IdentifyNotifier notifier = null;
		try {
			notifier = new IdentifyNotifier();
			notifier.sendEvent(event);
		} catch (Exception e) {
			String errorMessage = "Notify BatchSegmentJobMap To TMI error..";
			if (notifier != null) {
				notifier.clearJmsRemoteConnectionCache(event);
			}
			log.error(errorMessage);
			return false;
		}
		printLogMessage("end public static function sendBatchSegmentJobMapToTMI..");
		return true;
	}

	/**
	 * notify pollbean timer event
	 */
	public static void notifyHeartbeatPollTimerService(int pollDuraton) {
		printLogMessage("start public static function notifyHeartbeatPollTimerService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new IdentifyStartHeartbeatTimerEvent(
				pollDuraton,
				IdentifyNotifierEnum.TMASystemInitializationBean,
				IdentifyReceiverEnum.AggregationHeartbeatStarterBean);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyHeartbeatPollTimerService..");
	}

	/**
	 * notify merger batch job Done
	 * 
	 * @param batchJobId
	 */
	public static void notifyBatchjobDone(long batchJobId) {
		printLogMessage("start public static function notifyBatchjobDone..");
		try {
			IdentifyNotifier notifier = new IdentifyNotifier();
			IdentifyAbstractEvent event = new IdentifyMergerJobDoneEvent(
					batchJobId,
					IdentifyNotifierEnum.IdentifyTmaPollbeanService,
					IdentifyReceiverEnum.IdentifyBatchJobResultService);
			notifier.sendEvent(event);
		} catch (Exception e) {
			log.error("Notify BatchJob done error..", e);
		}
		printLogMessage("end public static function notifyBatchjobDone..");
	}
	
	/**
	 * notify Identify BatchJob Results send failed
	 * 
	 * @param batchJobId
	 */
	public static boolean notifyIdentifyBatchjobSendFailed(long batchJobId,String tmiIP) {
		printLogMessage("start public static function notifyIdentifyBatchjobSendFaild..");
		if (null == tmiIP || "".equals(tmiIP)) {
			log.warn("TMI address IP is not given.");
			return false;
		}
		IdentifyAbstractEvent event = null;
		IdentifyNotifier notifier = null;
		try {
			 notifier = new IdentifyNotifier();
			 event = new IdnetifyBatchjobResultsSendFailedEvent(
					batchJobId,
					IdentifyNotifierEnum.IdentifyBatchJobResultService,
					IdentifyReceiverEnum.IdentifyBatchJobResultSendFailedReceiver);
			event.setIpAddress(tmiIP);
			notifier.sendEvent(event);
		} catch (Exception e) {
			log.error("An error occurred while notify IdentifyBatchjobSendFaild to TMI..", e);
			if (notifier != null) {
				notifier.clearJmsRemoteConnectionCache(event);
			}	
			return false;
		}
		printLogMessage("end public static function  notifyIdentifyBatchjobSendFaild..");
		return true;
	}	
	
	
	

	/**
	 * send IdentifyResultRequest Object to Transformer
	 * 
	 * @response IdentifyResult Object
	 * @return
	 */
	public static boolean sendIdentifyResponseToTransformer(
			IdentifyResult identifyResult, String endPoint, Integer timeout) {
		printLogMessage("start public static function sendIdentifyResponseToTransformer..");
		
		int resultsStatusCode;
		IdentifyResultRequest response = IdentifyResultRequestBuilder
				.createIdentifyResultRequest(identifyResult);
		resultsStatusCode = sendIdentifyResponseToTransformer(response, endPoint, timeout);
		
		if (resultsStatusCode == Constants.HTTP_RESPONSE_CODE_500) {
			String errMsg = "Error accored while Sending results to transformer ";
			if (log.isErrorEnabled()){
				log.error(errMsg);
				return false;
			}
		}
		
		// just for test
		IdentifyResponseQueue.getInstance().add(response);
		printLogMessage("end public static function sendIdentifyResponseToTransformer..");
		return true;
	}
	
	

	/**
	 * sendIdentifyResponseToTransformer
	 * 
	 * @param response
	 * @param endPoint
	 */
	public static Integer sendIdentifyResponseToTransformer(
			IdentifyResultRequest response, String endPoint, Integer timeout) {
		IdentifyResultRequestSender sender = new IdentifyResultRequestSender();
		HttpResponse httpResponse = sender.sendIdentifyResponse(response,
				endPoint, timeout);
		return httpResponse.getHttpResponseCode();		

		
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
