/**
 * 
 */
package jp.co.nec.lsm.tma.exception;

import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;

/**
 * @author dongqk <br>
 * AggregationManagerException
 *
 */
public class AggregationRuntimeException extends TMRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1287506188023072691L;

	/**
	 * @param message
	 */
	public AggregationRuntimeException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public AggregationRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
