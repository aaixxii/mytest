package jp.co.nec.lsm.tma.core.amr;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.AmrInfo;
import jp.co.nec.lsm.tma.core.clientapi.response.AMRState;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TopLevelAMRInfoMerger {
	private static Logger log = LoggerFactory
			.getLogger(TopLevelAMRInfoMerger.class);

	/**
	 * mergeTopLevelAMRInfo
	 * 
	 * @param aMRInfo
	 * @param aMrInfoFromUsc
	 */
	public final static void mergeTopLevelAMRInfo(AMRState aMRInfo,
			AmrInfo aMrInfoFromUsc) {
		// if the argument is null, skip merger operation.
		if (aMrInfoFromUsc == null) {
			log.warn("the AMR information from usc is empty, skip merger..");
			return;
		}

		printLogMessage("ready to merger each AMR information..");

		if (aMrInfoFromUsc.hasFace())
			aMRInfo.increaseFace(aMrInfoFromUsc.getFace());
		if (aMrInfoFromUsc.hasFinger())
			aMRInfo.increaseFinger(aMrInfoFromUsc.getFinger());
		if (aMrInfoFromUsc.hasIrisLeft())
			aMRInfo.increaseIris_left(aMrInfoFromUsc.getIrisLeft());
		if (aMrInfoFromUsc.hasIrisRight())
			aMRInfo.increaseIris_right(aMrInfoFromUsc.getIrisRight());
		if (aMrInfoFromUsc.hasMfm1())
			aMRInfo.increaseMfm_1(aMrInfoFromUsc.getMfm1());
		if (aMrInfoFromUsc.hasMfm2())
			aMRInfo.increaseMfm_2(aMrInfoFromUsc.getMfm2());
		if (aMrInfoFromUsc.hasRead())
			aMRInfo.increaseRead(aMrInfoFromUsc.getRead());
		if (aMrInfoFromUsc.hasPassed1St())
			aMRInfo.increasePassedF(aMrInfoFromUsc.getPassed1St());
		if (aMrInfoFromUsc.hasPassed2Nd())
			aMRInfo.increasePassedS(aMrInfoFromUsc.getPassed2Nd());
		if (aMrInfoFromUsc.hasPassed3Rd())
			aMRInfo.increasePassedT(aMrInfoFromUsc.getPassed3Rd());

		printLogMessage("end merger each AMR information..");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
