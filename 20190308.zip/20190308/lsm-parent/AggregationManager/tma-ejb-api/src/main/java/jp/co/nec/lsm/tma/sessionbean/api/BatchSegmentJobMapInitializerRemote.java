package jp.co.nec.lsm.tma.sessionbean.api;

import javax.ejb.Remote;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;

/**
 * @author dongqk <br>
 * 
 * receive and processing BatchSegmentJobMap from TMI
 * processing the transmitted data from MU
 * 
 */
@Remote
public interface BatchSegmentJobMapInitializerRemote {
	/**
	 * put the data from TMI into the memory queue, <br>
	 * set startTime to now,<br>
	 * initializeIdentifyResult space<br>
	 * 
	 * @param batchSegmentJobMap
	 *            the data from TMI
	 */
	public void receiveBatchJobAndInitSpace(BatchSegmentJobMap batchSegmentJobMap);

}
