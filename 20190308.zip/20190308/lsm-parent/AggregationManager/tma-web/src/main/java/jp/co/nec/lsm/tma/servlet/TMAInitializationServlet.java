package jp.co.nec.lsm.tma.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tma.service.sessionbean.AggregationInitializationBean;


/**
 * @author dongqk <br>
 *         TMAInitializationServlet
 */
public class TMAInitializationServlet extends AbstractTMServlet {

	private static Logger log = LoggerFactory
			.getLogger(TMAInitializationServlet.class);
	private static final long serialVersionUID = 240324080833505099L;

	@EJB
	private AggregationInitializationBean initialization;

	/**
	 * Initialization
	 */
	public void init() throws ServletException {
		printLogMessage("start public function init(), get the instance of a InitializationBean class ...");	
		initialization.initializeAggregation();
		printLogMessage("end public function init(), get the instance of a InitializationBean class ...");
	}

	/**
	 * 
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// nothing to do
	}

	/**
	 * 
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doPost(req, res);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
