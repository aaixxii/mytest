package jp.co.nec.lsm.tma.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TMABatchJobStatusQuickViewServlet extends AbstractTMServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3120931148133419614L;
	private static Logger log = LoggerFactory
			.getLogger(TMABatchJobStatusQuickViewServlet.class);

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/plain");
		try {
			if (log.isInfoEnabled()) {
				log.info("output batch job status..");
			}

			StopWatch t = new StopWatch();
			t.start();

			String output = processCommand();
			writeResultToResponse(output, res);

			t.stop();
			PerformanceLogger.performanceOutput(
					"TMABatchJobStatusQuickViewServlet",
					LogConstants.FUNCTION_DO_GET, t.getTime());
		} catch (Exception e) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					e.getMessage(), e);
		}
	}

	/**
	 * processCommand
	 * 
	 * @throws InterruptedException
	 */
	private String processCommand() throws InterruptedException {
		String output = BatchSegmentJobManager
				.printBatchSegmentJobMap(BatchSegmentJobManager.getInstance()
						.getBatchSegmentJobMaps());
		return output;
	}

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
}
