package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tma.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class TMABatchSegmentJobMapsServletTest {
	private static final long BATCH_JOB_ID = 1212323L;
	private static final String LINE = System.getProperty("line.separator");

	@Before
	public void before() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	@After
	public void after() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	@Test
	public void testDoGet_empty() throws ServletException, IOException {
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchSegmentJobMapsServlet servlet = new TMABatchSegmentJobMapsServlet();
		servlet.doGet(req, res);

		Assert.assertEquals(res.getStatus(), 200);

		String result = "**********************************";
		Assert.assertEquals(res.getContentAsString().trim()
				.replaceAll(LINE, ""), result);
	}

	@Test
	public void testDoPost_empty() throws ServletException, IOException {
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchSegmentJobMapsServlet servlet = new TMABatchSegmentJobMapsServlet();
		servlet.doPost(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		String result = "**********************************";
		Assert.assertEquals(res.getContentAsString().trim()
				.replaceAll(LINE, ""), result);
	}

	@Test
	public void testDoGet_HasJobs() throws ServletException, IOException,
			ParseException {
		BatchSegmentJobMap bsjm = UtilCreateData.createBatchSegmentJobMapData(
				BATCH_JOB_ID, 10, 12, 1, 2);

		bsjm.setStartTime(new SimpleDateFormat("yyyy-MM-dd")
				.parse("2012-06-27"));
		BatchSegmentJobManager.getInstance().add(bsjm);

		int index = 0;
		for (SearchJobInfo job : bsjm.getSearchJobInfos()) {
			job.setReferenceId("ReferenceId-" + index++);
		}

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchSegmentJobMapsServlet servlet = new TMABatchSegmentJobMapsServlet();
		servlet.doGet(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		String expect = "**********************************"
				+ "BatchJobId: 1212323    BatchJobStatus: WAIT    FailureCount: 0    StartTime: 2012-06-27 00:00:00.000    TimeOut: 0"
				+ "----------------------------------------"
				+ "JobIndex: 0    ReferenceId: ReferenceId-0    RequestId: RequestId-0    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 1    ReferenceId: ReferenceId-1    RequestId: RequestId-1    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 2    ReferenceId: ReferenceId-2    RequestId: RequestId-2    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 3    ReferenceId: ReferenceId-3    RequestId: RequestId-3    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 4    ReferenceId: ReferenceId-4    RequestId: RequestId-4    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 5    ReferenceId: ReferenceId-5    RequestId: RequestId-5    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 6    ReferenceId: ReferenceId-6    RequestId: RequestId-6    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 7    ReferenceId: ReferenceId-7    RequestId: RequestId-7    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 8    ReferenceId: ReferenceId-8    RequestId: RequestId-8    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "JobIndex: 9    ReferenceId: ReferenceId-9    RequestId: RequestId-9    ReturnCode: JobSuccess    MaxCandidate: 12"
				+ "----------------------------------------"
				+ "SegmentId: 2    bSJobStatus: RUNNING    MuId: 1    FailureCount: 0    TargetVersion: 0    ProcessStartTS:     ProcessEndTS: "
				+ "SegmentId: 1    bSJobStatus: RUNNING    MuId: 1    FailureCount: 0    TargetVersion: 0    ProcessStartTS:     ProcessEndTS: "
				+ "**********************************";
		Assert.assertEquals(res.getContentAsString().replaceAll(LINE, ""),
				expect);
	}

}
