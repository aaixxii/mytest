package jp.co.nec.lsm.tma.servlet.debug;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestBuilder;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.jobs.IdentifyResponseQueue;
import jp.co.nec.lsm.tma.util.UtilCreateData;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidate;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBScore;
import com.nec.everest.proto.protobuf.BusinessMessage.E_MODALITY_TYPE;

public class TMAIdentifyResponseServletTest {
	private static final long BATCH_JOB_ID = 12123234L;
	private static final String LINE = System.getProperty("line.separator");

	@Before
	public void before() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	@After
	public void after() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	@Test
	public void testDoGet_empty() throws ServletException, IOException {
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMAIdentifyResponseServlet servlet = new TMAIdentifyResponseServlet();
		servlet.doGet(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		Assert.assertEquals(res.getContentAsString(), "");
	}

	@Test
	public void testDoPost_empty() throws ServletException, IOException {
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMAIdentifyResponseServlet servlet = new TMAIdentifyResponseServlet();
		servlet.doPost(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		Assert.assertEquals(res.getContentAsString(), "");
	}

	@Test
	public void testDoGet_HasJobs() throws ServletException, IOException,
			ParseException {
		BatchSegmentJobMap bsjm = UtilCreateData.createBatchSegmentJobMapData(
				BATCH_JOB_ID, 10, 12, 1, 2);
		bsjm.setStartTime(new SimpleDateFormat("yyyy-MM-dd")
				.parse("2012-06-27"));
		BatchSegmentJobManager.getInstance().add(bsjm);
		int index = 0;
		for (SearchJobInfo job : bsjm.getSearchJobInfos()) {
			job.setReferenceId("ReferenceId-" + index++);
		}

		IdentifyResult result = UtilCreateData.createIdentifyResultData(
				BATCH_JOB_ID, 1, 1, 1, 1, 2, 10);
		index = 0;
		for (IdentifyJobResult job : result.getSearchJobResults().values()) {
			job.setReferenceId("ReferenceId-" + index++);

			ObjectArrayList<Candidate> candidates = new ObjectArrayList<Candidate>();
			Candidate.Builder builder = Candidate.newBuilder();
			builder.setReferenceId("referenceId-hit");
			builder.setScaledScore(50);

			CPBCandidate.Builder cpbCandidate = builder.getModalScoreBuilder();
			cpbCandidate
					.setEnrollmentId("ReferenceId-hit")
					.setScaledScore(50)
					.addScore(
							CPBScore.newBuilder()
									.setModalityType(E_MODALITY_TYPE.FACE)
									.setValue("0").setModalitySubType("")
									.setBufferValue1("").build())
					.addScore(
							CPBScore.newBuilder()
									.setModalityType(E_MODALITY_TYPE.FINGER)
									.setValue("0").setModalitySubType("")
									.setBufferValue1("").build())
					.addScore(
							CPBScore.newBuilder()
									.setModalityType(E_MODALITY_TYPE.IRIS)
									.setValue("0").setModalitySubType("")
									.setBufferValue1("").build());
			builder.setModalScore(cpbCandidate.build());

			candidates.add(builder.build());

			job.setCandidates(candidates);

		}

		IdentifyResultRequest request = IdentifyResultRequestBuilder
				.createIdentifyResultRequest(result);

		IdentifyResultRequest.Builder requestBuilder = IdentifyResultRequest
				.newBuilder();
		requestBuilder.setBatchJobId(BATCH_JOB_ID);
		requestBuilder.setType(BatchType.IDENTIFY);

		for (ByteString byteString : request.getBusinessMessageList()) {
			CPBBusinessMessage message = CPBBusinessMessage
					.parseFrom(byteString);
			CPBBusinessMessage.Builder builder = message.toBuilder();
			builder.getRequestBuilder().setEnrollmentId("enrollmentId");
			builder.getDataBlockBuilder().getProcessMetricBuilder()
					.getProcessMetricBuilder(0).setEndTime("12121212");
			builder.getResponseBuilder().getResponseAttributesBuilder(0)
					.setAttributeValue("");
			requestBuilder.addBusinessMessage(builder.build().toByteString());
		}

		IdentifyResponseQueue instance = IdentifyResponseQueue.getInstance();
		instance.add(requestBuilder.build());

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMAIdentifyResponseServlet servlet = new TMAIdentifyResponseServlet();
		servlet.doGet(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		String expect = "BatchJobId: 12123234    BatchType: IDENTIFY"
				+ "----------------------------------------"
				+ "RequestId: RequestId-0    EnrollmentId: enrollmentId    RequestType: CLEAR    "
				+ "Status: 0    ErrorMessage:     Resendable: "
				+ "createdTimestamp:     "
				+ "----------------------------------------"
				+ "More: false"
				+ "EnrollmentId: ReferenceId-hit    ScaledScore: 50    MatchedFingerPattern: "
				+ "----------------------------------------"
				+ ""
				+ "----------------------------------------"
				+ "ProcessName: match    StartTime: 1340755200000    EndTime: 12121212    "
				+ "read: 0    mfm-1: 0    mfm-2: 0    face: 0    iris-left: 0    iris-right: 0    finger: 0    passed-first: 0    passed-second: 0    passed-third: 0    "
				+ "**********************************";

		Assert.assertEquals(res.getContentAsString().replaceAll(LINE, ""),
				expect);
	}
}
