package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;

import javax.servlet.ServletException;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tma.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class TMABatchJobStatusServletTest {
	private static final String LINE = System.getProperty("line.separator");

	@Before
	public void before() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	@After
	public void after() {
		BatchSegmentJobManager.getInstance().getBatchSegmentJobMaps().clear();
		BatchSegmentJobManager.getInstance().getIdentifyResults().clear();
	}

	@Test
	public void testDoGet_empty() throws ServletException, IOException {
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchJobStatusServlet servlet = new TMABatchJobStatusServlet();
		servlet.doGet(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		String result = "============================================================================================================"
				+ "Mode=ACTIVEbacklogs=0"
				+ "============================================================================================================";
		Assert.assertEquals(res.getContentAsString().trim()
				.replaceAll(LINE, ""), result);
	}

	@Test
	public void testDoPost_empty() throws ServletException, IOException {
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchJobStatusServlet servlet = new TMABatchJobStatusServlet();
		servlet.doPost(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		String result = "============================================================================================================"
				+ "Mode=ACTIVEbacklogs=0"
				+ "============================================================================================================";
		Assert.assertEquals(res.getContentAsString().trim()
				.replaceAll(LINE, ""), result);
	}

	@Test
	public void testDoGet_Exception() throws ServletException, IOException {
		BatchSegmentJobMap bsjm = UtilCreateData.createBatchSegmentJobMapData(
				121233L, 10, 12, 1, 2);
		BatchSegmentJobManager.getInstance().add(bsjm);
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchJobStatusServlet servlet = new TMABatchJobStatusServlet();
		try {
			servlet.doGet(req, res);
		} catch (Exception ex) {
			return;
		}
		Assert.fail();
	}

	@Test
	public void testDoGet_HasJobs() throws ServletException, IOException {
		BatchSegmentJobMap bsjm = UtilCreateData.createBatchSegmentJobMapData(
				1212L, 10, 12, 1, 2);
		IdentifyResult result = UtilCreateData.createIdentifyResultData(
				1212L, 1, 10, 10, 1, 2, 10);
		BatchSegmentJobManager.getInstance().add(bsjm);
		BatchSegmentJobManager.getInstance().add(result);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse res = new MockHttpServletResponse();
		TMABatchJobStatusServlet servlet = new TMABatchJobStatusServlet();
		servlet.doGet(req, res);

		Assert.assertEquals(res.getStatus(), 200);
		String expect = "============================================================================================================"
				+ "Mode=ACTIVE"
				+ "backlogs=1"
				+ ""
				+ "============================================================================================================"
				+ "BatchJobId:       1212	|	SegmentId:          1	|	SegmentStatus:          RUNNING"
				+ "BatchJobId:       1212	|	SegmentId:          2	|	SegmentStatus:          RUNNING"
				+ "-----------------------------------------------------------------------------------------------------------"
				+ "JobIndex:   1    ReturnCode: JobSuccess    JobIndex:   2    ReturnCode: JobSuccess"
				+ "JobIndex:   3    ReturnCode: JobSuccess    JobIndex:   4    ReturnCode: JobSuccess"
				+ "JobIndex:   5    ReturnCode: JobSuccess    JobIndex:   6    ReturnCode: JobSuccess"
				+ "JobIndex:   7    ReturnCode: JobSuccess    JobIndex:   8    ReturnCode: JobSuccess"
				+ "JobIndex:   9    ReturnCode: JobSuccess    JobIndex:  10    ReturnCode: JobSuccess"
				+ ""
				+ ""
				+ "============================================================================================================";
		Assert.assertEquals(res.getContentAsString().replaceAll(LINE, ""),
				expect);
	}

}
