package jp.co.nec.lsm.tme.snapshot;

import java.util.Date;
import java.util.List;

public class EnrollBatchJobSnapShot {
	private int transformerCount;
	private int extractorCount;
	private int dataSerCount;
	private int syncSerCount;
	private int responseCount;
	private Date outPutDate;

	private List<EnrollBatchJobSnapShotDetail> detailList;

	public void setTransformerCount(int transformerCount) {
		this.transformerCount = transformerCount;
	}

	public int getTransformerCount() {
		return transformerCount;
	}

	public void setExtractorCount(int extractorCount) {
		this.extractorCount = extractorCount;
	}

	public int getExtractorCount() {
		return extractorCount;
	}

	public void setDataSerCount(int dataSerCount) {
		this.dataSerCount = dataSerCount;
	}

	public int getDataSerCount() {
		return dataSerCount;
	}

	public void setSyncSerCount(int syncSerCount) {
		this.syncSerCount = syncSerCount;
	}

	public int getSyncSerCount() {
		return syncSerCount;
	}

	public void setResponseCount(int responseCount) {
		this.responseCount = responseCount;
	}

	public int getResponseCount() {
		return responseCount;
	}

	public void setOutPutDate(Date outPutDate) {
		this.outPutDate = outPutDate;
	}

	public Date getOutPutDate() {
		return outPutDate;
	}

	public void setDetailList(List<EnrollBatchJobSnapShotDetail> detailList) {
		this.detailList = detailList;
	}

	public List<EnrollBatchJobSnapShotDetail> getDetailList() {
		return detailList;
	}

}
