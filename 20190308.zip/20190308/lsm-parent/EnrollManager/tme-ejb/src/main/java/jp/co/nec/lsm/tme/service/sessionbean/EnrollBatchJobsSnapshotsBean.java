package jp.co.nec.lsm.tme.service.sessionbean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollResponseQueue;
import jp.co.nec.lsm.tme.core.jobs.EnrollResponseQueue.Statistics;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShot;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShotDetail;

/**
 * @author mozj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollBatchJobsSnapshotsBean {
		
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollBatchJobsSnapshotsBean.class);

	public  EnrollBatchJobsSnapshotsBean() {}	
	
	
	public EnrollBatchJobSnapShot GetBatchJobSnapShot(String limitCount) {
		if (log.isDebugEnabled()) {
			log.debug("start public function GetBatchJobSnapShot()");
		}

		EnrollBatchJobManager manager = EnrollBatchJobManager.getInstance();
		EnrollBatchJobSnapShot jobSnapShot = manager.GetBatchJobSnapShot();

		Map<Long, Statistics> statisticsMap = EnrollResponseQueue.getInstance()
				.responseStatistics();

		final String sql = "SELECT BATCHJOB_ID, ENQUEUE_TS, END_TS from"
				+ " ENROLL_BATCH_JOB_QUEUE bj WHERE bj.BATCHJOB_STATUS = "
				+ EnrollBatchJobStatus.RETURNED.ordinal() + " and rownum <="
				+ limitCount + "order by BATCHJOB_ID desc";

		List<EnrollBatchJobSnapShotDetail> detailList = new ArrayList<EnrollBatchJobSnapShotDetail>();

		List<EnrollBatchJobSnapShotDetail> list = jobSnapShot.getDetailList();
		detailList.addAll(list);
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		List<Map<String, Object>> resMapList = jdbcTemplate.queryForList(sql);
		int dbJobSize = resMapList.size();

		for (int i = 0; i < resMapList.size(); i++) {
			Map<String, Object> resMap = resMapList.get(i);
			final Long batchJobId = ((BigDecimal) resMap.get("BATCHJOB_ID"))
					.longValue();
			final Date enqueueTS = (Date) resMap.get("ENQUEUE_TS");
			final Date endTS = (Date) resMap.get("END_TS");

			int jobCount = 0, templatesCount = 0;
			final Statistics statistics = statisticsMap.get(batchJobId);
			if (statistics == null) {
				log.warn("batchjobid: {} get response infomation from cache queue error.");
			} else {
				jobCount = statistics.getAllTljSize();
				templatesCount = statistics.getCorrectTljSize();
			}

			EnrollBatchJobSnapShotDetail detail = new EnrollBatchJobSnapShotDetail();
			detail.setBatchJobId(batchJobId.longValue());
			detail.setJobCount(jobCount);
			detail.setStatus(EnrollBatchJobStatus.SYNCHRONIZED);
			detail.setTemplatesCount(templatesCount);
			detail.setHoldingTime(endTS.getTime() - enqueueTS.getTime());

			detailList.add(detail);
		}

		jobSnapShot
				.setResponseCount(jobSnapShot.getResponseCount() + dbJobSize);
		jobSnapShot.setDetailList(detailList);

		if (log.isDebugEnabled()) {
			log.debug("end public function GetBatchJobSnapShot()");
		}
		return jobSnapShot;
	}
}
