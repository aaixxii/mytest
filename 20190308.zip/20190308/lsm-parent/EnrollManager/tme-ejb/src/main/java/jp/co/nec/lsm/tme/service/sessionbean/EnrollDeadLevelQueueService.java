package jp.co.nec.lsm.tme.service.sessionbean;

import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

/**
 * @author mozj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollDeadLevelQueueService {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollDeadLevelQueueService.class);
	
	public EnrollDeadLevelQueueService() {
		
	}

	
	public void receiveEventFromDLQ(long batchJobId, boolean isEnrollJob) {
		log.info("receive the event from queue (enroll_DLQ_event / DLQ),"
				+ " batch job id: {}", batchJobId);

		if (isEnrollJob) {
			// get enroll batch job
			EnrollBatchJobManager queueManage = EnrollBatchJobManager
					.getInstance();
			LocalEnrollBatchJob enrollBatchJob = queueManage
					.getEnrollBatchJobById(batchJobId);
			if (enrollBatchJob == null) {
				log.warn("Can not find the batch job(BatchJobId: {}).",
						batchJobId);
				return;
			}
			if (enrollBatchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTED)
					|| enrollBatchJob
							.isBatchJobStatus(EnrollBatchJobStatus.REGISTERED)) {
				makeEnrollBatchJobSynced(enrollBatchJob);
			} else if (enrollBatchJob
					.isBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED)
					|| enrollBatchJob
							.isBatchJobStatus(EnrollBatchJobStatus.RETURNED)) {
				// delete a batch job from local enroll queue
				enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.RETURNED);
				queueManage.deleteCompleteBatchJob(enrollBatchJob);
			} else {
				log.warn("Batch job status is incorrect. now is {}.",
						enrollBatchJob.getBatchJobStatus().name());

			}
		} else {
			// delete only the batch job is deletion
			deleteDeleteJob();
		}
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private void deleteDeleteJob() {
		printLogMessage("start private function deleteDeleteJob().");

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobs = deletionJobManager
				.getDeletionJobQueue();

		// loop the deletion job queue to find over retry limit batch job
		for (LocalDeletionJob deleteJob : deletionJobs) {
			if (deleteJob == null) {
				log.warn("deletion batch job is null, skip..");
				continue;
			}

			// delete the over segment sync limit deletion job
			if (deleteJob.isOverSegSyncLimit()) {
				log
						.info(
								"delete the segment sync failure deletion batch job({}),"
										+ " this deletion "
										+ "batch job is over segment sync failure count {} ",
								deleteJob.getBatchJobId(),
								EnrollConstants.SEG_SYNC_RETYR_LIMIT);
				deletionJobManager.deleteDeletionJob(deleteJob);
			}
		}

		printLogMessage("end private function deleteDeleteJob().");
		return;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private void makeEnrollBatchJobSynced(LocalEnrollBatchJob enrollBatchJob) {
		printLogMessage("start private function makeEnrollBatchJobSynced().");

		if (enrollBatchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTED)) {

			enrollBatchJob.makeDBExceptionFailed();

			Date now = DateUtil.getCurrentDate();
			enrollBatchJob.setInsertEndTS(now);
			// change enroll Batch Job Status and set synchronize end time
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
			enrollBatchJob.setSyncStartTS(now);
		}

		if (enrollBatchJob.isBatchJobStatus(EnrollBatchJobStatus.REGISTERED)) {

			// change enroll Batch Job Status and set synchronize end time
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED);
			enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());

			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, enrollBatchJob
								.getBatchJobId(),
						EnrollBatchJobStatus.SYNCHRONIZED.name());
			}

			// Notify EnrollResponseServiceBean that Enroll Segment
			// synchronization.
			EnrollEventBus.notifyResponse(enrollBatchJob.getBatchJobId(),
					EnrollNotifierEnum.EnrollDeadLevelQueueService);
		} else {
			log.warn("Batch job status is incorrect. now is {}, need {} or {}",
					new Object[] { enrollBatchJob.getBatchJobStatus().name(),
							EnrollBatchJobStatus.EXTRACTED.name(),
							EnrollBatchJobStatus.REGISTERED.name() });
		}

		printLogMessage("end private function makeEnrollBatchJobSynced().");
		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
