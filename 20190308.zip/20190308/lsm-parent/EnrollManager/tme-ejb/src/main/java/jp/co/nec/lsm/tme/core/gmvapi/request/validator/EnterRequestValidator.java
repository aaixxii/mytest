package jp.co.nec.lsm.tme.core.gmvapi.request.validator;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 * 
 */
public class EnterRequestValidator {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnterRequestValidator.class);

	/**
	 * validate all data in Enter Request whether there are correct.
	 * 
	 * @param extractResultRequest
	 * @return
	 */
	public static ValidationResult validate(EnterRequest enterRequest) {
		printLogMessage("start public function validate().");
		ValidationResult result = new ValidationResult();
		ValidationResultError error = null;

		// check the input Enter Request data
		// check EnterRequest Type
		error = validateComponentType(enterRequest.getType());
		result.addErrorIfNeccessary(error);

		// check EnterRequest Contact URL
		error = validateContactURL(enterRequest.getContactURL());
		result.addErrorIfNeccessary(error);

		// if top level job count is beyond 1000(default)
		error = validateUniqueId(enterRequest.getUniqueId());
		result.addErrorIfNeccessary(error);

		// all data in enroll request are correct.
		printLogMessage("end public function validate().");
		return result;
	}

	/**
	 * 
	 * @return
	 */
	private static ValidationResultError validateComponentType(
			ComponentType type) {
		if (type != ComponentType.MFE) {
			String errorInfo = "EnterRequest Type is incorrect.";
			log.error(errorInfo);
			return constructError(false, errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @return
	 */
	private static ValidationResultError validateContactURL(String contactURL) {
		if (contactURL == null || contactURL.isEmpty()) {
			String errorInfo = "EnterRequest Contact URL is incorrect.";
			log.error(errorInfo);
			return constructError(false, errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @return
	 */
	private static ValidationResultError validateUniqueId(String uniqueId) {
		if (uniqueId == null || uniqueId.isEmpty()) {
			String errorInfo = "EnterRequest UniqueId is incorrect.";
			log.error(errorInfo);
			return constructError(false, errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param valid
	 * @param invalidReason
	 * @return
	 */
	private static ValidationResultError constructError(boolean valid,
			String invalidReason) {
		ValidationResultError error = new ValidationResultError();
		error.setValid(valid);
		error.setInvalidReason(invalidReason);
		return error;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
