package jp.co.nec.lsm.tme.common.constants;

public enum ExtractJobFailedReason {
	JOB_TIMEOUT, MFE_TIMEOUT, MFE_EXIT, MFE_REENTER;
}
