package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import java.util.List;

import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

/**
 * @author mozj <br>
 * 
 */
public class EnrollRequestValidator {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollRequestValidator.class);

	/**
	 * validate all data in enroll request whether there are correct.
	 * 
	 * @param request
	 *            enroll request from Transformer
	 * @return false: there are incorrect data in enroll request. true: all data
	 *         in enroll request are correct.
	 */
	public static ValidationResult validate(EnrollRequest enrollRequest,
			List<CPBBusinessMessage> businessMessageList, int maxTLJ) {
		printLogMessage("start public function validate().");

		ValidationResult result = new ValidationResult();
		ValidationResultError error = null;

		// check the input batch job data
		// check Batch Job Id
		long batchJobId = enrollRequest.getBatchJobId();
		error = validateBatchJobIdNotOverZero(batchJobId);
		result.addErrorIfNeccessary(error);

		// check Batch Job Type
		error = validateBatchType(batchJobId, enrollRequest.getType());
		result.addErrorIfNeccessary(error);

		// check Business Message List
		error = validateNotEmpty(businessMessageList, batchJobId);
		result.addErrorIfNeccessary(error);

		// if top level job count is beyond 1000(default)
		error = validateNotOverMaxNumOfExtractJobs(businessMessageList,
				batchJobId, maxTLJ);
		result.addErrorIfNeccessary(error);

		printLogMessage("end public function validate().");
		return result;
	}

	/**
	 * 
	 * @param type
	 * @return
	 */
	private static ValidationResultError validateBatchType(long batchJobId,
			BatchType type) {
		if (type != BatchType.ENROLL) {
			String errorInfo = "Enroll Job ( EnrollRequest BatchType is incorrect. Now is "
					+ type.name() + ").";

			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.INSERT_BATCHTYPE_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateBatchJobIdNotOverZero(
			long batchJobId) {
		if (batchJobId <= 0) {
			String errorInfo = "Enroll Job ( Batch Job Id is not over zero).";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.INSERT_BATCHJOBID_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param jobInfoList
	 * @return
	 */
	private static ValidationResultError validateNotEmpty(
			List<CPBBusinessMessage> businessMessageList, long batchJobId) {
		if (businessMessageList == null || businessMessageList.size() == 0) {
			String errorInfo = "Enroll Job ( There is no Extract Job in EnrollRequest).";
			log.error(errorInfo);

			return new ValidationResultError(false, 0,
					EnrollErrorMessage.EXTRACTJOB_COUNT_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param jobInfoList
	 * @return
	 */
	private static ValidationResultError validateNotOverMaxNumOfExtractJobs(
			List<CPBBusinessMessage> businessMessageList, long batchJobId,
			int maxTLJ) {
		if (businessMessageList != null && businessMessageList.size() > maxTLJ) {
			String errorInfo = "Enroll Job ( EnrollRequest top level job is beyond "
					+ maxTLJ + ").";
			log.error(errorInfo);

			return new ValidationResultError(false, 0,
					EnrollErrorMessage.EXTRACTJOB_COUNT_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
