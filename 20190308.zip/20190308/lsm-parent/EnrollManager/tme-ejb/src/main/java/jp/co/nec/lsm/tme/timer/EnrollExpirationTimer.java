package jp.co.nec.lsm.tme.timer;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import jp.co.nec.lsm.tm.common.expire.validator.ExpiredValidator;
import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnrollExpirationTimer {
	private static Logger log = LoggerFactory
			.getLogger(EnrollExpirationTimer.class);

	private Timer timer = new Timer();

	private long startTime = 1340593299327L;

	private int hours = 1;

	private long delay = hours * 60 * 60 * 1000;

	public EnrollExpirationTimer(Date startDate) {
		long time = startDate.getTime();
		if (time > this.startTime) {
			this.startTime = time;
		}
	}

	public EnrollExpirationTimer(Date startDate, long delay) {
		long time = startDate.getTime();
		if (time > this.startTime) {
			this.startTime = time;
		}
		this.delay = delay;
	}

	/**
	 * 
	 */
	public void start() {
		if (log.isDebugEnabled()) {
			log.debug("start Expiration Timer.");
		}
		timer.schedule(new TimerTask() {
			public void run() {
				startTime = startTime + delay;
				if (isExpired()) {
					stopTMeFunction();
				}
			}
		}, delay, delay);
	}

	/**
	 * 
	 */
	public void stop() {
		if (log.isDebugEnabled()) {
			log.debug("stop Expiration Timer.");
		}
		timer.cancel();
	}

	/**
	 * 
	 * @return
	 */
	public boolean isExpired() {
		if (log.isDebugEnabled()) {
			log.debug("check the date if Expired.");
		}
		try {
			return ExpiredValidator.isExpired(new Date(startTime));
		} catch (Exception ex) {
			return true;
		}
	}

	/**
	 * 
	 */
	private void stopTMeFunction() {
		if (log.isInfoEnabled()) {
			log.info("stop TMe Function because now date is Expired.");
		}

		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();

		batchJobGetterTimer.setStop(true);
		batchJobGetterTimer.setTransitionState(RoleStateTransition.PASSIVE);
	}
}
