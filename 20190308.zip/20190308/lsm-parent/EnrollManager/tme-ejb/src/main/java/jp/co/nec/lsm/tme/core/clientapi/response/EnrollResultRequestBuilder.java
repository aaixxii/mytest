package jp.co.nec.lsm.tme.core.clientapi.response;

import java.util.List;

import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.jobs.EnrollResponseQueue;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;

public class EnrollResultRequestBuilder {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(EnrollResultRequestBuilder.class);

	/**
	 * prepare Enroll Result of Request basing Enroll Batch Job
	 * 
	 * @param batchJob
	 *            Enroll Batch Job
	 * @return Enroll Result of Request
	 */
	public static EnrollResultRequest createEnrollResultRequest(
			LocalEnrollBatchJob batchJob) {
		printLogMessage("start private function createEnrollResultRequest..");

		EnrollResultRequest.Builder enrollResponse = EnrollResultRequest
				.newBuilder();

		// create ExtractResultInfo list for EnrollResponse
		List<ByteString> resultList = batchJob.prepareEnrollJobResultInfo();

		// set EnrollResponse EnrollResponse values
		printLogMessage("set EnrollResponse EnrollResponse values..");

		enrollResponse.setBatchJobId(batchJob.getBatchJobId());
		enrollResponse.addAllBusinessMessage(resultList);
		enrollResponse.setType(batchJob.getBatchJobType());

		// response Transformer the result of batchJob
		printLogMessage(" response Transformer the result of batchJob: "
				+ batchJob.getBatchJobId() + ".");

		// add response instance to enroll response queue
		EnrollResultRequest response = enrollResponse.build();
		EnrollResponseQueue.getInstance().add(response);

		printLogMessage("end private function createEnrollResultRequest..");
		return response;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
