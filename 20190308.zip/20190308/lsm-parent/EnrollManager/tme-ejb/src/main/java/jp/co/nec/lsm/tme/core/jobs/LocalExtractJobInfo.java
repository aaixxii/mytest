package jp.co.nec.lsm.tme.core.jobs;

import java.util.Date;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJob;
import jp.co.nec.lsm.tm.common.communication.PersonTemplate;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tme.common.util.ResponseMessageBuilder;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;

/**
 * @author zhulk <br>
 * 
 */
public class LocalExtractJobInfo {

	private int jobId;

	private String requestId;

	private LocalExtractJobStatus status;

	private String referenceId;

	private String errorCode;

	private String errorMessage;

	private int muId;

	private int failureCount;

	private ReturnCode returnCode;

	private CPBBusinessMessage request;

	private CPBBusinessMessage response;

	private byte[] template;

	private Date extract_start_TS;

	private Date extract_end_TS;

	private long biometricId;

	private boolean isReSendable;

	public LocalExtractJobInfo() {
		status = LocalExtractJobStatus.READY;
		failureCount = 0;
		returnCode = ReturnCode.NotUsed;
		biometricId = -1;
		isReSendable = false;
	}

	/*
	 * get the value of JobId property
	 */
	public int getJobId() {
		return jobId;
	}

	/*
	 * set the value of JobId property
	 */
	public void setJobId(int id) {
		this.jobId = id;
	}

	/*
	 * get the value of RequestId property
	 */
	public String getRequestId() {
		return requestId;
	}

	/*
	 * set the value of RequestId property
	 */
	public void setRequestId(String request) {
		this.requestId = request;
	}

	/**
	 * 
	 * @param status
	 * @return
	 */
	public boolean isStatus(LocalExtractJobStatus status) {
		return this.status == status;
	}

	/*
	 * set the value of Status property
	 */
	public void setStatus(LocalExtractJobStatus status) {
		this.status = status;
	}

	/*
	 * get the value of ReferenceId property
	 */
	public String getReferenceId() {
		return referenceId;
	}

	/*
	 * set the value of ReferenceId property
	 */
	public void setReferenceId(String reference) {
		this.referenceId = reference;
	}

	/*
	 * get the value of MUId property
	 */
	public int getMUId() {
		return muId;
	}

	/*
	 * set the value of MUId property
	 */
	public void setMUId(int muId) {
		this.muId = muId;
	}

	/*
	 * get the value of FailureCount property
	 */
	public int getFailureCount() {
		return failureCount;
	}

	/*
	 * set the value of FailureCount property
	 */
	public void setFailureCount(int count) {
		this.failureCount = count;
	}

	/*
	 * get the value of ReturnCode property
	 */
	public ReturnCode getReturnCode() {
		return returnCode;
	}

	/*
	 * set the value of ReturnCode property
	 */
	public void setReturnCode(ReturnCode extractReturnCode) {
		this.returnCode = extractReturnCode;
	}

	/*
	 * get the value of Template property
	 */
	public byte[] getTemplate() {
		return template;
	}

	/*
	 * set the value of Template property
	 */
	public void setTemplate(byte[] bs) {
		this.template = bs;
	}

	/*
	 * set the value of extract_start_TS property
	 */
	public void setExtractStartTS(Date extract_start_TS) {
		this.extract_start_TS = extract_start_TS;
	}

	/*
	 * get the value of extract_start_TS property
	 */
	public Date getExtractStartTS() {
		return extract_start_TS;
	}

	/*
	 * set the value of extract_end_TS property
	 */
	public void setExtractEndTS(Date extract_end_TS) {
		this.extract_end_TS = extract_end_TS;
	}

	/*
	 * get the value of extract_end_TS property
	 */
	public Date getExtractEndTS() {
		return extract_end_TS;
	}

	/**
	 * 
	 * @return
	 */
	public PersonTemplate createLocalPersonTemplate() {
		return new PersonTemplate(referenceId, template);
	}

	/**
	 * 
	 * @return
	 */
	public boolean isSuccessed() {
		return returnCode == ReturnCode.JobSuccess;
	}

	/**
	 * 
	 * @return
	 */
	public String getSummary() {
		String br = System.getProperty("line.separator");
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("extract job id: ");
		stringBuilder.append(jobId);
		stringBuilder.append("     status: ");
		stringBuilder.append(status.toString());
		stringBuilder.append("\t");
		stringBuilder.append("returnCode: ");
		stringBuilder.append(returnCode.toString());
		stringBuilder.append("\t");
		stringBuilder.append("gmvId: ");
		stringBuilder.append(muId);
		stringBuilder.append("\t");
		stringBuilder.append("failureCount: ");
		stringBuilder.append(failureCount);
		stringBuilder.append(br);
		return stringBuilder.toString();
	}

	/***
	 * create an Extract Job for assigning
	 * 
	 * @param enrollBatchJobInfo
	 * @return
	 */
	public ExtractJob createExtractJob() {
		ExtractJob.Builder extractJobInfo = ExtractJob.newBuilder();
		extractJobInfo.setJobIndex(jobId);
		extractJobInfo.setRequest(request.toByteString());
		return extractJobInfo.build();
	}

	/***
	 * change status and time of the assigned extract job
	 * 
	 * @param muId
	 * @param now
	 * @param enrollBatchJobInfo
	 */
	public void changeStatusToEXTRACTING(int muId, Date now) {
		setStatus(LocalExtractJobStatus.EXTRACTING);
		setExtractStartTS(now);
		setMUId(muId);
	}

	/**
	 * 
	 */
	public void retry() {
		// retry extract job
		muId = 0;
		failureCount++;
		status = LocalExtractJobStatus.READY;
		extract_start_TS = null;
	}

	/**
	 * 
	 */
	public void doneByInternalError(Date now) {
		// make extract job done
		failureCount++;
		status = LocalExtractJobStatus.DONE;
		extract_end_TS = now;
		returnCode = ReturnCode.JobFailed;
		errorCode = EnrollErrorMessage.RETRY_TIMES_OVER.getErrorCode();
		isReSendable = true;
		errorMessage = "Enroll Job ( Failed because retry times is over limit).";

		CPBRequest request = getRequest().getRequest();
		response = ResponseMessageBuilder.createBusinessMessageByRequest(
				request, returnCode, errorCode, errorMessage, getReSendable());
	}

	public void setBiometricId(long biometricId) {
		this.biometricId = biometricId;
	}

	public long getBiometricId() {
		return biometricId;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setResponse(CPBBusinessMessage response) {
		this.response = response;
	}

	public CPBBusinessMessage getResponse() {
		return response;
	}

	public void setRequest(CPBBusinessMessage request) {
		this.request = request;
	}

	public CPBBusinessMessage getRequest() {
		return request;
	}

	public void setReSendable(boolean isReSendable) {
		this.isReSendable = isReSendable;
	}

	public boolean isReSendable() {
		return isReSendable;
	}

	public String getReSendable() {
		return isReSendable ? Constants.RESEND_ABLE
				: Constants.RESEND_IMPOSSIBLE;
	}
}
