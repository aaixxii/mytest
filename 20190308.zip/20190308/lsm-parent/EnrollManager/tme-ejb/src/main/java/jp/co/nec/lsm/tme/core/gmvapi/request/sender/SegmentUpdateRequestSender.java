package jp.co.nec.lsm.tme.core.gmvapi.request.sender;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import jp.co.nec.lsm.proto.segment.SegmentUpdateRequestProto.SegmentUpdateRequest;
import jp.co.nec.lsm.proto.segment.SegmentUpdateResponseProto.SegmentUpdateResponse;
import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

public class SegmentUpdateRequestSender {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(SegmentUpdateRequestSender.class);

	public SegmentUpdateResponse sendRequest(long batchJobId, String url,
			SegmentUpdateRequest segmentUpdateRequst) {

		// sendPostRequest
		byte[] streamBody = null;
		try {
			InputStream inputStream = new ByteArrayInputStream(
					segmentUpdateRequst.toByteArray());
			Map<String, Object> httpClientParameters = new HashMap<String, Object>();
			httpClientParameters.put(EnrollConstants.HTTP_SOCKET_SENDBUFFER,
					EnrollConstants.SEGMENT_UPDATE_SENDBUFFER_VALUE);

			HttpRequestSender httpRequestSender = new HttpRequestSender(
					httpClientParameters);
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.httpURLInfoOutput(batchJobId, url));
			}
			HttpResponse httpResponse = httpRequestSender.sendPostRequest(url,
					batchJobId, inputStream, null);
			if (log.isInfoEnabled()) {
				log.info("Finished post to {}  status: {} for batchJob {}.",
						new Object[] { url, httpResponse.getHttpResponseCode(),
								batchJobId });
			}

			streamBody = httpResponse.getHttpResponseBody();

		} catch (Exception ex) {
			String message = "Exception occur when post SegmentPosition to url:"
					+ url;
			log.error(message, ex);
			// if has error return directly
			return null;
		}

		// parse the response
		try {
			if (streamBody != null) {
				// parse Segment Update Response from response body
				SegmentUpdateResponse segUpRes = SegmentUpdateResponse
						.parseFrom(streamBody);
				return segUpRes;
			}
		} catch (InvalidProtocolBufferException ex) {
			String message = "Exception occur when parese SegmentUpdateResponse from url:"
					+ url;
			log.error(message, ex);
		}

		return null;
	}
}
