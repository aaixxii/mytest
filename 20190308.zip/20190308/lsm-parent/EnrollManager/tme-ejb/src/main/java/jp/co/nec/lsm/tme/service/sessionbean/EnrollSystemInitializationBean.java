package jp.co.nec.lsm.tme.service.sessionbean;

import java.lang.management.ManagementFactory;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tm.common.util.SafeCloseUtil;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.db.dao.EnrollDateDao;
import jp.co.nec.lsm.tme.db.dao.EnrollMatchUnitDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.db.dao.EnrollTransactionManagerDao;
import jp.co.nec.lsm.tme.timer.EnrollExpirationTimer;

/**
 * @author liuj The class used to initialize system.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollSystemInitializationBean {
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;		
	
	private EnrollMatchUnitDao enrollMatchUnitDao;
	
	private EnrollSystemConfigDao systemConfigDao;
	
	private EnrollTransactionManagerDao transactionManagerDao;
	
	private EnrollDateDao dateDao;
	
	@EJB
	private EnrollRecoveryServiceBean recoveryService;

	private static final Logger log = LoggerFactory
			.getLogger(EnrollSystemInitializationBean.class);	

	/**
	 * constructor
	 */
	public EnrollSystemInitializationBean() {
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);
		enrollMatchUnitDao = new EnrollMatchUnitDao(entityManager);
		transactionManagerDao = new EnrollTransactionManagerDao(entityManager, dataSource);
		dateDao = new EnrollDateDao(dataSource);
	}


	/**
	 * initialize Enroll System.
	 */
	public void initializeTME() {
		printLogMessage("start public function initializeTME()..");

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_SYSTEM_INIT_BEAN,
					LogConstants.FUNCTION_INITIALIZE_TME, "DETAIL",
					"called in SystemInitializationBean"));
		}

		if (isSystemExpiredOrRunTimer()) {
			if (log.isWarnEnabled()) {
				log.warn("TMe system is already expired..");
			}
			return;
		}

		// remove all JMS message
		removeAllJmsMessage();
		// insert TME startUpTime into TRANSACTION_MANAGERS table.
		setStartupTime();
		// write All Missing Properties into SystemConfigure of DB
		writeAllMissingProperties();
		// Change Unit State of TimeOut.
		changePidUnitState();
		// Recover uncompleted enrollBatchJob.
		if (setStartMode()) {
			recoveryService.recoverUnCompletedBatchJob();
		}
		
		
		// Start Timer.
		EnrollEventBus.notifyStartJobPollTimerService();
		EnrollEventBus.notifyStartMFEPollTimerService();
		EnrollEventBus.notifyEnrollBatchJobGetterTimerService();
		int pollDuraton = systemConfigDao.getHeartbeatPollingDuration();
		EnrollEventBus.notifyEnrollBatchJobHeartbeatStarterService(pollDuraton);

		// out put the TME System Initialization
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput("SystemInitializationBean",
					"initialize", "DETAIL",
					"TME System Initialization successfully.."));
		}

		printLogMessage("end public function initializeTME()..");

	}

	/**
	 * isSystemExpiredOrRunTimer
	 */
	private boolean isSystemExpiredOrRunTimer() {
		Date dbDate = dateDao.getDatabaseDate();
		EnrollExpirationTimer expirationTimer = new EnrollExpirationTimer(
				dbDate);
		if (expirationTimer.isExpired()) {
			EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
					.getInstance();
			batchJobGetterTimer.setStop(true);
			batchJobGetterTimer.setTransitionState(RoleStateTransition.PASSIVE);
			return true;
		}
		expirationTimer.start();
		return false;
	}

	/**
	 * setStartMode
	 * 
	 * @param
	 */
	private boolean setStartMode() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		String model = System.getProperty(Constants.PROPERTY_KEY_NAME);
		if (model != null && (Constants.PASSIVE.equalsIgnoreCase(model))) {
			jobGetter.setTransitionState(RoleStateTransition.PASSIVE);
			return false;
		} else {
			jobGetter.setTransitionState(RoleStateTransition.ACTIVE);
			return true;
		}
	}

	/**
	 * write All Missing Properties into SystemConfigure of DB
	 */
	private void writeAllMissingProperties() {
		printLogMessage("start private function writeAllMissingProperties()..");

		systemConfigDao.writeAllMissingProperties();

		printLogMessage("end private function writeAllMissingProperties()..");
	}

	/***
	 * Change Unit State of TimeOut.
	 */
	private void changePidUnitState() {
		printLogMessage("start private function changePidUnitState()..");

		enrollMatchUnitDao.updateMatchUnits(MUState.WORKING, MUState.TIMED_OUT);

		printLogMessage("end private function changePidUnitState()..");
	}

	/**
	 * insert TME startUpTime into TRANSACTION_MANAGERS table.
	 */
	private void setStartupTime() {
		printLogMessage("start private function setStartupTime()..");

		transactionManagerDao.createOrLookup();

		printLogMessage("end private function setStartupTime()..");
	}

	/**
	 * remove all JMS message
	 * 
	 * @param queueName
	 */
	private void removeAllJmsMessage() {
		//removeJmsMessage(QueueNames.ENROLL_DLQ_NAME);
		removeJmsMessage(JNDIConstants.ENROLL_DLQ);
		

		//removeJmsMessage(QueueNames.ENROLL_QUEUE_NAME);
		removeJmsMessage(JNDIConstants.ENROLL_QUEUE);

		//removeJmsMessage(QueueNames.ENROLL_SYNC_SEGMENT_QUEUE_NAME);
		removeJmsMessage(JNDIConstants.ENROLL_SYNC_SEGMENT_QUEUE);

		//removeJmsMessage(QueueNames.TEMPLATE_MANAGER_QUEUE_NAME);
		removeJmsMessage(JNDIConstants.TEMPLATE_MANAGER_QUEUE);
	}

	/**
	 * remove JMS message
	 * 
	 * @param queueName
	 */
	@SuppressWarnings("unused")
    private void removeJmsMessageOld(String queueName) {
		try {			
			MBeanServer mBeanServer = ManagementFactory.getPlatformMBeanServer();

			ObjectName target = new ObjectName("org.hornetq:module=JMS,name=\""
					+ queueName + "\",type=Queue");
			Object[] mbean = new Object[] {target};
			
			mBeanServer.registerMBean(mbean, target);		

			String[] sig = new String[] { "java.lang.String" };
			mBeanServer.invoke(target, "removeMessages", new String[] { "" }, sig);					

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	   private void removeJmsMessage(String queueName) { 
	        InitialContext c = null;
	        Session session = null;       
	        Connection connection = null;      
	        try {
	             c = new InitialContext();
	            ConnectionFactory jmsConnectionFactory =  (ConnectionFactory) c.lookup(JNDIConstants.JmsFactory);           
	            connection = jmsConnectionFactory .createConnection();
	            Queue queue = (Queue) c.lookup(queueName);            
	            session = connection.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
	            MessageConsumer mc = session.createConsumer(queue);
	           Message obj = null;
	            while ((obj = mc.receive(100L)) != null) {
	               obj.getJMSMessageID();
	            } 
	        } catch (NamingException | JMSException e) {            
	            e.printStackTrace();
	        }  finally {           
	            SafeCloseUtil.close(session);
	            SafeCloseUtil.close(connection);           
	            try {               
	                c.close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	    }	

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
	
	
	
	

}
