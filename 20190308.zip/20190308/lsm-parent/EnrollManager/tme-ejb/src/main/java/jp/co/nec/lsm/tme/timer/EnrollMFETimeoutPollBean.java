package jp.co.nec.lsm.tme.timer;

import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tme.common.constants.ExtractJobFailedReason;
import jp.co.nec.lsm.tme.core.jobs.EnrollExtractJobFailManager;
import jp.co.nec.lsm.tme.db.dao.EnrollMatchUnitDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;

/**
 * @author zhulk
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollMFETimeoutPollBean {
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	
	private EnrollSystemConfigDao systemConfigDao;
	
	private EnrollMatchUnitDao enrollMatchUnitDao;

	private static Logger log = LoggerFactory
			.getLogger(EnrollMFETimeoutPollBean.class);

	/**
	 * constructor
	 */
	public EnrollMFETimeoutPollBean() {
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);
		enrollMatchUnitDao = new EnrollMatchUnitDao(entityManager);
	}

	/**
	 * 
	 * @param now
	 * @param timeMS
	 * @return
	 */
	private Date findMinStart(long timeMS) {
		Date now = DateUtil.getCurrentDate();
		long minStart = now.getTime() - timeMS;
		return new Date(minStart);
	}

	/**
	 * MFE timeout by HeartBeat. Retry ExtractJob<br>
	 * 
	 * @param gmvId
	 *            TME Unit Entity Id
	 * @param failManager
	 */
	public void timeoutMuProccess(long gmvId,
			EnrollExtractJobFailManager failManager) {

		Date now = DateUtil.getCurrentDate();
		// get MAX_EXTRACT_JOB_FAILURES Property
		Integer maxExtractFailure = systemConfigDao.getMaxExtractjobFailure();

		failManager.checkExtractJobByMFEId(gmvId, maxExtractFailure, now,
				ExtractJobFailedReason.MFE_TIMEOUT);
	}

	/**
	 * 
	 */	
	public void poll() {
		printLogMessage("poll() is called.");

		StopWatch t = new StopWatch();
		t.start();

		Integer heartbeatTimeout = systemConfigDao.getHeartBeatTimeOut();

		// time out match units due to report.
		if (heartbeatTimeout >= 0) {
			checkAllMFEsTimeouts(heartbeatTimeout);
		} else {
			log.warn("Do not check because of heartbeatTimeout < 0. ");
		}

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_MFE_TIMEOUT_POLL_BEAN,
				LogConstants.FUNCTION_POLL, t.getTime());
	}

	/**
	 * 
	 * @param heartbeatTimeout
	 */
	private void checkAllMFEsTimeouts(Integer heartbeatTimeout) {
		EnrollExtractJobFailManager failManager = new EnrollExtractJobFailManager();

		Date minReport = findMinStart(heartbeatTimeout);

		printLogMessage("Querying for match units timed out due to report...");
		List<MatchUnitEntity> deadMUs = enrollMatchUnitDao
				.getTimedOutUtilsFromReport(minReport);
		for (MatchUnitEntity mu : deadMUs) {
			log.warn("{} is timeout, declaring dead.", mu.toString());

			if (log.isInfoEnabled()) {
				log.info(InfoLogger.statusInfoOutput(ComponentType.MFE.name(),
						LogConstants.EVENT_TIMEOUT, "unit id", String
								.valueOf(mu.getId())));
			}
			mu.setState(MUState.TIMED_OUT);
			enrollMatchUnitDao.mergeEnrollTMEUnitEntity(mu);
			timeoutMuProccess(mu.getId(), failManager);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
