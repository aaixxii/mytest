package jp.co.nec.lsm.tme.common.util;

import java.util.Date;

import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;

public class EnrollBatchJobGetterTimer {
	private Date nextGetJobTime;
	private boolean isOverHighLevelLimit = false;
	private int notCompleteJobs;
	
	private boolean isStop = false;
	private Thread sleepThread;
	private RoleStateTransition transitionState = RoleStateTransition.ACTIVE;
	
	
	public RoleStateTransition getTransitionState() {
		return transitionState;
	}

	public void setTransitionState(RoleStateTransition transitionState) {
		this.transitionState = transitionState;
	}

	public Thread getSleepThread() {
		return sleepThread;
	}

	public void setSleepThread(Thread sleepThread) {
		this.sleepThread = sleepThread;
	}

	private static EnrollBatchJobGetterTimer batchJobGetterTimer;

	private EnrollBatchJobGetterTimer() {
	}

	public static EnrollBatchJobGetterTimer getInstance() {
		if (batchJobGetterTimer == null) {
			batchJobGetterTimer = new EnrollBatchJobGetterTimer();
		}
		return batchJobGetterTimer;
	}

	public void setNextGetJobTime(Date nextGetJobTime) {
		this.nextGetJobTime = nextGetJobTime;
	}

	public Date getNextGetJobTime() {
		return nextGetJobTime;
	}

	public boolean isOverHighLevelLimit() {
		return isOverHighLevelLimit;
	}

	public void setOverHighLevelLimit(boolean isOverHighLevelLimit) {
		this.isOverHighLevelLimit = isOverHighLevelLimit;
	}

	public int getNotCompleteJobs() {
		return notCompleteJobs;
	}

	public void setNotCompleteJobs(int notCompleteJobs) {
		this.notCompleteJobs = notCompleteJobs;
	}

	public void setStop(boolean isStop) {
		this.isStop = isStop;
	}

	public boolean isStop() {
		return isStop;
	}

	public boolean isActive() {
		return getTransitionState() == RoleStateTransition.ACTIVE;
	}

	public boolean isStandBy() {
		return getTransitionState() == RoleStateTransition.PASSIVE;
	}
}
