package jp.co.nec.lsm.tme.common.util;

import jp.co.nec.lsm.event.enroll.EnrollAbstractEvent;
import jp.co.nec.lsm.event.enroll.EnrollBatchJobGetterBeanTimerEvent;
import jp.co.nec.lsm.event.enroll.EnrollExtractJobCompletedEvent;
import jp.co.nec.lsm.event.enroll.EnrollSegmentSynchronizedEvent;
import jp.co.nec.lsm.event.enroll.EnrollStartHeartbeatTimerEvent;
import jp.co.nec.lsm.event.enroll.EnrollStartJobPollbeanTimerEvent;
import jp.co.nec.lsm.event.enroll.EnrollStartMFEPollbeanTimerEvent;
import jp.co.nec.lsm.event.enroll.EnrollTemplateUpdatedEvent;
import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.event.enroll.common.EnrollReceiverEnum;
import jp.co.nec.lsm.event.enroll.notifier.EnrollNotifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/****
 * @author mozj <br>
 *         This class for sent the notice.
 */
public class EnrollEventBus {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(EnrollEventBus.class);

	/**
	 * Notify EnrollSegmentSyncServiceBean that Segment synchronization.
	 * 
	 * @param batchJobId
	 */
	public static void notifySegmentSync(long batchJobId) {
		printLogMessage("start public static function notifySegmentSync..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollTemplateUpdatedEvent(batchJobId,
				EnrollNotifierEnum.TemplateManagerBean,
				EnrollReceiverEnum.EnrollSegmentSyncService, true);
		notify.sendEvent(event);

		printLogMessage("end public static function notifySegmentSync..");
	}

	/**
	 * Notify EnrollUpdateBatchJobServiceBean that Batch Job Completed by Batch
	 * Job Id
	 * 
	 * @param batchJobId
	 *            completed Batch Job Id
	 */
	public static void notifyBatchJobCompleted(long batchJobId,
			EnrollNotifierEnum notifyEnum) {
		printLogMessage("start public static function notifyBatchJobCompleted..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollExtractJobCompletedEvent(
				batchJobId, notifyEnum, EnrollReceiverEnum.TemplateManagerBean);
		notify.sendEvent(event);

		printLogMessage("end public static function notifyBatchJobCompleted..");
	}

	/**
	 * Notify EnrollResponseServiceBean that Enroll Segment synchronization.
	 * 
	 * @param batchJobId
	 */
	public static void notifyResponse(long batchJobId,
			EnrollNotifierEnum notifyEnum) {
		printLogMessage("start public static function notifyResponse..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollSegmentSynchronizedEvent(
				batchJobId, notifyEnum,
				EnrollReceiverEnum.EnrollResponseService);
		notify.sendEvent(event);

		printLogMessage("end public static function notifyResponse..");
	}

	/**
	 * Notify EnrollSystemInitializationBean to Start Timer.
	 */
	public static void notifyStartJobPollTimerService() {
		printLogMessage("start private function notifyStartJobPollTimerService()..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollStartJobPollbeanTimerEvent(0L,
				EnrollNotifierEnum.EnrollSystemInitializationBean,
				EnrollReceiverEnum.EnrollJobPollTimerStarterBean);
		notify.sendEvent(event);

		printLogMessage("end private function notifyStartJobPollTimerService()..");
	}

	/**
	 * Notify EnrollSystemInitializationBean to Start Timer.
	 */
	public static void notifyEnrollBatchJobGetterTimerService() {
		printLogMessage("start private function notifyEnrollBatchJobGetterTimerService()..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollBatchJobGetterBeanTimerEvent(0L,
				EnrollNotifierEnum.EnrollSystemInitializationBean,
				EnrollReceiverEnum.EnrollBatchJobGetterTimerStartBean);
		notify.sendEvent(event);

		printLogMessage("end private function notifyEnrollBatchJobGetterTimerService()..");
	}

	/**
	 * Notify EnrollSystemInitializationBean to Start Timer.
	 */
	public static void notifyEnrollBatchJobHeartbeatStarterService(
			int pollDuraton) {
		printLogMessage("start private function notifyEnrollBatchJobHeartbeatStarterService()..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollStartHeartbeatTimerEvent(
				pollDuraton, EnrollNotifierEnum.EnrollSystemInitializationBean,
				EnrollReceiverEnum.EnrollHeartbeatStarterBean);
		notify.sendEvent(event);

		printLogMessage("end private function notifyEnrollBatchJobHeartbeatStarterService()..");
	}

	/**
	 * Notify EnrollSystemInitializationBean to Start Timer.
	 */
	public static void notifyStartMFEPollTimerService() {
		printLogMessage("start private function notifyStartMFEPollTimerService()..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollStartMFEPollbeanTimerEvent(0L,
				EnrollNotifierEnum.EnrollSystemInitializationBean,
				EnrollReceiverEnum.EnrollMFEPollTimerStarterBean);
		notify.sendEvent(event);

		printLogMessage("end private function notifyStartMFEPollTimerService()..");
	}

	/**
	 * Notify EnrollSegmentSyncServiceBean that Segment synchronization.
	 */
	public static void notifyDeleteSync(long batchJobId) {
		printLogMessage("start private function notifyDeleteSync()..");

		EnrollNotifier notify = new EnrollNotifier();
		EnrollAbstractEvent event = new EnrollTemplateUpdatedEvent(batchJobId,
				EnrollNotifierEnum.TemplateManagerBean,
				EnrollReceiverEnum.EnrollSegmentSyncService, false);
		notify.sendEvent(event);

		printLogMessage("end private function notifyDeleteSync()..");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
