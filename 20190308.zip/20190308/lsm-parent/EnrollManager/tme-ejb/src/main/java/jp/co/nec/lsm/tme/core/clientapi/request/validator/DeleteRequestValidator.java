package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import java.util.List;

import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.constants.RequestSpecConstants;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.exception.EmptyRequestIDException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

/**
 * @author mozj <br>
 * 
 */
public class DeleteRequestValidator {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(DeleteRequestValidator.class);

	/**
	 * validate all data in Enter Request whether there are correct.
	 * 
	 * @param extractResultRequest
	 * @return
	 */
	public static ValidationResult validate(DeleteRequest deleteRequest,
			List<CPBBusinessMessage> businessMessageList) {
		printLogMessage("start public function validate().");

		ValidationResult result = new ValidationResult();
		ValidationResultError error = null;

		long batchJobId = deleteRequest.getBatchJobId();

		error = validateBatchJobIdNotOverZero(batchJobId);
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		error = validateBatchJobIdDuplication(batchJobId);
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		error = validateBatchType(batchJobId, deleteRequest.getType());
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		error = validateBusinessMessageSize(batchJobId, businessMessageList
				.size());
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}
		return null;
	}

	/**
	 * 
	 * @param deleteRequest
	 * @param businessMessageList
	 * @return
	 */
	public static ValidationResult validateRequest(long batchJobId,
			CPBRequest request) {
		printLogMessage("start public function validateRequest().");

		ValidationResult result = new ValidationResult();
		ValidationResultError error = null;

		error = validateRequestIdCorrect(batchJobId, request.getRequestId());
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		error = validateRequestType(batchJobId, request.getRequestType());
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		error = validateReferenceIdCorrect(batchJobId, request
				.getEnrollmentId());
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		printLogMessage("end public function validateRequest().");
		return null;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateBatchJobIdDuplication(
			long batchJobId) {
		if (DeletionJobManager.getInstance().getDeletionJob(batchJobId) != null) {
			String errorInfo = "Delete Job ( DeleteRequest is duplicate. ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_BATCHJOB_DUPLICATED
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param batchJobId
	 * @param requestType
	 * @return
	 */
	private static ValidationResultError validateRequestType(long batchJobId,
			E_REQUESET_TYPE requestType) {
		if (requestType != E_REQUESET_TYPE.DELETE) {
			String errorInfo = "Delete Job ( DeleteRequest E_REQUESET_TYPE"
					+ " Type is incorrect. Now is " + requestType.name()
					+ " ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_BATCHTYPE_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param type
	 * @return
	 */
	private static ValidationResultError validateBatchType(long batchJobId,
			BatchType type) {
		if (type != BatchType.DELETE) {
			String errorInfo = "Delete Job ( DeleteRequest BatchType is incorrect. "
					+ "Now is " + type.name() + " ).";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_BATCHTYPE_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param requestId
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateBusinessMessageSize(
			long batchJobId, int size) {
		if (size != 1) {
			String errorInfo = "Delete Job ( DeleteRequest has " + size
					+ " jobs. It should be 1. ) ";
			log.error(errorInfo);
			return new ValidationResultError(
					false,
					0,
					EnrollErrorMessage.DELETEJOB_COUNT_INCORRECT.getErrorCode(),
					errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateBatchJobIdNotOverZero(
			long batchJobId) {
		if (batchJobId <= 0) {
			String errorInfo = "Delete Job ( Delete batch Job Id is not over zero. ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_BATCHJOBID_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param requestId
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateRequestIdCorrect(
			long batchJobId, String requestId) {
		if (requestId == null || requestId.isEmpty()) {
			String errorInfo = "Delete Job ( DeleteRequest Request Id is null or empty. ) ";
			log.error(errorInfo);
			throw new EmptyRequestIDException(errorInfo);
		} else if (requestId.length() != RequestSpecConstants.REQUEST_ID_LENGTH) {
			String errorInfo = " Delete Job ( DeleteRequest Request Id:"
					+ requestId + " length:" + requestId.length()
					+ " is incorrect. ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_REQUESTID_LENGTH_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param requestId
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateReferenceIdCorrect(
			long batchJobId, String referenceId) {
		if (referenceId == null) {
			String errorInfo = "Delete Job ( DeleteRequest Reference Id is null. )";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_REFERENCEID_LENGTH_INCORRECT
							.getErrorCode(), errorInfo);
		} else if (referenceId.length() != RequestSpecConstants.REFERENCE_ID_LENGTH) {
			String errorInfo = "Delete Job ( DeleteRequest Reference Id:"
					+ referenceId + " length:" + referenceId.length()
					+ " is incorrect. ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, 0,
					EnrollErrorMessage.DELETE_REFERENCEID_LENGTH_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
