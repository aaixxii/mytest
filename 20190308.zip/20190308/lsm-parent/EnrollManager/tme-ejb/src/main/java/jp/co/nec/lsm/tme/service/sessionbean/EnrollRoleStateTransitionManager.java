package jp.co.nec.lsm.tme.service.sessionbean;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollRoleStateTransitionManager {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(EnrollRoleStateTransitionManager.class);
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private EnrollSystemConfigDao systemConfigDao;
	
	public EnrollRoleStateTransitionManager() {		
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);	
	}

	/**
	 * fade out method <br>
	 */
	public String fadeOut() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		if (jobGetter.isStandBy()) {
			if (log.isInfoEnabled()) {
				log.info("state already {}. skip..",
						RoleStateTransition.PASSIVE.name());
			}
			return "state already PASSIVE. skip..";
		}

		jobGetter.setTransitionState(RoleStateTransition.PASSIVE);

		if (log.isInfoEnabled()) {
			log.info("set state to {}", RoleStateTransition.PASSIVE.name());
		}
		return "Success convert State to PASSIVE..";
	}

	/**
	 * wake Up method <br>
	 * 
	 * @param isNecessaryRecovery
	 * @param recoveryService
	 */
	public String wakeUp(EnrollRecoveryServiceBean recoveryService,
			boolean isNecessaryRecovery) {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		if (jobGetter.isStop()) {
			if (log.isInfoEnabled()) {
				log.info("TMe system is stoped. skip..");
			}
			return "TMe system is stoped. skip..";
		}
		if (jobGetter.isActive()) {
			if (log.isInfoEnabled()) {
				log.info("state already {}. skip..", RoleStateTransition.ACTIVE
						.name());
			}
			return "state already ACTIVE. skip..";
		}

		// check input parameter
		if (recoveryService == null) {
			String errorMessage = "recoveryService input parameter is null"
					+ " when recovery operation.";
			log.error(errorMessage);
			return errorMessage;
		}

		if (isNecessaryRecovery) {
			// first recovery the uncompleted jobs
			recoveryService.recoverUnCompletedBatchJob();

			if (log.isInfoEnabled()) {
				log.info("recovery the uncompleted jobs successfully "
						+ "while wake up operation");
			}
		} else {
			if (log.isInfoEnabled()) {
				log.info("delete the uncompleted jobs.");
			}

			recoveryService.unRecoverBatchJob();
		}

		jobGetter.setTransitionState(RoleStateTransition.ACTIVE);

		// interrupt the batch job getter sleep thread.
		Thread sleepThread = jobGetter.getSleepThread();
		if (sleepThread != null) {
			if (log.isInfoEnabled()) {
				log.info("interrupt the batch job getter sleep thread. "
						+ "thread Id: {}", sleepThread.getId());
			}
			sleepThread.interrupt();
		}

		if (log.isInfoEnabled()) {
			log.info("set state to {}", RoleStateTransition.ACTIVE.name());
		}
		return "Success convert State to ACTIVE..";
	}

	/**
	 * quickView
	 */
	public String quickView() {
		return EnrollBatchJobManager.reportTransitionState(systemConfigDao);
	}

}
