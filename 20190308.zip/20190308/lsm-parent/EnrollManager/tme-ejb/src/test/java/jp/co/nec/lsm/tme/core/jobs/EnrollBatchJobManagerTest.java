package jp.co.nec.lsm.tme.core.jobs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShot;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShotDetail;

public class EnrollBatchJobManagerTest {

	private int jobNumber = 1000;
	private final String referentID = "QueueManager_";

	@Before
	public void setUp() {
		clearMemoryQueue();
	}

	@After
	public void tearDown() {
		clearMemoryQueue();
	}

	/**
	 * clear Memory Queue
	 */
	private void clearMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();
		// remove all LocalEnrollBatchJob from Memory Queue
		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
	}

	/**
	 * test function getInstance and getEnrollLinkQueue
	 */
	@Test
	public void testGetInstanceAndGetEnrollLinkQueue() {
		// clear Memory Queue
		clearMemoryQueue();

		// call EnrollQueueManager.getInstance()
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		// assert result
		assertNotNull(enrollQueue);

		// call EnrollQueueManager.getEnrollLinkQueue()
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = enrollQueue
				.getEnrollLinkQueue();
		// assert result
		assertNotNull(enrollLinkQueue);

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function addEnrollBatchJob
	 */
	@Test
	public void testAddEnrollBatchJob() {
		final long batchID = 984L;

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber, 22, 12);

		// call EnrollQueueManager.addEnrollBatchJob(), add
		// LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob);

		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = enrollQueue
				.getEnrollLinkQueue();

		// assert result
		assertEquals(1, enrollLinkQueue.size());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function getEnrollBatchJobById
	 */
	@Test
	public void testGetEnrollBatchJobById() {
		final long batchID = 934L;

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber, 22, 12);
		// add LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob);

		// call EnrollQueueManager.addEnrollBatchJob()
		LocalEnrollBatchJob batchJob = enrollQueue
				.getEnrollBatchJobById(batchID);

		// assert result
		assertEquals(batchID, batchJob.getBatchJobId());
		assertEquals(jobNumber, batchJob.getExtractJobCount());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function getCompleteBatchJob
	 */
	@Test
	public void testGetCompleteBatchJob() {
		final long batchID = 964L;

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber, 22, 12);
		// add LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob);
		// call getCompleteBatchJob
		LocalEnrollBatchJob batchJob1 = enrollQueue
				.getCompleteBatchJob(enrollBatchJob.getBatchJobId());
		// assert result
		assertNull(batchJob1);

		// change LocalEnrollBatchJob Status for test
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTED);
		// call getCompleteBatchJob
		LocalEnrollBatchJob batchJob2 = enrollQueue
				.getCompleteBatchJob(enrollBatchJob.getBatchJobId());
		// assert result
		assertEquals(batchID, batchJob2.getBatchJobId());
		assertEquals(jobNumber, batchJob2.getExtractJobCount());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function DeleteCompleteBatchJob
	 */
	@Test
	public void testDeleteCompleteBatchJob() {
		final long batchID = 994L;

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber, 22, 12);
		// add LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob);
		// change LocalEnrollBatchJob Status for test
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.RETURNED);

		// call deleteCompleteBatchJob
		enrollQueue.deleteCompleteBatchJob(enrollBatchJob);

		// assert result
		LocalEnrollBatchJob batchJob3 = enrollQueue
				.getEnrollBatchJobById(batchID);
		assertNull(batchJob3);

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function GetNotSynchronizedEnrollBatchJobs
	 */
	@Test
	public void testGetNotSynchronizedEnrollBatchJobs() {
		final long batchID1 = 9094L;
		final long batchID2 = 9034L;
		final long batchID3 = 9014L;
		final long batchID4 = 9044L;
		final long batchID5 = 9114L;
		final long batchID6 = 9244L;

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob1 = prepareLocalEnrollBatchJob(
				batchID1, jobNumber, 22, 23);
		LocalEnrollBatchJob enrollBatchJob2 = prepareLocalEnrollBatchJob(
				batchID2, jobNumber, 22, 21);
		LocalEnrollBatchJob enrollBatchJob3 = prepareLocalEnrollBatchJob(
				batchID3, jobNumber, 22, 34);
		LocalEnrollBatchJob enrollBatchJob4 = prepareLocalEnrollBatchJob(
				batchID4, jobNumber, 22, 32);
		LocalEnrollBatchJob enrollBatchJob5 = prepareLocalEnrollBatchJob(
				batchID5, jobNumber, 22, 34);
		LocalEnrollBatchJob enrollBatchJob6 = prepareLocalEnrollBatchJob(
				batchID6, jobNumber, 22, 32);

		enrollBatchJob2.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob4.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);

		enrollBatchJob5.setSegmentPosition(null);
		enrollBatchJob5.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);

		// add LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob1);
		enrollQueue.addEnrollBatchJob(enrollBatchJob2);
		enrollQueue.addEnrollBatchJob(enrollBatchJob3);
		enrollQueue.addEnrollBatchJob(enrollBatchJob4);
		enrollQueue.addEnrollBatchJob(enrollBatchJob5);
		enrollQueue.addEnrollBatchJob(enrollBatchJob6);

		// call deleteCompleteBatchJob
		List<LocalEnrollBatchJob> batchJobList = enrollQueue
				.getNotSynchronizedEnrollBatchJobs();

		// assert result
		assertEquals(3, batchJobList.size());
		assertEquals(batchID5, batchJobList.get(0).getBatchJobId());
		assertEquals(batchID2, batchJobList.get(1).getBatchJobId());
		assertEquals(batchID4, batchJobList.get(2).getBatchJobId());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function GetNotSynchronizedEnrollBatchJobs
	 */
	@Test
	public void testGetNotSynchronizedEnrollBatchJobs_Order() {
		final long batchID1 = 9024L;
		final long batchID2 = 9034L;
		final long batchID3 = 9014L;
		final long batchID4 = 9044L;
		final long batchID5 = 9054L;
		final long batchID6 = 9064L;
		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob1 = prepareLocalEnrollBatchJob(
				batchID1, jobNumber, 22, 23);
		LocalEnrollBatchJob enrollBatchJob2 = prepareLocalEnrollBatchJob(
				batchID2, jobNumber, 22, 43);
		LocalEnrollBatchJob enrollBatchJob3 = prepareLocalEnrollBatchJob(
				batchID3, jobNumber, 22, 12);
		LocalEnrollBatchJob enrollBatchJob4 = prepareLocalEnrollBatchJob(
				batchID4, jobNumber, 22, 45);
		LocalEnrollBatchJob enrollBatchJob5 = prepareLocalEnrollBatchJob(
				batchID5, jobNumber, 21, 57);
		LocalEnrollBatchJob enrollBatchJob6 = prepareLocalEnrollBatchJob(
				batchID6, jobNumber, 20, 48);
		// add LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob1);
		enrollQueue.addEnrollBatchJob(enrollBatchJob2);
		enrollQueue.addEnrollBatchJob(enrollBatchJob3);
		enrollQueue.addEnrollBatchJob(enrollBatchJob4);
		enrollQueue.addEnrollBatchJob(enrollBatchJob5);
		enrollQueue.addEnrollBatchJob(enrollBatchJob6);

		enrollBatchJob1.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob2.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob3.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob4.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob5.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob6.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);

		// call deleteCompleteBatchJob
		List<LocalEnrollBatchJob> batchJobList = enrollQueue
				.getNotSynchronizedEnrollBatchJobs();

		// assert result
		assertEquals(6, batchJobList.size());
		assertEquals(batchID6, batchJobList.get(0).getBatchJobId());
		assertEquals(batchID5, batchJobList.get(1).getBatchJobId());
		assertEquals(batchID3, batchJobList.get(2).getBatchJobId());
		assertEquals(batchID1, batchJobList.get(3).getBatchJobId());
		assertEquals(batchID2, batchJobList.get(4).getBatchJobId());
		assertEquals(batchID4, batchJobList.get(5).getBatchJobId());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * prepare LocalEnrollBatchJob for test
	 * 
	 * @param batchJobId
	 * @param jobCount
	 * @return
	 */
	private LocalEnrollBatchJob prepareLocalEnrollBatchJob(long batchJobId,
			int jobCount, int segmentId, int segVersion) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());
		List<SegmentPosition> segmentPositions = new ArrayList<SegmentPosition>();
		SegmentPosition segPosition = new SegmentPosition();
		segPosition.setSegmentId(segmentId);
		segPosition.setVersion(segVersion);
		segPosition.setIndexStart(123);
		segPosition.setIndexEnd(234L);
		segmentPositions.add(segPosition);
		enrollBatchJob.setSegmentPosition(segmentPositions);

		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo jobInfo = new LocalExtractJobInfo();
			jobInfo.setExtractEndTS(DateUtil.getCurrentDate());
			jobInfo.setExtractStartTS(DateUtil.getCurrentDate());
			jobInfo.setFailureCount(i);
			jobInfo.setJobId(i);
			jobInfo.setReferenceId(referentID + i);
			jobInfo.setRequestId(String.valueOf(i));
			jobInfo.setReturnCode(ReturnCode.NotUsed);
			jobInfo.setStatus(LocalExtractJobStatus.EXTRACTING);
			jobInfo.setTemplate(prepareTemplate(String.valueOf(i))
					.toByteArray());
			enrollBatchJob.putExtractJobInfo(jobInfo);
		}
		return enrollBatchJob;
	}

	/**
	 * prepare Template for LocalExtractJobInfo
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;
			}
		}
		return ByteString.copyFrom(bs);
	}

	/**
	 * test function getSummary
	 */
	@Test
	public void testgetSummary() {
		final long batchID = 12394L;

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber, 22, 12);
		// change LocalEnrollBatchJob Status for test
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
		// add LocalEnrollBatchJob into Memory Queue
		EnrollBatchJobManager enrollQueue = EnrollBatchJobManager.getInstance();
		enrollQueue.addEnrollBatchJob(enrollBatchJob);

		// call deleteCompleteBatchJob
		String result = enrollQueue.getSummary();

		// assert result
		assertTrue(100 < result.length());

		// clear Memory Queue
		clearMemoryQueue();
	}

	@Test
	public void testGetBatchJobSnapShot() throws InterruptedException {
		final long batchID = 12394541L;

		// clear Memory Queue
		clearMemoryQueue();
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		for (int index = 0; index <= 5; index++) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			enrollBatchJob.setBatchJobId(batchID + index);
			enrollBatchJob
					.setBatchJobStatus(EnrollBatchJobStatus.values()[index]);
			enrollBatchJob.setBatchJobType(BatchType.ENROLL);
			enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());

			for (int i = 1; i <= 10; i++) {
				LocalExtractJobInfo jobInfo = new LocalExtractJobInfo();
				jobInfo.setJobId(i);
				jobInfo.setReferenceId(referentID + i);
				jobInfo.setRequestId(String.valueOf(i));

				if (index == 0) {
					jobInfo.setReturnCode(ReturnCode.NotUsed);
					jobInfo.setStatus(LocalExtractJobStatus.READY);
				} else if (index == 1) {
					jobInfo.setReturnCode(ReturnCode.NotUsed);
					jobInfo.setStatus(LocalExtractJobStatus.EXTRACTING);
				} else if (index == 4) {
					enrollBatchJob.setSyncGmv("DM");
					jobInfo.setReturnCode(ReturnCode.JobFailed);
					jobInfo.setStatus(LocalExtractJobStatus.DONE);
				} else {
					jobInfo.setReturnCode(ReturnCode.JobSuccess);
					jobInfo.setStatus(LocalExtractJobStatus.DONE);
				}

				enrollBatchJob.putExtractJobInfo(jobInfo);
			}

			queueManage.addEnrollBatchJob(enrollBatchJob);
		}

		Thread.sleep(10);

		EnrollBatchJobSnapShot snapShot = queueManage.GetBatchJobSnapShot();

		assertEquals(1, snapShot.getTransformerCount());
		assertEquals(1, snapShot.getExtractorCount());
		assertEquals(1, snapShot.getDataSerCount());
		assertEquals(1, snapShot.getSyncSerCount());
		assertEquals(1, snapShot.getResponseCount());
		assertNotNull(snapShot.getOutPutDate());

		List<EnrollBatchJobSnapShotDetail> list = snapShot.getDetailList();
		assertEquals(6, list.size());
		for (int index = 0; index <= 5; index++) {
			EnrollBatchJobStatus status = EnrollBatchJobStatus.values()[index];
			EnrollBatchJobSnapShotDetail detail = list.get(5 - index);
			assertEquals(batchID + index, detail.getBatchJobId());
			assertEquals(10, detail.getJobCount());
			assertEquals(status, detail.getStatus());
			assertTrue(0 < detail.getHoldingTime());
			assertEquals(String.valueOf(detail.getHoldingTime() / 1000) + "s",
					detail.getHoldingTime(status));
			if (index == 0) {
				assertEquals(0, detail.getExtractingJobCount());
				assertEquals("0", detail.getExtractingJobCount(status));
				assertEquals(0, detail.getExtractedJobCount());
				assertEquals("0", detail.getExtractedJobCount(status));
				assertEquals(0, detail.getTemplatesCount());
				assertEquals("<div style=\"color:Red\">0</div>", detail
						.getTemplatesCount(status));
				assertNull(detail.getSyncingGMV());
				assertEquals("-", detail.getSyncingGMV(status));
			} else if (index == 1) {
				assertEquals(10, detail.getExtractingJobCount());
				assertEquals("10", detail.getExtractingJobCount(status));
				assertEquals(0, detail.getExtractedJobCount());
				assertEquals("0", detail.getExtractedJobCount(status));
				assertEquals(0, detail.getTemplatesCount());
				assertEquals("<div style=\"color:Red\">0</div>", detail
						.getTemplatesCount(status));
				assertNull(detail.getSyncingGMV());
				assertEquals("-", detail.getSyncingGMV(status));
			} else if (index == 4) {
				assertEquals(0, detail.getExtractingJobCount());
				assertEquals("0", detail.getExtractingJobCount(status));
				assertEquals(10, detail.getExtractedJobCount());
				assertEquals("10", detail.getExtractedJobCount(status));
				assertEquals(0, detail.getTemplatesCount());
				assertEquals("<div style=\"color:Red\">0</div>", detail
						.getTemplatesCount(status));
				assertEquals("DM", detail.getSyncingGMV());
				assertEquals("DM", detail.getSyncingGMV(status));
			} else {
				assertEquals(0, detail.getExtractingJobCount());
				assertEquals("0", detail.getExtractingJobCount(status));
				assertEquals(10, detail.getExtractedJobCount());
				assertEquals("10", detail.getExtractedJobCount(status));
				assertEquals(10, detail.getTemplatesCount());
				assertEquals("10", detail.getTemplatesCount(status));
				assertNull(detail.getSyncingGMV());
				assertEquals("-", detail.getSyncingGMV(status));

				status = EnrollBatchJobStatus.QUEUED;
				assertEquals("-", detail.getHoldingTime(status));
				assertEquals("-", detail.getExtractingJobCount(status));
				assertEquals("-", detail.getExtractedJobCount(status));
				assertEquals("-", detail.getTemplatesCount(status));
				assertEquals("-", detail.getSyncingGMV(status));
			}
		}
	}
}
