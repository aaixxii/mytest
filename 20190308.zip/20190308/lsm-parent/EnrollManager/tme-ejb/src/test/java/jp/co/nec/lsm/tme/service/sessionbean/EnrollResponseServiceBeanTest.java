package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.httpclient.HttpMethod;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.util.TMETestUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollResponseServiceBeanTest {
	int port = 12345;
	@Resource
	private DataSource dataSource;
	@Resource
	private EnrollResponseServiceBean enrollResponseServiceBean;

	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}

		clearDB();
	}

	@After
	public void tearDown() {
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
	}

	/**
	 * 
	 */
	private void updateDB() {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'TRANSFORMER.ENROLL_POST_URL','http://127.0.0.1:"
						+ port + "')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (2,'TRANSFORMER.SEND_MAX_RETRY_COUNT','1')");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testdoResponse]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call AcceptService, add BatchJob into database<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testDeleteCompleteBatchJob() {

		long batchJobId = 18;
		int jobCount = 18;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		for (int i = 0; i < jobCount; i++) {
			CPBBusinessMessage request = TMETestUtil.preperaResponse(
					batchJobId, i + 1);
			businessMessageList.add(request);
		}

		LocalEnrollBatchJob enrollBatchJob = LocalEnrollBatchJob
				.createEnrollBatchJob(batchJobId, BatchType.ENROLL,
						businessMessageList, DateUtil.getCurrentDate());

		EnrollBatchJobManager.getInstance().addEnrollBatchJob(enrollBatchJob);

		// 3 - assert concerning information
		assertNotNull(queueManage.getEnrollBatchJobById(batchJobId));

		LocalEnrollBatchJob enrollBatchJobFirst = queueManage
				.getEnrollBatchJobById(batchJobId);
		enrollBatchJobFirst.setBatchJobStatus(EnrollBatchJobStatus.RETURNED);

		enrollResponseServiceBean.deleteCompleteBatchJob(enrollBatchJobFirst);
		assertNull(queueManage.getEnrollBatchJobById(batchJobId));

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testdoResponse]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call AcceptService, add BatchJob into database<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testDoResponse() {

		long batchJobId = 180;
		int jobCount = 18;

		clearDB();
		updateDB();
		setMock();
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 1 - prepare EnrollRequest For test
		LocalEnrollBatchJob enrollBatchJob = prepareDateforEnrollResultRequest(
				batchJobId, jobCount);

		// 2 - call AcceptService, add BatchJob into database
		queueManage.addEnrollBatchJob(enrollBatchJob);

		// 3 - assert concerning information
		assertNotNull(queueManage.getEnrollBatchJobById(batchJobId));

		LocalEnrollBatchJob enrollBatchJobFirst = queueManage
				.getEnrollBatchJobById(batchJobId);
		enrollBatchJobFirst
				.setBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED);

		enrollResponseServiceBean.doResponse(enrollBatchJobFirst
				.getBatchJobId());
		assertNull(queueManage.getEnrollBatchJobById(batchJobId));

	}

	/**
	 * prepare Data For EnrollResponse
	 * 
	 * @return
	 */
	private LocalEnrollBatchJob prepareDateforEnrollResultRequest(
			long batchJobId, int count) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setInsertEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setInsertStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setSyncStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setBatchJob_start_TS(DateUtil.getCurrentDate());

		for (int i = 1; i <= count; i++) {
			LocalExtractJobInfo info = new LocalExtractJobInfo();
			info.setExtractEndTS(DateUtil.getCurrentDate());
			info.setExtractStartTS(DateUtil.getCurrentDate());
			info.setFailureCount(i);
			info.setJobId(i);
			info.setMUId(23);
			info.setReferenceId("abcdef" + i);
			info.setRequestId(String.valueOf(i));
			if (i % 2 == 0) {
				info.setReturnCode(ReturnCode.JobSuccess);
			} else {
				info.setReturnCode(ReturnCode.JobFailed);
				info.setErrorCode("123456789");
				info.setReSendable(true);
				info.setErrorMessage("ErrorMessage");
			}
			info.setStatus(LocalExtractJobStatus.DONE);
			info.setTemplate(prepareTemplate(String.valueOf(i)).toByteArray());
			info.setRequest(TMETestUtil.preperaResponse(batchJobId, i + 1));
			info.setResponse(TMETestUtil.preperaResponse(batchJobId, i + 1));
			enrollBatchJob.putExtractJobInfo(info);
		}

		return enrollBatchJob;
	}

	/**
	 * prepare ByteString for LocalEnrollBatchJobInfo 1 - prepare Data For
	 * EnrollResponse
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	private void setMock() {
		new MockUp<HttpRequestSender>() {
			@Mock
			private HttpResponse sendHttpRequest(HttpMethod httpMethod,
					String url, Long batchJobId) {

				HttpResponse resp = new HttpResponse();
				resp.setHttpResponseBody(new byte[] {});
				return resp;
			}
		};
	}
}
