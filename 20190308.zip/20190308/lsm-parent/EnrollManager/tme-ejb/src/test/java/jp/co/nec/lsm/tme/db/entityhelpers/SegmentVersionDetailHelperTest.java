package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.SegmentVersionDetailEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SegmentVersionDetailHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
@Ignore
public class SegmentVersionDetailHelperTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetAllSegmentVersionDetails]<br/>
	 * 1 - prepare Segments/SegmentVersionDetail For test<br/>
	 * 2 - call getAllSegmentVersionDetails, get all SegmentVersionDetails
	 * information<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testgetAllSegmentVersionDetails() {
		// delete concerning table to avoid disturbing
		prepareDeleteSegmentVersinAndSegments();
		// 1 - prepare Segments/SegmentVersionDetail For test
		prepareSegments();
		prepareSegmentVersionDetail();

		SegmentVersionDetailHelper versionDetailHelper = new SegmentVersionDetailHelper(
				entityManager);

		// 2 - call getAllSegmentVersionDetails, get all SegmentVersionDetails
		// information
		List<SegmentVersionDetailEntity> versionDetailEntityList = versionDetailHelper
				.getAllSegmentVersionDetails();
		// 3 - assert concerning information
		assertEquals(4, versionDetailEntityList.size());

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [teatgetSegmentVersionDetails]<br/>
	 * 1 - prepare Segments/SegmentVersionDetail/getSegmentVersionDetails For
	 * test<br/>
	 * 2 - call getSegmentVersionDetails, get SegmentVersionDetails information<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void teatgetSegmentVersionDetails() {

		// delete concerning table to avoid disturbing
		prepareDeleteSegmentVersinAndSegments();

		// 1 - prepare Segments/SegmentVersionDetail/getSegmentVersionDetails
		// For test
		prepareSegments();
		prepareSegmentVersionDetail();
		preparegetSegmentVersionDetails();

		SegmentVersionDetailHelper versionDetailHelper = new SegmentVersionDetailHelper(
				entityManager);

		// 2 - call getSegmentVersionDetails, get SegmentVersionDetails
		// information
		List<SegmentVersionDetailEntity> list = versionDetailHelper
				.getSegmentVersionDetails(25);

		// 3 - assert concerning information
		assertEquals(6, list.size());

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetSegmentVersionDetail]<br/>
	 * 1 - prepare Segments/SegmentVersionDetail For test<br/>
	 * 2 - call getSegmentVersionDetail, get SegmentVersionDetail information<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testgetSegmentVersionDetail() {

		// delete concerning table to avoid disturbing
		prepareDeleteSegmentVersinAndSegments();

		// 1 - prepare Segments/SegmentVersionDetail For test
		prepareSegments();
		prepareSegmentVersionDetail();

		SegmentVersionDetailHelper versionDetailHelper = new SegmentVersionDetailHelper(
				entityManager);

		// 2 - call getSegmentVersionDetail, get SegmentVersionDetail
		// information
		SegmentVersionDetailEntity segmentVersion = versionDetailHelper
				.getSegmentVersionDetail(1, 9);

		// 3 - assert concerning information
		assertEquals(12, segmentVersion.getBioIdStart());
		assertEquals(21, segmentVersion.getBioIdEnd().longValue());

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetSegmentVersionDetail]<br/>
	 * 1 - prepare Segments/SegmentVersionDetail/persistSegmentDetails For test<br/>
	 * 2 - call persistSegmentDetails, get SegmentDetails information<br/>
	 * 3 - call getAllSegmentVersionDetails, get all SegmentVersionDetails
	 * information<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testpersistSegmentDetails() {

		// delete concerning table to avoid disturbing
		prepareDeleteSegmentVersinAndSegments();

		// 1 - prepare Segments/SegmentVersionDetail/persistSegmentDetails For
		// test
		prepareSegments();
		prepareSegmentVersionDetail();
		SegmentVersionDetailHelper versionDetailHelper = new SegmentVersionDetailHelper(
				entityManager);
		List<SegmentVersionDetailEntity> segmentDetails = preparepersistSegmentDetails();

		// 2 - call persistSegmentDetails, get SegmentDetails information
		versionDetailHelper.persistSegmentDetails(segmentDetails);

		// 3 - call getAllSegmentVersionDetails, get all SegmentVersionDetails
		// information
		List<SegmentVersionDetailEntity> versionDetailEntityList = versionDetailHelper
				.getAllSegmentVersionDetails();

		// 4 - assert concerning information
		assertEquals(20, versionDetailEntityList.size());

	}

	/**
	 * prepare data for testing 1 - prepare Data For
	 * TMESegmentVersionDetailHelper
	 */
	private List<SegmentVersionDetailEntity> preparepersistSegmentDetails() {
		// prepareSegments();
		List<SegmentVersionDetailEntity> segmentVersionList = new ArrayList<SegmentVersionDetailEntity>();
		for (long id = 20; id <= 35; id++) {
			SegmentVersionDetailEntity segmentVersionDetailEntity = new SegmentVersionDetailEntity();
			segmentVersionDetailEntity.setSegmentId(id);
			segmentVersionDetailEntity.setVersion(id + 1);
			segmentVersionDetailEntity.setBioIdStart(id);
			segmentVersionDetailEntity.setBioIdEnd(id + 50);
			segmentVersionDetailEntity.setUpdateTs(DateUtil.getCurrentDate());
			segmentVersionList.add(segmentVersionDetailEntity);
		}
		return segmentVersionList;
	}

	/**
	 * prepare data for testing 1 - prepare Data For
	 * TMESegmentVersionDetailHelper
	 * 
	 * @return
	 */
	private List<SegmentVersionDetailEntity> preparegetSegmentVersionDetails() {
		// prepareSegments();
		List<SegmentVersionDetailEntity> segmentVersionList = new ArrayList<SegmentVersionDetailEntity>();
		for (long id = 10; id <= 15; id++) {
			SegmentVersionDetailEntity segmentVersionDetailEntity = new SegmentVersionDetailEntity();
			segmentVersionDetailEntity.setSegmentId(25);
			segmentVersionDetailEntity.setVersion(id + 1);
			segmentVersionDetailEntity.setBioIdStart(id);
			segmentVersionDetailEntity.setBioIdEnd(id + 50);
			segmentVersionDetailEntity.setUpdateTs(DateUtil.getCurrentDate());
			segmentVersionList.add(segmentVersionDetailEntity);
		}
		SegmentVersionDetailHelper versionDetailHelper = new SegmentVersionDetailHelper(
				entityManager);
		versionDetailHelper.persistSegmentDetails(segmentVersionList);
		return segmentVersionList;
	}

	/**
	 * prepare data for testing 1 - prepare Data For
	 * TMESegmentVersionDetailHelper
	 */
	private void prepareSegmentVersionDetail() {

		String SegmentVersionDetailSql = "insert into SEGMENT_VERSION_DETAIL (SEGMENT_ID,VERSION,BIO_ID_START,"
				+ "BIO_ID_END,UPDATE_TS,RECORD_COUNT,CHANGE_TYPE)"
				+ " values(:SEGMENT_ID,:VERSION,:BIO_ID_START,:BIO_ID_END,:UPDATE_TS,:RECORD_COUNT, 0)";
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=3
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(1));
			argMap.put("VERSION", new Long(9));
			argMap.put("BIO_ID_START", new Long(12));
			argMap.put("BIO_ID_END", new Long(21));
			argMap.put("UPDATE_TS", DateUtil.getCurrentDate());
			argMap.put("RECORD_COUNT", new Long(2));
			jdbcTemplate.update(SegmentVersionDetailSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=12
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(2));
			argMap.put("VERSION", new Long(7));
			argMap.put("BIO_ID_START", new Long(73));
			argMap.put("BIO_ID_END", new Long(123));
			argMap.put("UPDATE_TS", DateUtil.getCurrentDate());
			argMap.put("RECORD_COUNT", new Long(4));
			jdbcTemplate.update(SegmentVersionDetailSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=31
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(5));
			argMap.put("VERSION", new Long(4));
			argMap.put("BIO_ID_START", new Long(22));
			argMap.put("BIO_ID_END", new Long(72));
			argMap.put("UPDATE_TS", DateUtil.getCurrentDate());
			argMap.put("RECORD_COUNT", new Long(1));
			jdbcTemplate.update(SegmentVersionDetailSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(9));
			argMap.put("VERSION", new Long(3));
			argMap.put("BIO_ID_START", new Long(345));
			argMap.put("BIO_ID_END", new Long(643));
			argMap.put("UPDATE_TS", DateUtil.getCurrentDate());
			argMap.put("RECORD_COUNT", new Long(5));
			jdbcTemplate.update(SegmentVersionDetailSql, argMap);
		}

	}

	/**
	 * delete concerning table to avoid disturbing
	 */
	private void prepareDeleteSegmentVersinAndSegments() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
	}

	/**
	 * prepare data for testing
	 */
	private void prepareSegments() {

		String segmentsSql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(:SEGMENT_ID,  :BIO_ID_START,:BIO_ID_END,"
				+ ":BINARY_LENGTH_COMPACTED, :RECORD_COUNT, :VERSION, :GENERATION, :BINARY_LENGTH_UNCOMPACTED)";
		{
			// insert into segments, SEGMENT_ID=1
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(1));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		{
			// insert into segments, SEGMENT_ID=2
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(2));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		{
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(5));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		String sql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, 1, 10, 10, 10, 1, 1, 100)";
		long max = jdbcTemplate
				.queryForObject("select MAX(SEGMENT_ID) from SEGMENTS",Long.class);
		for (long id = max + 1; id <= 35; id++) {
			jdbcTemplate.update(sql, new Object[] { new Long(id) },
					new int[] { Types.BIGINT });
		}
	}
}
