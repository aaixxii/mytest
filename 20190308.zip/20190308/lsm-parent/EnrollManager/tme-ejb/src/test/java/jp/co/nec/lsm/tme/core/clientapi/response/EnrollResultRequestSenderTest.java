package jp.co.nec.lsm.tme.core.clientapi.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.apache.commons.httpclient.HttpMethod;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.util.TMETestUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class EnrollResultRequestSenderTest {
	int port = 13345;

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testprepareEnrollResultRequest]<br/>
	 * 1 - prepare DateforEnrollResultRequest/EnrollResultRequest For test<br/>
	 * 2 - assert concerning information<br/>
	 */
	@Test
	public void testSendEnrollResponse() {
		long batchJobId = 1023;
		int jobCount = 20;

		// 1 - prepare LocalEnrollBatchJob For test
		LocalEnrollBatchJob batchJob = TMETestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);

		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo extractJobInfo = batchJob.getExtractJobInfo(i);
			extractJobInfo.setReturnCode(ReturnCode.JobSuccess);
		}

		// call EnrollResponse.prepareEnrollResultRequest
		EnrollResultRequest enrollResultRequest = EnrollResultRequestBuilder
				.createEnrollResultRequest(batchJob);

		// 2 - call sendEnrollResponse
		try {
			setMock();
			String url = "http://127.0.0.1:" + port;
			ResultRequestSender sender = new ResultRequestSender();
			HttpResponse returnedByte = sender.sendResponse(enrollResultRequest
					.toByteArray(), batchJobId, url);

			assertNotNull(returnedByte);
			assertEquals(0, returnedByte.getHttpResponseBody().length);
		} catch (Exception e) {
			fail();
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testprepareEnrollResultRequest]<br/>
	 * 1 - prepare DateforEnrollResultRequest/EnrollResultRequest For test<br/>
	 * 2 - assert concerning information<br/>
	 */
	@Test
	public void testSendEnrollResponse_Exception() {
		String url = "http://127.0.0.1:" + port;
		long batchJobId = 154;
		try {
			setMock();
			ResultRequestSender sender = new ResultRequestSender();
			sender.sendResponse(new byte[] { 1 }, batchJobId, url);

			fail();
		} catch (EnrollRuntimeException e) {
			assertEquals(e.getMessage(), "Exception when post batchJob "
					+ batchJobId + " to " + url);
		} catch (Exception e) {
			fail();
		}
	}

	private void setMock() {
		new MockUp<HttpRequestSender>() {
			@Mock
			private HttpResponse sendHttpRequest(HttpMethod httpMethod,
					String url, Long batchJobId) {
				if (batchJobId == 154) {
					throw new RuntimeException("");
				}

				HttpResponse resp = new HttpResponse();
				resp.setHttpResponseBody(new byte[] {});
				return resp;
			}
		};
	}
}
