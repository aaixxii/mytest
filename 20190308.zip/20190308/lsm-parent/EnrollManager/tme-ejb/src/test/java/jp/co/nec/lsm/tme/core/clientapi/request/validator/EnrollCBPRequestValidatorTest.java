package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBiometricElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBiometricsData;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tme.exception.EmptyRequestIDException;

public class EnrollCBPRequestValidatorTest {

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestId() {
		long batchJobId = 123;

		// prepare for test
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.valueOf(16));
		request.setEnrollmentId(String.format("%036d", 1));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.INSERT_REQUESTID_LENGTH_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestId_Empty() {
		long batchJobId = 123;

		// prepare for test
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId("");
		request.setEnrollmentId(String.format("%036d", 1));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		try {
			// call validate()
			EnrollCBPRequestValidator.validate(batchJobId, 1, request.build());
			fail();
		} catch (EmptyRequestIDException ex) {
			return;
		} catch (Exception ex) {
			fail();
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_E_REQUESET_TYPE() {
		long batchJobId = 123;

		// prepare for test
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 1546));
		request.setEnrollmentId(String.format("%036d", 1));
		request.setRequestType(E_REQUESET_TYPE.DELETE);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.E_REQUESET_TYPE_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_EnrollmentId() {
		long batchJobId = 123;

		// prepare for test
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 1546));
		request.setEnrollmentId(String.format("%037d", 1));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.INSERT_REFERENCEID_LENGTH_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NULLEnrollmentId() {
		long batchJobId = 123;

		// prepare for test
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 1546));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.INSERT_REFERENCEID_LENGTH_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NoBiometricsData() {
		long batchJobId = 123;

		// prepare for test
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 1546));
		request.setEnrollmentId(String.format("%036d", 1));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.BIOMETRICSDATA_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NoBiometricElement() {
		long batchJobId = 123;

		// prepare for test
		CPBBiometricsData.Builder biometricsData = CPBBiometricsData
				.newBuilder();
		biometricsData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_PATH);
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 1546));
		request.setEnrollmentId(String.format("%036d", 1));
		request.setRequestType(E_REQUESET_TYPE.INSERT);
		request.setBiometricsData(biometricsData);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.BIOMETRICSDATA_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NoFilePath() {
		long batchJobId = 123;

		// prepare for test
		CPBBiometricElement.Builder biometricElement = CPBBiometricElement
				.newBuilder();
		biometricElement.setFilePath("");
		biometricElement.setChecksum("");
		CPBBiometricsData.Builder biometricsData = CPBBiometricsData
				.newBuilder();
		biometricsData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_PATH);
		biometricsData.setBiometricElement(biometricElement);

		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 1546));
		request.setEnrollmentId(String.format("%036d", 1));
		request.setRequestType(E_REQUESET_TYPE.INSERT);
		request.setBiometricsData(biometricsData);

		// call validate()
		ValidationResult result = EnrollCBPRequestValidator.validate(
				batchJobId, 1, request.build());

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(1, error.getJobIndex());
			assertEquals(EnrollErrorMessage.BIOMETRICSDATA_INCORRECT
					.getErrorCode(), error.getErrorCode());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}
}
