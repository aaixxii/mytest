package jp.co.nec.lsm.tme.timer;

import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.EJB;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobGetterTimerStartBeanTest {
	boolean isNotNull = false;
	@Resource
	private EnrollBatchJobGetterPollBean pollBean;

	@EJB
	private EnrollBatchJobGetterTimerStartBean timerStartBean;

	/**
	 * setMockMethod
	 */
	public void setJMSMockMethod() {
		new MockUp<ServiceLocator>() {
			@SuppressWarnings( { "unchecked" })
			@Mock
			public <T> T getLookUpJndiObject(String jndiName, Class<T> clazz) {
				if (isNotNull) {
					return (T) pollBean;
				}
				throw new EnrollRuntimeException("Test Exception");
			}
		};
	}

	@Test
	public void testTimeOut_NotBound() {
		isNotNull = false;
		setJMSMockMethod();
		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		batchJobGetterTimer.setStop(false);
		batchJobGetterTimer.setTransitionState(RoleStateTransition.ACTIVE);
		batchJobGetterTimer.setNextGetJobTime(new Date());

		timerStartBean.startTimer();

		new StopThread().start();

		timerStartBean.timeout(null);
	}

	@Test
	public void testTimeOut_Bound() {
		isNotNull = true;
		setJMSMockMethod();
		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		batchJobGetterTimer.setStop(false);
		batchJobGetterTimer.setTransitionState(RoleStateTransition.ACTIVE);
		batchJobGetterTimer.setNextGetJobTime(new Date(new Date().getTime() + 4000));
		batchJobGetterTimer.setOverHighLevelLimit(true);

		timerStartBean.startTimer();

		new StopThread().start();

		timerStartBean.timeout(null);
	}

	class StopThread extends Thread {
		public void run() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
					.getInstance();
			batchJobGetterTimer.setStop(true);
		}
	}
}
