package jp.co.nec.lsm.tme.service.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.junit.Before;
import org.junit.Test;

import jp.co.nec.lsm.proto.extract.ExtractJobRequestProto.ExtractJobRequest;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJob;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJobResponse;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.util.TMETestUtil;

public class EnrollExtractJobAssignServiceBeanTest {

	private EnrollExtractJobAssignServiceBean assignServiceBean;

	EnrollBatchJobManager queueManage;

	@Before
	public void setUp() {
		assignServiceBean = new EnrollExtractJobAssignServiceBean();
		cleanMemoryQueue();
	}

	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
	}

	/**
	 * prepare data for ExtractJobRequest
	 * 
	 * @param muId
	 * @param requestJobNumber
	 * @return
	 */
	private ExtractJobRequest prepareExtractJobRequest(int muId,
			int requestJobNumber) {
		ExtractJobRequest.Builder jobRequest = ExtractJobRequest.newBuilder();
		jobRequest.setGmvId(muId);
		jobRequest.setMaxExtractJob(requestJobNumber);
		return jobRequest.build();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - prepare EnrollBatchJob/ExtractJobRequest For test<br/>
	 * 2 - call add, add LocalEnrollBatchJob to database<br/>
	 * 3 - call doAssign, to assign Extract Job<br/>
	 * 4 - call getEnrollBatchJobById, to get EnrollBatchJob<br/>
	 * 5 - query database to get data<br/>
	 * 6 - assert concerning information<br/>
	 */
	@Test
	public void testdoAssign() {
		long batchJobId = 13;
		int jobCount = 13;
		int assignedFirst = jobCount / 2;
		int assignedSecond = jobCount - assignedFirst;
		int muIdFirst = 13;
		int muIdSecond = 14;

		// clear Memory Queue and MATCH_UNITS table
		cleanMemoryQueue();

		// 1 - prepare EnrollBatchJob/ExtractJobRequest For test
		queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = TMETestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);
		// 2 - call add, add LocalEnrollBatchJob to database
		queueManage.addEnrollBatchJob(enrollBatchJob);

		ExtractJobRequest jobRequestFirst = prepareExtractJobRequest(muIdFirst,
				assignedFirst);

		// 3 - call doAssign, to assign Extract Job
		ExtractJobResponse extractJoResbFirst = (ExtractJobResponse) assignServiceBean
				.doAssign(jobRequestFirst);

		// 4 - call getEnrollBatchJobById, to get EnrollBatchJob
		LocalEnrollBatchJob enrollBatchJobFirst = queueManage
				.getEnrollBatchJobById(extractJoResbFirst.getBatchJobId());

		// 5 - query database to get data
		List<ExtractJob> jobInfoListFirst = extractJoResbFirst
				.getExtractJobList();

		// 6 - assert concerning information
		assertEquals(batchJobId, extractJoResbFirst.getBatchJobId());
		assertEquals(assignedFirst, extractJoResbFirst.getExtractJobCount());

		assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJobFirst
				.getBatchJobStatus());
		assertEquals(assignedFirst, enrollBatchJobFirst
				.getAssignedExtractJobCount());
		assertNotNull(enrollBatchJobFirst.getExtractStartTS());

		assertEquals(assignedFirst, jobInfoListFirst.size());

		for (int j = 0; j < assignedFirst; j++) {
			ExtractJob extractJobInfo = jobInfoListFirst.get(j);
			assertNotNull(extractJobInfo);

			LocalExtractJobInfo enrollBatchJobInfo = enrollBatchJobFirst
					.getExtractJobInfo(extractJobInfo.getJobIndex());
			assertNotNull(enrollBatchJobInfo);

			assertEquals(extractJobInfo.getJobIndex(), enrollBatchJobInfo
					.getJobId());
			assertTrue(extractJobInfo.getRequest().toByteArray().length > 0);
			for (int i = 0; i < extractJobInfo.getRequest().toByteArray().length; i++) {
				assertEquals(extractJobInfo.getRequest().toByteArray()[i],
						enrollBatchJobInfo.getRequest().toByteArray()[i]);
			}

			assertTrue(enrollBatchJobInfo
					.isStatus(LocalExtractJobStatus.EXTRACTING));
			assertNotNull(enrollBatchJobInfo.getExtractStartTS());
			assertEquals(muIdFirst, enrollBatchJobInfo.getMUId());
		}

		// 1 - prepare EnrollBatchJob/ExtractJobRequest For test
		ExtractJobRequest jobRequestSecond = prepareExtractJobRequest(
				muIdSecond, assignedSecond);

		// 3 - call doAssign, to assign Extract Job
		ExtractJobResponse extractJobSecond = (ExtractJobResponse) assignServiceBean
				.doAssign(jobRequestSecond);

		// 4 - call getEnrollBatchJobById, to get EnrollBatchJob
		LocalEnrollBatchJob enrollBatchJobSecond = queueManage
				.getEnrollBatchJobById(extractJobSecond.getBatchJobId());

		// 5 - query database to get data
		List<ExtractJob> jobInfoListSecond = extractJobSecond
				.getExtractJobList();

		// 6 - assert concerning information
		assertEquals(batchJobId, extractJobSecond.getBatchJobId());
		assertEquals(assignedSecond, extractJobSecond.getExtractJobCount());

		assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJobSecond
				.getBatchJobStatus());
		assertEquals(assignedFirst + assignedSecond, enrollBatchJobSecond
				.getAssignedExtractJobCount());

		assertEquals(assignedSecond, jobInfoListSecond.size());

		for (int j = 0; j < assignedSecond; j++) {
			ExtractJob extractJobInfo = jobInfoListSecond.get(j);
			assertNotNull(extractJobInfo);

			LocalExtractJobInfo enrollBatchJobInfo = enrollBatchJobSecond
					.getExtractJobInfo(extractJobInfo.getJobIndex());
			assertNotNull(enrollBatchJobInfo);
			assertEquals(extractJobInfo.getJobIndex(), enrollBatchJobInfo
					.getJobId());
			assertTrue(extractJobInfo.getRequest().toByteArray().length > 0);
			for (int i = 0; i < extractJobInfo.getRequest().toByteArray().length; i++) {
				assertEquals(extractJobInfo.getRequest().toByteArray()[i],
						enrollBatchJobInfo.getRequest().toByteArray()[i]);
			}

			assertTrue(enrollBatchJobInfo
					.isStatus(LocalExtractJobStatus.EXTRACTING));
			assertNotNull(enrollBatchJobInfo.getExtractStartTS());
			assertEquals(muIdSecond, enrollBatchJobInfo.getMUId());
		}

		// clear Memory Queue and MATCH_UNITS table
		cleanMemoryQueue();
	}

	@Test
	public void testdoAssign_ArgumentException() {

		try {
			assignServiceBean.doAssign(null);
		} catch (IllegalArgumentException ex) {
			assertEquals("ExtractJobRequest can not be null.", ex.getMessage());
		} catch (Exception ex) {
			fail();
		}
	}

	@Test
	public void testdoAssign_NoJob() {

		cleanMemoryQueue();

		ExtractJobRequest jobRequestFirst = prepareExtractJobRequest(12, 23);

		ExtractJobResponse response = assignServiceBean
				.doAssign(jobRequestFirst);

		assertNull(response);

		cleanMemoryQueue();
	}
}
