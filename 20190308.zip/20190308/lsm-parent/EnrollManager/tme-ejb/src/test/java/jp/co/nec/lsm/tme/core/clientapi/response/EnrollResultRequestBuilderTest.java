package jp.co.nec.lsm.tme.core.clientapi.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.util.TMETestUtil;

public class EnrollResultRequestBuilderTest {

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testprepareEnrollResultRequest]<br/>
	 * 1 - prepare DateforEnrollResultRequest/EnrollResultRequest For test<br/>
	 * 2 - assert concerning information<br/>
	 * 
	 * @throws InvalidProtocolBufferException
	 */
	@Test
	public void testCreateEnrollResultRequest()
			throws InvalidProtocolBufferException {
		long batchJobId = 123;
		int count = 10;

		// 1 - prepare LocalEnrollBatchJob For test
		LocalEnrollBatchJob batchJob = TMETestUtil
				.prepareDateforEnrollResultRequest(batchJobId, count);

		for (int i = 1; i <= count; i++) {
			LocalExtractJobInfo extractJobInfo = batchJob.getExtractJobInfo(i);
			extractJobInfo.setReturnCode(ReturnCode.JobSuccess);
		}
		// call EnrollResponse.prepareEnrollResultRequest
		EnrollResultRequest enrollResultRequest = EnrollResultRequestBuilder
				.createEnrollResultRequest(batchJob);

		// 2 - assert concerning information
		assertEquals(batchJobId, enrollResultRequest.getBatchJobId());
		assertEquals(count, enrollResultRequest.getBusinessMessageList().size());

		int assertCount = 0;
		// assert all EnrollJobResultInfo data
		for (int i = 0; i < enrollResultRequest.getBusinessMessageList().size(); i++) {
			for (int j = 1; j <= count; j++) {

				LocalExtractJobInfo extractJob = batchJob.getExtractJobInfo(j);
				ByteString resultByteString = enrollResultRequest
						.getBusinessMessageList().get(i);

				CPBBusinessMessage businessMessage = CPBBusinessMessage
						.parseFrom(resultByteString);

				if (businessMessage.getRequest().getRequestId().equals(
						extractJob.getRequestId())) {
					// assert EnrollJobResultInfo data
					assertTrue(resultByteString.toByteArray().length > 0);
					for (int k = 0; k < resultByteString.toByteArray().length; k++) {
						assertEquals(extractJob.getResponse().toByteArray()[k],
								resultByteString.toByteArray()[k]);
					}

					assertCount++;
				}
			}
		}
		assertEquals(count, assertCount);
	}
}
