package jp.co.nec.lsm.tme.core.jobs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

public class DeletionJobManagerTest {

	@Before
	public void setUp() {
		clearMemoryQueue();
	}

	@After
	public void tearDown() {
		clearMemoryQueue();
	}

	/**
	 * clear Memory Queue
	 */
	private void clearMemoryQueue() {
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = queueManage
				.getDeletionJobQueue();
		// remove all LocalEnrollBatchJob from Memory Queue
		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}
	}

	/**
	 * test function getInstance and getDeletionJobQueue
	 */
	@Test
	public void testGetInstanceAndGetDeletionJobQueue() {
		// clear Memory Queue
		clearMemoryQueue();

		// call DeletionJobManager.getInstance()
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		// assert result
		assertNotNull(queueManage);

		// call DeletionJobManager.getEnrollLinkQueue()
		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = queueManage
				.getDeletionJobQueue();
		// assert result
		assertNotNull(deletionJobQueue);

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function enqueueDeletionJob
	 */
	@Test
	public void testEnqueueDeletionJob() {
		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalDeletionJob for test
		LocalDeletionJob deletionJob = new LocalDeletionJob(12, 3, 21,
				"testReferenceId");

		// call DeletionJobManager.enqueueDeletionJob(), add
		// LocalDeletionJob into Memory Queue
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		queueManage.enqueueDeletionJob(deletionJob);

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = queueManage
				.getDeletionJobQueue();

		// assert result
		assertEquals(1, deletionJobQueue.size());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function enqueueDeletionJob
	 */
	@Test
	public void testGetDeletionJob() {
		// clear Memory Queue
		clearMemoryQueue();

		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setEnrollmentId("EnrollmentId");
		request.setRequestId("RequestId");
		request.setRequestType(E_REQUESET_TYPE.DELETE);

		// prepare LocalDeletionJob for test
		LocalDeletionJob deletionJob = new LocalDeletionJob(12, request.build());

		// call DeletionJobManager.enqueueDeletionJob(), add
		// LocalDeletionJob into Memory Queue
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		queueManage.enqueueDeletionJob(deletionJob);

		LocalDeletionJob deleteJob = queueManage.getDeletionJob(12);

		// assert result
		assertNotNull(deleteJob);

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function getNotSynchronizedDeletionJobs
	 */
	@Test
	public void testGetNotSynchronizedDeletionJobs() {
		String referenceId = "testReferenceId";

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalDeletionJob for test
		LocalDeletionJob deletionJob1 = new LocalDeletionJob(12, 3, 1221,
				referenceId + 1);
		LocalDeletionJob deletionJob2 = new LocalDeletionJob(12, 0, 1021,
				referenceId + 2);
		LocalDeletionJob deletionJob3 = new LocalDeletionJob(11, 4, 921,
				referenceId + 3);
		LocalDeletionJob deletionJob4 = new LocalDeletionJob(12, 5, 1521,
				referenceId + 4);
		LocalDeletionJob deletionJob5 = new LocalDeletionJob(11, 1, 1821,
				referenceId + 5);
		LocalDeletionJob deletionJob6 = new LocalDeletionJob(10, 7, 2521,
				referenceId + 6);

		// call DeletionJobManager.enqueueDeletionJob(), add
		// LocalDeletionJob into Memory Queue
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		queueManage.enqueueDeletionJob(deletionJob1);
		queueManage.enqueueDeletionJob(deletionJob2);
		queueManage.enqueueDeletionJob(deletionJob3);
		queueManage.enqueueDeletionJob(deletionJob4);
		queueManage.enqueueDeletionJob(deletionJob5);
		queueManage.enqueueDeletionJob(deletionJob6);

		// call DeletionJobManager.getNotSynchronizedDeletionJobs()
		List<LocalDeletionJob> deletionJobs = queueManage
				.getNotSynchronizedDeletionJobs();
		// assert result
		assertEquals(6, deletionJobs.size());

		assertEquals(10, deletionJobs.get(0).getSegmentId());
		assertEquals(7, deletionJobs.get(0).getVersion());
		assertEquals(2521, deletionJobs.get(0).getBiometricsId());
		assertEquals(referenceId + 6, deletionJobs.get(0).getReferenceId());

		assertEquals(11, deletionJobs.get(1).getSegmentId());
		assertEquals(1, deletionJobs.get(1).getVersion());
		assertEquals(1821, deletionJobs.get(1).getBiometricsId());
		assertEquals(referenceId + 5, deletionJobs.get(1).getReferenceId());

		assertEquals(11, deletionJobs.get(2).getSegmentId());
		assertEquals(4, deletionJobs.get(2).getVersion());
		assertEquals(921, deletionJobs.get(2).getBiometricsId());
		assertEquals(referenceId + 3, deletionJobs.get(2).getReferenceId());

		assertEquals(12, deletionJobs.get(3).getSegmentId());
		assertEquals(0, deletionJobs.get(3).getVersion());
		assertEquals(1021, deletionJobs.get(3).getBiometricsId());
		assertEquals(referenceId + 2, deletionJobs.get(3).getReferenceId());

		assertEquals(12, deletionJobs.get(4).getSegmentId());
		assertEquals(3, deletionJobs.get(4).getVersion());
		assertEquals(1221, deletionJobs.get(4).getBiometricsId());
		assertEquals(referenceId + 1, deletionJobs.get(4).getReferenceId());

		assertEquals(12, deletionJobs.get(5).getSegmentId());
		assertEquals(5, deletionJobs.get(5).getVersion());
		assertEquals(1521, deletionJobs.get(5).getBiometricsId());
		assertEquals(referenceId + 4, deletionJobs.get(5).getReferenceId());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function getNotSynchronizedDeletionJobs
	 */
	@Test
	public void testGetNotSynchronizedDeletionJobs_HasSynced() {
		String referenceId = "testReferenceId";

		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalDeletionJob for test
		LocalDeletionJob deletionJob1 = new LocalDeletionJob(12, 3, 1221,
				referenceId + 1);
		LocalDeletionJob deletionJob2 = new LocalDeletionJob(12, 0, 1021,
				referenceId + 2);
		LocalDeletionJob deletionJob3 = new LocalDeletionJob(11, 4, 921,
				referenceId + 3);
		LocalDeletionJob deletionJob4 = new LocalDeletionJob(12, 5, 1521,
				referenceId + 4);
		LocalDeletionJob deletionJob5 = new LocalDeletionJob(11, 1, 1821,
				referenceId + 5);
		deletionJob5.setSynchronized(true);
		LocalDeletionJob deletionJob6 = new LocalDeletionJob(10, 7, 2521,
				referenceId + 6);
		deletionJob6.setSynchronized(true);

		// call DeletionJobManager.enqueueDeletionJob(), add
		// LocalDeletionJob into Memory Queue
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		queueManage.enqueueDeletionJob(deletionJob1);
		queueManage.enqueueDeletionJob(deletionJob2);
		queueManage.enqueueDeletionJob(deletionJob3);
		queueManage.enqueueDeletionJob(deletionJob4);
		queueManage.enqueueDeletionJob(deletionJob5);
		queueManage.enqueueDeletionJob(deletionJob6);

		// call DeletionJobManager.getNotSynchronizedDeletionJobs()
		List<LocalDeletionJob> deletionJobs = queueManage
				.getNotSynchronizedDeletionJobs();
		// assert result
		assertEquals(4, deletionJobs.size());

		assertEquals(11, deletionJobs.get(0).getSegmentId());
		assertEquals(4, deletionJobs.get(0).getVersion());
		assertEquals(921, deletionJobs.get(0).getBiometricsId());
		assertEquals(referenceId + 3, deletionJobs.get(0).getReferenceId());

		assertEquals(12, deletionJobs.get(1).getSegmentId());
		assertEquals(0, deletionJobs.get(1).getVersion());
		assertEquals(1021, deletionJobs.get(1).getBiometricsId());
		assertEquals(referenceId + 2, deletionJobs.get(1).getReferenceId());

		assertEquals(12, deletionJobs.get(2).getSegmentId());
		assertEquals(3, deletionJobs.get(2).getVersion());
		assertEquals(1221, deletionJobs.get(2).getBiometricsId());
		assertEquals(referenceId + 1, deletionJobs.get(2).getReferenceId());

		assertEquals(12, deletionJobs.get(3).getSegmentId());
		assertEquals(5, deletionJobs.get(3).getVersion());
		assertEquals(1521, deletionJobs.get(3).getBiometricsId());
		assertEquals(referenceId + 4, deletionJobs.get(3).getReferenceId());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function DeleteCompleteBatchJob
	 */
	@Test
	public void testDeleteCompleteBatchJob() {
		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalDeletionJob for test
		LocalDeletionJob deletionJob = new LocalDeletionJob(12, 3, 21,
				"testReferenceId");

		// call DeletionJobManager.enqueueDeletionJob(), add
		// LocalDeletionJob into Memory Queue
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		queueManage.enqueueDeletionJob(deletionJob);

		// call deleteCompleteBatchJob
		queueManage.deleteDeletionJob(deletionJob);

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = queueManage
				.getDeletionJobQueue();

		// assert result
		assertEquals(0, deletionJobQueue.size());

		// clear Memory Queue
		clearMemoryQueue();
	}

	/**
	 * test function getSummary
	 */
	@Test
	public void testgetSummary() {
		// clear Memory Queue
		clearMemoryQueue();

		// prepare LocalDeletionJob for test
		LocalDeletionJob deletionJob = new LocalDeletionJob(12, 3, 21,
				"testReferenceId");

		// call DeletionJobManager.enqueueDeletionJob(), add
		// LocalDeletionJob into Memory Queue
		DeletionJobManager queueManage = DeletionJobManager.getInstance();
		queueManage.enqueueDeletionJob(deletionJob);

		// call deleteCompleteBatchJob
		String str = queueManage.getSummary();

		// assert result
		assertTrue(100 < str.length());

		// clear Memory Queue
		clearMemoryQueue();
	}
}
