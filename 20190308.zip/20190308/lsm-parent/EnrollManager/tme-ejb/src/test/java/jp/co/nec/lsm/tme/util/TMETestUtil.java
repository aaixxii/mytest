package jp.co.nec.lsm.tme.util;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBAttributeGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBiometricElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBiometricsData;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBInlineBiometricElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBModalityDataElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBModalityDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBParameterGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequestAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequestAttributes;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequestParameter;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequestParameters;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import com.nec.everest.proto.protobuf.BusinessMessage.E_MODALITY_TYPE;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.sender.AbstractEventSender;
import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.common.util.ResponseMessageBuilder;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import mockit.Mock;
import mockit.MockUp;

public class TMETestUtil {

	public static int PERSON_TEMPLATE_SIZE = 15680;

	/**
	 * prepare Data For EnrollResponse
	 * 
	 * @return
	 */
	public static LocalEnrollBatchJob prepareDateforEnrollResultRequest(
			long batchJobId, int count) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.QUEUED);
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setInsertEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setInsertStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setSyncStartTS(DateUtil.getCurrentDate());

		for (int i = 1; i <= count; i++) {
			LocalExtractJobInfo info = new LocalExtractJobInfo();
			info.setExtractEndTS(DateUtil.getCurrentDate());
			info.setExtractStartTS(DateUtil.getCurrentDate());
			info.setFailureCount(i);
			info.setJobId(i);
			info.setMUId(23);
			info.setReferenceId("abcdef" + i);
			info.setReturnCode(ReturnCode.NotUsed);
			info.setStatus(LocalExtractJobStatus.READY);
			info.setTemplate(prepareTemplate(String.valueOf(i)).toByteArray());

			CPBBusinessMessage businessMessage = preperaResponse(batchJobId, i);
			info.setRequestId(businessMessage.getRequest().getRequestId());
			info.setRequest(businessMessage);
			info.setResponse(businessMessage);
			enrollBatchJob.putExtractJobInfo(info);
		}

		return enrollBatchJob;
	}

	public static void main(String[] args) {
		CPBBusinessMessage businessMessage = preperaResponse(12, 2);
		CPBBusinessMessage.Builder business = businessMessage.toBuilder();
		business.setResponse(ResponseMessageBuilder.rebuildCPBResponse(
				businessMessage.getResponse(), ReturnCode.JobFailed,
				"error           Code", "error               Message", "Y"));

		CPBBusinessMessage end = business.build();

		System.out.println(end.toString());
	}

	/**
	 * 
	 * @param batchJobIs
	 * @param i
	 * @return
	 */
	public static CPBBusinessMessage preperaResponse(long batchJobId, int i) {
		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();

		// CPBBiometricElement
		CPBBiometricElement.Builder biometricElement = CPBBiometricElement
				.newBuilder();
		biometricElement.setFilePath("TestFilePath");
		biometricElement.setChecksum("13224");
		biometricElement.setBufferValue1("BufferValue1");

		// CPBInlineBiometricElement
		CPBInlineBiometricElement.Builder inlineBiometricElement = CPBInlineBiometricElement
				.newBuilder();
		inlineBiometricElement.setModalityType(E_MODALITY_TYPE.FINGER);
		inlineBiometricElement.setModalitySubType("SubType");
		inlineBiometricElement.setBiometricData("A14432BFEDA132");
		inlineBiometricElement.setBufferValue1("BufferValue1");

		// CPBBiometricsData
		CPBBiometricsData.Builder biometricsData = CPBBiometricsData
				.newBuilder();
		biometricsData
				.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FMR);
		biometricsData.setBiometricElement(biometricElement);
		biometricsData.addInlineBiometricElement(inlineBiometricElement);

		// CPBRequestAttribute
		CPBRequestAttribute.Builder requestAttribute = CPBRequestAttribute
				.newBuilder();
		requestAttribute.setAttributeName("requestAttributeName");
		requestAttribute.setAttributeValue("requestAttributeValue");

		// CPBAttributeGroup
		CPBAttributeGroup.Builder attributeGroup = CPBAttributeGroup
				.newBuilder();
		attributeGroup.setGroupName("attributeGroup");
		attributeGroup.addRequestAttribute(requestAttribute);

		// CPBRequestAttributes
		CPBRequestAttributes.Builder requestAttributes = CPBRequestAttributes
				.newBuilder();
		requestAttributes.addAttributeGroup(attributeGroup);
		requestAttributes.addRequestAttribute(requestAttribute);

		// CPBRequestParameter
		CPBRequestParameter.Builder requestParameter = CPBRequestParameter
				.newBuilder();
		requestParameter.setParameterName("ParameterName");
		requestParameter.setParameterValue("ParameterValue");

		CPBParameterGroup.Builder parameterGroup = CPBParameterGroup
				.newBuilder();
		parameterGroup.setGroupName("Test");
		parameterGroup.addRequestParameter(requestParameter);

		CPBRequestParameters.Builder requestParameters = CPBRequestParameters
				.newBuilder();
		requestParameters.addParameterGroup(parameterGroup);

		// CPBRequest
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%018d", batchJobId)
				+ String.format("%018d", 15 + i));
		request.setEnrollmentId("QueueManager_" + String.format("%023d", i));
		request.setRequestType(E_REQUESET_TYPE.INSERT);
		request.setBiometricsData(biometricsData);
		request.setRequestAttributes(requestAttributes);
		// request.addRequestParameters(requestParameters);

		// CPBResponseAttribute
		CPBResponseAttribute.Builder attribute = CPBResponseAttribute
				.newBuilder();
		attribute.setAttributeName("TestAttributeName");
		attribute.setAttributeValue("TestAttributeValue");

		// CPBResponse
		CPBResponse.Builder response = CPBResponse.newBuilder();
		response.setStatus("0");
		response.setResendable("");
		response.setErrorMessage("message_123456789");
		response.addResponseAttributes(attribute.build());

		// CPBProcessInfo
		CPBProcessInfo.Builder processInfo = CPBProcessInfo.newBuilder();
		processInfo.setProcessName("TestProcessName");
		processInfo.setStartTime("TestProcessStartTrime");
		processInfo.setEndTime("TestProcessEndTrime");

		// CPBProcessMetrics
		CPBProcessMetrics.Builder processMetrics = CPBProcessMetrics
				.newBuilder();
		processMetrics.addProcessMetric(processInfo);

		// CPBDataElement
		CPBDataElement.Builder dataElement = CPBDataElement.newBuilder();
		dataElement.setElementName("TestElementName");
		dataElement.setElementValue("TestElementValue");

		// CPBDataGroup
		CPBDataGroup.Builder dataGroup = CPBDataGroup.newBuilder();
		dataGroup.setGroupName("TestDataGroupName");
		dataGroup.addDataElement(dataElement);

		// CPBModalityDataElement
		CPBModalityDataElement.Builder modalityDataElement = CPBModalityDataElement
				.newBuilder();
		modalityDataElement.setModalityType(E_MODALITY_TYPE.FACE);
		modalityDataElement.setModalitySubType("TestModalitySubType");
		modalityDataElement.setAttempt("TestAttempt");
		modalityDataElement.setValue("TestValue");

		// CPBModalityDataGroup
		CPBModalityDataGroup.Builder modalityDataGroup = CPBModalityDataGroup
				.newBuilder();
		modalityDataGroup.setGroupName("TestModalityDataGroupName");
		modalityDataGroup.addModalityDataElement(modalityDataElement);

		// CPBDataBlock
		CPBDataBlock.Builder dataBlock = CPBDataBlock.newBuilder();
		dataBlock.setProcessMetric(processMetrics);
		dataBlock.addDataGroup(dataGroup);
		dataBlock.addModalityDataGroup(modalityDataGroup);

		businessMessage.setRequest(request.build());
		businessMessage.setResponse(response.build());
		businessMessage.setDataBlock(dataBlock);

		return businessMessage.build();
	}

	/**
	 * prepare ByteString for LocalEnrollBatchJobInfo 1 - prepare Data For
	 * EnrollResponse
	 * 
	 * @param jobId
	 * @return
	 */
	public static ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	/**
	 * 
	 * @param batchJobId
	 * @param extractJobCount
	 * @return
	 */
	public static List<CPBBusinessMessage> prepareCPBBusinessMessage(
			long batchJobId, int extractJobCount, String referentID,
			String referentURL) {
		return prepareCPBBusinessMessage(batchJobId, extractJobCount, "",
				referentID, referentURL);

	}

	/**
	 * 
	 * @param batchJobId
	 * @param extractJobCount
	 * @param requestID
	 * @param referentID
	 * @param referentURL
	 * @return
	 */
	public static List<CPBBusinessMessage> prepareCPBBusinessMessage(
			long batchJobId, int extractJobCount, String requestID,
			String referentID, String referentURL) {

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		for (int i = 1; i <= extractJobCount; i++) {

			// CPBBiometricElement
			CPBBiometricElement.Builder biometricElement = CPBBiometricElement
					.newBuilder();
			biometricElement.setFilePath(referentURL
					+ String.format("%026d", i));
			biometricElement.setChecksum("13224");
			biometricElement.setBufferValue1("BufferValue1");

			// CPBInlineBiometricElement
			CPBInlineBiometricElement.Builder inlineBiometricElement = CPBInlineBiometricElement
					.newBuilder();
			inlineBiometricElement.setModalityType(E_MODALITY_TYPE.FINGER);
			inlineBiometricElement.setModalitySubType("SubType");
			inlineBiometricElement.setBiometricData("A14432BFEDA132");
			inlineBiometricElement.setBufferValue1("BufferValue1");

			// CPBBiometricsData
			CPBBiometricsData.Builder biometricsData = CPBBiometricsData
					.newBuilder();
			biometricsData
					.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FMR);
			biometricsData.setBiometricElement(biometricElement);
			biometricsData.addInlineBiometricElement(inlineBiometricElement);

			// CPBRequestAttribute
			CPBRequestAttribute.Builder requestAttribute = CPBRequestAttribute
					.newBuilder();
			requestAttribute.setAttributeName("requestAttributeName");
			requestAttribute.setAttributeValue("requestAttributeValue");

			// CPBAttributeGroup
			CPBAttributeGroup.Builder attributeGroup = CPBAttributeGroup
					.newBuilder();
			attributeGroup.setGroupName("attributeGroup");
			attributeGroup.addRequestAttribute(requestAttribute);

			// CPBRequestAttributes
			CPBRequestAttributes.Builder requestAttributes = CPBRequestAttributes
					.newBuilder();
			requestAttributes.addAttributeGroup(attributeGroup);
			requestAttributes.addRequestAttribute(requestAttribute);

			// CPBRequestParameter
			CPBRequestParameter.Builder requestParameter = CPBRequestParameter
					.newBuilder();
			requestParameter.setParameterName("ParameterName");
			requestParameter.setParameterValue("ParameterValue");

			// CPBRequest
			CPBRequest.Builder request = CPBRequest.newBuilder();
			request.setRequestId(requestID + String.format("%036d", 15 + i));
			request.setEnrollmentId(String.format("%09d", batchJobId)
					+ referentID + String.format("%09d", i));
			request.setRequestType(E_REQUESET_TYPE.INSERT);
			request.setBiometricsData(biometricsData);
			request.setRequestAttributes(requestAttributes);
			// request.addRequestParameters(requestParameter);

			// CPBBusinessMessage
			CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
					.newBuilder();
			businessMessage.setRequest(request.build());

			businessMessageList.add(businessMessage.build());
		}

		return businessMessageList;
	}

	/**
	 * setMockMethod
	 */
	public static void setJMSMockMethod() {
		new MockUp<AbstractEventSender>() {
			@Mock
			public void convertAndSend(Event message) {
				return;
			}
		};
	}
}
