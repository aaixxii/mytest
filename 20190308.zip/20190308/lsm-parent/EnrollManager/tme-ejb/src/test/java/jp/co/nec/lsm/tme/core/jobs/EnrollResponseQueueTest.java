package jp.co.nec.lsm.tme.core.jobs;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.clientapi.response.EnrollResultRequestBuilder;
import jp.co.nec.lsm.tme.core.jobs.EnrollResponseQueue.Statistics;
import jp.co.nec.lsm.tme.util.TMETestUtil;
import junit.framework.Assert;

public class EnrollResponseQueueTest {

	/** test instance **/
	private static final EnrollResponseQueue INSTANCE = EnrollResponseQueue
			.getInstance();

	@Before
	public void setUp() {
		EnrollBatchJobManager.getInstance().clearAll();
		INSTANCE.clearAll();
	}

	@After
	public void tearDown() {
		EnrollBatchJobManager.getInstance().clearAll();
		INSTANCE.clearAll();
	}

	@Test
	public void testAddParaNull() {
		INSTANCE.add(null);
		Assert.assertEquals(INSTANCE.responseStatistics().size(), 0);
	}

	/**
	 * addBatchJob
	 * 
	 * @param beginBatchJobId
	 */
	private void addBatchJob(long beginBatchJobId, int max) {
		final int count = 10;
		for (int index = 0; index < max; index++) {
			LocalEnrollBatchJob batchJob = TMETestUtil
					.prepareDateforEnrollResultRequest(beginBatchJobId + index,
							count);
			for (int i = 1; i <= count; i++) {
				LocalExtractJobInfo extractJobInfo = batchJob
						.getExtractJobInfo(i);
				extractJobInfo.setReturnCode(ReturnCode.JobSuccess);
			}

			EnrollResultRequest enrollResultRequest = EnrollResultRequestBuilder
					.createEnrollResultRequest(batchJob);
			INSTANCE.add(enrollResultRequest);
		}
	}

	@Test
	public void testAdd() {
		final long beginBatchJobId = 1L;
		final int max = 150;

		addBatchJob(beginBatchJobId, max);

		Set<Long> treeSet = new TreeSet<Long>(INSTANCE.getResponseMapKeySet());
		Assert.assertEquals(treeSet.size(), EnrollResponseQueue.MAX_CAPACITY);

		long beginBatchJobIdExpect = max - EnrollResponseQueue.MAX_CAPACITY + 1;
		for (Long batchJobid : treeSet) {
			Assert.assertEquals(batchJobid.longValue(), beginBatchJobIdExpect++);
		}
	}

	@Test
	public void testResponseStatisticsEmpty() {
		Map<Long, Statistics> statistics = INSTANCE.responseStatistics();
		Assert.assertEquals(statistics.size(), 0);
	}

	@Test
	public void testResponseStatistics() {
		final long beginBatchJobId = 201L;
		final int max = 200;

		addBatchJob(beginBatchJobId, max);
		Map<Long, Statistics> statisticsMap = INSTANCE.responseStatistics();

		Set<Long> sets = new TreeSet<Long>(statisticsMap.keySet());
		long beginBatchJobIdExpect = beginBatchJobId + max
				- EnrollResponseQueue.MAX_CAPACITY;
		for (Long batchJobId : sets) {
			Statistics statistics = statisticsMap.get(batchJobId);
			Assert.assertEquals(batchJobId.longValue(), beginBatchJobIdExpect++);
			Assert.assertEquals(statistics.getAllTljSize().intValue(), 10);
			Assert.assertEquals(statistics.getCorrectTljSize().intValue(), 10);
		}
	}
}
