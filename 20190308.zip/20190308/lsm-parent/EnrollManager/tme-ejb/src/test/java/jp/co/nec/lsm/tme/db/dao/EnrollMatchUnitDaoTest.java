package jp.co.nec.lsm.tme.db.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuContactEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollMatchUnitDaoTest {
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	
	@EJB
	EnrollMatchUnitDao matchUnitDao;

	@Before
	public void setUp() {
		prepareDeleteConcerningTable();
	}

	@After
	public void tearDown() {
		prepareDeleteConcerningTable();
	}

	/**
	 * clear concerning table in database for testing
	 */
	private void prepareDeleteConcerningTable() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM MATCH_UNITS");
	}

	/**
	 * prepare data for testupdate method
	 * 
	 * 1 - prepare Data For TMEMatchUnitHelper
	 * 
	 * @return
	 */
	private MatchUnitEntity prepareUpdate() {
		MatchUnitEntity mu = new MatchUnitEntity();
		MuContactEntity muContactEntity = new MuContactEntity();
		{
			muContactEntity.setIdle(true);
			muContactEntity.setLastContactTime(DateUtil.getCurrentDate());
			muContactEntity.setLastReportTime(DateUtil.getCurrentDate());
			muContactEntity.setMuId(2L);
		}
		mu.setBalanced(true);
		mu.setNumCPUs((short) 2);
		mu.setRevision(4);
		mu.setURL("http://1234567");
		mu.setUniqueId("unique");
		mu.setType(ComponentType.MFE);
		mu.setState(MUState.TIMED_OUT);
		mu.setPerformanceFactor(1.1f);
		mu.setPrimarySize(4L);
		mu.setSecondarySize(20L);
		mu.setVersion("version");
		mu.setTimes(muContactEntity);

		entityManager.persist(mu);
		return mu;
	}

	@Test
	public void testSearch_Param() {
		MatchUnitEntity matchUnitEntity = matchUnitDao.search(null);

		assertNull(matchUnitEntity);
	}

	@Test
	public void testUpdata_Param_1() {
		MatchUnitEntity mu = prepareUpdate();

		matchUnitDao.update(null, null, null, null, null, null, null, null);

		assertEquals(MUState.TIMED_OUT, mu.getState());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(true, mu.getTimes().getIdle());
		assertEquals("version", mu.getVersion());
	}

	@Test
	public void testUpdata_Param_2() {
		MatchUnitEntity mu = prepareUpdate();

		matchUnitDao.update(null, null, null, null, null, null, null, "");

		assertEquals(MUState.TIMED_OUT, mu.getState());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(true, mu.getTimes().getIdle());
		assertEquals("version", mu.getVersion());
	}

	@Test
	public void testAdd_Param_1() {
		MatchUnitEntity matchUnitEntity = matchUnitDao.add(null, null, null,
				null, null, null, null, null);

		assertNull(matchUnitEntity);
	}

	@Test
	public void testAdd_Param_2() {
		MatchUnitEntity matchUnitEntity = matchUnitDao.add(null, "", "", null,
				null, null, null, null);

		assertNull(matchUnitEntity);
	}

	@Test
	public void testIsWorkingUnitExist_Param() {
		boolean isExit = matchUnitDao.isWorkingUnitExist(121);

		assertTrue(!isExit);
	}

	@Test
	public void testIsWorkingUnitExist() {
		MatchUnitEntity mu = prepareUpdate();
		boolean isExit = matchUnitDao.isWorkingUnitExist(mu.getId());

		assertTrue(!isExit);
	}

	@Test
	public void testMergeEnrollTMEUnitEntity_Param() {
		MatchUnitEntity mu = prepareUpdate();

		mu.setVersion("sdfsdfsg");
		mu.setState(MUState.WORKING);

		matchUnitDao.mergeEnrollTMEUnitEntity(null);

		assertEquals(MUState.WORKING, mu.getState());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(true, mu.getTimes().getIdle());
		assertEquals("sdfsdfsg", mu.getVersion());
	}

	@Test
	public void testGetMatchUnitsByTypeAndState_Param() {
		List<MatchUnitEntity> matchUnitEntityList = matchUnitDao
				.getMatchUnitsByTypeAndState(null, null);

		assertNull(matchUnitEntityList);
	}

	@Test
	public void testUpdateMatchUnits_Param() {
		MatchUnitEntity mu = prepareUpdate();

		matchUnitDao.updateMatchUnits(null, null);

		assertEquals(MUState.TIMED_OUT, mu.getState());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(true, mu.getTimes().getIdle());
		assertEquals("version", mu.getVersion());
	}

	@Test
	public void testGetTimedOutUtilsFromReport_Param() {
		List<MatchUnitEntity> matchUnitEntityList = matchUnitDao
				.getTimedOutUtilsFromReport(null);

		assertNull(matchUnitEntityList);
	}
}
