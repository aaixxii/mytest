package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJob;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJobResponse;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResult;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.service.pojo.EnrollReportServiceBean;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class TemplateManagerBeanTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private TemplateManagerBean templateManagerBean;
	@Resource
	EnrollAcceptServiceBean enrollAcceptServiceBean;
	private EnrollReportServiceBean enrollReportServiceBean;

	private String referenceId = "BiometricsDeletion_referenceId_";
	private final String referentID = "abcde1234_";
	private final String referentURL = "abcde1234_";
	JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);

		enrollReportServiceBean = new EnrollReportServiceBean();
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = DeletionJobManager
				.getInstance().getDeletionJobQueue();

		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}

		cleanDB();
	}

	@After
	public void tearDown() {
		cleanDB();
	}

	private void cleanDB() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
	}

	private ExtractJobResponse prepareExtractJobResponse(long batchJobId,
			int start, int end) {

		List<ExtractJob> jobInfoList = new ArrayList<ExtractJob>();
		for (int i = start + 1; i <= start + end; i++) {
			ExtractJob.Builder extractJobInfo = ExtractJob.newBuilder();
			extractJobInfo.setJobIndex(i);
			extractJobInfo.setRequest(TMETestUtil
					.preperaResponse(batchJobId, i).toByteString());
			jobInfoList.add(extractJobInfo.build());
		}

		ExtractJobResponse.Builder extractJob = ExtractJobResponse.newBuilder();
		extractJob.addAllExtractJob(jobInfoList);
		extractJob.setBatchJobId(batchJobId);
		return extractJob.build();
	}

	/**
	 * prepare data for Template
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	/**
	 * prepare data for ExtractResult
	 * 
	 * @param extractJob
	 * @return
	 */
	private ExtractJobResultRequest prepareExtractResult(
			ExtractJobResponse extractJob) {
		ExtractJobResultRequest.Builder extractResult = ExtractJobResultRequest
				.newBuilder();
		extractResult.setBatchJobId(extractJob.getBatchJobId());
		List<ExtractJobResult> extractJobResult = new ArrayList<ExtractJobResult>();

		for (int i = 1; i <= extractJob.getExtractJobCount(); i++) {
			ExtractJobResult.Builder jobResult = ExtractJobResult.newBuilder();
			jobResult.setJobIndex(extractJob.getExtractJobList().get(i - 1)
					.getJobIndex());
			jobResult.setReturnCode(ReturnCode.JobSuccess);
			jobResult.setErrorCode(i);
			jobResult.setErrorMessage("ErrorMessage_" + i);
			jobResult.setResponse(TMETestUtil.preperaResponse(
					extractJob.getBatchJobId(), i).toByteString());
			jobResult.setTemplate(prepareTemplate(String.valueOf(jobResult
					.getJobIndex())));
			extractJobResult.add(jobResult.build());
		}
		extractResult.addAllExtractJobResult(extractJobResult);

		return extractResult.build();
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testUpdateEnrollBatchJob]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare EnterRequest For test<br/>
	 * 3 - prepare Extract Job Response<br/>
	 * 4 - prepare ExtractResultReques<br/>
	 * 5 - call getEnrollBatchJobById, to to get specified EnrollBatchJob<br/>
	 * 6 - call UpdateBatchJob, to update BatchJob<br/>
	 * 7 - call CompleteExtractBatchJob, to complete ExtractBatchJob<br/>
	 * 8 - query database to get data<br/>
	 * 9 - assert concerning information<br/>
	 */
	@Test
	public void testUpdateEnrollBatchJob() {
		long batchJobId = 20;
		int jobCount = 20;
		long segmentCount = 0;

		setMockMethod();
		cleanDB();

		jdbcTemplate.execute("insert into SYSTEM_CONFIG (CONFIG_ID,"
				+ "PROPERTY_NAME,PROPERTY_VALUE)"
				+ " values (1,'BEHAVIOR.MAX_SEGMENT_SIZE','10000000')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(100, "
				+ "'PERSON_TEMPLATE_SIZE', '"
				+ TMETestUtil.PERSON_TEMPLATE_SIZE + "')");
		String sqlDelete = "delete from person_biometrics where REFERENCE_ID like '%"
				+ referentID + "%'";
		String sqlSelect = "select REFERENCE_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,DATE_ADDED,CORRUPTED_FLAG "
				+ "from person_biometrics where REFERENCE_ID like '%"
				+ referentID + "%'";
		String sqlSelectSegment = "select count(*) as COUNT from SEGMENT_VERSION_DETAIL";
		String sqlSelectExtractjob = "select count(*) from ENROLL_JOB_QUEUE where RETURN_CODE = "
				+ ReturnCode.JobSuccess.ordinal();
		String sqlSelectBatchjob = "select count(*) from ENROLL_BATCH_JOB_QUEUE  where BATCHJOB_STATUS = "
				+ EnrollBatchJobStatus.REGISTERED.getIntValues();

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute(sqlDelete);
		List<Map<String, Object>> listDelete = jdbcTemplate
				.queryForList(sqlSelect);
		List<Map<String, Object>> listSegment = jdbcTemplate
				.queryForList(sqlSelectSegment);

		// 2 - assert concerning information
		assertTrue(listDelete.isEmpty());
		assertTrue(!listSegment.isEmpty());
		segmentCount = ((BigDecimal) listSegment.get(0).get("COUNT"))
				.longValue();

		List<CPBBusinessMessage> businessMessageList = TMETestUtil
				.prepareCPBBusinessMessage(batchJobId, jobCount, referentID,
						referentURL);
		enrollAcceptServiceBean.doAccept(batchJobId, BatchType.ENROLL,
				businessMessageList);

		// 3 - prepare Extract Job Response
		ExtractJobResponse extractJob = prepareExtractJobResponse(batchJobId,
				0, jobCount);

		// 4 - prepare ExtractResultReques
		ExtractJobResultRequest extractResult = prepareExtractResult(extractJob);

		// 5 - call getEnrollBatchJobById, to to get specified EnrollBatchJob
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob batchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo extractjob = batchJob.getExtractJobInfo(i);
			extractjob.setStatus(LocalExtractJobStatus.EXTRACTING);
			extractjob.setExtractStartTS(DateUtil.getCurrentDate());
		}

		// 6 - call UpdateBatchJob, to update BatchJob
		enrollReportServiceBean.updateBatchJob(extractResult, batchJob);
		batchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTED);
		// 7 - call CompleteExtractBatchJob, to complete ExtractBatchJob
		templateManagerBean.insertTemplates(batchJobId);

		List<Map<String, Object>> list = jdbcTemplate.queryForList(sqlSelect);

		// 8 - query database to get data
		LocalEnrollBatchJob enrollBatchJob1 = queueManage
				.getEnrollBatchJobById(batchJobId);

		// 9 - assert concerning information
		long assertCount = 0;
		for (int j = 0; j < list.size(); j++) {
			for (int i = 1; i <= list.size(); i++) {
				if (enrollBatchJob1.getExtractJobInfo(i).getReferenceId()
						.equals(
								list.get(j).get("REFERENCE_ID").toString()
										.trim())) {
					assertNotNull(list.get(j).get("BIOMETRIC_DATA_LEN"));
					assertNotNull(list.get(j).get("DATE_ADDED"));
					assertNotNull(list.get(j).get("CORRUPTED_FLAG"));
					assertCount++;
					break;
				}
			}
		}
		assertEquals(jobCount, assertCount);
		assertEquals(assertCount, list.size());

		int extractjobCount = jdbcTemplate.queryForObject(sqlSelectExtractjob, Integer.class);
		assertEquals(jobCount, extractjobCount);

		int batchjobCount = jdbcTemplate.queryForObject(sqlSelectBatchjob, Integer.class);
		assertEquals(1, batchjobCount);

		listSegment = jdbcTemplate.queryForList(sqlSelectSegment);
		assertTrue(segmentCount < ((BigDecimal) listSegment.get(0).get("COUNT"))
				.longValue());

		jdbcTemplate.execute(sqlDelete);
		cleanDB();

		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * @param batchJobId
	 * @param deleteReferenceId
	 */
	private void preparelocalDeleteJob(long batchJobId, String deleteReferenceId) {
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setEnrollmentId(deleteReferenceId);
		request.setRequestId(deleteReferenceId);
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		DeletionJobManager.getInstance().enqueueDeletionJob(
				new LocalDeletionJob(batchJobId, request.build()));
		return;
	}

	@Test
	public void testBiometricsDeletion_Deleted() {
		long batchJobId = 34564;
		setMockMethod();

		clearDatabase();
		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 5);
		preparelocalDeleteJob(batchJobId, deleteReferenceId);
		templateManagerBean.deleteTemplate(batchJobId, deleteReferenceId);

		String sql_delete_biometrics = "select * FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = '"
				+ deleteReferenceId + "'";
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_delete_biometrics = jdbcTemplate
				.queryForList(sql_delete_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(9, list_person_biometrics.size());
		assertEquals(0, list_delete_biometrics.size());

		assertEquals(2, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("9", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(0)
				.get("CHANGE_TYPE").toString());
		assertEquals("1", list_segment_version_detail1.get(1).get("VERSION")
				.toString());
		assertEquals("0", list_segment_version_detail1.get(1).get(
				"RECORD_COUNT").toString());
		assertEquals("5", list_segment_version_detail1.get(1).get(
				"BIO_ID_START").toString());
		assertEquals("1", list_segment_version_detail1.get(1)
				.get("CHANGE_TYPE").toString());
		assertEquals(deleteReferenceId, list_segment_version_detail1.get(1)
				.get("REFERENCE_ID").toString());

		assertEquals(1, list_segments1.size());
		assertEquals("1", list_segments1.get(0).get("VERSION").toString());
		assertEquals("9", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("1", list_segments1.get(0).get("GENERATION").toString());
		assertEquals(String.format("%d", 9 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_COMPACTED").toString());
		assertEquals(
				String.format("%d", 10 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_UNCOMPACTED")
						.toString());

		List<LocalDeletionJob> unSynchedDeletionJobs = DeletionJobManager
				.getInstance().getNotSynchronizedDeletionJobs();
		assertEquals(1, unSynchedDeletionJobs.size());
		assertEquals(1, unSynchedDeletionJobs.get(0).getSegmentId());
		assertEquals(1, unSynchedDeletionJobs.get(0).getVersion());
		assertEquals(5, unSynchedDeletionJobs.get(0).getBiometricsId());
		assertEquals(deleteReferenceId, unSynchedDeletionJobs.get(0)
				.getReferenceId());

		clearDatabase();
	}

	@Test
	public void testBiometricsDeletion_NoFind() {
		long batchJobId = 13458;
		setMockMethod();

		clearDatabase();
		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 15);

		preparelocalDeleteJob(batchJobId, deleteReferenceId);

		templateManagerBean.deleteTemplate(batchJobId, deleteReferenceId);

		String sql_delete_biometrics = "select * FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = '"
				+ deleteReferenceId + "'";
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_delete_biometrics = jdbcTemplate
				.queryForList(sql_delete_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(10, list_person_biometrics.size());
		assertEquals(0, list_delete_biometrics.size());

		assertEquals(1, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(0)
				.get("CHANGE_TYPE").toString());

		assertEquals(1, list_segments1.size());
		assertEquals("0", list_segments1.get(0).get("VERSION").toString());
		assertEquals("10", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("0", list_segments1.get(0).get("GENERATION").toString());
		assertEquals(
				String.format("%d", 10 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_COMPACTED").toString());
		assertEquals(
				String.format("%d", 10 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_UNCOMPACTED")
						.toString());

		List<LocalDeletionJob> unSynchedDeletionJobs = DeletionJobManager
				.getInstance().getNotSynchronizedDeletionJobs();
		assertEquals(0, unSynchedDeletionJobs.size());

		clearDatabase();
	}

	private void preparePersonBiometics(int count) {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(100, "
				+ "'PERSON_TEMPLATE_SIZE', '"
				+ TMETestUtil.PERSON_TEMPLATE_SIZE + "')");
		for (int i = 1; i <= count; i++) {
			String sql = "INSERT INTO person_biometrics( biometrics_id, reference_id,"
					+ " biometric_data, biometric_data_len, date_added ) VALUES("
					+ i
					+ ",'"
					+ (referenceId + String.format("%05d", i))
					+ "', '0', "
					+ TMETestUtil.PERSON_TEMPLATE_SIZE
					+ ", systimestamp)";
			jdbcTemplate.execute(sql);
		}
	}

	private void prepareSegment(int count, int lastRecordCount) {
		int startId = -1;
		int endId = -1;
		int segLength = -1;
		for (int i = 1; i <= count; i++) {
			startId = ((i - 1) * 15 + 1);
			if (i == count) {
				endId = startId + lastRecordCount - 1;
			} else {
				endId = (i * 15);
			}
			segLength = (endId - startId + 1)
					* TMETestUtil.PERSON_TEMPLATE_SIZE;
			String segSQL = "INSERT INTO SEGMENTS(SEGMENT_ID, BIO_ID_START, BIO_ID_END,"
					+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, GENERATION,"
					+ " BINARY_LENGTH_UNCOMPACTED ) VALUES ( "
					+ i
					+ ", "
					+ startId
					+ ","
					+ endId
					+ ","
					+ segLength
					+ ","
					+ (endId - startId + 1) + ", 0,0," + segLength + ")";
			jdbcTemplate.execute(segSQL);

			String segDetailSQL = "INSERT INTO SEGMENT_VERSION_DETAIL(SEGMENT_ID,VERSION,"
					+ " BIO_ID_START, BIO_ID_END,UPDATE_TS,RECORD_COUNT, CHANGE_TYPE) VALUES ( "
					+ i
					+ ", 0,"
					+ startId
					+ ","
					+ endId
					+ ",systimestamp,"
					+ (endId - startId + 1) + ", 0)";
			jdbcTemplate.execute(segDetailSQL);
		}
	}

	private void clearDatabase() {
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
	}
}