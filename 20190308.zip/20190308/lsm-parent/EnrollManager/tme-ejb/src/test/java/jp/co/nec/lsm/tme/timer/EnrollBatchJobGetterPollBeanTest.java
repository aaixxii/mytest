package jp.co.nec.lsm.tme.timer;

import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.httpclient.HttpMethod;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.SystemConfigEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.util.TMETestUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobGetterPollBeanTest {

	@Resource
	private DataSource dataSource;
	
	@Inject
	private EnrollBatchJobGetterPollBean pollBean;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	private boolean loopFalg = true;
	private long fistTime = 0;
	private long secndTime = 0;

	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;

	@Before
	public void setUp() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		enrollLinkQueue = queueManage.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}

		jdbcTemplate = new JdbcTemplate(dataSource);

		fistTime = 0;
		secndTime = 0;

		clearDB();
	}

	@After
	public void tearDown() {
		clearDB();
	}

	/**
	 * 
	 */
	private void clearDB() {
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from ENROLL_BATCH_JOB_QUEUE");
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 */
	private void updateDB(int port) {
		persist("INTERVALS.ENROLL_JOBFETCH_FOR_HIGH_LEVEL", "15000");

		persist("INTERVALS.ENROLL_JOBFETCH_FOR_NORMAL_LEVEL", "10000");

		persist("INTERVALS.ENROLL_JOBFETCH_FOR_LOW_LEVEL", "5000");

		persist("BATCHJOB_COUNT.ENROLL_JOBFETCH_FOR_HIGH_LEVEL", "5");

		persist("BATCHJOB_COUNT.ENROLL_JOBFETCH_FOR_LOW_LEVEL", "3");

		persist("TRANSFORMER.ENROLL_GETBATCHJOB_URL", "http://127.0.0.1:"
				+ port);

		persist("TRANSFORMER.ENROLL_GET_JOB_COUNT", "100");

		persist("TRANSFORMER.ENROLL_GET_BATCHJOB_COUNT", "1");

		persist("TRANSFORMER.ENROLL_TURNAROUNDTIME_SEC", "10");

		persist("ENROLL_SERVICE.ENABLED", "TRUE");
	}

	private void persist(String name, String value) {
		SystemConfigEntity sce = new SystemConfigEntity();
		sce.setName(name);
		sce.setValue(value);
		manager.persist(sce);
		manager.flush();
	}

	@Test
	public void testPoll_low() {
		long batchJobStartId = 826;
		int batchJobCount = 2;
		int extractJonCount = 12;
		int port = 6622;
		int poolTimes = 0;

		updateDB(port);
		setMock();

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		while (loopFalg && ++poolTimes < 55 * 3) {
			pollBean.poll();

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		assertResult(5500, 4500);
	}

	@Test
	public void testPoll_nomal() {
		long batchJobStartId = 8146;
		int batchJobCount = 4;
		int extractJonCount = 12;
		int port = 6522;
		int poolTimes = 0;

		updateDB(port);
		setMock();

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		while (loopFalg && ++poolTimes < 105 * 3) {
			pollBean.poll();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

		assertResult(10500, 9500);
	}

	@Test
	public void testPoll_high() {
		long batchJobStartId = 8746;
		int batchJobCount = 6;
		int extractJonCount = 12;
		int port = 6537;
		int poolTimes = 0;

		updateDB(port);

		setMock();

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		while (loopFalg && ++poolTimes < 155 * 3) {
			pollBean.poll();

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

		assertResult(15500, 14500);
	}

	@Test
	public void testPoll_highLimits() {
		long batchJobStartId = 9746;
		int batchJobCount = 9;
		int extractJonCount = 12;
		int port = 6887;
		int poolTimes = 0;

		updateDB(port);

		class SubThread extends Thread {

			public SubThread() {
			}

			public void run() {
				for (int i = 0; i < 2;) {
					EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
							.getInstance();
					Date nextGetJobTime = batchJobGetterTimer
							.getNextGetJobTime();

					if (nextGetJobTime != null) {
						if (i == 0) {
							fistTime = nextGetJobTime.getTime();
							i++;
						} else if (i == 1
								&& fistTime != nextGetJobTime.getTime()) {
							secndTime = nextGetJobTime.getTime();
							i++;
						}
					}

					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
					}
				}

				loopFalg = false;
			}
		}

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);
		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		batchJobGetterTimer.setNextGetJobTime(null);

		new SubThread().start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		while (loopFalg && ++poolTimes < 155 * 3) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}

			pollBean.poll();
		}

		assertResult(15500, 14500);
	}

	/**
	 * 
	 * @param highLimit
	 * @param loeLimit
	 */
	private void assertResult(long highLimit, long lowLimit) {

		long intervalTime = secndTime - fistTime;

		assertTrue(intervalTime < highLimit && intervalTime > lowLimit);
	}

	private void setMock() {
		new MockUp<HttpRequestSender>() {
			@Mock
			HttpResponse sendHttpRequest(HttpMethod httpMethod, String url,
					Long batchJobId) {
				if (fistTime == 0) {
					fistTime = DateUtil.getCurrentDate().getTime();
				} else if (fistTime != 0) {
					secndTime = DateUtil.getCurrentDate().getTime();
					loopFalg = false;
				}
				return null;
			}
		};
	}

	/**
	 * 
	 * @param batchJobStartId
	 * @param batchJobCount
	 * @param extractJonCount
	 */
	private void enqueueBatchJobs(long batchJobStartId, int batchJobCount,
			int extractJonCount) {
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		for (long j = batchJobStartId; j < batchJobStartId + batchJobCount; j++) {

			EnrollBatchJobQueueEntity batchJob = new EnrollBatchJobQueueEntity();
			batchJob.setBatchjobId(j);

			batchJob.setBatchjobStatus(EnrollBatchJobStatus.QUEUED
					.getIntValues());

			batchJob.setSegmentId1st(j);
			batchJob.setVersion1st(j);
			batchJob.setIndexStart1st(j);
			batchJob.setIndexEnd1st(j);

			batchJob.setSegmentId2nd(j + 1);
			batchJob.setVersion2nd(j + 1);
			batchJob.setIndexStart2nd(j + 1);
			batchJob.setIndexEnd2nd(j + 1);

			batchJob.setSegmentId3rd(j + 2);
			batchJob.setVersion3rd(j + 2);
			batchJob.setIndexStart3rd(j + 2);
			batchJob.setIndexEnd3rd(j + 2);

			batchJob.setEnqueueTs(DateUtil.getCurrentDate());

			manager.persist(batchJob);
			for (int i = 1; i <= extractJonCount; i++) {

				EnrollJobQueueEntity job = new EnrollJobQueueEntity();
				job.setBatchJobId(j);
				job.setJobIndex(i);
				job.setReferenceId("REFERENCE_ID" + (100000 + i));
				job.setRequestId(String.valueOf(i * i));

				job.setReturnCode(ReturnCode.NotUsed);

				job.setErrorCode(String.format("%03d", j) + "_5_"
						+ String.format("%02d", i));
				job.setErrorMessage(String.format("%03d", j) + "_ErrorMessage_"
						+ String.format("%03d", i));
				job.setRequest(TMETestUtil.preperaResponse(j, i).toByteArray());
				job
						.setResponse(TMETestUtil.preperaResponse(j, i)
								.toByteArray());
				manager.persist(job);

			}
			manager.flush();
			jdbcTemplate.execute("commit");
		}
	}

}
