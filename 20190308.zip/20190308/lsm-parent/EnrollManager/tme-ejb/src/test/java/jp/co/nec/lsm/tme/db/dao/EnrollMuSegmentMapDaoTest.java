package jp.co.nec.lsm.tme.db.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollMuSegmentMapDaoTest {

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;
	
	@EJB
	EnrollMuSegmentMapDao enrollMuSegmentMapDao;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);

		// clear DataBase
		clearDataBase();
	}

	@After
	public void tearDown() {
		// clear DataBase
		clearDataBase();
	}

	/**
	 * clear DataBase
	 */
	private void clearDataBase() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");

		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testUpdateMuSegMap]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare MatchUnit/Segment/MuSegment For test<br/>
	 * 3 - query database to get data<br/>
	 * 4 - assert concerning information<br/>
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testUpdateMuSegMap() {

		// 1 - clear database to avoid disturbing
		clearDataBase();

		// 2 - prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit();
		prepareInsertSegment();
		prepareInsertMuSegment();
		boolean[][] mu_seg_map = new boolean[3][4];
		mu_seg_map[0][0] = false;
		mu_seg_map[0][1] = true;
		mu_seg_map[0][2] = true;
		mu_seg_map[0][3] = false;
		mu_seg_map[1][0] = true;
		mu_seg_map[1][1] = false;
		mu_seg_map[1][2] = true;
		mu_seg_map[1][3] = true;
		mu_seg_map[2][0] = true;
		mu_seg_map[2][1] = true;
		mu_seg_map[2][2] = false;
		mu_seg_map[2][3] = true;

		// 3 - query database to get data
		Query queryMu = manager.createQuery("FROM MatchUnitEntity order by id");
		List<MatchUnitEntity> muList = queryMu.getResultList();
		Query querySeg = manager
				.createQuery("SELECT seg.segmentId FROM SegmentEntity seg order by segmentId");
		List<Long> segList = querySeg.getResultList();
		Query queryMuSeg = manager.createQuery("FROM MuSegmentEntity");
		List<MuSegmentEntity> mu_segList = queryMuSeg.getResultList();
		enrollMuSegmentMapDao.updateMuSegMap(mu_seg_map, muList, segList,
				mu_segList, ComponentType.USC);
		Query queryNewMuSeg = manager.createQuery("FROM MuSegmentEntity");
		List<MuSegmentEntity> new_mu_segList = queryNewMuSeg.getResultList();

		// 4 - assert concerning information
		assertEquals(8, new_mu_segList.size());
		for (MuSegmentEntity museg : new_mu_segList) {
			assertEquals(mu_seg_map[(int) museg.getMuId() - 1][(int) museg
					.getSegmentId() - 1], true);
		}

		// clear DataBase
		clearDataBase();
	}

	@Test
	public void testUpdateMuSegMap_Param_1() {
		try {
			boolean[][] mu_seg_map = null;
			List<MatchUnitEntity> muList = null;
			List<Long> segList = null;
			List<MuSegmentEntity> mu_segList = null;

			enrollMuSegmentMapDao.updateMuSegMap(mu_seg_map, muList, segList,
					mu_segList, ComponentType.USC);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	@Test
	public void testUpdateMuSegMap_Param_2() {
		try {
			boolean[][] mu_seg_map = new boolean[3][4];
			List<MatchUnitEntity> muList = new ArrayList<MatchUnitEntity>();
			List<Long> segList = new ArrayList<Long>();
			List<MuSegmentEntity> mu_segList = new ArrayList<MuSegmentEntity>();

			enrollMuSegmentMapDao.updateMuSegMap(mu_seg_map, muList, segList,
					mu_segList, ComponentType.USC);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	@Test
	public void testUpdateMuSegMap_Param_3() {
		try {
			boolean[][] mu_seg_map = new boolean[1][4];
			List<MatchUnitEntity> muList = new ArrayList<MatchUnitEntity>();
			muList.add(new MatchUnitEntity());
			List<Long> segList = new ArrayList<Long>();
			List<MuSegmentEntity> mu_segList = new ArrayList<MuSegmentEntity>();

			enrollMuSegmentMapDao.updateMuSegMap(mu_seg_map, muList, segList,
					mu_segList, ComponentType.USC);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	@Test
	public void testFindUnitBySegIdp_Param() {
		try {
			enrollMuSegmentMapDao.findUnitBySegId(null, 123);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert MatchUnit into
	 * database
	 */
	private void prepareInsertMatchUnit() {
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(1, 1, 'TIMED_OUT', 2, 1, 1, 1)");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(2, 2, 'TIMED_OUT', 2, 1, 2, 1)");

		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(3, 3, 'TIMED_OUT', 2, 1, 3, 1)");
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert Segment into
	 * database
	 */
	private void prepareInsertSegment() {
		jdbcTemplate
				.execute("insert into SEGMENTS "
						+ "(SEGMENT_ID, BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED, RECORD_COUNT,"
						+ " VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED) values"
						+ "(1, 100, 100, 100, 100, 100,100,100)");
		jdbcTemplate
				.execute("insert into SEGMENTS "
						+ "(SEGMENT_ID, BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED, RECORD_COUNT,"
						+ " VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED) values"
						+ "(2, 200,200, 200, 200, 200,200,200)");

		jdbcTemplate
				.execute("insert into SEGMENTS "
						+ "(SEGMENT_ID, BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED, RECORD_COUNT, "
						+ "VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED) values"
						+ "(3, 300, 300, 300, 300, 300,300,300)");

		jdbcTemplate
				.execute("insert into SEGMENTS "
						+ "(SEGMENT_ID, BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED, RECORD_COUNT, "
						+ "VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED) values"
						+ "(4, 400, 400,400,400,400,400,400)");
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert MuSegment into
	 * database
	 */
	private void prepareInsertMuSegment() {
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(2,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(3,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(1,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(3,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(1,3,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(2,3,0)");
	}
}
