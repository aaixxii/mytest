package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollSystemDownManagerBeanTest {
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;

	@Resource
	private EnrollSystemDownManagerBean sdm;
	@Resource
	private EnrollSystemConfigDao systemConfigDao;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Test
	public void testShutDown() {
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		String sql = "select * from TRANSACTION_MANAGERS where UNIQUE_ID = '"
				+ getTMEUniqueId() + "'";
		
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		Thread sleepThread = new TestThread();
		sleepThread.start();
		jobGetter.setSleepThread(sleepThread);
		
		sdm.shutdown();

		List<Map<String, Object>> dbData = jdbcTemplate.queryForList(sql);
		assertEquals(1, dbData.size());
		Map<String, Object> tmeMap = dbData.get(0);

		assertEquals(TmState.EXITED.toString(), tmeMap.get("STATE").toString());
	}

	class TestThread extends Thread {
		public void run() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Get an ip-address of TME from pid.tm.properties.
	 * 
	 * If the ip-address is not gotten from properties, it must be missing the
	 * default setting. Therefore It is not necessary to send SM and get the
	 * real ip of NIC.
	 * 
	 * @return
	 */
	private String getTMEUniqueId() {
		String mmUniqueId = systemConfigDao.getTMEIpAddress();
		if (mmUniqueId == null) {

			mmUniqueId = Constants.DEFAULT_TME_UNIQUE_ID;

			// basically, we prefer to use numeric IP address but will use
			// hostname otherwise.
			// worst-case scenario we use the default above.
			try {
				mmUniqueId = InetAddress.getLocalHost().getHostName();

				Enumeration<NetworkInterface> interfaces = java.net.NetworkInterface
						.getNetworkInterfaces();
				while (interfaces.hasMoreElements()) {
					NetworkInterface ni = interfaces.nextElement();
					// log.debug("Interface: " + ni.getDisplayName());
					Enumeration<InetAddress> addrs = ni.getInetAddresses();
					while (addrs.hasMoreElements()) {
						InetAddress addr = addrs.nextElement();
						// log.debug("Address: " + addr.getHostAddress());
						if (!addr.isLoopbackAddress()) {
							mmUniqueId = addr.getHostAddress();
						}
					}
				}
			} catch (SocketException e) {
				throw new EnrollRuntimeException("SocketException", e);
			} catch (UnknownHostException e) {
				throw new EnrollRuntimeException("UnknownHostException", e);
			}
		}
		return mmUniqueId + Constants.COLON + systemConfigDao.getTMEWebPort();
	}
}
