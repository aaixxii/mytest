package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.common.SegmentInformationProto.SegmentInformation;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.proto.segment.ReportStateRequestProto.ReportStateRequest;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.constants.ReportResponseReturnStatus;
import jp.co.nec.lsm.tm.common.core.jobs.ReportResponseReturn;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuContactEntity;
import jp.co.nec.lsm.tm.db.common.entities.SystemConfigEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MatchUnitHelper;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollStatusManagerBeanTest {
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private MatchUnitHelper muHelper;
	private JdbcTemplate jdbcTemplate;
	@Resource
	EnrollStatusManagerBean statusMangerBean;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private final String referentID = "abcde1234_";
	private final String referentURL = "test url";

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (i = 1; i <= enrollLinkQueue.size(); i++) {
			enrollLinkQueue.poll();
		}

		jdbcTemplate = new JdbcTemplate(dataSource);
		muHelper = new MatchUnitHelper(manager);
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testHeartbeat]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare EnrollTMEUnitEntity/EnrollMuContactEntity/ReportStateRequest/
	 * SegmentInformation For test<br/>
	 * 3 - call addAllSegmentInformation, to insert data into database<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testReportState() {

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SEGMENTS");

		// 2 - prepare
		// EnrollTMEUnitEntity/EnrollMuContactEntity/ReportStateRequest/SegmentInformation
		// For test
		String sql = "select * from MU_CONTACTS ";
		List<Map<String, Object>> mucList = jdbcTemplate.queryForList(sql);

		assertEquals(0, mucList.size());

		MatchUnitEntity pid = new MatchUnitEntity();
		pid.setUniqueId("TME:192.168.1.13");
		pid.setURL("http://192.168.1.13:8080/enrollManager");
		pid.setState(MUState.WORKING);
		pid.setType(ComponentType.MFE);
		pid.setRevision(0);
		pid.setBalanced(false);
		pid.setVersion("1.0.0");
		pid.setIpAddress("192.168.1.13");
		manager.persist(pid);
		MuContactEntity mc = new MuContactEntity();
		mc.setMuId(pid.getId());
		mc.setIdle(false);
		mc.setLastContactTime(new Date(1234L));
		mc.setLastReportTime(new Date(1234L));
		manager.persist(mc);
		ReportStateRequest.Builder reportStateRequest = ReportStateRequest
				.newBuilder();
		reportStateRequest.setGmvId((int) pid.getId());
		List<SegmentInformation> segList = new ArrayList<SegmentInformation>();

		// 3 - call addAllSegmentInformation, to insert data into database
		reportStateRequest.addAllSegmentInformation(segList);

		// 4 - query database to get data
		ReportResponseReturn reps = statusMangerBean
				.reportState(reportStateRequest.build());

		manager.flush();

		List<Map<String, Object>> mucList1 = jdbcTemplate.queryForList(sql);

		assertEquals(1, mucList1.size());

		Query query = manager
				.createQuery("FROM MuContactEntity mc WHERE mc.muId = :uniqueId");
		query.setParameter("uniqueId", mc.getMuId());
		MuContactEntity result = (MuContactEntity) query.getSingleResult();

		assertNotNull(result);
		assertTrue(result.getLastContactTime().getTime() != 1234L);
		assertTrue(result.getLastReportTime().getTime() != 1234L);

		assertEquals(pid.getId(), reps.getReportStateResponse().getGmvId());
		assertEquals(ReportResponseReturnStatus.REPORT_NORMAL_RETURNED, reps
				.getReturnStatus());
	}

	@Test
	public void testReportState_Param_Null() {
		try {
			statusMangerBean.reportState(null);
		} catch (IllegalArgumentException ex) {
			return;
		}
		fail();
	}

	@Test
	public void testReportState_NotWorking() {

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SEGMENTS");

		// 2 - prepare
		// EnrollTMEUnitEntity/EnrollMuContactEntity/ReportStateRequest/SegmentInformation
		// For test
		String sql = "select * from MU_CONTACTS ";
		List<Map<String, Object>> mucList = jdbcTemplate.queryForList(sql);

		assertEquals(0, mucList.size());

		MatchUnitEntity pid = new MatchUnitEntity();
		pid.setUniqueId("TME:192.168.1.13");
		pid.setURL("http://192.168.1.13:8080/enrollManager");
		pid.setState(MUState.EXITED);
		pid.setType(ComponentType.MFE);
		pid.setRevision(0);
		pid.setBalanced(false);
		pid.setVersion("1.0.0");
		pid.setIpAddress("192.168.1.13");
		manager.persist(pid);
		MuContactEntity mc = new MuContactEntity();
		mc.setMuId(pid.getId());
		mc.setIdle(false);
		mc.setLastContactTime(new Date(1234L));
		mc.setLastReportTime(new Date(1234L));
		manager.persist(mc);
		ReportStateRequest.Builder reportStateRequest = ReportStateRequest
				.newBuilder();
		reportStateRequest.setGmvId((int) pid.getId());
		List<SegmentInformation> segList = new ArrayList<SegmentInformation>();

		// 3 - call addAllSegmentInformation, to insert data into database
		reportStateRequest.addAllSegmentInformation(segList);

		// 4 - query database to get data
		ReportResponseReturn reps = statusMangerBean
				.reportState(reportStateRequest.build());

		manager.flush();

		List<Map<String, Object>> mucList1 = jdbcTemplate.queryForList(sql);

		assertEquals(1, mucList1.size());

		Query query = manager
				.createQuery("FROM MuContactEntity mc WHERE mc.muId = :uniqueId");
		query.setParameter("uniqueId", mc.getMuId());
		MuContactEntity result = (MuContactEntity) query.getSingleResult();

		assertNotNull(result);
		assertTrue(result.getLastContactTime().getTime() == 1234L);
		assertNotNull(result.getLastReportTime().getTime() == 1234L);

		assertNull(reps.getReportStateResponse());
		assertEquals(ReportResponseReturnStatus.REPORT_UNIT_STATUS_UNNORMAL,
				reps.getReturnStatus());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testUpdateMuSegMap]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare
	 * EnrollTMEUnitEntity/EnrollQueueManager/LocalEnrollBatchJobInfo For test<br/>
	 * 3 - call addEnrollBatchJob, to insert data into database<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testExit() {

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();
		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}

		// 2 - prepare
		// EnrollTMEUnitEntity/EnrollQueueManager/LocalEnrollBatchJobInfo For
		// test
		MatchUnitEntity pid = new MatchUnitEntity();
		pid.setUniqueId("TME:192.168.1.131");
		pid.setURL("http://192.168.1.13:8080/enrollManager");
		pid.setIpAddress("192.168.1.13");
		pid.setState(MUState.WORKING);
		pid.setType(ComponentType.MFE);
		pid.setRevision(0);
		pid.setBalanced(false);
		pid.setVersion("1.0.0");
		manager.persist(pid);

		for (int i = 70; i <= 71; i++) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			enrollBatchJob.setBatchJobId(i);
			enrollBatchJob.setBatchJobType(BatchType.ENROLL);
			enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());
			if (i == 71) {
				enrollBatchJob
						.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
			} else {
				enrollBatchJob
						.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
			}

			for (int j = 1; j <= 12; j++) {
				LocalExtractJobInfo info = new LocalExtractJobInfo();
				info.setJobId(j);
				info.setRequestId(String.valueOf(j));
				info.setReferenceId(referentID + j);
				if (j <= 6) {
					info.setStatus(LocalExtractJobStatus.EXTRACTING);
					info.setMUId((int) pid.getId());
					info.setExtractStartTS(DateUtil.getCurrentDate());
				} else if (i == 71 && j > 6) {
					info.setStatus(LocalExtractJobStatus.EXTRACTING);
					info.setMUId((int) pid.getId() + 1);
					info.setExtractStartTS(DateUtil.getCurrentDate());
				} else {
					info.setStatus(LocalExtractJobStatus.READY);
					info.setMUId(0);
				}
				enrollBatchJob.putExtractJobInfo(info);
			}

			// 3 - call addEnrollBatchJob, to insert data into database
			queueManage.addEnrollBatchJob(enrollBatchJob);
		}
		statusMangerBean.exit(pid.getId());

		// 4 - query database to get data
		// 5 - assert concerning information
		enrollLinkQueue = queueManage.getEnrollLinkQueue();
		assertEquals(2, enrollLinkQueue.size());
		for (LocalEnrollBatchJob batchJob : enrollLinkQueue) {

			assertEquals(12, batchJob.getExtractJobCount());

			long batchJobId = batchJob.getBatchJobId();
			if (batchJobId == 71) {
				assertEquals(EnrollBatchJobStatus.EXTRACTING, batchJob
						.getBatchJobStatus());
				assertEquals(6, batchJob.getAssignedExtractJobCount());
			} else {
				assertEquals(EnrollBatchJobStatus.QUEUED, batchJob
						.getBatchJobStatus());
				assertEquals(0, batchJob.getAssignedExtractJobCount());
			}
			for (int jobId = 1; jobId <= batchJob.getExtractJobCount(); jobId++) {

				LocalExtractJobInfo extractJobinfo = batchJob
						.getExtractJobInfo(jobId);
				if (batchJobId == 71 && jobId > 6) {
					assertEquals(0, extractJobinfo.getFailureCount());
					assertTrue(extractJobinfo
							.isStatus(LocalExtractJobStatus.EXTRACTING));
					assertNotNull(extractJobinfo.getExtractStartTS());
				} else if (jobId <= 6) {
					assertEquals(1, extractJobinfo.getFailureCount());
					assertTrue(extractJobinfo
							.isStatus(LocalExtractJobStatus.READY));
					assertEquals(null, extractJobinfo.getExtractStartTS());
				} else {
					assertEquals(0, extractJobinfo.getFailureCount());
					assertTrue(extractJobinfo
							.isStatus(LocalExtractJobStatus.READY));
					assertEquals(null, extractJobinfo.getExtractStartTS());
				}
			}
		}
		MatchUnitEntity mu = muHelper.findAndWarnState(pid.getId());
		assertEquals(MUState.EXITED, mu.getState());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testUpdateMuSegMap]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare EnterRequest For test<br/>
	 * 3 - call search, to get data<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testEnter_Add() {

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SEGMENTS");

		// 2 - prepare EnterRequest For test
		EnterRequest.Builder enterRequest = EnterRequest.newBuilder();
		enterRequest.setUniqueId("TME:192.168.1.131");
		enterRequest.setContactURL(referentURL);
		enterRequest.setType(ComponentType.MFE);
		enterRequest.setVersion("2132");
		enterRequest.setNumberOfCpus(1);
		enterRequest.setPrimarySize(12124);
		enterRequest.setSecondarySize(124342332);
		statusMangerBean.enter(enterRequest.build());

		// 3 - call search, to get data
		MatchUnitEntity mu = muHelper.search(enterRequest.getUniqueId());

		// 4 - assert concerning information
		assertEquals("TME:192.168.1.131", mu.getUniqueId());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(MUState.WORKING, mu.getState());
		assertEquals(referentURL, mu.getURL());
		assertNotNull(mu.getTimes().getLastContactTime());
		assertNotNull(mu.getTimes().getLastReportTime());

	}

	@Test
	public void testEnter_Update() {
		long batchJobId = 163324356;
		int jobCount = 16;


		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");

		String insertMU = "insert into match_units(MU_ID, UNIQUE_ID, STATE, TYPE, REVISION, IP_ADDRESS,"
				+ " BALANCED_FLAG) values(1, 'TME:192.168.1.13', 'WORKING', 1, 0, '192.168.1.13', 0)";
		jdbcTemplate.execute(insertMU);

		String insertMUC = "insert into MU_CONTACTS(MU_ID, LAST_CONTACT_TS, LAST_REPORT_TS,"
				+ " IDLE_FLAG) values(1, systimestamp, systimestamp, 0)";
		jdbcTemplate.execute(insertMUC);
		
		SystemConfigEntity sysEntity = new SystemConfigEntity();
		sysEntity.setName("BEHAVIOR.MAX_EXTRACT_JOB_FAILURES");
		sysEntity.setValue("3");
		manager.persist(sysEntity);
		manager.flush();
		
		// 2 - prepare EnterRequest For test
		EnterRequest.Builder enterRequest = EnterRequest.newBuilder();
		enterRequest.setUniqueId("TME:192.168.1.13");
		enterRequest.setContactURL(referentURL);
		enterRequest.setType(ComponentType.valueOf(1));
		enterRequest.setVersion("2132");
		enterRequest.setNumberOfCpus(1);
		enterRequest.setPrimarySize(12124);
		enterRequest.setSecondarySize(124342332);


		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();
		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
		prepareBatchJob(batchJobId, jobCount);

		statusMangerBean.enter(enterRequest.build());

		assertBachJob(batchJobId, jobCount);

		// 3 - call search, to get data
		MatchUnitEntity mu = muHelper.search(enterRequest.getUniqueId());

		// 4 - assert concerning information
		assertEquals("TME:192.168.1.13", mu.getUniqueId());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(MUState.WORKING, mu.getState());
		assertEquals(referentURL, mu.getURL());
		assertNotNull(mu.getTimes().getLastContactTime());
		assertNotNull(mu.getTimes().getLastReportTime());
	}

	@Test
	public void testEnter_Param_Null() {
		try {
			statusMangerBean.enter(null);
		} catch (IllegalArgumentException ex) {
			return;
		}
		fail();
	}

	@Test
	public void testEnter_Param_Type() {

		// 2 - prepare EnterRequest For test
		EnterRequest.Builder enterRequest = EnterRequest.newBuilder();
		enterRequest.setUniqueId("TME:192.168.1.13");
		enterRequest.setContactURL(referentURL);
		enterRequest.setType(ComponentType.DM);
		enterRequest.setVersion("2132");
		enterRequest.setNumberOfCpus(1);
		enterRequest.setPrimarySize(12124);
		enterRequest.setSecondarySize(124342332);
		try {
			statusMangerBean.enter(enterRequest.build());
		} catch (IllegalArgumentException ex) {
			return;
		}
		fail();
	}

	private void prepareBatchJob(long batchJobId, int jobCount) {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 2 - prepare LocalEnrollBatchJob/LocalEnrollBatchJobInfo For test
		for (int i = 0; i < 2; i++) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			enrollBatchJob.setBatchJobId(batchJobId + i);
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
			for (int j = 1; j <= jobCount; j++) {
				LocalExtractJobInfo batchJob = new LocalExtractJobInfo();
				batchJob.setJobId(j);
				batchJob.setStatus(LocalExtractJobStatus.EXTRACTING);
				batchJob.setMUId(1);
				batchJob.setExtractStartTS(new Date(10000));
				if (j <= jobCount / 2 && i == 0) {
					batchJob.setFailureCount(0);
				} else {
					batchJob.setFailureCount(2);
				}
				// CPBRequest
				CPBRequest.Builder request = CPBRequest.newBuilder();
				request.setRequestId(String.format("%018d", batchJobId)
						+ String.format("%018d", j));
				request.setEnrollmentId("QueueManager_"
						+ String.format("%023d", j));
				request.setRequestType(E_REQUESET_TYPE.INSERT);
				CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
						.newBuilder();
				businessMessage.setRequest(request);
				batchJob.setRequest(businessMessage.build());
				// 3 - call addOneEnrollBatchJobInfo, to insert one
				// EnrollBatchJobInfo into database
				enrollBatchJob.putExtractJobInfo(batchJob);
			}
			queueManage.addEnrollBatchJob(enrollBatchJob);
		}
	}

	private void assertBachJob(long batchJobId, int jobCount) {
		Integer maxExtractFailure = 3;
		EnrollBatchJobManager queueManage2 = EnrollBatchJobManager
				.getInstance();

		// 7 - assert concerning information
		for (int i = 0; i < 2; i++) {
			LocalEnrollBatchJob enrollBatchJob = queueManage2
					.getEnrollBatchJobById(batchJobId + i);
			for (int j = 1; j <= enrollBatchJob.getExtractJobCount(); j++) {
				LocalExtractJobInfo extractJob = enrollBatchJob
						.getExtractJobInfo(j);
				if (extractJob.getFailureCount() < maxExtractFailure) {
					assertEquals(1, extractJob.getFailureCount());
					assertTrue(extractJob.isStatus(LocalExtractJobStatus.READY));
					assertNull(extractJob.getExtractStartTS());
				} else {
					assertTrue(extractJob.isStatus(LocalExtractJobStatus.DONE));
					assertNotNull(extractJob.getExtractEndTS());
				}
			}
			if (i == 0) {
				assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
						.getBatchJobStatus());
				assertEquals(jobCount / 2, enrollBatchJob
						.getCompletedExtractJobCount());
			} else {
				assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
						.getBatchJobStatus());
				assertEquals(jobCount, enrollBatchJob
						.getCompletedExtractJobCount());
			}
		}
	}
}