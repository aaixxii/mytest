package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.concurrent.ConcurrentLinkedQueue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.util.TMETestUtil;

public class EnrollDeadLevelQueueServiceTest {
	EnrollDeadLevelQueueService deadLevelQueueService;

	@Before
	public void setUp() {
		deadLevelQueueService = new EnrollDeadLevelQueueService();
		cleanMemoryQueue();

		setMockMethod();
	}

	@After
	public void tearDown() {
		cleanMemoryQueue();
	}

	/**
	 * 
	 * @param batchJobId
	 * @param status
	 */
	private void prepareEnrollBatchJob(long batchJobId, int jobCount,
			EnrollBatchJobStatus status) {

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		LocalEnrollBatchJob enrollBatchJob = TMETestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);

		enrollBatchJob.setBatchJobStatus(status);

		queueManage.addEnrollBatchJob(enrollBatchJob);
	}

	@Test
	public void testMakeBatchJobJobSynced_Enroll() {
		long batchJobId = 5634943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.REGISTERED);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobExtracted() {
		long batchJobId = 5634943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.EXTRACTED);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobSyned() {
		long batchJobId = 5634943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.SYNCHRONIZED);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNull(enrollBatchJob);
	}

	@Test
	public void testMakeBatchJobJobRetuend() {
		long batchJobId = 5634943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.RETURNED);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNull(enrollBatchJob);
	}

	@Test
	public void testMakeBatchJobJobSynced_Enroll_NoFind() {
		long batchJobId = 129233;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.REGISTERED);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId + 1, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.REGISTERED, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobSynced_Enroll_InvalidStatus() {
		long batchJobId = 34943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.EXTRACTING);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId + 1, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobSynced_DeleteJob() {
		long batchJobId = 23443;

		prepareDeleetBatchJob(batchJobId);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId, false);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNull(deletejob);
	}

	@Test
	public void testMakeBatchJobJobSynced_DeleteJob_NoFind() {
		long batchJobId = 45363;

		prepareDeleetBatchJobNotFound(batchJobId);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId + 1, false);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNotNull(deletejob);
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = deletionJobManager
				.getDeletionJobQueue();

		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * 
	 * @param batchJobId
	 * @param status
	 */
	private void prepareDeleetBatchJob(long batchJobId) {
		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		LocalDeletionJob deletejob = new LocalDeletionJob();

		deletejob.setBatchJobId(batchJobId);
		deletejob.increaseSyncCount();
		deletejob.increaseSyncCount();
		deletejob.setSynchronized(true);

		deletionJobManager.enqueueDeletionJob(deletejob);
	}

	/**
	 * 
	 * @param batchJobId
	 * @param status
	 */
	private void prepareDeleetBatchJobNotFound(long batchJobId) {
		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		LocalDeletionJob deletejob = new LocalDeletionJob();

		deletejob.setBatchJobId(batchJobId);
		deletejob.setSynchronized(true);

		deletionJobManager.enqueueDeletionJob(deletejob);
	}

	@Test
	public void testDeleteDeleteJobFromMemory() {
		long batchJobId = 64543;

		prepareDeleetBatchJob(batchJobId);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId, false);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNull(deletejob);
	}

	@Test
	public void testDeleteDeleteJobFromMemory_NoFind() {
		long batchJobId = 122543;

		prepareDeleetBatchJobNotFound(batchJobId);

		deadLevelQueueService.receiveEventFromDLQ(batchJobId + 1, false);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNotNull(deletejob);
	}
}
