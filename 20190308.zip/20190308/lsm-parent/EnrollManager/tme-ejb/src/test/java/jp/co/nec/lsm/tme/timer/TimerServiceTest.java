package jp.co.nec.lsm.tme.timer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.ejb.EJBException;
import javax.ejb.NoMoreTimeoutsException;
import javax.ejb.NoSuchObjectLocalException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerHandle;
import javax.ejb.TimerService;

public class TimerServiceTest implements TimerService{
	Collection<Timer> timers = new ArrayList<Timer>();

	@Override
	public Timer createCalendarTimer(ScheduleExpression arg0)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createCalendarTimer(ScheduleExpression arg0, TimerConfig arg1)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createIntervalTimer(Date arg0, long arg1, TimerConfig arg2)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createIntervalTimer(long arg0, long arg1, TimerConfig arg2)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createSingleActionTimer(Date arg0, TimerConfig arg1)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createSingleActionTimer(long arg0, TimerConfig arg1)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createTimer(long arg0, Serializable arg1)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		timers.add(new TimerTest());
		return null;
	}

	@Override
	public Timer createTimer(Date arg0, Serializable arg1)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Timer createTimer(long arg0, long arg1, Serializable arg2)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		timers.add(new TimerTest());
		return null;
	}

	@Override
	public Timer createTimer(Date arg0, long arg1, Serializable arg2)
			throws IllegalArgumentException, IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Timer> getTimers() throws IllegalStateException,
			EJBException {
		// TODO Auto-generated method stub

		return timers;
	}
	
	class TimerTest implements Timer{

		@Override
		public void cancel() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			
		}

		@Override
		public TimerHandle getHandle() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Serializable getInfo() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Date getNextTimeout() throws IllegalStateException,
				NoMoreTimeoutsException, NoSuchObjectLocalException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public ScheduleExpression getSchedule() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getTimeRemaining() throws IllegalStateException,
				NoMoreTimeoutsException, NoSuchObjectLocalException,
				EJBException {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public boolean isCalendarTimer() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isPersistent() throws IllegalStateException,
				NoSuchObjectLocalException, EJBException {
			// TODO Auto-generated method stub
			return false;
		}
		
	}

    @Override
    public Collection<Timer> getAllTimers() throws IllegalStateException, EJBException {
        // TODO Auto-generated method stub
        return null;
    }

}
