package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.exception.EmptyRequestIDException;

public class DeleteRequestValidatorTest {

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BatchJobId() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(-123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BatchJobType() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.ENROLL);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BusinessMessageCount_0() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BusinessMessageCount_2() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestId() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%030d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(
				deleteRequest.build().getBatchJobId(), businessMessageList.get(
						0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestId_Empty() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(19323);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId("");
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		try {
			// call EnrollRequestValidator.validate()
			DeleteRequestValidator.validateRequest(deleteRequest.build()
					.getBatchJobId(), businessMessageList.get(0).getRequest());
			fail();
		} catch (EmptyRequestIDException ex) {
			return;
		} catch (Exception ex) {
			fail();
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_EnrollmentId_length() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%030d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(
				deleteRequest.build().getBatchJobId(), businessMessageList.get(
						0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NoEnrollmentId() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(
				deleteRequest.build().getBatchJobId(), businessMessageList.get(
						0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestType() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.INSERT);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(
				deleteRequest.build().getBatchJobId(), businessMessageList.get(
						0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BatchJobIdDuplication() {
		long batchJobId = 100;

		DeletionJobManager djm = DeletionJobManager.getInstance();
		ConcurrentLinkedQueue<LocalDeletionJob> queue = djm
				.getDeletionJobQueue();
		for (LocalDeletionJob job : queue) {
			queue.remove(job);
		}

		LocalDeletionJob deletionJob = new LocalDeletionJob();
		deletionJob.setBatchJobId(batchJobId);
		djm.enqueueDeletionJob(deletionJob);

		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(batchJobId);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());

		ConcurrentLinkedQueue<LocalDeletionJob> queue2 = djm
				.getDeletionJobQueue();
		for (LocalDeletionJob job : queue2) {
			queue.remove(job);
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NULL() {

		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(1564);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(
				deleteRequest.build().getBatchJobId(), businessMessageList.get(
						0).getRequest());

		// assert result
		assertNull(result);
	}
}
