package jp.co.nec.lsm.tme.core.segment.loadbalance;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MuSegMapHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SegmentHelper;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentLoadBalanceManagerTest {
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	@Resource
	private SegmentLoadBalanceManager slbManager;
	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;
	private MuSegMapHelper muSegMapHelper;
	private SegmentHelper segHelper;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		muSegMapHelper = new MuSegMapHelper(manager);
		segHelper = new SegmentHelper(manager);

		// clear DataBase
		clearDataBase();
	}

	@After
	public void tearDown() {
		// clear DataBase
		clearDataBase();
	}

	/**
	 * clear DataBase
	 */
	private void clearDataBase() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	/**
	 * update SYSTEM_CONFIG table
	 */
	private void updateDataBase(String enable, int minUSC, int uscRedundancy) {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'LOAD_BALANCER.USC_MIN_REDUNDANCY','"
						+ (uscRedundancy - 1) + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (3,'SEGMENT_LOAD_BALANCER.ENABLED','"
						+ enable + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (4,'SEGMENT_LOAD_BALANCER.MIN_USCS_FOR_SLB','"
						+ minUSC + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (5,'LOAD_BALANCER.USC_DEFAULT_REDUNDANCY','"
						+ uscRedundancy + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (6,'LOAD_BALANCER.USC_MAX_REDUNDANCY','"
						+ (uscRedundancy + 1) + "')");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpreparePreMatrix]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare MatchUnit/Segment/MuSegment For test<br/>
	 * 3 - query database to get data<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testPreparePreMatrix() {

		// 1 - clear database to avoid disturbing
		clearDataBase();
		// update SYSTEM_CONFIG table
		updateDataBase("TRUE", 2, 2);

		// 2 - prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// 3 - query database to get data
		// get MuSegment entities
		List<MuSegmentEntity> preMuSegMaps = muSegMapHelper.findMuSegMapOfMU();
		// get all UscSegment entities
		List<MatchUnitEntity> preUSCEntities = muSegMapHelper
				.findUscInMuSegMap();
		// get deployed Segment entities
		List<Long> preSegmentEntities = segHelper.getAllSegmentIds();

		boolean[][] preMatrix = slbManager.preparePreMatrix(preUSCEntities,
				preSegmentEntities, preMuSegMaps);

		// 4 - assert concerning information
		assertEquals(3, preMatrix.length);
		assertEquals(3, preMatrix.length);
		assertEquals(6, preMuSegMaps.size());
		for (MuSegmentEntity museg : preMuSegMaps) {
			assertEquals(preMatrix[(int) museg.getMuId() - 1][(int) museg
					.getSegmentId() - 1], true);
		}

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_WorkingUSCUnderMinRedundancy() {
		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 7);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(6, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_WorkingUSCUnderMinRedundancy_2() {
		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 4);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		jdbcTemplate
				.execute("update match_units set state = 'TIMED_OUT' where mu_id = 1");

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(6, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_RedundancyException() {
		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		jdbcTemplate
				.execute("update SYSTEM_CONFIG set PROPERTY_VALUE = '3' where CONFIG_ID = 1");

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
			fail();
		} catch (Exception e) {
		}

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_hasTimeOut() {
		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		jdbcTemplate
				.execute("update match_units set state = 'TIMED_OUT' where mu_id = 1");
		jdbcTemplate
				.execute("update match_units set state = 'TIMED_OUT' where mu_id = 5");

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}
		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(8, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_ChangeRedundancy() {
		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		jdbcTemplate
				.execute("update SYSTEM_CONFIG set PROPERTY_VALUE = '3' where CONFIG_ID = 5");

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}
		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(9, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_ChangeRedundancy_2() {
		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		jdbcTemplate
				.execute("update SYSTEM_CONFIG set PROPERTY_VALUE = '1' where CONFIG_ID = 5");

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}
		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(7, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpreparePreMatrix]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare MatchUnit/Segment/MuSegment For test<br/>
	 * 3 - call excuteSLB<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testExcuteSLB_SegmentAdd() {

		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(8, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_Disable() {

		// clear database
		clearDataBase();
		updateDataBase("FASLE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(6, uscSegMaps.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(6, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_MinDM() {

		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(8, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_MinUSC() {

		// clear database
		clearDataBase();
		updateDataBase("TRUE", 4, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(6, uscSegMaps.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_DMRedundancy() {

		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(8, uscSegMaps.size());
		List<MatchUnitEntity> uscEntities = muSegMapHelper.findUscInMuSegMap();
		assertEquals(3, uscEntities.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	@Test
	public void testExcuteSLB_USCUnderRedundancy() {

		// clear database
		clearDataBase();
		updateDataBase("TRUE", 4, 4);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(4);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(6, uscSegMaps.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(8, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpreparePreMatrix]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare MatchUnit/Segment/MuSegment For test<br/>
	 * 3 - call excuteSLB<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testExcuteSLB_NoSegmentAdd() {

		// clear database
		clearDataBase();
		updateDataBase("TRUE", 2, 2);

		// prepare MatchUnit/Segment/MuSegment For test
		prepareInsertMatchUnit(3, 2);
		prepareInsertSegment(3);
		prepareInsertMuSegment();

		// call excuteSLB()
		try {
			slbManager.excuteSLB();
		} catch (Exception e) {
			fail();
		}

		// assert result
		// assert MuSegment cord for USC
		List<MuSegmentEntity> uscSegMaps = muSegMapHelper.findMuSegMapOfMU();
		assertEquals(6, uscSegMaps.size());
		// assert MuSegment cord for DM
		List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
		assertEquals(6, dmSegMaps.size());

		// clear database to avoid disturbing
		clearDataBase();
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert MatchUnit into
	 * database
	 */
	private void prepareInsertMatchUnit(int uscCount, int dmCount) {
		for (int i = 1; i <= uscCount; i++) {
			jdbcTemplate
					.execute("insert into match_units "
							+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
							+ "(" + i + ", 1, 'WORKING', 2, 1, 1, 1)");
		}

		for (int i = uscCount + 1; i <= dmCount + uscCount; i++) {
			jdbcTemplate
					.execute("insert into match_units "
							+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
							+ "(" + i + ", 2, 'WORKING', 0, 1, 2, 1)");
		}
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert Segment into
	 * database
	 */
	private void prepareInsertSegment(int count) {
		for (int i = 1; i <= count; i++) {
			jdbcTemplate.execute("insert into SEGMENTS(SEGMENT_ID,"
					+ " BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED,"
					+ " RECORD_COUNT, VERSION, GENERATION, "
					+ "BINARY_LENGTH_UNCOMPACTED) values(" + i
					+ ", 100, 100, 100, 100, 100,100,100)");
		}
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert MuSegment into
	 * database
	 */
	private void prepareInsertMuSegment() {
		// add MuSegment cord for USC
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(2,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(3,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(1,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(3,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(1,3,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(2,3,0)");

		// add MuSegment cord for DM
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(4,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(5,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(4,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(5,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(4,3,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(5,3,0)");
	}

}
