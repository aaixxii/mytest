package jp.co.nec.lsm.tme.timer;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;

public class EnrollExpirationTimerTest {

	private EnrollExpirationTimer timer;

	@Before
	public void setUp() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.ACTIVE);
	}

	@After
	public void tearDown() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.ACTIVE);
	}

	@Test
	public void testExpirationTimer() throws InterruptedException,
			ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Date date = sdf.parse("2112-08-19 23:59:59");
		timer = new EnrollExpirationTimer(date, 3000);
		try {
			timer.start();
			Thread.sleep(10000);
			EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
					.getInstance();
			assertTrue(jobGetter.isStop());
			assertTrue(jobGetter.getTransitionState() == RoleStateTransition.PASSIVE);
		} finally {
			timer.stop();
		}
	}

	@Test
	public void testExpirationTimer_NotExpiration()
			throws InterruptedException, ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = sdf.parse("2112-07-15 00:00:00");
		timer = new EnrollExpirationTimer(date, 3000);
		try {
			timer.start();
			Thread.sleep(10000);
			EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
					.getInstance();
			assertTrue(!jobGetter.isStop());
			assertTrue(jobGetter.getTransitionState() != RoleStateTransition.PASSIVE);
		} finally {
			timer.stop();
		}
	}
}
