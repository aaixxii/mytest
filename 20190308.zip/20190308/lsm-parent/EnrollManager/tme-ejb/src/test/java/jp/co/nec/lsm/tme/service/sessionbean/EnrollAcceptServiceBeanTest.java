package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.exception.DuplicateEnrollBatchJobException;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollAcceptServiceBeanTest {

    @Autowired
	EnrollAcceptServiceBean enrollAcceptServiceBean;
	@Resource
	protected DataSource dataSource;

	private final String referentID = "_abcdefg123456789_";
	private final String referentURL = "abcde1234_";
	JdbcTemplate template;

	@Before
	public void setUp() {
		int i = 0;
		template = new JdbcTemplate(dataSource);
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}
	}

	private void clearDB() {
		template.execute("delete FROM ENROLL_JOB_QUEUE");
		template.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testEnrollAcceptServiceBean]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call doAccept, add EnrollRequest into local enroll queue<br/>
	 * 3 - assert Local Enroll Batch Job information<br/>
	 */
	@Test
	public void testAcceptService() {
		long batchJobId = 11;
		int jobCount = 11;
		clearDB();
		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE where BATCHJOB_ID=11";
		String sql1 = "select * FROM ENROLL_JOB_QUEUE where BATCHJOB_ID=11";

		// 1 - prepare EnrollRequest For test
		List<CPBBusinessMessage> businessMessageList = TMETestUtil
				.prepareCPBBusinessMessage(batchJobId, jobCount, referentID,
						referentURL);

		LocalEnrollBatchJob enrollBatchJob = LocalEnrollBatchJob
				.createEnrollBatchJob(batchJobId, BatchType.ENROLL,
						businessMessageList, DateUtil.getCurrentDate());

		// 2 - call doAccept, add EnrollRequest into local enroll queue
		enrollAcceptServiceBean.acceptService(batchJobId, enrollBatchJob);

		List<Map<String, Object>> list = template.queryForList(sql);
		assertEquals(1, list.size());
		for (int i = 1; i <= list.size(); i++) {
			assertNotNull(list.get(i - 1));
			assertEquals(batchJobId, Integer.parseInt(list.get(i - 1).get(
					"BATCHJOB_ID").toString()));
			assertEquals(EnrollBatchJobStatus.QUEUED.getIntValues(),
					Integer.parseInt(list.get(i - 1).get("BATCHJOB_STATUS")
							.toString()));
			assertNotNull(list.get(i - 1).get("ENQUEUE_TS"));
			assertNull(list.get(i - 1).get("START_TS"));
		}

		List<Map<String, Object>> joblist = template.queryForList(sql1);

		assertEquals(11, joblist.size());
		for (int i = 0; i < joblist.size(); i++) {
			for (int k = 0; k < businessMessageList.size(); k++) {
				if (joblist.get(i).get("REFERENCE_ID") == businessMessageList
						.get(k).getRequest().getEnrollmentId()) {
					assertEquals(joblist.get(i).get("BATCHJOB_ID"), String
							.valueOf(batchJobId));
					assertEquals(joblist.get(i).get("JOB_INDEX"), String
							.valueOf(k));
					assertEquals(joblist.get(i).get("REQUEST_ID"),
							businessMessageList.get(k).getRequest()
									.getRequestId());
					assertTrue(businessMessageList.get(k).toByteArray().length > 0);
					for (int j = 0; j < businessMessageList.get(k)
							.toByteArray().length; j++) {
						assertEquals(
								((byte[]) joblist.get(i).get("REQUEST"))[j],
								businessMessageList.get(k).toByteArray()[j]);
					}
				}
			}
		}

		clearDB();
		template.execute("commit");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testEnrollAcceptServiceBean]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call doAccept, add EnrollRequest into local enroll queue<br/>
	 * 3 - assert Local Enroll Batch Job information<br/>
	 */
	@Test
	public void testAcceptService_Length() {
		long batchJobId = 1341;
		int jobCount = 11;
		clearDB();
		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE where BATCHJOB_ID="
				+ batchJobId;
		String sql1 = "select * FROM ENROLL_JOB_QUEUE where BATCHJOB_ID="
				+ batchJobId;

		// 1 - prepare EnrollRequest For test
		List<CPBBusinessMessage> businessMessageList = TMETestUtil
				.prepareCPBBusinessMessage(batchJobId, jobCount, "Request",
						referentID + "12", referentURL);

		LocalEnrollBatchJob enrollBatchJob = LocalEnrollBatchJob
				.createEnrollBatchJob(batchJobId, BatchType.ENROLL,
						businessMessageList, DateUtil.getCurrentDate());

		// 2 - call doAccept, add EnrollRequest into local enroll queue
		enrollAcceptServiceBean.acceptService(batchJobId, enrollBatchJob);

		List<Map<String, Object>> list = template.queryForList(sql);

		for (int i = 1; i <= list.size(); i++) {
			assertNotNull(list.get(i - 1));
			assertEquals(batchJobId, Integer.parseInt(list.get(i - 1).get(
					"BATCHJOB_ID").toString()));
			assertEquals(EnrollBatchJobStatus.QUEUED.getIntValues(),
					Integer.parseInt(list.get(i - 1).get("BATCHJOB_STATUS")
							.toString()));
			assertNotNull(list.get(i - 1).get("ENQUEUE_TS"));
			assertNull(list.get(i - 1).get("START_TS"));
		}

		List<Map<String, Object>> joblist = template.queryForList(sql1);

		assertEquals(11, joblist.size());
		for (int i = 0; i < joblist.size(); i++) {
			for (int k = 0; k < businessMessageList.size(); k++) {
				if (joblist.get(i).get("REFERENCE_ID") == businessMessageList
						.get(k).getRequest().getEnrollmentId().substring(0, 36)) {
					assertEquals(joblist.get(i).get("BATCHJOB_ID"), String
							.valueOf(batchJobId));
					assertEquals(joblist.get(i).get("JOB_INDEX"), String
							.valueOf(k));
					assertEquals(joblist.get(i).get("REQUEST_ID"),
							businessMessageList.get(k).getRequest()
									.getRequestId().substring(0, 36));
					assertTrue(businessMessageList.get(k).toByteArray().length > 0);
					for (int j = 0; j < businessMessageList.get(k)
							.toByteArray().length; j++) {
						assertEquals(
								((byte[]) joblist.get(i).get("REQUEST"))[j],
								businessMessageList.get(k).toByteArray()[j]);
					}
				}
			}
		}

		clearDB();
		template.execute("commit");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testEnrollAcceptServiceBean]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call doAccept, add EnrollRequest into local enroll queue<br/>
	 * 3 - assert Local Enroll Batch Job information<br/>
	 */
	@Test
	public void testAcceptService_Duplicate() {
		long batchJobId = 12431;
		clearDB();

		String enrollBatchJobQueueSql = "insert into ENROLL_BATCH_JOB_QUEUE ("
				+ "BATCHJOB_ID,BATCHJOB_STATUS, ENQUEUE_TS,"
				+ "SEGMENT_ID_1ST, VERSION_1ST, INDEX_START_1ST, INDEX_END_1ST, "
				+ "SEGMENT_ID_2ND, VERSION_2ND, INDEX_START_2ND, INDEX_END_2ND, "
				+ "SEGMENT_ID_3RD, VERSION_3RD, INDEX_START_3RD, INDEX_END_3RD )"
				+ " values(" + batchJobId + ", " + 0
				+ ", TO_DATE('29-02-2012 12:00:00', 'DD-MM-YYYY HH24.MI.SS'),"
				+ "0, 0, 0, 0 , 0, 0, 0, 0, 0, 0, 0, 0)";

		template.execute(enrollBatchJobQueueSql);

		try {
			enrollAcceptServiceBean.doAccept(batchJobId, BatchType.ENROLL,
					new ArrayList<CPBBusinessMessage>());
			fail();
		} catch (DuplicateEnrollBatchJobException ex) {

		} catch (Exception ex) {
			fail();
		}

		clearDB();
		template.execute("commit");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testEnrollAcceptServiceBean]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call doAccept, add EnrollRequest into local enroll queue<br/>
	 * 3 - assert Local Enroll Batch Job information<br/>
	 */
	@Test
	public void testDoAccept() {
		long batchJobId = 110;
		int jobCount = 11;
		clearDB();

		// 1 - prepare EnrollRequest For test
		List<CPBBusinessMessage> businessMessageList = TMETestUtil
				.prepareCPBBusinessMessage(batchJobId, jobCount, referentID,
						referentURL);
		// 2 - call doAccept, add EnrollRequest into local enroll queue
		enrollAcceptServiceBean.doAccept(batchJobId, BatchType.ENROLL,
				businessMessageList);

		assertExtractJob(batchJobId, template, businessMessageList);
		assertEnrollBatchJob(batchJobId, jobCount, businessMessageList);

		clearDB();
		template.execute("commit");
	}

	private void assertExtractJob(long batchJobId, JdbcTemplate template,
			List<CPBBusinessMessage> businessMessageList) {
		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE where BATCHJOB_ID="
				+ batchJobId;
		String sql1 = "select * FROM ENROLL_JOB_QUEUE where BATCHJOB_ID="
				+ batchJobId;

		template.execute(sql);
		List<Map<String, Object>> list = template.queryForList(sql);

		assertEquals(1, list.size());
		for (int i = 1; i <= list.size(); i++) {
			assertNotNull(list.get(i - 1));
			assertEquals(batchJobId, Integer.parseInt(list.get(i - 1).get(
					"BATCHJOB_ID").toString()));
			assertEquals(EnrollBatchJobStatus.QUEUED.getIntValues(),
					Integer.parseInt(list.get(i - 1).get("BATCHJOB_STATUS")
							.toString()));
			assertNotNull(list.get(i - 1).get("ENQUEUE_TS"));
			assertNull(list.get(i - 1).get("START_TS"));
		}

		template.execute(sql1);
		List<Map<String, Object>> joblist = template.queryForList(sql1);

		assertEquals(11, joblist.size());
		for (int i = 0; i < joblist.size(); i++) {
			for (int k = 0; k < businessMessageList.size(); k++) {
				if (joblist.get(i).get("REFERENCE_ID") == businessMessageList
						.get(k).getRequest().getEnrollmentId()) {
					assertEquals(joblist.get(i).get("BATCHJOB_ID"), String
							.valueOf(batchJobId));
					assertEquals(joblist.get(i).get("JOB_INDEX"), String
							.valueOf(k));
					assertEquals(joblist.get(i).get("REQUEST_ID"),
							businessMessageList.get(k).getRequest()
									.getRequestId());
					assertTrue(businessMessageList.get(k).toByteArray().length > 0);
					for (int j = 0; j < businessMessageList.get(k)
							.toByteArray().length; j++) {
						assertEquals(
								((byte[]) joblist.get(i).get("REQUEST"))[j],
								businessMessageList.get(k).toByteArray()[j]);
					}
				}
			}
		}
	}

	private void assertEnrollBatchJob(long batchJobId, int jobCount,
			List<CPBBusinessMessage> businessMessageList) {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);
		// 3 - assert Local Enroll Batch Job information
		assertNotNull(enrollBatchJob);
		assertEquals(batchJobId, enrollBatchJob.getBatchJobId());
		assertEquals(jobCount, enrollBatchJob.getExtractJobCount());
		assertEquals(true, enrollBatchJob.isBatchJobType(BatchType.ENROLL));
		assertEquals(EnrollBatchJobStatus.QUEUED, enrollBatchJob
				.getBatchJobStatus());
		// loop to assert Local Enroll Batch Job information
		for (int j = 1; j <= jobCount; j++) {

			LocalExtractJobInfo extractJob = enrollBatchJob
					.getExtractJobInfo(j);
			assertEquals(j, extractJob.getJobId());
			assertEquals(String.format("%036d", (15 + j)), extractJob
					.getRequestId());
			assertEquals(String.format("%09d", batchJobId) + referentID
					+ String.format("%09d", j), extractJob.getReferenceId());
			assertTrue(extractJob.isStatus(LocalExtractJobStatus.READY));
			assertNull(extractJob.getErrorCode());
			assertEquals(false, extractJob.isReSendable());
			assertNull(extractJob.getErrorMessage());
			assertEquals(0, extractJob.getMUId());
			assertEquals(-1, extractJob.getBiometricId());
			assertEquals(0, extractJob.getFailureCount());
			assertEquals(ReturnCode.NotUsed, extractJob.getReturnCode());
			assertNull(extractJob.getResponse());
			assertNotNull(extractJob.getRequest());
			byte[] data1 = businessMessageList.get(j - 1).toByteArray();
			assertTrue(data1.length > 0);
			for (int i = 0; i < data1.length; i++) {
				assertEquals(data1[i], extractJob.getRequest().toByteArray()[i]);
			}
			assertNull(extractJob.getExtractStartTS());
			assertNull(extractJob.getExtractEndTS());
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testdoAccept_Duplicate_Memory]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call doAccept, add EnrollRequest into local enroll queue<br/>
	 * 3 - assert Local Enroll Batch Job information<br/>
	 */
	@Test
	public void testdoAccept_Duplicate_Memory() {
		long batchJobId = 12431;

		enrollAcceptServiceBean.doAccept(batchJobId, BatchType.IDENTIFY,
				new ArrayList<CPBBusinessMessage>());
		try {
			enrollAcceptServiceBean.doAccept(batchJobId, BatchType.IDENTIFY,
					new ArrayList<CPBBusinessMessage>());
			fail();
		} catch (DuplicateEnrollBatchJobException ex) {

		} catch (Exception ex) {
			fail();
		}

	}

	@Test
	public void testvalidateRequest() {
		long batchJobId = 12431;

		EnrollRequest.Builder enrollrequest = EnrollRequest.newBuilder();
		enrollrequest.setBatchJobId(batchJobId);
		enrollrequest.setType(BatchType.DELETE);

		try {
			enrollAcceptServiceBean.validateRequest(enrollrequest.build(),
					new ArrayList<CPBBusinessMessage>());
			fail();
		} catch (EnrollRuntimeException ex) {

		} catch (Exception ex) {
			fail();
		}

	}
}
