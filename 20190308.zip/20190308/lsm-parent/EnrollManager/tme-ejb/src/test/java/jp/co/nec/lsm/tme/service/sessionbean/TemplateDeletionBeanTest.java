package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class TemplateDeletionBeanTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private TemplateDeletionBean deletionBean;

	private String referenceId = "BiometricsDeletion_referenceId_";

	JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		clearMemoryQueue();
		clearDatabase();
	}

	@After
	public void tearDown() {
		clearMemoryQueue();
		clearDatabase();
	}

	/**
	 * clear Memory Queue
	 */
	private void clearMemoryQueue() {
		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = DeletionJobManager
				.getInstance().getDeletionJobQueue();

		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * 
	 * @param batchJobId
	 * @param deleteReferenceId
	 */
	private void preparelocalDeleteJob(long batchJobId, String deleteReferenceId) {
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setEnrollmentId(deleteReferenceId);
		request.setRequestId(deleteReferenceId);
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		DeletionJobManager.getInstance().enqueueDeletionJob(
				new LocalDeletionJob(batchJobId, request.build()));
		return;
	}

	@Test
	public void testBiometricsDeletion_Deleted() {
		long batchJobId = 6435;
		setMockMethod();
		clearMemoryQueue();
		clearDatabase();

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 5);
		preparelocalDeleteJob(batchJobId, deleteReferenceId);
		DeleteResultRequest result = deletionBean.deleteTemplate(batchJobId,
				deleteReferenceId);

		assertNotNull(result);

		String sql_delete_biometrics = "select * FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = '"
				+ deleteReferenceId + "'";
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_delete_biometrics = jdbcTemplate
				.queryForList(sql_delete_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(9, list_person_biometrics.size());
		assertEquals(0, list_delete_biometrics.size());

		assertEquals(2, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("9", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(0)
				.get("CHANGE_TYPE").toString());
		assertEquals("1", list_segment_version_detail1.get(1).get("VERSION")
				.toString());
		assertEquals("0", list_segment_version_detail1.get(1).get(
				"RECORD_COUNT").toString());
		assertEquals("5", list_segment_version_detail1.get(1).get(
				"BIO_ID_START").toString());
		assertEquals("1", list_segment_version_detail1.get(1)
				.get("CHANGE_TYPE").toString());
		assertEquals(deleteReferenceId, list_segment_version_detail1.get(1)
				.get("REFERENCE_ID").toString());

		assertEquals(1, list_segments1.size());
		assertEquals("1", list_segments1.get(0).get("VERSION").toString());
		assertEquals("9", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("1", list_segments1.get(0).get("GENERATION").toString());
		assertEquals(String.format("%d", 9 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_COMPACTED").toString());
		assertEquals(
				String.format("%d", 10 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_UNCOMPACTED")
						.toString());

		List<LocalDeletionJob> unSynchedDeletionJobs = DeletionJobManager
				.getInstance().getNotSynchronizedDeletionJobs();
		assertEquals(1, unSynchedDeletionJobs.size());
		assertEquals(1, unSynchedDeletionJobs.get(0).getSegmentId());
		assertEquals(1, unSynchedDeletionJobs.get(0).getVersion());
		assertEquals(5, unSynchedDeletionJobs.get(0).getBiometricsId());
		assertEquals(deleteReferenceId, unSynchedDeletionJobs.get(0)
				.getReferenceId());

		clearMemoryQueue();
		clearDatabase();
	}

	@Test
	public void testBiometricsDeletion_NoFind() {
		long batchJobId = 5462;
		setMockMethod();
		clearMemoryQueue();
		clearDatabase();

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 15);

		preparelocalDeleteJob(batchJobId, deleteReferenceId);
		DeleteResultRequest result = deletionBean.deleteTemplate(batchJobId,
				deleteReferenceId);

		assertNotNull(result);

		String sql_delete_biometrics = "select * FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = '"
				+ deleteReferenceId + "'";
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_delete_biometrics = jdbcTemplate
				.queryForList(sql_delete_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(10, list_person_biometrics.size());
		assertEquals(0, list_delete_biometrics.size());

		assertEquals(1, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(0)
				.get("CHANGE_TYPE").toString());

		assertEquals(1, list_segments1.size());
		assertEquals("0", list_segments1.get(0).get("VERSION").toString());
		assertEquals("10", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("0", list_segments1.get(0).get("GENERATION").toString());
		assertEquals(
				String.format("%d", 10 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_COMPACTED").toString());
		assertEquals(
				String.format("%d", 10 * TMETestUtil.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_UNCOMPACTED")
						.toString());

		List<LocalDeletionJob> unSynchedDeletionJobs = DeletionJobManager
				.getInstance().getNotSynchronizedDeletionJobs();
		assertEquals(0, unSynchedDeletionJobs.size());

		clearMemoryQueue();
		clearDatabase();
	}

	@Test
	public void testBiometricsDeletion_NoFindInMemory() {
		long batchJobId = 15462;
		setMockMethod();
		clearMemoryQueue();
		clearDatabase();

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 15);

		DeleteResultRequest result = deletionBean.deleteTemplate(batchJobId,
				deleteReferenceId);

		assertNull(result);

		clearMemoryQueue();
	}

	@Test
	public void testBiometricsDeletion_ErrorRequest() {
		long batchJobId = 62;
		setMockMethod();
		clearMemoryQueue();

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%025d", 15);

		preparelocalDeleteJob(batchJobId, deleteReferenceId);

		DeleteResultRequest result = deletionBean.deleteTemplate(batchJobId,
				deleteReferenceId);

		assertNotNull(result);
		assertEquals(1, result.getBusinessMessageCount());
		ByteString message = result.getBusinessMessageList().get(0);

		try {
			CPBBusinessMessage bMessage = CPBBusinessMessage.parseFrom(message);
			assertEquals(EnrollErrorMessage.DELETE_REFERENCEID_LENGTH_INCORRECT
					.getErrorCode(), bMessage.getResponse().getStatus());
		} catch (InvalidProtocolBufferException e) {
			fail();
		}

		clearMemoryQueue();
	}

	private void preparePersonBiometics(int count) {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(100, "
				+ "'PERSON_TEMPLATE_SIZE', '"
				+ TMETestUtil.PERSON_TEMPLATE_SIZE + "')");
		for (int i = 1; i <= count; i++) {
			String sql = "INSERT INTO person_biometrics( biometrics_id, reference_id,"
					+ " biometric_data, biometric_data_len, date_added ) VALUES("
					+ i
					+ ",'"
					+ (referenceId + String.format("%05d", i))
					+ "', '0', "
					+ TMETestUtil.PERSON_TEMPLATE_SIZE
					+ ", systimestamp)";
			jdbcTemplate.execute(sql);
		}
	}

	private void prepareSegment(int count, int lastRecordCount) {
		int startId = -1;
		int endId = -1;
		int segLength = -1;
		for (int i = 1; i <= count; i++) {
			startId = ((i - 1) * 15 + 1);
			if (i == count) {
				endId = startId + lastRecordCount - 1;
			} else {
				endId = (i * 15);
			}
			segLength = (endId - startId + 1)
					* TMETestUtil.PERSON_TEMPLATE_SIZE;
			String segSQL = "INSERT INTO SEGMENTS(SEGMENT_ID, BIO_ID_START, BIO_ID_END,"
					+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, GENERATION,"
					+ " BINARY_LENGTH_UNCOMPACTED ) VALUES ( "
					+ i
					+ ", "
					+ startId
					+ ","
					+ endId
					+ ","
					+ segLength
					+ ","
					+ (endId - startId + 1) + ", 0,0," + segLength + ")";
			jdbcTemplate.execute(segSQL);

			String segDetailSQL = "INSERT INTO SEGMENT_VERSION_DETAIL(SEGMENT_ID,VERSION,"
					+ " BIO_ID_START, BIO_ID_END,UPDATE_TS,RECORD_COUNT, CHANGE_TYPE) VALUES ( "
					+ i
					+ ", 0,"
					+ startId
					+ ","
					+ endId
					+ ",systimestamp,"
					+ (endId - startId + 1) + ", 0)";
			jdbcTemplate.execute(segDetailSQL);
		}
	}

	private void clearDatabase() {
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
	}
}