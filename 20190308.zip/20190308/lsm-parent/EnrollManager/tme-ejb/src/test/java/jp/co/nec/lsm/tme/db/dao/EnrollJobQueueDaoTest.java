package jp.co.nec.lsm.tme.db.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.procedure.ExctractJobInsertProcedure;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollJobQueueDaoTest {
	@Resource
	private DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	
	@EJB
	EnrollJobQueueDao enrollJobQueueDao;

	private String requestId = "RequestId901234567890123456789.+-*/=";
	private String referenceId = "ReferenceId1234567890123456789.+-*/=";

	@Before
	public void setUp() {
		prepareDeleteConcerningTable();
	}

	@After
	public void tearDown() {
		prepareDeleteConcerningTable();
	}

	/**
	 * clear concerning table in database for testing
	 */
	private void prepareDeleteConcerningTable() {
		jdbcTemplate.execute("delete from ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete from ENROLL_BATCH_JOB_QUEUE");
	}

	@Test
	public void testInsertExctractJobQueue_Param_1() {

		enrollJobQueueDao.insertExctractJobQueue(null);

		// assert result
		List<Map<String, Object>> recordList = jdbcTemplate
				.queryForList("select * from ENROLL_JOB_QUEUE order by JOB_INDEX");

		assertEquals(0, (int) recordList.size());
	}

	@Test
	public void testInsertExctractJobQueue_Param_2() {

		enrollJobQueueDao
				.insertExctractJobQueue(new ArrayList<EnrollJobQueueEntity>());

		// assert result
		List<Map<String, Object>> recordList = jdbcTemplate
				.queryForList("select * from ENROLL_JOB_QUEUE order by JOB_INDEX");

		assertEquals(0, (int) recordList.size());
	}

	@Test
	public void testUpdateExctractJobQueue_Param_1() {
		long batchJobId = 3410;
		int jobCount = 10;
		// prepare test data
		List<EnrollJobQueueEntity> extractJobObjectList = prepareEnrollJobQueueEntityList(
				batchJobId, jobCount);
		insertDate(extractJobObjectList, batchJobId);

		enrollJobQueueDao.updateExctractJobQueue(null);

		// assert result
		List<Map<String, Object>> recordList = jdbcTemplate
				.queryForList("select * from ENROLL_JOB_QUEUE order by JOB_INDEX");

		assertEquals(jobCount, recordList.size());
		for (int i = 0; i < jobCount; i++) {
			Map<String, Object> record = recordList.get(i);
			assertEquals(batchJobId, Long.parseLong(record.get("BATCHJOB_ID")
					.toString()));
			assertEquals(i + 1, Integer.parseInt(record.get("JOB_INDEX")
					.toString()));
			assertEquals(requestId, record.get("REQUEST_ID").toString());
			assertEquals(referenceId, record.get("REFERENCE_ID").toString());
			assertNull(record.get("ERROR_CODE"));
			assertNull(record.get("ERROR_MESSAGE"));
			assertEquals(ReturnCode.NotUsed.ordinal(), Integer.parseInt(record
					.get("RETURN_CODE").toString()));
			byte[] data = (byte[]) record.get("REQUEST");
			byte[] data2 = new byte[] { (byte) (i + 1), 1, 2, 3, 4, 5, 6, 7, 8,
					9 };
			for (int j = 0; j < data.length; j++) {
				assertEquals(data2[j], data[j]);
			}

			assertNull(record.get("RESPONSE"));
		}

	}

	@Test
	public void testUpdateExctractJobQueue_Param_2() {
		long batchJobId = 7210;
		int jobCount = 10;
		// prepare test data
		List<EnrollJobQueueEntity> extractJobObjectList = prepareEnrollJobQueueEntityList(
				batchJobId, jobCount);
		insertDate(extractJobObjectList, batchJobId);

		enrollJobQueueDao
				.updateExctractJobQueue(new ArrayList<EnrollJobQueueEntity>());

		// assert result
		List<Map<String, Object>> recordList = jdbcTemplate
				.queryForList("select * from ENROLL_JOB_QUEUE order by JOB_INDEX");

		assertEquals(jobCount, recordList.size());
		for (int i = 0; i < jobCount; i++) {
			Map<String, Object> record = recordList.get(i);
			assertEquals(batchJobId, Long.parseLong(record.get("BATCHJOB_ID")
					.toString()));
			assertEquals(i + 1, Integer.parseInt(record.get("JOB_INDEX")
					.toString()));
			assertEquals(requestId, record.get("REQUEST_ID").toString());
			assertEquals(referenceId, record.get("REFERENCE_ID").toString());
			assertNull(record.get("ERROR_CODE"));
			assertNull(record.get("ERROR_MESSAGE"));
			assertEquals(ReturnCode.NotUsed.ordinal(), Integer.parseInt(record
					.get("RETURN_CODE").toString()));
			byte[] data = (byte[]) record.get("REQUEST");
			byte[] data2 = new byte[] { (byte) (i + 1), 1, 2, 3, 4, 5, 6, 7, 8,
					9 };
			for (int j = 0; j < data.length; j++) {
				assertEquals(data2[j], data[j]);
			}

			assertNull(record.get("RESPONSE"));
		}
	}

	private void insertDate(List<EnrollJobQueueEntity> extractJobObjectList,
			long batchJobId) {
		jdbcTemplate.execute("insert into ENROLL_BATCH_JOB_QUEUE(BATCHJOB_ID, "
				+ "BATCHJOB_STATUS, ENQUEUE_TS) values(" + batchJobId + ", "
				+ EnrollBatchJobStatus.QUEUED.getIntValues()
				+ ", TO_DATE('29-02-2012 12:00:00', 'DD-MM-YYYY HH24.MI.SS'))");

		ExctractJobInsertProcedure insertProcedure = new ExctractJobInsertProcedure(
				dataSource);
		insertProcedure.execute(extractJobObjectList);
	}

	/**
	 * 
	 * @param batchJobId
	 * @param jobCount
	 * @return
	 */
	private List<EnrollJobQueueEntity> prepareEnrollJobQueueEntityList(
			long batchJobId, int jobCount) {
		List<EnrollJobQueueEntity> extractJobObjectList = new ArrayList<EnrollJobQueueEntity>();

		for (int i = 1; i <= jobCount; i++) {
			EnrollJobQueueEntity extractJobEntity = new EnrollJobQueueEntity();

			extractJobEntity.setBatchJobId(batchJobId);
			extractJobEntity.setJobIndex(i);
			extractJobEntity.setRequestId(requestId);
			extractJobEntity.setReferenceId(referenceId);

			extractJobEntity.setReturnCode(ReturnCode.NotUsed);
			extractJobEntity.setRequest(new byte[] { (byte) i, 1, 2, 3, 4, 5,
					6, 7, 8, 9 });

			extractJobObjectList.add(extractJobEntity);
		}

		return extractJobObjectList;
	}
}
