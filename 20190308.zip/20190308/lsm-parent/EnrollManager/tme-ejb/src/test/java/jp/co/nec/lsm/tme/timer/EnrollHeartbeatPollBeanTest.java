package jp.co.nec.lsm.tme.timer;

import static org.junit.Assert.assertEquals;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

/**
 * 
 * Test Class for EnrollPollBean Test Case Test [testEnrollPollBean] 1 - prepare
 * data for EnrollPollBean 2 - timeoutMuByHeartBeat 3 - poll
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollHeartbeatPollBeanTest {

	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	@EJB
	private EnrollHeartbeatPollBean pollBean;
	private TransactionManagerHelper tmHelper;

	@Resource
	private EnrollSystemConfigDao systemConfigDao;

	// @Resource
	// private EnrollSystemConfigDao systemConfigDao;

	/**
	 * clear disturbing data for testing
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		deletetransaction_managers();
		preparetransaction_managers();
	}

	@PostConstruct
	public void init() {
		tmHelper = new TransactionManagerHelper(manager, dataSource, TMType.TME);
	}

	public void deletetransaction_managers() {
		String deletetransaction_managers = "delete from TRANSACTION_MANAGERS";
		jdbcTemplate.execute(deletetransaction_managers);
		jdbcTemplate.execute("commit");
	}

	public void preparetransaction_managers() {
		String strinserttransaction_managers = "insert into TRANSACTION_MANAGERS(TM_ID ,"
				+ "    UNIQUE_ID,"
				+ "    STATE,"
				+ "    CONTACT_URL,"
				+ "    LAST_HEARTBEAT_TS,"
				+ "    LAST_POLL_TS,VERSION) values(?,?,?,?,sysdate,sysdate,?)";
		for (int i = 1; i < 6; i++) {
			String uniqueId = "192.168.100." + (184 + i);
			String contact_url;
			if (i > 2 && i < 4) {
				contact_url = "http://" + uniqueId + ":8080/identifymanager";
			} else if (i > 4) {
				contact_url = "http://" + uniqueId + ":8080/aggregationmanager";
			} else {
				contact_url = "http://" + uniqueId + ":8080/enrollmanager";
			}
			String version = "2.0.1.1";
			jdbcTemplate.update(strinserttransaction_managers, new Object[] {
					50 * i, uniqueId, "TIMED_OUT", contact_url, version });
		}
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testPoll() {
		String sql = "select * from TRANSACTION_MANAGERS where UNIQUE_ID = '"
				+ getTMEUniqueId() + "'";
		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity enrollTransactionManaget = tmHelper
				.createOrLookupVersion(now, "2.3.0");
		enrollTransactionManaget.setState(TmState.EXITED);
		manager.merge(enrollTransactionManaget);
		manager.flush();
		List<Map<String, Object>> dbData = jdbcTemplate.queryForList(sql);
		assertEquals(1, dbData.size());
		Map<String, Object> tmeMap = dbData.get(0);

		assertEquals(TmState.EXITED.toString(), tmeMap.get("STATE").toString());

		pollBean.poll();
		dbData = jdbcTemplate.queryForList(sql);
		assertEquals(1, dbData.size());
		tmeMap = dbData.get(0);

		assertEquals(TmState.WORKING.toString(), tmeMap.get("STATE").toString());

	}

	class TestThread extends Thread {
		public void run() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Get an ip-address of TME from pid.tm.properties.
	 * 
	 * If the ip-address is not gotten from properties, it must be missing the
	 * default setting. Therefore It is not necessary to send SM and get the
	 * real ip of NIC.
	 * 
	 * @return
	 */
	private String getTMEUniqueId() {
		String mmUniqueId = systemConfigDao.getTMEIpAddress();
		if (mmUniqueId == null) {

			mmUniqueId = Constants.DEFAULT_TME_UNIQUE_ID;

			// basically, we prefer to use numeric IP address but will use
			// hostname otherwise.
			// worst-case scenario we use the default above.
			try {
				mmUniqueId = InetAddress.getLocalHost().getHostName();

				Enumeration<NetworkInterface> interfaces = java.net.NetworkInterface
						.getNetworkInterfaces();
				while (interfaces.hasMoreElements()) {
					NetworkInterface ni = interfaces.nextElement();
					// log.debug("Interface: " + ni.getDisplayName());
					Enumeration<InetAddress> addrs = ni.getInetAddresses();
					while (addrs.hasMoreElements()) {
						InetAddress addr = addrs.nextElement();
						// log.debug("Address: " + addr.getHostAddress());
						if (!addr.isLoopbackAddress()) {
							mmUniqueId = addr.getHostAddress();
						}
					}
				}
			} catch (SocketException e) {
				throw new EnrollRuntimeException("SocketException", e);
			} catch (UnknownHostException e) {
				throw new EnrollRuntimeException("UnknownHostException", e);
			}
		}
		return mmUniqueId + Constants.COLON + systemConfigDao.getTMEWebPort();
	}
}
