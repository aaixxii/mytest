package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tme.core.segment.loadbalance.SegmentLoadBalanceManager;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

/**
 * SegmentDeployServlet
 */
public class SegmentDeployServlet extends AbstractTMServlet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 7422725454201494675L;
	private static Logger log = LoggerFactory
			.getLogger(SegmentDeployServlet.class);

	@EJB
	private SegmentLoadBalanceManager segmentLoadBlance;

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		if (log.isInfoEnabled()) {
			log.info("Call servlet segment load blance deploy..");
		}

		// call segment load balance
		try {
			segmentLoadBlance.excuteSLB();
		} catch (EnrollRuntimeException e) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					e.getMessage(), e);
			return;
		}

		String output = "Call servlet segment load blance deploy sucessfully ..";
		if (log.isInfoEnabled()) {
			log.info(output);
		}

		writeResultToResponse(output, res);
	}

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
}
