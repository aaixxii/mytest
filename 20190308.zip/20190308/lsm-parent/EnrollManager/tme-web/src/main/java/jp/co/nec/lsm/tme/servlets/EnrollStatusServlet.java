package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj
 * @web.servlet name="EnrollStatusServlet"
 * @web.servlet-mapping url-pattern="/Status"
 */
public class EnrollStatusServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -192181913511070758L;

	private static final Logger log = LoggerFactory
			.getLogger(EnrollStatusServlet.class);

	/**
	 * 
	 */
	public void init() throws ServletException {

	}

	/**
	 * Get enroll batch job status
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		printLogMessage("start public function doGet()..");

		EnrollBatchJobManager manager = EnrollBatchJobManager.getInstance();
		res.setContentType("text/plain");
		res.getWriter().println(manager.getSummary());

		printLogMessage("end public function doGet()..");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
