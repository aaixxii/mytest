package jp.co.nec.lsm.tme.servlets;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.proto.control.EnterResponseProto.EnterResponse;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tme.core.gmvapi.request.validator.EnterRequestValidator;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollStatusManagerBean;

/**
 * @author mozj
 * @web.servlet name="EnterServletRemote"
 * @web.servlet-mapping url-pattern="/Enter"
 */
public class EnrollEnterServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7892006755640778233L;
	private static final Logger log = LoggerFactory
			.getLogger(EnrollEnterServlet.class);
	
	@EJB
	private EnrollStatusManagerBean statusManager;

	public void init() throws ServletException {

	}

	/**
	 * 
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException {
		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		EnterRequest enterRequest = null;
		try {
			enterRequest = EnterRequest.parseFrom(req.getInputStream());

			validateRequest(enterRequest);
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					"parse EnterRequest object error", ex);
			return;
		}

		try {
			EnterResponse enterResponse = statusManager.enter(enterRequest);

			// return HTTP-200
			res.setContentType("application/octet-stream");
			res.setContentLength(enterResponse.getSerializedSize());
			res.setStatus(HttpServletResponse.SC_OK);
			enterResponse.writeTo(res.getOutputStream());
			res.flushBuffer();
		} catch (Exception ex) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"enroll enter error.", ex);
			return;
		}
		stopWatch.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_ENTER_SERVLET_TME,
				LogConstants.FUNCTION_DO_POST, stopWatch.getTime());

	}

	/**
	 * validate all data in Enter Request whether there are correct.
	 * 
	 * @param extractResultRequest
	 *            Extract Result request
	 * @return
	 */
	private void validateRequest(EnterRequest enterRequest) {
		printLogMessage("start private function validateRequest().");

		ValidationResult validationResult = EnterRequestValidator
				.validate(enterRequest);
		if (validationResult.hasErrors()) {
			String massege = "EnterRequest has some error.";
			log.error(massege);
			throw new EnrollRuntimeException(massege);
		}

		// all data in enroll request are correct.
		printLogMessage("end private function validateRequest().");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
