package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollBatchJobsSnapshotsBean;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShot;

public class EnrollBatchJobsSnapshotsSevlet extends AbstractTMServlet {
	private static Logger log = LoggerFactory
			.getLogger(EnrollBatchJobsSnapshotsSevlet.class);

	private static final long serialVersionUID = 7649511399208047845L;

	private static final String JSP_PATH_NAME = "/jsp/EnrollSnapShot.jsp";
	private static final String DEFAUL_LIMIT_COUNT = "100";
	private static final String PARAMETER_ATTR_NAME = "EnrollBatchJobSnapShot";

	@EJB
	private EnrollBatchJobsSnapshotsBean  batchJobsSnapshots;

	/**
	 * Initialization
	 */
	public void init() throws ServletException {
	}

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		if (log.isInfoEnabled()) {
			log.info("Output the memory job status.");
		}

		EnrollBatchJobSnapShot jobSnapShot = batchJobsSnapshots
				.GetBatchJobSnapShot(DEFAUL_LIMIT_COUNT);

		req.setAttribute(PARAMETER_ATTR_NAME, jobSnapShot);

		try {
			forward(req, res);
		} catch (ServletException e) {
			String msg = "ServletException occured while Jump to Jsp -> "
					+ JSP_PATH_NAME;
			log.info(msg, e);
			throw new EnrollRuntimeException(msg, e);
		} catch (IOException e) {
			String msg = "IOException occured while Jump to Jsp -> "
					+ JSP_PATH_NAME;
			log.info(msg, e);
			throw new EnrollRuntimeException(msg, e);
		}
	}

	private void forward(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		RequestDispatcher dispather = req.getRequestDispatcher(JSP_PATH_NAME);
		dispather.forward(req, res);
	}

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doPost(req, res);
	}
}
