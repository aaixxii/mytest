package jp.co.nec.lsm.tme.listener;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.constants.TmState;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class ShutDownManagerListenerTest {
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;
	@Resource
	ShutDownManagerListener shutDownManager;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Test
	public void testShutDown() {
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		String sql = "select * from TRANSACTION_MANAGERS";
		shutDownManager.contextInitialized(null);
		shutDownManager.contextDestroyed(null);

		List<Map<String, Object>> dbData = jdbcTemplate.queryForList(sql);
		assertEquals(1, dbData.size());
		Map<String, Object> tmeMap = dbData.get(0);

		assertEquals(TmState.EXITED.toString(), tmeMap.get("STATE").toString());
	}
}
