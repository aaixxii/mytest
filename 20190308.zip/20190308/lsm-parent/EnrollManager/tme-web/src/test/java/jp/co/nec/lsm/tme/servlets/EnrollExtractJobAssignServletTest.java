package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import jp.co.nec.lsm.proto.extract.ExtractJobRequestProto.ExtractJobRequest;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.service.pojo.EnrollExtractJobAssignServiceBean;
import mockit.Mock;
import mockit.MockUp;

public class EnrollExtractJobAssignServletTest {

	EnrollExtractJobAssignServlet assignSevlet;
	EnrollBatchJobManager queueManage;

	@Before
	public void setUp() throws ServletException {
		assignSevlet = new EnrollExtractJobAssignServlet();
		assignSevlet.init();

		cleanMemoryQueue();
	}

	@After
	public void tearDown() {
		cleanMemoryQueue();
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 */
	private void prepareEnrollBatchJobQueue(long batchJobId, int jobCount) {
		// clear Memory Queue and MATCH_UNITS table
		cleanMemoryQueue();

		// 1 - prepare EnrollBatchJob/ExtractJobRequest For test
		queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = WebTestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);
		// 2 - call add, add LocalEnrollBatchJob to database
		queueManage.addEnrollBatchJob(enrollBatchJob);

	}

	private ExtractJobRequest prepareRequest(int gmvId, int extractJobCount) {
		ExtractJobRequest.Builder request = ExtractJobRequest.newBuilder();
		request.setGmvId(gmvId);
		request.setMaxExtractJob(extractJobCount);
		return request.build();
	}

	@Test
	public void testDoPost_Success() throws ServletException, IOException {
		long batchJobId = 4513;
		int jobCount = 13;
		int assignedCount = jobCount / 2;
		int muId = 13;

		setMockMethod();

		prepareEnrollBatchJobQueue(batchJobId, jobCount);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExtractJobRequest request = prepareRequest(muId, assignedCount);

		byte[] context = request.toByteArray();
		req.setContent(context);

		assignSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 < resp.getContentLength());

		cleanMemoryQueue();
	}

	@Test
	public void testDoPost_NO_CONTENT() throws ServletException, IOException {
		int jobCount = 13;
		int assignedCount = jobCount / 2;
		int muId = 13;

		setMockMethod();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExtractJobRequest request = prepareRequest(muId, assignedCount);

		byte[] context = request.toByteArray();
		req.setContent(context);

		assignSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_NO_CONTENT, resp.getStatus());
		assertTrue(0 == resp.getContentLength());

		cleanMemoryQueue();
	}

	@Test
	public void testDoPost_InternalError() throws ServletException, IOException {

		cleanMemoryQueue();

		new MockUp<EnrollExtractJobAssignServiceBean>() {
			@Mock
			private void printLogMessage(String logMessage) {
				throw new RuntimeException();
			}
		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		ExtractJobRequest request = prepareRequest(12, 23);

		byte[] context = request.toByteArray();
		req.setContent(context);

		assignSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, resp
				.getStatus());
		assertEquals(120, resp.getContentLength());

		cleanMemoryQueue();
	}

	@Test
	public void testDoPost_BadRequest() throws ServletException, IOException {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		byte[] context = new byte[] { 13, 46, 2, 0, 1, 4, 63, 13, 0 };
		req.setContent(context);

		assignSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(124, resp.getContentLength());
	}

	@Test
	public void testDoPost_NoContent() throws ServletException, IOException {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		assignSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertEquals(0, resp.getContentLength());
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		new MockUp<EnrollExtractJobAssignServiceBean>() {
			@Mock
			private void printLogMessage(String logMessage) {
				return;
			}
		};
	}
}
