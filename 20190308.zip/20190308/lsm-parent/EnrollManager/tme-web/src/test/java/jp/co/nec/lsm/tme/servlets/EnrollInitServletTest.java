package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.sender.AbstractEventSender;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollInitServletTest {

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private TransactionManagerHelper tmHelper;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	protected JdbcTemplate jdbcTemplate;

	@Resource
	EnrollInitServlet initServlet;

	@Before
	public void setUp() {
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}

		tmHelper = new TransactionManagerHelper(manager, dataSource,TMType.TME);
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Test
	public void testInitializeTME() throws Exception {

		new MockUp<AbstractEventSender>() {
			@Mock
			public void convertAndSend(Event message) {
				return;
			}
		};

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

		initServlet.init();

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();
		initServlet.service(req, resp);

		testSetStartupTime();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testSetStartupTime]<br/>
	 * 1 - query database to get data<br/>
	 * 2 - assert concerning information<br/>
	 */
	public void testSetStartupTime() {

		// 1 - query database to get data
		TransactionManagerEntity tm = tmHelper.createOrLookup(DateUtil
				.getCurrentDate());

		// 2 - assert concerning information
		assertNotNull(tm);
		assertNotNull(tm.getLastHeartbeatTs());
		assertNotNull(tm.getLastPollTs());
		assertEquals(TmState.WORKING, tm.getState());
	}
}
