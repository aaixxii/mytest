package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MuSegMapHelper;
import jp.co.nec.lsm.tme.core.segment.loadbalance.SegmentLoadBalanceManager;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentDeployServletTest {
	@Resource
	private SegmentDeployServlet servlet;
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private MuSegMapHelper muSegMapHelper;

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		// clear DataBase
		clearDataBase();
		muSegMapHelper = new MuSegMapHelper(manager);
	}

	@Test
	public void test_WithSlbSucessfully() throws ServletException, IOException {
		try {
			// clear database
			clearDataBase();
			updateDataBase("TRUE", 2, 2, 2, 2);

			// prepare MatchUnit/Segment/MuSegment For test
			prepareInsertMatchUnit(3, 2);
			prepareInsertSegment(4);
			prepareInsertMuSegment();

			MockHttpServletRequest req = new MockHttpServletRequest();
			MockHttpServletResponse res = new MockHttpServletResponse();
			servlet.doPost(req, res);

			// assert result
			// assert MuSegment cord for USC
			List<MuSegmentEntity> uscSegMaps = muSegMapHelper
					.findMuSegMapOfMU();
			assertEquals(8, uscSegMaps.size());
			// assert MuSegment cord for DM
			List<MuSegmentEntity> dmSegMaps = muSegMapHelper.findMuSegMapOfDM();
			assertEquals(8, dmSegMaps.size());

			Assert.assertEquals(HttpServletResponse.SC_OK, res.getStatus());
			Assert.assertEquals(
					"Call servlet segment load blance deploy sucessfully ..",
					res.getContentAsString());
		} finally {
			// clear database to avoid disturbing
			clearDataBase();
		}
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		new MockUp<SegmentLoadBalanceManager>() {
			@Mock
			public void excuteSLB() {
				throw new EnrollRuntimeException("test throw DeployException");
			}
		};
	}

	@Test
	public void test_WithSlbError() throws ServletException, IOException {
		try {
			setMockMethod();
			// clear database
			clearDataBase();
			updateDataBase("TRUE", 2, 2, 2, 2);
			prepareInsertMatchUnit(3, 2);
			prepareInsertSegment(4);
			prepareInsertMuSegment();

			MockHttpServletRequest req = new MockHttpServletRequest();
			MockHttpServletResponse res = new MockHttpServletResponse();
			servlet.doGet(req, res);

			Assert.assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					res.getStatus());

		} finally {
			// clear database to avoid disturbing
			clearDataBase();
		}
	}

	private void clearDataBase() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	/**
	 * update SYSTEM_CONFIG table
	 */
	private void updateDataBase(String enable, int minDM, int minUSC,
			int dmRedundancy, int uscRedundancy) {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'LOAD_BALANCER.USC_MIN_REDUNDANCY','"
						+ uscRedundancy + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (2,'LOAD_BALANCER.DM_MIN_REDUNDANCY','"
						+ dmRedundancy + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (3,'SEGMENT_LOAD_BALANCER.ENABLED','"
						+ enable + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (4,'SEGMENT_LOAD_BALANCER.MIN_USCS_FOR_SLB','"
						+ minUSC + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (5,'SEGMENT_LOAD_BALANCER.MIN_DMS_FOR_SLB','"
						+ minDM + "')");


		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (6,'LOAD_BALANCER.USC_DEFAULT_REDUNDANCY','"
						+ uscRedundancy + "')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (7,'LOAD_BALANCER.USC_MAX_REDUNDANCY','"
						+ (uscRedundancy + 1) + "')");	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert MatchUnit into
	 * database
	 */
	private void prepareInsertMatchUnit(int uscCount, int dmCount) {
		for (int i = 1; i <= uscCount; i++) {
			jdbcTemplate
					.execute("insert into match_units "
							+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
							+ "(" + i + ", 1, 'WORKING', 2, 1, 1, 1)");
		}

		for (int i = uscCount + 1; i <= dmCount + uscCount; i++) {
			jdbcTemplate
					.execute("insert into match_units "
							+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
							+ "(" + i + ", 2, 'WORKING', 0, 1, 2, 1)");
		}
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert Segment into
	 * database
	 */
	private void prepareInsertSegment(int count) {
		for (int i = 1; i <= count; i++) {
			jdbcTemplate.execute("insert into SEGMENTS(SEGMENT_ID,"
					+ " BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED,"
					+ " RECORD_COUNT, VERSION, GENERATION, "
					+ "BINARY_LENGTH_UNCOMPACTED) values(" + i
					+ ", 100, 100, 100, 100, 100,100,100)");
		}
	}

	/**
	 * prepare data for EnrollSegmentSyncServiceBean insert MuSegment into
	 * database
	 */
	private void prepareInsertMuSegment() {
		// add MuSegment cord for USC
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(2,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(3,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(1,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(3,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(1,3,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(2,3,0)");

		// add MuSegment cord for DM
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(4,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(5,1,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(4,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(5,2,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(4,3,0)");
		jdbcTemplate.execute("insert into MU_SEGMENTS "
				+ "(MU_ID,SEGMENT_ID,RANK) values" + "(5,3,0)");
	}

}
