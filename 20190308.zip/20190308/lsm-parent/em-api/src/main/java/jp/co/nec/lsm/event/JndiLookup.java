package jp.co.nec.lsm.event;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
public class JndiLookup {
	/** log instance **/
	private final static Logger log = LoggerFactory.getLogger(JndiLookup.class);
	/** JNDI Object cache **/
	private static Map<String, Object> jndiCache = new ConcurrentHashMap<String, Object>();

	/**
	 * 
	 * @param jndiName
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T lookUp(String jndiName, Class<T> clazz) {
		InitialContext c = null;
		try {
			Object object = jndiCache.get(jndiName);
			if (object == null) {
				c = new InitialContext();
				object = c.lookup(jndiName);
				jndiCache.put(jndiName, object);
			}

			if (object == null) {
				String errorMessage = "the jndi look up object is "
						+ "null. jndi name:" + jndiName;
				log.error(errorMessage);
				throw new RuntimeException(errorMessage);
			}
			return (T) object;
		} catch (NamingException ex) {
			String errorMessage = "NamingException: jndiName:" + jndiName;
			log.error(errorMessage);
			throw new RuntimeException(errorMessage, ex);
		} finally {
			if (c != null) {
				try {
					c.close();
				} catch (NamingException e) {
					log.error("NamingException", e);
				}
			}
		}
	}
}
