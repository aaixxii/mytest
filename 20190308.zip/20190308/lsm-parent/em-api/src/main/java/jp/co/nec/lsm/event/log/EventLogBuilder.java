package jp.co.nec.lsm.event.log;

import java.text.SimpleDateFormat;

import jp.co.nec.lsm.tm.common.util.DateUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jimy <br>
 * EventLogBuilder to build the event log message
 */
public class EventLogBuilder {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(EventLogBuilder.class);

	/**
	 * output event
	 * 
	 * @param eventName
	 *            eventName
	 * @param batchJobId
	 *            batchJobId
	 * @param keyValues
	 *            keyValues format
	 */
	public static void eventOutput(String eventName, long batchJobId,
			String... keyValues) {
		// check log level due to log level is INFO
		if (log.isInfoEnabled()) {
			StringBuilder sb = new StringBuilder();
			sb.append("CATEGORY===");
			sb.append("EVENT");
			sb.append("<>EVENT===");
			sb.append(eventName);
			sb.append("<>BATCH_JOB_ID===");
			sb.append(batchJobId);
			sb.append("<>TIME_STAMP===");
			SimpleDateFormat sdf = new SimpleDateFormat(
					"yyyy/MM/dd HH:mm:ss.SSS");
			sb.append(sdf.format(DateUtil.getCurrentDate()));
			if (keyValues == null) {
				log.info(sb.toString());
				return;
			}
			int index = 0;
			for (String keyValue : keyValues) {
				if (index++ % 2 == 0) {
					sb.append("<>");
					sb.append(keyValue);
					sb.append("===");
				} else {
					sb.append(keyValue);
				}
			}
			log.info(sb.toString());
		}
		return;
	}
}
